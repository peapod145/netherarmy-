package cn.blockforge.generated.netherarmy;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 灵魂土偶装备界面：底板、槽位框、实体预览区全部沿用原版马（驴）界面
 * （{@code HorseInventoryScreen}）的做法——面板用 {@code horse.png}，
 * 土偶自身的 10 个格子用原版背包里那颗标准槽位框画在对应坐标上，
 * 中间是跟随鼠标的实体预览，下半区是玩家背包与快捷栏。
 */
public final class SoulsandFigurineScreen extends AbstractContainerScreen<SoulsandFigurineMenu> {
    private static final ResourceLocation HORSE_BACKGROUND =
            ResourceLocation.withDefaultNamespace("textures/gui/container/horse.png");
    private static final ResourceLocation INVENTORY_TEXTURES =
            ResourceLocation.withDefaultNamespace("textures/gui/container/inventory.png");
    /** 标准槽位框：玩家背包左上角那一格 (8,84) 的框在贴图里占 (7,83) 起 18×18。 */
    private static final int WELL_U = 7;
    private static final int WELL_V = 83;
    private static final int WELL_SIZE = 18;
    /** 预览区：原版马界面是 x=26..78 / y=18..70，右边界让开主手副手那两格。 */
    private static final int PREVIEW_LEFT = 26;
    private static final int PREVIEW_TOP = 14;
    private static final int PREVIEW_RIGHT = 74;
    private static final int PREVIEW_BOTTOM = 70;
    /** 人形模型：比马（17）大、比玩家背包（30）小一点，留出手持武器的宽度。 */
    private static final int PREVIEW_SCALE = 26;
    /**
     * 模式按钮：马界面右侧 2×2 物品栏正下方那条空带。物品栏槽位框最低到 y=52，
     * 左边主手/副手槽框占 x=76..93、y=43..78，所以按钮只能从 x=98 起、y=54 起，
     * 到面板右侧内边 x=165 为止——68×16 是既贴齐右边框、又不压任何槽位的最小尺寸，
     * 刚好容下"模式：保镖"和 "Mode: Escort"。
     */
    private static final int MODE_BUTTON_LEFT = 98;
    private static final int MODE_BUTTON_TOP = 54;
    private static final int MODE_BUTTON_WIDTH = 68;
    private static final int MODE_BUTTON_HEIGHT = 16;

    private float xMouse;
    private float yMouse;
    private Button modeButton;

    public SoulsandFigurineScreen(SoulsandFigurineMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        // 左侧一整列盔甲格占掉了原版标题位置，标题与“物品栏”文字都挪到预览区这一列
        this.titleLabelX = PREVIEW_LEFT;
        this.titleLabelY = 4;
        this.inventoryLabelX = PREVIEW_LEFT;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void init() {
        super.init();
        int width = this.font.width(this.title);
        int boxWidth = PREVIEW_RIGHT - PREVIEW_LEFT;
        this.titleLabelX = width <= boxWidth
                ? PREVIEW_LEFT + (boxWidth - width) / 2
                : PREVIEW_LEFT - (width - boxWidth) / 2;
        this.modeButton = this.addRenderableWidget(Button.builder(
                        modeLabel(SoulsandFigurineMode.DEFAULT), button -> this.cycleMode())
                .pos(this.leftPos + MODE_BUTTON_LEFT, this.topPos + MODE_BUTTON_TOP)
                .size(MODE_BUTTON_WIDTH, MODE_BUTTON_HEIGHT)
                .build());
        this.refreshModeButton();
    }

    private static Component modeLabel(SoulsandFigurineMode mode) {
        return Component.translatable("container.netherarmy.soulsand_figurine.mode_button", mode.shortName());
    }

    /** 按一次换一档：真正的切换在服务端做，这里只把请求发过去。 */
    private void cycleMode() {
        SoulsandFigurine figurine = this.menu.getFigurine();
        if (figurine != null) {
            PacketDistributor.sendToServer(new SoulsandFigurineModePayload(figurine.getId()));
        }
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        this.refreshModeButton();
    }

    private SoulsandFigurineMode currentMode() {
        SoulsandFigurine figurine = this.menu.getFigurine();
        return figurine == null ? SoulsandFigurineMode.DEFAULT : figurine.getMode();
    }

    private void refreshModeButton() {
        if (this.modeButton != null) {
            this.modeButton.setMessage(modeLabel(this.currentMode()));
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int left = this.leftPos;
        int top = this.topPos;
        graphics.blit(HORSE_BACKGROUND, left, top, 0, 0, this.imageWidth, this.imageHeight);
        for (int i = 0; i < this.menu.getFigurineSlotCount(); i++) {
            Slot slot = this.menu.getSlot(i);
            if (slot.isActive()) {
                graphics.blit(INVENTORY_TEXTURES, left + slot.x - 1, top + slot.y - 1,
                        WELL_U, WELL_V, WELL_SIZE, WELL_SIZE);
            }
        }
        SoulsandFigurine figurine = this.menu.getFigurine();
        if (figurine != null && figurine.isAlive()) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(graphics,
                    left + PREVIEW_LEFT, top + PREVIEW_TOP,
                    left + PREVIEW_RIGHT, top + PREVIEW_BOTTOM,
                    PREVIEW_SCALE, 0.0625F, this.xMouse, this.yMouse, figurine);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.xMouse = mouseX;
        this.yMouse = mouseY;
        super.render(graphics, mouseX, mouseY, partialTick);
        this.renderTooltip(graphics, mouseX, mouseY);
        this.renderEmptySlotHint(graphics, mouseX, mouseY);
        this.renderModeTooltip(graphics, mouseX, mouseY);
    }

    /** 鼠标瞄到模式按钮时弹出当前模式的说明。 */
    private void renderModeTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
        if (this.modeButton == null || !this.modeButton.isMouseOver(mouseX, mouseY)) {
            return;
        }
        SoulsandFigurineMode mode = this.currentMode();
        graphics.renderComponentTooltip(this.font, List.of(
                mode.displayName(),
                mode.description().copy().withStyle(ChatFormatting.GRAY),
                Component.translatable("container.netherarmy.soulsand_figurine.mode_hint")
                        .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC)),
                mouseX, mouseY);
    }

    /** 空格子上悬停时说明这一格是干什么的（盔甲格有原版影子图标，不用提示）。 */
    private void renderEmptySlotHint(GuiGraphics graphics, int mouseX, int mouseY) {
        Slot slot = this.hoveredSlot;
        if (slot == null || slot.hasItem() || slot.index >= SoulsandFigurineMenu.FIGURINE_SLOT_COUNT) {
            return;
        }
        List<Component> lines;
        if (slot.index == SoulsandFigurineMenu.MAINHAND_SLOT) {
            lines = List.of(Component.translatable("container.netherarmy.soulsand_figurine.main_hand"));
        } else if (slot.index == SoulsandFigurineMenu.OFFHAND_SLOT) {
            lines = List.of(Component.translatable("container.netherarmy.soulsand_figurine.off_hand"));
        } else if (slot.index >= SoulsandFigurineMenu.STORAGE_SLOT_START) {
            lines = List.of(
                    Component.translatable("container.netherarmy.soulsand_figurine.storage"),
                    Component.translatable("container.netherarmy.soulsand_figurine.storage_hint")
                            .withStyle(net.minecraft.ChatFormatting.GRAY, net.minecraft.ChatFormatting.ITALIC));
        } else {
            return;
        }
        graphics.renderComponentTooltip(this.font, lines, mouseX, mouseY);
    }
}
