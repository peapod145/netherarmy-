package cn.blockforge.generated.netherarmy;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * 模组指令入口：{@code /netherarmy} 根节点。
 *
 * <p>与无头骑士（Dullahan）陷阱相关的三条指令（均限 OP 权限 2）：
 * <ul>
 *   <li>{@code /netherarmy dullahan_trap [<坐标>]}——在指定坐标（默认执行者脚下）放置一只
 *       陷阱骷髅马，与 0.01%/tick 的自然刷新走完全相同的落地代码，玩家靠近 10 格即引爆，
 *       用于自证"这一事件确实能够生成"；</li>
 *   <li>{@code /netherarmy dullahan_detonate}——引爆执行者 64 格内所有陷阱骷髅马，
 *       无需真的踩进 10 格触发圈；</li>
 *   <li>{@code /netherarmy dullahan_ambush [<坐标>]}——跳过陷阱马阶段，直接在指定坐标
 *       复刻引爆瞬间：TNT 等价爆炸 + 四名全副武装的无头骑士（锁定执行者），与陷阱引爆
 *       走同一个 {@link DullhanTrapSpawner#summonArmedRiders}。</li>
 *   <li>{@code /netherarmy advancement_check}——成就自检：逐条核对模组自带的 13 枚成就
 *       是否真的被服务端加载、父链是否完整、会落在哪个栏目，并给出现场的达成情况。
 *       成就 JSON 只要有一条父链断裂（父进度不存在），原版就会把它连同整条子链从界面上
 *       抹掉，"在栏目里找不到"多半就是这么来的，故这里专门把父链单独列出来。</li>
 * </ul>
 *
 * <p>另有独立根节点 {@code /geardle}：{@code /geardle on} 与 {@code /geardle off}
 * 手动开启/关闭"格尔多效果"——即右键使用格尔多后产生的一系列状况（凋灵骷髅阵营
 * 生物持续刷新、夜晚致盲与遮罩、背后格尔多渲染、床与重生锚失效、随机下界重生）。
 * 效果状态本身按玩家持久化（{@link GeardleHandler#APOCALYPSE_TAG}），命令只是同一
 * 状态机的手动入口：任何玩家可切换自己的；OP（权限 2）可带 {@code <玩家>} 参数
 * 指定目标。{@code /geardle on} 不判【痛苦深处】成就，该成就仍只认"使用格尔多"。</p>
 */
public final class NetherArmyCommands {
    private NetherArmyCommands() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("netherarmy")
                .then(Commands.literal("dullahan_trap")
                        .requires(source -> source.hasPermission(2))
                        .executes(context -> placeTrap(context, null))
                        .then(Commands.argument("position", Vec3Argument.vec3())
                                .executes(context -> placeTrap(context,
                                        Vec3Argument.getVec3(context, "position")))))
                .then(Commands.literal("dullahan_detonate")
                        .requires(source -> source.hasPermission(2))
                        .executes(NetherArmyCommands::detonateTrap))
                .then(Commands.literal("dullahan_ambush")
                        .requires(source -> source.hasPermission(2))
                        .executes(context -> ambush(context, null))
                        .then(Commands.argument("position", Vec3Argument.vec3())
                                .executes(context -> ambush(context,
                                        Vec3Argument.getVec3(context, "position")))))
                .then(Commands.literal("advancement_check")
                        .requires(source -> source.hasPermission(2))
                        .executes(NetherArmyCommands::checkAdvancements)));

        registerGeardle(event);
    }

    // ------------------------------------------------------------------
    // /geardle on|off —— 手动开关格尔多效果
    // ------------------------------------------------------------------

    private static void registerGeardle(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("geardle")
                .then(Commands.literal("on")
                        .executes(context -> toggleGeardle(context, true, null))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(source -> source.hasPermission(2))
                                .executes(context -> toggleGeardle(context, true, "player"))))
                .then(Commands.literal("off")
                        .executes(context -> toggleGeardle(context, false, null))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(source -> source.hasPermission(2))
                                .executes(context -> toggleGeardle(context, false, "player")))));
    }

    private static int toggleGeardle(CommandContext<CommandSourceStack> context, boolean on,
                                     String playerName) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        ServerPlayer target;
        if (playerName != null) {
            target = EntityArgument.getPlayer(context, playerName);
        } else if (source.getEntity() instanceof ServerPlayer player) {
            target = player;
        } else {
            source.sendFailure(Component.literal(
                    "/geardle 需要玩家执行者；控制台请用 /geardle on|off <玩家>。"));
            return 0;
        }
        final String name = target.getGameProfile().getName();
        if (!GeardleHandler.setApocalypse(target, on)) {
            source.sendFailure(Component.literal(name
                    + (on ? " 本来就处于格尔多效果中。" : " 本来就没有激活格尔多效果。")));
            return 0;
        }
        source.sendSuccess(() -> Component.literal((on ? "已开启" : "已关闭") + name
                + "的格尔多效果"), true);
        return 1;
    }

    private static int placeTrap(CommandContext<CommandSourceStack> context, Vec3 requested) {
        CommandSourceStack source = context.getSource();
        ServerLevel level = source.getLevel();
        Vec3 at = requested != null ? requested : source.getPosition();
        if (!DullhanTrapSpawner.spawnTrapHorseAt(level, at, level.getRandom())) {
            source.sendFailure(Component.literal("在指定坐标附近找不到可站立的地面，陷阱骷髅马未能放置。"));
            return 0;
        }
        source.sendSuccess(() -> Component.literal(String.format(
                "已在[%s]处生成无头骑士陷阱", shortPos(at))), true);
        return 1;
    }

    /** 就地引爆执行者 64 格内的陷阱骷髅马：验证"事件能生成"时无需真的走过去踩 10 格触发圈。 */
    private static int detonateTrap(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        ServerLevel level = source.getLevel();
        ServerPlayer victim = source.getEntity() instanceof ServerPlayer player ? player : null;
        int detonated = DullhanTrapSpawner.detonateNearbyTraps(level, source.getPosition(), victim);
        if (detonated == 0) {
            source.sendFailure(Component.literal("执行者 64 格内没有待引爆的无头骑士陷阱骷髅马。"));
            return 0;
        }
        source.sendSuccess(() -> Component.literal(String.format(
                "已强制引爆 %d 只无头骑士陷阱骷髅马。", detonated)), true);
        return detonated;
    }

    /** 直接复刻引爆瞬间（爆炸 + 伏击），不依赖场上存在陷阱马。 */
    private static int ambush(CommandContext<CommandSourceStack> context, Vec3 requested) {
        CommandSourceStack source = context.getSource();
        ServerLevel level = source.getLevel();
        Vec3 at = requested != null ? requested : source.getPosition();
        Vec3 center = new Vec3(at.x, Math.max(at.y, level.getMinBuildHeight() + 1), at.z);
        level.explode(null, center.x, center.y, center.z, 4.0F,
                net.minecraft.world.level.Level.ExplosionInteraction.TNT);
        ServerPlayer victim = source.getEntity() instanceof ServerPlayer player ? player : null;
        int riders = DullhanTrapSpawner.summonArmedRiders(level, center, victim, level.getRandom());
        source.sendSuccess(() -> Component.literal(String.format(
                "已在 %s 引爆无头骑士伏击：TNT 等价爆炸 + %d 名全副武装的无头骑士。",
                shortPos(center), riders)), true);
        return riders;
    }

    private static String shortPos(Vec3 at) {
        return new BlockPos(Mth.floor(at.x), Mth.floor(at.y), Mth.floor(at.z)).toShortString();
    }

    // ------------------------------------------------------------------
    // /netherarmy advancement_check —— 成就自检
    // ------------------------------------------------------------------

    /** 模组自带的 13 枚成就（配方解锁进度不算在内，它们归配方书那一栏）。 */
    private static final String[] MOD_ADVANCEMENTS = {
            "every_arrow_misses",
            "who_is_the_hunter",
            "kill_by_borrowed_knife",
            "flying_ace",
            "god_of_the_hunt",
            "the_sky_is_war",
            "drive_wolf_devour_tiger",
            "crystal_alloy",
            "bad_apple",
            "dullahan_ambush",
            "explosion_against_explosion",
            "fellow_pressure",
            "i_am_my_own_master",
    };

    /** 十枚配方解锁进度：只负责在配方书里点亮配方，不进任何成就栏目。 */
    private static final String[] RECIPE_ADVANCEMENTS = {
            "recipes/bad_apple",
            "recipes/disha_battle_axe",
            "recipes/mesmerizer_crown",
            "recipes/nether_crystal_ingot",
            "recipes/nether_crystal_helmet",
            "recipes/nether_crystal_chestplate",
            "recipes/nether_crystal_leggings",
            "recipes/nether_crystal_boots",
            "recipes/nether_reactor_core",
            "recipes/soul_shield",
    };

    /**
     * 逐条核对成就是否真的进了服务端：
     * <ol>
     *   <li>{@code get(id)} 拿不到 holder——JSON 没打进 jar，或解析失败；</li>
     *   <li>沿 {@code parent()} 往上走，任一祖先取不到——原版 {@code AdvancementTree}
     *       挂不上节点，这条连同整条子链都不属于任何栏目，界面上就是"找不到"；</li>
     *   <li>走到根之后按根进度判定栏目，{@code minecraft:nether/root} 即"下界"；</li>
     *   <li>执行者是玩家时，再报当前进度与还差哪些条件。</li>
     * </ol>
     */
    private static int checkAdvancements(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        var advancements = source.getServer().getAdvancements();
        ServerPlayer player = source.getEntity() instanceof ServerPlayer serverPlayer ? serverPlayer : null;
        int loaded = 0;
        int broken = 0;
        int achieved = 0;
        source.sendSuccess(() -> Component.literal("=== netherarmy 成就自检：共 "
                        + MOD_ADVANCEMENTS.length + " 枚 ===")
                .withStyle(ChatFormatting.GOLD), false);
        for (String path : MOD_ADVANCEMENTS) {
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, path);
            AdvancementHolder holder = advancements.get(id);
            if (holder == null) {
                broken++;
                source.sendSuccess(() -> Component.literal("✗ " + path + "：服务端加载不到这条成就"
                                + "（jar 里没有这个 JSON，或 JSON 解析失败）")
                        .withStyle(ChatFormatting.RED), false);
                continue;
            }
            loaded++;
            // 父链：从直接 parent 一路走到根，断在哪一步就记下来。
            ResourceLocation parent = holder.value().parent().orElse(null);
            ResourceLocation root = id;
            ResourceLocation missingParent = null;
            int guard = 0;
            while (parent != null && guard++ < 24) {
                AdvancementHolder parentNode = advancements.get(parent);
                if (parentNode == null) {
                    missingParent = parent;
                    break;
                }
                root = parent;
                parent = parentNode.value().parent().orElse(null);
            }
            if (missingParent != null) {
                broken++;
            }
            final String tab = tabNameFor(root);
            final String parentText = holder.value().parent()
                    .map(ResourceLocation::toString).orElse("无（自身即根）");
            boolean done = false;
            String progressText;
            if (player == null) {
                progressText = "执行者不是玩家，未查询个人进度";
            } else {
                AdvancementProgress progress = player.getAdvancements().getOrStartProgress(holder);
                done = progress.isDone();
                if (done) {
                    achieved++;
                    progressText = "已达成";
                } else {
                    StringBuilder remaining = new StringBuilder();
                    for (Object criterion : progress.getRemainingCriteria()) {
                        remaining.append(remaining.isEmpty() ? "" : "、").append(criterion);
                    }
                    progressText = remaining.isEmpty()
                            ? "未达成（前置成就还没完成，条件尚未开始判定）"
                            : "未达成，还差条件：" + remaining;
                }
            }
            final boolean doneSnapshot = done;
            final String progressSnapshot = progressText;
            final ResourceLocation brokenSnapshot = missingParent;
            source.sendSuccess(() -> {
                MutableComponent line = Component.literal(doneSnapshot ? "√ " : "○ ")
                        .withStyle(doneSnapshot ? ChatFormatting.GREEN : ChatFormatting.YELLOW)
                        .append(Component.literal(path + "　"))
                        .append(Component.literal("栏目：" + tab + "　").withStyle(ChatFormatting.AQUA))
                        .append(Component.literal("parent：" + parentText).withStyle(ChatFormatting.DARK_GRAY))
                        .append(Component.literal("　" + progressSnapshot)
                                .withStyle(doneSnapshot ? ChatFormatting.GREEN : ChatFormatting.GRAY));
                if (brokenSnapshot != null) {
                    line.append(Component.literal("　父链断裂于 " + brokenSnapshot
                            + "：这条成就连同它的子链都不会出现在任何栏目里").withStyle(ChatFormatting.RED));
                }
                return line;
            }, false);
        }
        int recipeLoaded = 0;
        for (String path : RECIPE_ADVANCEMENTS) {
            if (advancements.get(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, path)) != null) {
                recipeLoaded++;
            }
        }
        final int loadedSnapshot = loaded;
        final int brokenSnapshot = broken;
        final int achievedSnapshot = achieved;
        final int recipeSnapshot = recipeLoaded;
        source.sendSuccess(() -> Component.literal(String.format(
                        "汇总：加载 %d/%d 枚，父链异常 %d 枚，执行者已达成 %d 枚；配方解锁进度 %d/%d 枚。",
                        loadedSnapshot, MOD_ADVANCEMENTS.length, brokenSnapshot, achievedSnapshot,
                        recipeSnapshot, RECIPE_ADVANCEMENTS.length))
                .withStyle(brokenSnapshot == 0 ? ChatFormatting.GREEN : ChatFormatting.RED), false);
        return loadedSnapshot;
    }

    /** 根进度决定归属栏目：原版五栏 + 配方书，其余按模组自定义栏目处理。 */
    private static String tabNameFor(ResourceLocation root) {
        if (root.getNamespace().equals(GeneratedMod.MOD_ID)) {
            return "模组自定义（根：" + root + "）";
        }
        return switch (root.getPath()) {
            case "nether/root" -> "下界";
            case "adventure/root" -> "冒险";
            case "story/root" -> "故事";
            case "end/root" -> "末地";
            case "husbandry/root" -> "畜牧";
            case "recipes/root" -> "配方书（不占成就栏目）";
            default -> "原版其他（根：" + root + "）";
        };
    }
}
