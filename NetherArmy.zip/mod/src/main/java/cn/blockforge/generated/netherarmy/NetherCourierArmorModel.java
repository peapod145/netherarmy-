package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 下界传令兵的自带胸甲：胸板与左右肩甲逐立方体复刻《下界传令兵-2.bbmodel》中
 * chestplate / arm_plate_left / arm_plate_right 三个部件，使用独立的 32×32
 * 甲片贴图（{@code textures/entity/nether_courier_armor.png}）。
 *
 * <h3>肩甲与手臂绑定</h3>
 * <p>渲染层在 {@code copyPropertiesTo} 之后还会调用本模型的
 * {@code setupAnim}（与本体渲染同参），而 {@code HumanoidModel.setupAnim}
 * 会把双臂旋转重写为默认的下垂摆动动画——这正是上一版"肩甲不随手臂前平举、
 * 走路时像垂手一样前后摆"的原因。本版与 {@link NetherCourierModel} 完全同款：
 * 两者的 {@code setupAnim} 末尾都调用 {@link CourierArmAnimation#apply}——
 * 先把两条手臂钉死为绕 X 轴 -90°（常态前平举），攻击时在钉死的基准上叠加
 * 右臂挥手。肩甲立方体挂在手臂枢轴之下，因此常态即随双臂前平举、出手时随
 * 右臂一起挥动，与本体不再脱节。</p>
 *
 * <h3>坐标换算与枢轴</h3>
 * <p>与 {@link NetherCourierModel} 同一套 {@code y_java = 24 - y_bb} 换算，
 * 各部件枢轴必须与本体模型完全一致（头/身 (0,0,0)、肩 (±5,2,0)、髋 (±1.9,12,0)），
 * 渲染层的 {@code copyPropertiesTo} 只同步旋转，枢轴不一致就会脱节错位：</p>
 * <ul>
 *   <li>chestplate：x -4..4, y 11..23, z -2..2 → 挂 body 下 box(-4,1,-2,8,12,4)，
 *       texOffs(0,0)。胸板比躯干整体下移 1 格（护到腰），与躯干面共面，
 *       加 0.05 的微量外扩防 z-fighting，视觉上仍是作者画的尺寸；</li>
 *   <li>arm_plate_right（+x 侧，罩在模型左臂 4..6 外面）：x 4..8, y 11..23,
 *       z -2..2 → 挂 left_arm 下 box(-1,-1,-2,4,12,4)，texOffs(0,16)；</li>
 *   <li>arm_plate_left（-x 侧，罩在模型右臂外面）：x -8..-4 → 挂 right_arm 下
 *       box(-3,-1,-2,4,12,4)，texOffs(0,16)。</li>
 * </ul>
 * <p>bbmodel 里左肩甲的逐面 UV 是右肩甲的水平镜像（Blockbench 镜像笔刷产物），
 * 两片共用贴图 (0,16)-(16,32) 同一矩形；Java 的 {@code mirror()} 是整幅水平
 * 翻转、落不到作者的镜像区域上，故两片直接复用同一 texOffs，观感一致。</p>
 *
 * <p>人形骨架各部件本身不带任何立方体，只负责与本体模型同步姿态
 * （{@code copyPropertiesTo + setupAnim}）；渲染层固定以纯白着色绘制，
 * 因此实体受击闪红时胸甲不变色——这正是用户要求的"自带胸甲、受击不红"。</p>
 */
public final class NetherCourierArmorModel extends HumanoidModel<NetherCourier> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_courier_armor"), "main");

    public NetherCourierArmorModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(NetherCourier entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // 与 NetherCourierModel 同一出口：常态双臂钉死前平举（肩甲立方体挂在
        // 手臂部件下才会真正与胳膊绑定），攻击时随右臂一起挥手。attackTime 经
        // 渲染层的 copyPropertiesTo 与本体的值一致，两层姿态同步。
        CourierArmAnimation.apply(this);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        // 胸板：源立方体 x -4..4、y 11..23、z -2..2（bbmodel 绝对坐标），
        // 挂在与本体一致的躯干枢轴 (0,0,0) 下 → 局部 y 1..13。
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create(),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        body.addOrReplaceChild("chestplate",
                CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-4.0F, 1.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.05F)),
                PartPose.ZERO);

        // 肩甲：源立方体 4×12×4、y 11..23，罩在手臂外侧，挂手臂枢轴 (∓5,2,0)
        // 下随手臂一起前平举（局部 y -1..11）。
        PartDefinition rightArm = root.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        rightArm.addOrReplaceChild("right_arm_plate",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-3.0F, -1.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.02F)),
                PartPose.ZERO);
        PartDefinition leftArm = root.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        leftArm.addOrReplaceChild("left_arm_plate",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-1.0F, -1.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.02F)),
                PartPose.ZERO);

        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, 32, 32);
    }
}
