package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** 格尔多使用前的客户端确认界面。 */
public final class GeardleConfirmationScreen extends ConfirmScreen {
    private final int hand;
    private boolean responded;

    public GeardleConfirmationScreen(int hand) {
        super(confirmed -> respond(hand, confirmed),
                Component.literal("警告").withStyle(ChatFormatting.RED),
                Component.literal("警告，使用此物品你将如坠深渊，确定吗？")
                        .withStyle(ChatFormatting.RED),
                Component.literal("是"),
                Component.literal("否"));
        this.hand = hand;
    }

    private static void respond(int hand, boolean confirmed) {
        Minecraft minecraft = Minecraft.getInstance();
        PacketDistributor.sendToServer(new GeardleConfirmationResponsePayload(hand, confirmed));
        GeardleHandler.CLIENT_PENDING_GEARDLE_HAND = -1;
        // ConfirmScreen 的按钮回调不会替我们切回游戏界面，必须显式关闭，
        // 否则点击“是/否”后仍会卡在确认框中。
        if (minecraft.screen instanceof GeardleConfirmationScreen) {
            minecraft.setScreen(null);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    @Override
    public void onClose() {
        // 按 Esc 或触发窗口关闭时按“否”处理，并清掉客户端待处理标记。
        if (!responded) {
            responded = true;
            respond(hand, false);
        }
    }

    public static void open(int hand) {
        Minecraft.getInstance().setScreen(new GeardleConfirmationScreen(hand));
    }
}
