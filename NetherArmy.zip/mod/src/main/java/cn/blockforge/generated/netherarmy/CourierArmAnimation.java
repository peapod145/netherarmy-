package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.util.Mth;

/**
 * 下界传令兵双臂姿态的统一出口（本体模型与肩甲模型共用，两层绝不脱节）。
 *
 * <h3>常态：双臂刚性前平举</h3>
 * <p>覆盖 super 对双臂的一切改写（走路摆臂、原版人形下垂、骑乘、游泳姿态），
 * 旗杆挂在右臂末端随手臂前指。</p>
 *
 * <h3>攻击：在平举基准上给右臂叠加挥手</h3>
 * <p>上一版"攻击不会挥手"的根因：{@code HumanoidModel#setupAttackAnimation}
 * 的挥砍增量是<b>叠在垂手基准</b>（xRot≈0，向下）上的，而本模型在它之后又把
 * 双臂钉回 -90° 平举，挥砍增量被整个抹掉。本版改为在钉死之后自行叠加同款挥砍，
 * 缓动曲线逐字取自原版：{@code t = attackTime}（渲染器每帧写入
 * {@code entity.getAttackAnim(partialTick)}，出手瞬间为 1、每 tick 减 0.1），
 * {@code e = 1-(1-t)^4} 再取 {@code sin(π·e)}——慢起手抬臂（约 8 tick）、
 * 快落刀挥下（约 2 tick），与玩家/僵尸拳的节拍一致。</p>
 *
 * <p>叠加量（以平举 -90° 为基准）：xRot 峰值再抬 {@value #SWING_RAISE} rad
 * （≈60°，原版挥拳 1.2 rad 同量级，收势落回水平前指）；zRot 带原版同款的
 * {@code sin(π·t)·-0.4} 横向摆弧；yRot 跟随躯干扭转（super 里
 * {@code setupAttackAnimation} 写入的 {@code body.yRot}，我们没钉它，扭躯干
 * 的动作本来就在，这条让手臂跟上半拍）。肩甲（挂在手臂部件下）与旗帜
 * （ItemInHandLayer 建在手臂系里）随右臂一起挥动。</p>
 *
 * <p>攻击臂恒为右手：{@link NetherCourier#isLeftHanded()} 钉死 false，且近战
 * 目标只以 MAIN_HAND 出手，无需原版 {@code getAttackArm} 的判定。</p>
 */
final class CourierArmAnimation {
    /** 抬臂峰值（弧度，≈60°）。 */
    private static final float SWING_RAISE = 1.05F;
    /** 挥砍中手臂的横向摆弧峰值（原版 setupAttackAnimation 同款系数）。 */
    private static final float SWING_SIDeways = -0.4F;

    private CourierArmAnimation() {
    }

    /**
     * 钉死常态平举，并在 {@code model.attackTime > 0}（正在挥砍）时给右臂叠加
     * 挥手增量。肩甲模型经 {@code copyPropertiesTo} 拿到与本体同一个
     * {@code attackTime}，在各自的 {@code setupAnim} 末尾调用本方法即可同步。
     */
    static void apply(HumanoidModel<NetherCourier> model) {
        model.rightArm.xRot = -Mth.HALF_PI;
        model.rightArm.yRot = 0.0F;
        model.rightArm.zRot = 0.0F;
        model.leftArm.xRot = -Mth.HALF_PI;
        model.leftArm.yRot = 0.0F;
        model.leftArm.zRot = 0.0F;

        float swing = model.attackTime;
        if (swing <= 0.0F) {
            return;
        }
        float eased = 1.0F - swing;
        eased *= eased;
        eased *= eased;
        eased = 1.0F - eased;
        model.rightArm.xRot -= Mth.sin(eased * (float) Math.PI) * SWING_RAISE;
        model.rightArm.zRot += Mth.sin(swing * (float) Math.PI) * SWING_SIDeways;
        model.rightArm.yRot += model.body.yRot;
    }
}
