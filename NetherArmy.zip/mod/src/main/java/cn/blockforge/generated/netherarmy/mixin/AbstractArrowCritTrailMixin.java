package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * 修正"高速暴击箭的暴击星尾迹跑到箭前面"的问题（炼狱晶弓把初速翻倍到 6 格/刻后暴露）。
 *
 * <p><b>原版是怎么撒的：</b>{@code AbstractArrow#tick} 在 {@code level.tick()} 里、
 * {@code setPos} 之前撒 4 颗 {@link ParticleTypes#CRIT}：</p>
 *
 * <pre>{@code
 * for (int i = 0; i < 4; i++)
 *     level.addParticle(ParticleTypes.CRIT,
 *         getX() + d5 * i / 4.0, getY() + d6 * i / 4.0, getZ() + d1 * i / 4.0,
 *         -d5, -d6 + 0.2, -d1);   // d5/d6/d1 = 这一 tick 的位移
 * }</pre>
 *
 * <p>注意 {@code getX()} 此刻拿到的还是<b>这一 tick 的起点</b>（位置要等本方法末尾
 * {@code setPos} 才更新），而客户端画箭走
 * {@code Entity#getPosition(partialTick) = lerp(xo, x, partialTick)}，也就是"起点→终点"
 * 的插值。原版这 4 颗撒在 {@code [起点, 起点 + 0.75Δ]} 上，等于永远压在箭<b>前方</b>：
 * 3 格/刻时最多探出 4.5 格，配合 {@code -3} 的初速往回飞，糊成一条细尾勉强看不出问题；
 * 炼狱晶弓把初速翻倍到 6 格/刻后，探出距离同比放大、星点初速也变成 {@code -6}，
 * 于是星点成了"飘在箭前几格的一簇散星"，怎么调参数都不贴箭。</p>
 *
 * <p><b>这里的做法：</b>只改"速度超过原版任何弓弩"的暴击箭，把撒点区间从
 * {@code [起点, 起点 + 0.75Δ]} 换成 {@code [起点 - Δ, 起点]}——也就是<b>这一 tick 已经
 * 飞过的那一段</b>。于是星点永远不会出现在箭前方，最前一颗恰好压在箭身上，
 * 相邻 tick 的区间首尾相接，星点始终落在真实弹道那条直线上。星点初速保持原版
 * 3 格/刻箭矢的量级（{@code -方向 × 3}，{@code CritParticle} 构造器再乘 0.4、
 * 每刻 0.7 摩擦），所以看上去仍是"从箭身上甩出去"的星尾，而不是钉在原地的一串珠子。</p>
 *
 * <p><b>为什么不用"逐帧在渲染位置撒"：</b>{@code ParticleEngine#add} 只是把粒子塞进
 * {@code particlesToAdd} 队列，真正的冲刷在 {@code particleEngine.tick()} 末尾，
 * 而 {@code level.tick()} 排在它前面——渲染阶段撒的粒子要等<b>下一个 tick</b> 才可见，
 * 等于凭空多出 6 格滞后，反而更偏。所以只能在 tick 内撒，误差上限就是一个 tick 的
 * 位移；能做的只是把它挪到箭的<b>后</b>侧。</p>
 *
 * <p>原版弓（3.0）、弩（3.15）和普通暴击箭完全走原版逻辑，水下气泡那处调用也原样放行。</p>
 */
@Mixin(AbstractArrow.class)
public abstract class AbstractArrowCritTrailMixin {

    /** 高于原版任何弓弩的箭速上限（原版满蓄力 3.0、弩 3.15），只用来判定"这是不是被加速过的箭"。 */
    private static final double VANILLA_SPEED_LIMIT = 3.5D;

    /** 星点间距（格）：与原版 3 格/刻时的密度（约 1.3 颗/格）对齐。 */
    private static final double SPACING = 0.75D;

    /** 单 tick 最多撒多少颗，防止别的模组的离谱速度把粒子刷爆。 */
    private static final int MAX_SPARKS = 40;

    /** 星点初速的量级：原版就是给箭速大小（3 格/刻）的反向速度，这里保持同一个量级。 */
    private static final double SPARK_SPEED = 3.0D;

    /** 原版给星点的竖直初速偏移（{@code -d6 + 0.2}）。 */
    private static final double UPWARD_KICK = 0.2D;

    /**
     * 本 tick 是否已经铺过星点。
     *
     * <p>被重定向的那个调用点位于 {@code for (int i = 0; i < 4; i++)} 循环体内，
     * <b>一个 tick 会被执行 4 次</b>：不记这个标记就会把整条星带重复撒 4 遍，
     * 密度翻四倍、糊成一团亮斑。</p>
     */
    @Unique
    private int netherarmy$critTrailTick = -1;

    /**
     * 拦截 {@code AbstractArrow#tick} 里对 {@code Level#addParticle} 的调用。
     *
     * <p>不按 ordinal 绑定具体某一处：方法里另有一处撒水下气泡 {@code BUBBLE} 的调用，
     * 这里在运行时按粒子类型分流——{@code CRIT} 且高速才改写，其余原样交给原版
     * （{@code level.addParticle}）。这样即使以后原版调整调用顺序也不会绑错。</p>
     */
    @Redirect(method = "tick",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"))
    private void netherarmy$retrailCritStars(Level level, ParticleOptions particle,
                                             double x, double y, double z,
                                             double velX, double velY, double velZ) {
        AbstractArrow self = (AbstractArrow) (Object) this;
        Vec3 motion = self.getDeltaMovement();
        double speed = motion.length();
        if (particle != ParticleTypes.CRIT || speed <= VANILLA_SPEED_LIMIT) {
            level.addParticle(particle, x, y, z, velX, velY, velZ);
            return;
        }
        // 循环体里的 4 次调用共用一个注入点：一 tick 只铺一次。
        if (self.tickCount == this.netherarmy$critTrailTick) {
            return;
        }
        this.netherarmy$critTrailTick = self.tickCount;

        // 撒点区间取 [起点 - Δ, 起点]：全是箭"已经飞过"的位置，不会有星点跑到箭前面。
        Vec3 direction = motion.scale(1.0D / speed);
        double baseX = self.getX();
        double baseY = self.getY();
        double baseZ = self.getZ();
        double sparkX = -direction.x * SPARK_SPEED;
        double sparkY = -direction.y * SPARK_SPEED + UPWARD_KICK;
        double sparkZ = -direction.z * SPARK_SPEED;
        int count = Mth.clamp(Mth.ceil(speed / SPACING), 4, MAX_SPARKS);
        for (int i = 0; i <= count; i++) {
            // along 从 -speed 走到 0，即从上一 tick 的位置铺到当前位置。
            double along = -speed + speed / count * i;
            level.addParticle(ParticleTypes.CRIT,
                    baseX + direction.x * along,
                    baseY + direction.y * along,
                    baseZ + direction.z * along,
                    sparkX, sparkY, sparkZ);
        }
    }
}
