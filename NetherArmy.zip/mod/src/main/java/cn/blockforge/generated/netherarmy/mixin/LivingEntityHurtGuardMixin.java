package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.DamageGuard;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;

/**
 * 本模组生物受击的异常兜底：受击结算整段包一层 try/catch。
 *
 * <p>原版 {@code LivingEntity#hurt} → {@code actuallyHurt} 这条链本身不考虑"伤害来源
 * 长得不像原版"：别的模组的自定义伤害类型可能没有发出者、{@code getEntity()} 为空、
 * 抛射物是对方自己的类，或者干脆给出 {@code NaN}/{@code Infinity}。本模组在这条链上
 * 额外挂了一串处理器（见 {@link DamageGuard}），只要其中任何一个、或者第三方模组挂上来的
 * 处理器在同一位置抛了异常，异常就会一路逃出 {@code hurt}，落在服务端刻里 ——
 * 单人游戏的表现就是"遇到内部服务器错误"的弹窗 + 世界被关掉。</p>
 *
 * <p>这里只对<b>本模组注册的生物</b>生效（按注册名命名空间判定），把这些异常收在原地：
 * 记一条 warn（带完整堆栈，前 20 条）后按"这一击没打中"返回 {@code false}，
 * 原版该做的受击动画、音效、击退、仇恨…统统不受影响，只是这次伤害不落账。
 * 数值层面的清洗在 {@link DamageGuard}，两条线互不替代。</p>
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityHurtGuardMixin {

    @WrapMethod(method = "hurt")
    private boolean netherarmy$guardHurt(DamageSource source, float amount, Operation<Boolean> original) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!DamageGuard.isNetherArmyEntity(self)) {
            // 原版与第三方生物保持原样，不替别人兜底。
            return original.call(source, amount);
        }
        try {
            return original.call(source, amount);
        } catch (Throwable failure) {
            DamageGuard.reportHurtFailure(self, source, failure);
            return false;
        }
    }
}
