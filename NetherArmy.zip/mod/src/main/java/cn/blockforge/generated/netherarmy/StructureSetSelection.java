package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.LegacyRandomSource;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;

/**
 * 结构集加权抽签的复刻。
 *
 * <p>1.21.1 的 {@code /locate structure} 会在服务端主线程上逐个候选区块验证
 * {@code findGenerationPoint}，生成阶段（{@code ChunkGenerator#createStructures}）
 * 则是先按权重抽签、只让抽中的那个结构去判定。本类复刻这套抽签，让共享结构集
 * （{@code minecraft:nether_complexes}）里的结构在没被抽中的候选区块上直接返回空，
 * 避免为不属于自己的候选区块做昂贵的拼图放置与同步区块生成。
 *
 * <p>结构只属于一个单条目结构集时不做任何过滤，行为与原版完全一致。
 */
final class StructureSetSelection {

    private StructureSetSelection() {
    }

    /**
     * 复刻原版抽签，判断本次候选区块是否轮到 {@code self}。
     *
     * @param self      正在判定生成点的结构实例
     * @param fastQuery 是否处于 {@code /locate} 这类存在性查询路径
     *                  （{@link StructureLocateGuard#inPresenceCheck()}）
     * @return true 表示可以继续生成；false 表示本次候选区块属于别人或已判空
     */
    static boolean isSelectedForThisChunk(Structure.GenerationContext context, Structure self, boolean fastQuery) {
        Registry<StructureSet> structureSets =
                context.registryAccess().registryOrThrow(Registries.STRUCTURE_SET);
        StructureSet owningSet = null;
        int owningSetCount = 0;

        for (Holder<StructureSet> holder : structureSets.holders().toList()) {
            StructureSet set = holder.value();
            for (StructureSet.StructureSelectionEntry entry : set.structures()) {
                if (entry.structure().value() == self) {
                    owningSet = set;
                    owningSetCount++;
                    break;
                }
            }
        }

        // 没有唯一的 random_spread 所属集时，不改变原版行为。
        if (owningSetCount != 1 || !(owningSet.placement() instanceof RandomSpreadStructurePlacement)) {
            return true;
        }

        List<StructureSet.StructureSelectionEntry> entries = new ArrayList<>(owningSet.structures());
        if (entries.size() == 1) {
            return true;
        }

        int totalWeight = 0;
        for (StructureSet.StructureSelectionEntry entry : entries) {
            totalWeight += entry.weight();
        }

        WorldgenRandom random = new WorldgenRandom(new LegacyRandomSource(0L));
        ChunkPos chunkPos = context.chunkPos();
        random.setLargeFeatureSeed(context.seed(), chunkPos.x, chunkPos.z);

        while (!entries.isEmpty()) {
            int roll = random.nextInt(totalWeight);
            int selectedIndex = 0;
            for (int i = 0; i < entries.size(); i++) {
                roll -= entries.get(i).weight();
                if (roll < 0) {
                    selectedIndex = i;
                    break;
                }
            }

            StructureSet.StructureSelectionEntry selected = entries.get(selectedIndex);
            if (selected.structure().value() == self) {
                return true;
            }

            if (fastQuery) {
                // /locate 查询里不做"抽中的结构判定失败就剔除重抽"这一步：
                // 直接让出这个候选区块。省掉的是对手结构（多半是庞大的堡垒遗迹）的
                // 一整轮拼图放置——4 万个候选里 88% 都落在这一支上，是卡顿的大头。
                // 代价只是 /locate 偶尔少报几座"要等别人判空后才轮到本结构"的远处结构，
                // 绝不会多报，也完全不影响真正的区块生成（生成路径 fastQuery=false）。
                return false;
            }

            // 原版抽中的结构能够生成时就结束本区块的抽签；只有无效结构才会被剔除重抽。
            if (selected.structure().value().findValidGenerationPoint(context).isPresent()) {
                return false;
            }
            totalWeight -= selected.weight();
            entries.remove(selectedIndex);
        }
        return false;
    }
}
