package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 诡影使徒模型层。由 tools/gen_shadow_apostle_model.py 从用户提供的
 * Shadow_Apostle.bbmodel 与 Shadow_Apostle.animation.json 生成。
 * 六组环状骨棒按原动画角速度常驻旋转，和烈焰人一样不受攻击状态影响。
 */
public final class ShadowApostleModel extends EntityModel<ShadowApostle> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "shadow_apostle"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 32;

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart ringUpperOuter;
    private final ModelPart ringMiddleOuter;
    private final ModelPart ringMiddleCounter;
    private final ModelPart ringLowerCounter;
    private final ModelPart ringUpperFast;
    private final ModelPart ringLowerFast;

    private static final float[] HEAD = {
        4.0F, 4.0F, 4.0F, -4.0F, 4.0F, 4.0F, -4.0F, 4.0F, -4.0F, 4.0F,
        4.0F, -4.0F, 24.0F, 0.0F, 16.0F, 8.0F, 0.0F, 1.0F, 0.0F, 4.0F,
        -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, 4.0F, 4.0F, -4.0F,
        4.0F, 16.0F, 8.0F, 8.0F, 0.0F, 0.0F, -1.0F, 0.0F, -4.0F, -4.0F,
        -4.0F, 4.0F, -4.0F, -4.0F, 4.0F, 4.0F, -4.0F, -4.0F, 4.0F, -4.0F,
        8.0F, 8.0F, 16.0F, 16.0F, 0.0F, 0.0F, -1.0F, 4.0F, -4.0F, 4.0F,
        -4.0F, -4.0F, 4.0F, -4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 24.0F,
        8.0F, 32.0F, 16.0F, 0.0F, 0.0F, 1.0F, 4.0F, -4.0F, -4.0F, 4.0F,
        -4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 4.0F, -4.0F, 16.0F, 8.0F,
        24.0F, 16.0F, 1.0F, 0.0F, 0.0F, -4.0F, -4.0F, 4.0F, -4.0F, -4.0F,
        -4.0F, -4.0F, 4.0F, -4.0F, -4.0F, 4.0F, 4.0F, 0.0F, 8.0F, 8.0F,
        16.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGUPPEROUTER = {
        -5.0F, 4.0F, -5.0F, -7.0F, 4.0F, -5.0F, -7.0F, 4.0F, -7.0F, -5.0F,
        4.0F, -7.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, -5.0F,
        -4.0F, -7.0F, -7.0F, -4.0F, -7.0F, -7.0F, -4.0F, -5.0F, -5.0F, -4.0F,
        -5.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -7.0F, -4.0F,
        -7.0F, -5.0F, -4.0F, -7.0F, -5.0F, 4.0F, -7.0F, -7.0F, 4.0F, -7.0F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -5.0F, -4.0F, -5.0F,
        -7.0F, -4.0F, -5.0F, -7.0F, 4.0F, -5.0F, -5.0F, 4.0F, -5.0F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, -5.0F, -4.0F, -7.0F, -5.0F,
        -4.0F, -5.0F, -5.0F, 4.0F, -5.0F, -5.0F, 4.0F, -7.0F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -7.0F, -4.0F, -5.0F, -7.0F, -4.0F,
        -7.0F, -7.0F, 4.0F, -7.0F, -7.0F, 4.0F, -5.0F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, 7.0F, 4.0F, -5.0F, 5.0F, 4.0F, -5.0F,
        5.0F, 4.0F, -7.0F, 7.0F, 4.0F, -7.0F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, 7.0F, -4.0F, -7.0F, 5.0F, -4.0F, -7.0F, 5.0F,
        -4.0F, -5.0F, 7.0F, -4.0F, -5.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, 5.0F, -4.0F, -7.0F, 7.0F, -4.0F, -7.0F, 7.0F, 4.0F,
        -7.0F, 5.0F, 4.0F, -7.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, 7.0F, -4.0F, -5.0F, 5.0F, -4.0F, -5.0F, 5.0F, 4.0F, -5.0F,
        7.0F, 4.0F, -5.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        7.0F, -4.0F, -7.0F, 7.0F, -4.0F, -5.0F, 7.0F, 4.0F, -5.0F, 7.0F,
        4.0F, -7.0F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 5.0F,
        -4.0F, -5.0F, 5.0F, -4.0F, -7.0F, 5.0F, 4.0F, -7.0F, 5.0F, 4.0F,
        -5.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, 7.0F, 4.0F,
        7.0F, 5.0F, 4.0F, 7.0F, 5.0F, 4.0F, 5.0F, 7.0F, 4.0F, 5.0F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 7.0F, -4.0F, 5.0F,
        5.0F, -4.0F, 5.0F, 5.0F, -4.0F, 7.0F, 7.0F, -4.0F, 7.0F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 5.0F, -4.0F, 5.0F, 7.0F,
        -4.0F, 5.0F, 7.0F, 4.0F, 5.0F, 5.0F, 4.0F, 5.0F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 7.0F, -4.0F, 7.0F, 5.0F, -4.0F,
        7.0F, 5.0F, 4.0F, 7.0F, 7.0F, 4.0F, 7.0F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, 7.0F, -4.0F, 5.0F, 7.0F, -4.0F, 7.0F,
        7.0F, 4.0F, 7.0F, 7.0F, 4.0F, 5.0F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, 5.0F, -4.0F, 7.0F, 5.0F, -4.0F, 5.0F, 5.0F,
        4.0F, 5.0F, 5.0F, 4.0F, 7.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, -5.0F, 4.0F, 7.0F, -7.0F, 4.0F, 7.0F, -7.0F, 4.0F,
        5.0F, -5.0F, 4.0F, 5.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, -5.0F, -4.0F, 5.0F, -7.0F, -4.0F, 5.0F, -7.0F, -4.0F, 7.0F,
        -5.0F, -4.0F, 7.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        -7.0F, -4.0F, 5.0F, -5.0F, -4.0F, 5.0F, -5.0F, 4.0F, 5.0F, -7.0F,
        4.0F, 5.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -5.0F,
        -4.0F, 7.0F, -7.0F, -4.0F, 7.0F, -7.0F, 4.0F, 7.0F, -5.0F, 4.0F,
        7.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, -5.0F, -4.0F,
        5.0F, -5.0F, -4.0F, 7.0F, -5.0F, 4.0F, 7.0F, -5.0F, 4.0F, 5.0F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -7.0F, -4.0F, 7.0F,
        -7.0F, -4.0F, 5.0F, -7.0F, 4.0F, 5.0F, -7.0F, 4.0F, 7.0F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGMIDDLEOUTER = {
        -2.0F, 4.0F, 4.0F, -4.0F, 4.0F, 4.0F, -4.0F, 4.0F, 2.0F, -2.0F,
        4.0F, 2.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, -2.0F,
        -4.0F, 2.0F, -4.0F, -4.0F, 2.0F, -4.0F, -4.0F, 4.0F, -2.0F, -4.0F,
        4.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -4.0F, -4.0F,
        2.0F, -2.0F, -4.0F, 2.0F, -2.0F, 4.0F, 2.0F, -4.0F, 4.0F, 2.0F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -2.0F, -4.0F, 4.0F,
        -4.0F, -4.0F, 4.0F, -4.0F, 4.0F, 4.0F, -2.0F, 4.0F, 4.0F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, -2.0F, -4.0F, 2.0F, -2.0F,
        -4.0F, 4.0F, -2.0F, 4.0F, 4.0F, -2.0F, 4.0F, 2.0F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -4.0F, -4.0F, 4.0F, -4.0F, -4.0F,
        2.0F, -4.0F, 4.0F, 2.0F, -4.0F, 4.0F, 4.0F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, 4.0F, 4.0F, 4.0F, 2.0F, 4.0F, 4.0F,
        2.0F, 4.0F, 2.0F, 4.0F, 4.0F, 2.0F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, 4.0F, -4.0F, 2.0F, 2.0F, -4.0F, 2.0F, 2.0F,
        -4.0F, 4.0F, 4.0F, -4.0F, 4.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, 2.0F, -4.0F, 2.0F, 4.0F, -4.0F, 2.0F, 4.0F, 4.0F,
        2.0F, 2.0F, 4.0F, 2.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, 4.0F, -4.0F, 4.0F, 2.0F, -4.0F, 4.0F, 2.0F, 4.0F, 4.0F,
        4.0F, 4.0F, 4.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        4.0F, -4.0F, 2.0F, 4.0F, -4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 4.0F,
        4.0F, 2.0F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 2.0F,
        -4.0F, 4.0F, 2.0F, -4.0F, 2.0F, 2.0F, 4.0F, 2.0F, 2.0F, 4.0F,
        4.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, 4.0F, 4.0F,
        -2.0F, 2.0F, 4.0F, -2.0F, 2.0F, 4.0F, -4.0F, 4.0F, 4.0F, -4.0F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 4.0F, -4.0F, -4.0F,
        2.0F, -4.0F, -4.0F, 2.0F, -4.0F, -2.0F, 4.0F, -4.0F, -2.0F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 2.0F, -4.0F, -4.0F, 4.0F,
        -4.0F, -4.0F, 4.0F, 4.0F, -4.0F, 2.0F, 4.0F, -4.0F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 4.0F, -4.0F, -2.0F, 2.0F, -4.0F,
        -2.0F, 2.0F, 4.0F, -2.0F, 4.0F, 4.0F, -2.0F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, 4.0F, -4.0F, -4.0F, 4.0F, -4.0F, -2.0F,
        4.0F, 4.0F, -2.0F, 4.0F, 4.0F, -4.0F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, 2.0F, -4.0F, -2.0F, 2.0F, -4.0F, -4.0F, 2.0F,
        4.0F, -4.0F, 2.0F, 4.0F, -2.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, -2.0F, 4.0F, -2.0F, -4.0F, 4.0F, -2.0F, -4.0F, 4.0F,
        -4.0F, -2.0F, 4.0F, -4.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, -2.0F, -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, -4.0F, -2.0F,
        -2.0F, -4.0F, -2.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        -4.0F, -4.0F, -4.0F, -2.0F, -4.0F, -4.0F, -2.0F, 4.0F, -4.0F, -4.0F,
        4.0F, -4.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -2.0F,
        -4.0F, -2.0F, -4.0F, -4.0F, -2.0F, -4.0F, 4.0F, -2.0F, -2.0F, 4.0F,
        -2.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, -2.0F, -4.0F,
        -4.0F, -2.0F, -4.0F, -2.0F, -2.0F, 4.0F, -2.0F, -2.0F, 4.0F, -4.0F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -4.0F, -4.0F, -2.0F,
        -4.0F, -4.0F, -4.0F, -4.0F, 4.0F, -4.0F, -4.0F, 4.0F, -2.0F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGMIDDLECOUNTER = {
        9.0F, 4.0F, 9.0F, 7.0F, 4.0F, 9.0F, 7.0F, 4.0F, 7.0F, 9.0F,
        4.0F, 7.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 9.0F,
        -4.0F, 7.0F, 7.0F, -4.0F, 7.0F, 7.0F, -4.0F, 9.0F, 9.0F, -4.0F,
        9.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 7.0F, -4.0F,
        7.0F, 9.0F, -4.0F, 7.0F, 9.0F, 4.0F, 7.0F, 7.0F, 4.0F, 7.0F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 9.0F, -4.0F, 9.0F,
        7.0F, -4.0F, 9.0F, 7.0F, 4.0F, 9.0F, 9.0F, 4.0F, 9.0F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 9.0F, -4.0F, 7.0F, 9.0F,
        -4.0F, 9.0F, 9.0F, 4.0F, 9.0F, 9.0F, 4.0F, 7.0F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 7.0F, -4.0F, 9.0F, 7.0F, -4.0F,
        7.0F, 7.0F, 4.0F, 7.0F, 7.0F, 4.0F, 9.0F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, -7.0F, 4.0F, 9.0F, -9.0F, 4.0F, 9.0F,
        -9.0F, 4.0F, 7.0F, -7.0F, 4.0F, 7.0F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, -7.0F, -4.0F, 7.0F, -9.0F, -4.0F, 7.0F, -9.0F,
        -4.0F, 9.0F, -7.0F, -4.0F, 9.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, -9.0F, -4.0F, 7.0F, -7.0F, -4.0F, 7.0F, -7.0F, 4.0F,
        7.0F, -9.0F, 4.0F, 7.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, -7.0F, -4.0F, 9.0F, -9.0F, -4.0F, 9.0F, -9.0F, 4.0F, 9.0F,
        -7.0F, 4.0F, 9.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        -7.0F, -4.0F, 7.0F, -7.0F, -4.0F, 9.0F, -7.0F, 4.0F, 9.0F, -7.0F,
        4.0F, 7.0F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -9.0F,
        -4.0F, 9.0F, -9.0F, -4.0F, 7.0F, -9.0F, 4.0F, 7.0F, -9.0F, 4.0F,
        9.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, -7.0F, 4.0F,
        -7.0F, -9.0F, 4.0F, -7.0F, -9.0F, 4.0F, -9.0F, -7.0F, 4.0F, -9.0F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, -7.0F, -4.0F, -9.0F,
        -9.0F, -4.0F, -9.0F, -9.0F, -4.0F, -7.0F, -7.0F, -4.0F, -7.0F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -9.0F, -4.0F, -9.0F, -7.0F,
        -4.0F, -9.0F, -7.0F, 4.0F, -9.0F, -9.0F, 4.0F, -9.0F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -7.0F, -4.0F, -7.0F, -9.0F, -4.0F,
        -7.0F, -9.0F, 4.0F, -7.0F, -7.0F, 4.0F, -7.0F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, -7.0F, -4.0F, -9.0F, -7.0F, -4.0F, -7.0F,
        -7.0F, 4.0F, -7.0F, -7.0F, 4.0F, -9.0F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, -9.0F, -4.0F, -7.0F, -9.0F, -4.0F, -9.0F, -9.0F,
        4.0F, -9.0F, -9.0F, 4.0F, -7.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, 9.0F, 4.0F, -7.0F, 7.0F, 4.0F, -7.0F, 7.0F, 4.0F,
        -9.0F, 9.0F, 4.0F, -9.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, 9.0F, -4.0F, -9.0F, 7.0F, -4.0F, -9.0F, 7.0F, -4.0F, -7.0F,
        9.0F, -4.0F, -7.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        7.0F, -4.0F, -9.0F, 9.0F, -4.0F, -9.0F, 9.0F, 4.0F, -9.0F, 7.0F,
        4.0F, -9.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 9.0F,
        -4.0F, -7.0F, 7.0F, -4.0F, -7.0F, 7.0F, 4.0F, -7.0F, 9.0F, 4.0F,
        -7.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 9.0F, -4.0F,
        -9.0F, 9.0F, -4.0F, -7.0F, 9.0F, 4.0F, -7.0F, 9.0F, 4.0F, -9.0F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 7.0F, -4.0F, -7.0F,
        7.0F, -4.0F, -9.0F, 7.0F, 4.0F, -9.0F, 7.0F, 4.0F, -7.0F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGLOWERCOUNTER = {
        1.0F, 4.0F, 7.25F, -1.0F, 4.0F, 7.25F, -1.0F, 4.0F, 5.25F, 1.0F,
        4.0F, 5.25F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 1.0F,
        -4.0F, 5.25F, -1.0F, -4.0F, 5.25F, -1.0F, -4.0F, 7.25F, 1.0F, -4.0F,
        7.25F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -1.0F, -4.0F,
        5.25F, 1.0F, -4.0F, 5.25F, 1.0F, 4.0F, 5.25F, -1.0F, 4.0F, 5.25F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 1.0F, -4.0F, 7.25F,
        -1.0F, -4.0F, 7.25F, -1.0F, 4.0F, 7.25F, 1.0F, 4.0F, 7.25F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 1.0F, -4.0F, 5.25F, 1.0F,
        -4.0F, 7.25F, 1.0F, 4.0F, 7.25F, 1.0F, 4.0F, 5.25F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -1.0F, -4.0F, 7.25F, -1.0F, -4.0F,
        5.25F, -1.0F, 4.0F, 5.25F, -1.0F, 4.0F, 7.25F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, -5.0F, 4.0F, 1.25F, -7.0F, 4.0F, 1.25F,
        -7.0F, 4.0F, -0.75F, -5.0F, 4.0F, -0.75F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, -5.0F, -4.0F, -0.75F, -7.0F, -4.0F, -0.75F, -7.0F,
        -4.0F, 1.25F, -5.0F, -4.0F, 1.25F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, -7.0F, -4.0F, -0.75F, -5.0F, -4.0F, -0.75F, -5.0F, 4.0F,
        -0.75F, -7.0F, 4.0F, -0.75F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, -5.0F, -4.0F, 1.25F, -7.0F, -4.0F, 1.25F, -7.0F, 4.0F, 1.25F,
        -5.0F, 4.0F, 1.25F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        -5.0F, -4.0F, -0.75F, -5.0F, -4.0F, 1.25F, -5.0F, 4.0F, 1.25F, -5.0F,
        4.0F, -0.75F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -7.0F,
        -4.0F, 1.25F, -7.0F, -4.0F, -0.75F, -7.0F, 4.0F, -0.75F, -7.0F, 4.0F,
        1.25F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, 7.0F, 4.0F,
        1.25F, 5.0F, 4.0F, 1.25F, 5.0F, 4.0F, -0.75F, 7.0F, 4.0F, -0.75F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 7.0F, -4.0F, -0.75F,
        5.0F, -4.0F, -0.75F, 5.0F, -4.0F, 1.25F, 7.0F, -4.0F, 1.25F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 5.0F, -4.0F, -0.75F, 7.0F,
        -4.0F, -0.75F, 7.0F, 4.0F, -0.75F, 5.0F, 4.0F, -0.75F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 7.0F, -4.0F, 1.25F, 5.0F, -4.0F,
        1.25F, 5.0F, 4.0F, 1.25F, 7.0F, 4.0F, 1.25F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, 7.0F, -4.0F, -0.75F, 7.0F, -4.0F, 1.25F,
        7.0F, 4.0F, 1.25F, 7.0F, 4.0F, -0.75F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, 5.0F, -4.0F, 1.25F, 5.0F, -4.0F, -0.75F, 5.0F,
        4.0F, -0.75F, 5.0F, 4.0F, 1.25F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, 1.0F, 4.0F, -5.75F, -1.0F, 4.0F, -5.75F, -1.0F, 4.0F,
        -7.75F, 1.0F, 4.0F, -7.75F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, 1.0F, -4.0F, -7.75F, -1.0F, -4.0F, -7.75F, -1.0F, -4.0F, -5.75F,
        1.0F, -4.0F, -5.75F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        -1.0F, -4.0F, -7.75F, 1.0F, -4.0F, -7.75F, 1.0F, 4.0F, -7.75F, -1.0F,
        4.0F, -7.75F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        -4.0F, -5.75F, -1.0F, -4.0F, -5.75F, -1.0F, 4.0F, -5.75F, 1.0F, 4.0F,
        -5.75F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 1.0F, -4.0F,
        -7.75F, 1.0F, -4.0F, -5.75F, 1.0F, 4.0F, -5.75F, 1.0F, 4.0F, -7.75F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -1.0F, -4.0F, -5.75F,
        -1.0F, -4.0F, -7.75F, -1.0F, 4.0F, -7.75F, -1.0F, 4.0F, -5.75F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGUPPERFAST = {
        1.0F, 7.0F, 11.25F, -1.0F, 7.0F, 11.25F, -1.0F, 7.0F, 9.25F, 1.0F,
        7.0F, 9.25F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 1.0F,
        -1.0F, 9.25F, -1.0F, -1.0F, 9.25F, -1.0F, -1.0F, 11.25F, 1.0F, -1.0F,
        11.25F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -1.0F, -1.0F,
        9.25F, 1.0F, -1.0F, 9.25F, 1.0F, 7.0F, 9.25F, -1.0F, 7.0F, 9.25F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 1.0F, -1.0F, 11.25F,
        -1.0F, -1.0F, 11.25F, -1.0F, 7.0F, 11.25F, 1.0F, 7.0F, 11.25F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 1.0F, -1.0F, 9.25F, 1.0F,
        -1.0F, 11.25F, 1.0F, 7.0F, 11.25F, 1.0F, 7.0F, 9.25F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -1.0F, -1.0F, 11.25F, -1.0F, -1.0F,
        9.25F, -1.0F, 7.0F, 9.25F, -1.0F, 7.0F, 11.25F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, -9.0F, 7.0F, 1.25F, -11.0F, 7.0F, 1.25F,
        -11.0F, 7.0F, -0.75F, -9.0F, 7.0F, -0.75F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, -9.0F, -1.0F, -0.75F, -11.0F, -1.0F, -0.75F, -11.0F,
        -1.0F, 1.25F, -9.0F, -1.0F, 1.25F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, -11.0F, -1.0F, -0.75F, -9.0F, -1.0F, -0.75F, -9.0F, 7.0F,
        -0.75F, -11.0F, 7.0F, -0.75F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, -9.0F, -1.0F, 1.25F, -11.0F, -1.0F, 1.25F, -11.0F, 7.0F, 1.25F,
        -9.0F, 7.0F, 1.25F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        -9.0F, -1.0F, -0.75F, -9.0F, -1.0F, 1.25F, -9.0F, 7.0F, 1.25F, -9.0F,
        7.0F, -0.75F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -11.0F,
        -1.0F, 1.25F, -11.0F, -1.0F, -0.75F, -11.0F, 7.0F, -0.75F, -11.0F, 7.0F,
        1.25F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, 11.0F, 7.0F,
        1.25F, 9.0F, 7.0F, 1.25F, 9.0F, 7.0F, -0.75F, 11.0F, 7.0F, -0.75F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 11.0F, -1.0F, -0.75F,
        9.0F, -1.0F, -0.75F, 9.0F, -1.0F, 1.25F, 11.0F, -1.0F, 1.25F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 9.0F, -1.0F, -0.75F, 11.0F,
        -1.0F, -0.75F, 11.0F, 7.0F, -0.75F, 9.0F, 7.0F, -0.75F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 11.0F, -1.0F, 1.25F, 9.0F, -1.0F,
        1.25F, 9.0F, 7.0F, 1.25F, 11.0F, 7.0F, 1.25F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, 11.0F, -1.0F, -0.75F, 11.0F, -1.0F, 1.25F,
        11.0F, 7.0F, 1.25F, 11.0F, 7.0F, -0.75F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, 9.0F, -1.0F, 1.25F, 9.0F, -1.0F, -0.75F, 9.0F,
        7.0F, -0.75F, 9.0F, 7.0F, 1.25F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, 1.0F, 7.0F, -9.75F, -1.0F, 7.0F, -9.75F, -1.0F, 7.0F,
        -11.75F, 1.0F, 7.0F, -11.75F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, 1.0F, -1.0F, -11.75F, -1.0F, -1.0F, -11.75F, -1.0F, -1.0F, -9.75F,
        1.0F, -1.0F, -9.75F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        -1.0F, -1.0F, -11.75F, 1.0F, -1.0F, -11.75F, 1.0F, 7.0F, -11.75F, -1.0F,
        7.0F, -11.75F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        -1.0F, -9.75F, -1.0F, -1.0F, -9.75F, -1.0F, 7.0F, -9.75F, 1.0F, 7.0F,
        -9.75F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 1.0F, -1.0F,
        -11.75F, 1.0F, -1.0F, -9.75F, 1.0F, 7.0F, -9.75F, 1.0F, 7.0F, -11.75F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -1.0F, -1.0F, -9.75F,
        -1.0F, -1.0F, -11.75F, -1.0F, 7.0F, -11.75F, -1.0F, 7.0F, -9.75F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };
    private static final float[] RINGLOWERFAST = {
        6.0F, 3.0F, 9.0F, 4.0F, 3.0F, 9.0F, 4.0F, 3.0F, 7.0F, 6.0F,
        3.0F, 7.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, 6.0F,
        -5.0F, 7.0F, 4.0F, -5.0F, 7.0F, 4.0F, -5.0F, 9.0F, 6.0F, -5.0F,
        9.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, 4.0F, -5.0F,
        7.0F, 6.0F, -5.0F, 7.0F, 6.0F, 3.0F, 7.0F, 4.0F, 3.0F, 7.0F,
        2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 6.0F, -5.0F, 9.0F,
        4.0F, -5.0F, 9.0F, 4.0F, 3.0F, 9.0F, 6.0F, 3.0F, 9.0F, 6.0F,
        18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 6.0F, -5.0F, 7.0F, 6.0F,
        -5.0F, 9.0F, 6.0F, 3.0F, 9.0F, 6.0F, 3.0F, 7.0F, 4.0F, 18.0F,
        6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 4.0F, -5.0F, 9.0F, 4.0F, -5.0F,
        7.0F, 4.0F, 3.0F, 7.0F, 4.0F, 3.0F, 9.0F, 0.0F, 18.0F, 2.0F,
        26.0F, -1.0F, 0.0F, 0.0F, -7.0F, 3.0F, 6.0F, -9.0F, 3.0F, 6.0F,
        -9.0F, 3.0F, 4.0F, -7.0F, 3.0F, 4.0F, 6.0F, 16.0F, 4.0F, 18.0F,
        0.0F, 1.0F, 0.0F, -7.0F, -5.0F, 4.0F, -9.0F, -5.0F, 4.0F, -9.0F,
        -5.0F, 6.0F, -7.0F, -5.0F, 6.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F,
        -1.0F, 0.0F, -9.0F, -5.0F, 4.0F, -7.0F, -5.0F, 4.0F, -7.0F, 3.0F,
        4.0F, -9.0F, 3.0F, 4.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F,
        -1.0F, -7.0F, -5.0F, 6.0F, -9.0F, -5.0F, 6.0F, -9.0F, 3.0F, 6.0F,
        -7.0F, 3.0F, 6.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F,
        -7.0F, -5.0F, 4.0F, -7.0F, -5.0F, 6.0F, -7.0F, 3.0F, 6.0F, -7.0F,
        3.0F, 4.0F, 4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, -9.0F,
        -5.0F, 6.0F, -9.0F, -5.0F, 4.0F, -9.0F, 3.0F, 4.0F, -9.0F, 3.0F,
        6.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F, -4.0F, 3.0F,
        -7.0F, -6.0F, 3.0F, -7.0F, -6.0F, 3.0F, -9.0F, -4.0F, 3.0F, -9.0F,
        6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F, 0.0F, -4.0F, -5.0F, -9.0F,
        -6.0F, -5.0F, -9.0F, -6.0F, -5.0F, -7.0F, -4.0F, -5.0F, -7.0F, 4.0F,
        18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -6.0F, -5.0F, -9.0F, -4.0F,
        -5.0F, -9.0F, -4.0F, 3.0F, -9.0F, -6.0F, 3.0F, -9.0F, 2.0F, 18.0F,
        4.0F, 26.0F, 0.0F, 0.0F, -1.0F, -4.0F, -5.0F, -7.0F, -6.0F, -5.0F,
        -7.0F, -6.0F, 3.0F, -7.0F, -4.0F, 3.0F, -7.0F, 6.0F, 18.0F, 8.0F,
        26.0F, 0.0F, 0.0F, 1.0F, -4.0F, -5.0F, -9.0F, -4.0F, -5.0F, -7.0F,
        -4.0F, 3.0F, -7.0F, -4.0F, 3.0F, -9.0F, 4.0F, 18.0F, 6.0F, 26.0F,
        1.0F, 0.0F, 0.0F, -6.0F, -5.0F, -7.0F, -6.0F, -5.0F, -9.0F, -6.0F,
        3.0F, -9.0F, -6.0F, 3.0F, -7.0F, 0.0F, 18.0F, 2.0F, 26.0F, -1.0F,
        0.0F, 0.0F, 9.0F, 3.0F, -4.0F, 7.0F, 3.0F, -4.0F, 7.0F, 3.0F,
        -6.0F, 9.0F, 3.0F, -6.0F, 6.0F, 16.0F, 4.0F, 18.0F, 0.0F, 1.0F,
        0.0F, 9.0F, -5.0F, -6.0F, 7.0F, -5.0F, -6.0F, 7.0F, -5.0F, -4.0F,
        9.0F, -5.0F, -4.0F, 4.0F, 18.0F, 2.0F, 16.0F, 0.0F, -1.0F, 0.0F,
        7.0F, -5.0F, -6.0F, 9.0F, -5.0F, -6.0F, 9.0F, 3.0F, -6.0F, 7.0F,
        3.0F, -6.0F, 2.0F, 18.0F, 4.0F, 26.0F, 0.0F, 0.0F, -1.0F, 9.0F,
        -5.0F, -4.0F, 7.0F, -5.0F, -4.0F, 7.0F, 3.0F, -4.0F, 9.0F, 3.0F,
        -4.0F, 6.0F, 18.0F, 8.0F, 26.0F, 0.0F, 0.0F, 1.0F, 9.0F, -5.0F,
        -6.0F, 9.0F, -5.0F, -4.0F, 9.0F, 3.0F, -4.0F, 9.0F, 3.0F, -6.0F,
        4.0F, 18.0F, 6.0F, 26.0F, 1.0F, 0.0F, 0.0F, 7.0F, -5.0F, -4.0F,
        7.0F, -5.0F, -6.0F, 7.0F, 3.0F, -6.0F, 7.0F, 3.0F, -4.0F, 0.0F,
        18.0F, 2.0F, 26.0F, -1.0F, 0.0F, 0.0F
    };

    public ShadowApostleModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.ringUpperOuter = root.getChild("ringUpperOuter");
        this.ringMiddleOuter = root.getChild("ringMiddleOuter");
        this.ringMiddleCounter = root.getChild("ringMiddleCounter");
        this.ringLowerCounter = root.getChild("ringLowerCounter");
        this.ringUpperFast = root.getChild("ringUpperFast");
        this.ringLowerFast = root.getChild("ringLowerFast");
    }

    @Override
    public void setupAnim(ShadowApostle entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.ringUpperOuter.yRot = Mth.wrapDegrees(ageInTicks * 18.0F) * Mth.DEG_TO_RAD;
        this.ringMiddleOuter.yRot = Mth.wrapDegrees(ageInTicks * 18.0F) * Mth.DEG_TO_RAD;
        this.ringMiddleCounter.yRot = Mth.wrapDegrees(ageInTicks * -9.0F) * Mth.DEG_TO_RAD;
        this.ringLowerCounter.yRot = Mth.wrapDegrees(ageInTicks * -9.0F) * Mth.DEG_TO_RAD;
        this.ringUpperFast.yRot = Mth.wrapDegrees(ageInTicks * -18.0F) * Mth.DEG_TO_RAD;
        this.ringLowerFast.yRot = Mth.wrapDegrees(ageInTicks * 36.0F) * Mth.DEG_TO_RAD;
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.head, HEAD, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringUpperOuter, RINGUPPEROUTER, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringMiddleOuter, RINGMIDDLEOUTER, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringMiddleCounter, RINGMIDDLECOUNTER, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringLowerCounter, RINGLOWERCOUNTER, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringUpperFast, RINGUPPERFAST, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.ringLowerFast, RINGLOWERFAST, TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("ringUpperOuter", CubeListBuilder.create(), PartPose.offset(0.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("ringMiddleOuter", CubeListBuilder.create(), PartPose.offset(0.0F, 11.0F, 0.0F));
        root.addOrReplaceChild("ringMiddleCounter", CubeListBuilder.create(), PartPose.offset(0.0F, 11.0F, 0.0F));
        root.addOrReplaceChild("ringLowerCounter", CubeListBuilder.create(), PartPose.offset(0.0F, 18.0F, -0.25F));
        root.addOrReplaceChild("ringUpperFast", CubeListBuilder.create(), PartPose.offset(0.0F, 5.0F, -0.25F));
        root.addOrReplaceChild("ringLowerFast", CubeListBuilder.create(), PartPose.offset(0.0F, 17.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
