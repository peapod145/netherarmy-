package cn.blockforge.generated.netherarmy;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * 凋灵骷髅阵营的<b>最高级仇恨判定</b>：敌我结论由这一处说了算，压过原版筛选与第三方覆写。
 *
 * <h3>为什么要提到最高级</h3>
 * <p>军团的索敌要穿过三道不属于本模组的闸门，任何一道关掉都表现为"锁不上"：</p>
 * <ol>
 * <li><b>原版合法性</b>：{@code TargetingConditions#test} 依次要求
 * {@code target.canBeSeenByAnyone()}、{@code attacker.canAttack(target)}
 * （内部又是 {@code target.canBeSeenAsEnemy()} = 非旁观 + 存活 + {@code !isInvulnerable}）、
 * {@code attacker.canAttackType(type)}、{@code !attacker.isAlliedTo(target)}。
 * 第三方模组最常见的两种写法——给自己家怪挂 {@code setInvulnerable(true)} 的登场/护盾阶段，
 * 或者覆写 {@code canAttackType}/{@code isAlliedTo} 声明"亡灵是一家"——都会让军团在
 * 谓词这一步直接出局，无论仇恨是怎么建立的。</li>
 * <li><b>阵营名册</b>：见 {@link WitherFactionRoster}。公开原版标签被别的模组写脏之后，
 * 对面那只怪会被误认成同袍，三条仇恨通道一起失效。</li>
 * <li><b>别的模组的仇恨干预</b>：强制仇恨工具写完 {@code setTarget} 之后，第三方 AI 覆写
 * 可以在下一 tick 把目标抹掉，军团连"被钉上"这件事都记不住。</li>
 * </ol>
 *
 * <h3>这一类怎么把三闸门抬到自己身上</h3>
 * <ul>
 * <li>{@link #canLegionAttack} 是唯一的敌我结论来源；三个 mixin
 * （{@code LegionSupremeCanAttackMixin} / {@code LegionSupremeCanAttackTypeMixin} /
 * {@code LegionSupremeAllianceMixin}）在 {@code canAttack}、{@code canAttackType}、
 * {@code isAlliedTo} 的 HEAD 直接以它的答案收尾（{@code setReturnValue} 会取消后续所有注入），
 * 于是原版的无敌/旁观筛选与第三方声明的同盟关系都盖不住军团的判断。判定仍然尊重本模组自己的
 * 豁免：同袍、心控友军、反逆器械、创造/旁观玩家、和平难度的玩家，一条都不会放开。</li>
 * <li>优先级：军团成员挂 {@link SupremeHostilityTargetGoal}，占 {@code targetSelector}
 * <b>0 号（最高）</b>槽位，压过受击反击、玩家索敌与器械索敌。</li>
 * <li>记账：{@link #noteAggressor} 记住"谁打过军团"（军团公敌，全军团共享），
 * {@link #notePinnedTarget} 记住"谁被外部钉到自己头上"。两条都是纯内存短账，
 * 目标被别的模组抹掉后下一轮扫描会自行补回——强制仇恨工具的效果不再依赖那一次写入存活多久。</li>
 * </ul>
 *
 * <h3>仍然不是"见面即宣战"</h3>
 * <p>需求口径没变：阵营生物不会主动对非阵营实体宣战。0 号目标组的谓词只在<b>敌意已经成立</b>
 * 时才放行——对方先把手伸到军团头上（伤害过军团任一成员、把军团成员锁为自己的目标），
 * 或者外部工具已经把目标钉到本阵营生物身上。三者都没有时，扫描结果始终为空。</p>
 */
public final class WitherFactionSupremeHostility {

    /** 目标组优先级：0 是 {@code targetSelector} 的最高档，压过军团其余全部索敌。 */
    public static final int TARGET_GOAL_PRIORITY = 0;
    /** 已有活目标时的复核间隔（tick）：优先级最高，但不必每刻重排一次仇恨。 */
    private static final int RECHECK_INTERVAL_TICKS = 10;
    /** 军团公敌的记账时长（tick）：30 秒内全军团都认得这个动手的家伙。 */
    private static final long AGGRESSOR_TTL_TICKS = 600L;
    /** 钉靶记账时长（tick）：外部强制仇恨写入后，本成员自行续期 5 秒。 */
    private static final long PIN_TTL_TICKS = 100L;
    /** 记账表上限，超过即回收过期项，防止长期战斗把内存堆满。 */
    private static final int MAX_TRACKED = 512;

    /** 攻击过军团的实体 UUID → 过期的游戏刻。军团共享，服务端单线程读写。 */
    private static final Map<UUID, Long> AGGRESSORS = new ConcurrentHashMap<>();
    /** 阵营成员 UUID → 被钉在它头上的目标。逐成员记录，供扫描补写。 */
    private static final Map<UUID, Pin> PINS = new ConcurrentHashMap<>();

    private record Pin(UUID target, long expiresAtTick) {
    }

    private WitherFactionSupremeHostility() {
    }

    /**
     * 军团视角的敌我终判：攻击者必须是阵营成员，候选必须不是阵营成员、没被本模组豁免挡下，
     * 且活着。返回 {@code true} 即"军团可以把它锁为攻击目标"，其余一切筛选让路。
     */
    public static boolean canLegionAttack(LivingEntity attacker, LivingEntity candidate) {
        if (candidate == null || attacker == null || attacker == candidate) {
            return false;
        }
        if (!WitherFactionRoster.isMember(attacker)) {
            return false;
        }
        if (!candidate.isAlive()) {
            return false;
        }
        // 和平难度不打玩家：原版 canAttack 里唯一的难度分支，这里原样保留。
        if (candidate instanceof Player && attacker.level().getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        // 创造/旁观玩家不进仇恨（与 Mob#setTarget 的总闸同一口径）。
        if (WitherFactionCreativePassivityHandler.isIgnoredPlayer(candidate)) {
            return false;
        }
        // 本模组自己的豁免全在这一条里：同袍、心控友军、反逆器械、叛军玩家、器械同侧……
        return MesmerizerControl.canAttack(attacker, candidate);
    }

    /** 类型级终判，供 {@code Mob#canAttackType} 使用：阵营成员只不与名册内的类型交战。 */
    public static boolean canLegionAttackType(LivingEntity attacker, net.minecraft.world.entity.EntityType<?> type) {
        if (!WitherFactionRoster.isMember(attacker) || type == null) {
            return false;
        }
        return !WitherFactionRoster.isMemberType(type);
    }

    /** 同盟终判：阵营成员只把名册内的实体当自己人，第三方声明的"亡灵同盟"不作数。 */
    public static Boolean resolveAlliance(LivingEntity self, LivingEntity other) {
        if (!WitherFactionRoster.isMember(self)) {
            return null;
        }
        return WitherFactionRoster.isMember(other);
    }

    /** 记下"这个实体攻击过军团"，军团全体在保鲜期内都认它是敌人。 */
    public static void noteAggressor(Level level, LivingEntity aggressor) {
        if (level == null || aggressor == null || WitherFactionRoster.isMember(aggressor)) {
            return;
        }
        prune(level.getGameTime());
        AGGRESSORS.put(aggressor.getUUID(), level.getGameTime() + AGGRESSOR_TTL_TICKS);
    }

    /** 该实体是否在军团公敌名册里（打过军团任一成员，且仍在保鲜期内）。 */
    public static boolean isAggressor(Level level, LivingEntity candidate) {
        Long expiresAt = AGGRESSORS.get(candidate.getUUID());
        return expiresAt != null && level.getGameTime() <= expiresAt;
    }

    /** 记下"某个目标被写到了阵营成员头上"，供扫描在目标被第三方抹掉后补回。 */
    public static void notePinnedTarget(Mob legionMember, LivingEntity target) {
        if (legionMember == null || target == null || !WitherFactionRoster.isMember(legionMember)) {
            return;
        }
        prune(legionMember.level().getGameTime());
        PINS.put(legionMember.getUUID(), new Pin(target.getUUID(), legionMember.level().getGameTime() + PIN_TTL_TICKS));
    }

    /** 该候选正是当前钉在这个阵营成员身上的目标（外部强制仇恨的续命通道）。 */
    public static boolean isPinnedTarget(Level level, Mob legionMember, LivingEntity candidate) {
        Pin pin = PINS.get(legionMember.getUUID());
        return pin != null && level.getGameTime() <= pin.expiresAtTick() && pin.target().equals(candidate.getUUID());
    }

    /** 遗忘实体的账，顺带把两张表压回上限内。 */
    private static void prune(long nowTick) {
        if (AGGRESSORS.size() > MAX_TRACKED) {
            AGGRESSORS.entrySet().removeIf(entry -> entry.getValue() < nowTick);
            if (AGGRESSORS.size() > MAX_TRACKED) {
                AGGRESSORS.clear();
            }
        }
        if (PINS.size() > MAX_TRACKED) {
            PINS.entrySet().removeIf(entry -> entry.getValue().expiresAtTick() < nowTick);
            if (PINS.size() > MAX_TRACKED) {
                PINS.clear();
            }
        }
    }

    /**
     * 0 号索敌目标组的谓词：只在敌意已经成立时放行。
     *
     * <p>三种来源，任一即可：</p>
     * <ol>
     * <li>外部强制仇恨工具钉在当前成员身上的目标（{@link #isPinnedTarget}）；</li>
     * <li>攻击过军团任一成员的实体（{@link #isAggressor}，含"伤害被凋灵之首免疫等手段挡下、
     * 原版 {@code lastHurtByMob} 根本没写进去"的情况——这正是过去锁不上的那批）；</li>
     * <li>已经把军团成员列为目标、或刚与军团成员交过手的实体（{@code getTarget}/
     * {@code getLastHurtByMob} 反查，第三方主动挑衅时军团立刻还手，不必先挨一下）。</li>
     * </ol>
     */
    public static boolean isSupremeTarget(Mob legionMember, LivingEntity candidate) {
        Level level = legionMember.level();
        if (!canLegionAttack(legionMember, candidate)) {
            return false;
        }
        if (isPinnedTarget(level, legionMember, candidate) || isAggressor(level, candidate)) {
            return true;
        }
        if (candidate instanceof Mob other) {
            if (WitherFactionRoster.isMember(other.getTarget())
                    || WitherFactionRoster.isMember(other.getLastHurtByMob())) {
                return true;
            }
        }
        return false;
    }

    /** 幂等检查：同一成员只挂一个 0 号目标组。 */
    public static boolean hasSupremeGoal(Mob mob) {
        return mob.targetSelector.getAvailableGoals().stream()
                .map(WrappedGoal::getGoal)
                .anyMatch(SupremeHostilityTargetGoal.class::isInstance);
    }

    /**
     * 军团最高优先级索敌：{@code targetSelector} 0 号槽位，无目标时每刻扫描，
     * 已有活目标时按 10 tick 复核一次（优先级最高，但不必每刻重排仇恨）。
     */
    public static final class SupremeHostilityTargetGoal extends InstantLockTargetGoal<LivingEntity> {

        private final Mob owner;

        public SupremeHostilityTargetGoal(Mob mob) {
            super(mob, LivingEntity.class, 10, true, false, candidate -> isSupremeTarget(mob, candidate));
            this.owner = mob;
        }

        @Override
        public boolean canUse() {
            LivingEntity current = this.owner.getTarget();
            boolean idle = current == null || !current.isAlive();
            if (!idle && this.owner.tickCount % RECHECK_INTERVAL_TICKS != 0) {
                return false;
            }
            this.findTarget();
            return this.target != null;
        }

        @Override
        public boolean canContinueToUse() {
            // 保持原版的"黏性"：一旦咬住就只问合法性，不问记账是否过期，
            // 免得 30 秒黑名单到期后战斗被硬生生掐断、目标在各优先级之间来回跳。
            LivingEntity target = this.owner.getTarget();
            return target != null && target.isAlive()
                    && WitherFactionSupremeHostility.canLegionAttack(this.owner, target);
        }
    }
}
