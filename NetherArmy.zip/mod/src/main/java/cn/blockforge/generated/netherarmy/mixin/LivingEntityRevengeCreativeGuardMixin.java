package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherFactionCreativePassivityHandler;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 阻止凋灵骷髅阵营把创造/旁观玩家记为受击反击目标。 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityRevengeCreativeGuardMixin {

    @Inject(method = "setLastHurtByMob", at = @At("HEAD"), cancellable = true)
    private void netherarmy$blockCreativeRevenge(LivingEntity attacker, CallbackInfo callback) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof Mob mob && attacker != null
                && WitherFactionCreativePassivityHandler.shouldBlockTarget(mob, attacker)) {
            callback.cancel();
        }
    }
}
