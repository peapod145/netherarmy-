package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** 诡影使徒：继承烈焰人的飞行、悬浮、黑烟和目标选择逻辑，替换攻击方式。 */
public final class ShadowApostle extends Blaze {
    private static final EntityDataAccessor<Boolean> DATA_CHARGING = SynchedEntityData.defineId(
            ShadowApostle.class, EntityDataSerializers.BOOLEAN);

    public ShadowApostle(EntityType<? extends ShadowApostle> type, Level level) {
        super(type, level);
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Blaze.createAttributes()
                .add(Attributes.MAX_HEALTH, 25.0D)
                .add(Attributes.ARMOR, 2.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_CHARGING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(4, new ApostleAttackGoal(this));
        this.goalSelector.addGoal(5, new MoveTowardsRestrictionGoal(this, 1.0D));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D, 0.0F));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers());
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        // 与凋灵骷髅一致，主动攻击猪灵系和铁傀儡。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractPiglin.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    public boolean isCharging() {
        return this.entityData.get(DATA_CHARGING);
    }

    private void setCharging(boolean charging) {
        this.entityData.set(DATA_CHARGING, charging);
        if (!this.level().isClientSide()) {
            SoulFireBurn.setSoulFlame(this, charging);
        }
    }

    @Override
    public boolean isOnFire() {
        return this.isCharging();
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BLAZE_DEATH;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return false;
        }
        DamageSource source = serverLevel.damageSources().source(GeneratedMod.WITHER_GHOST_VOID, this);
        if (!target.hurt(source, 4.0F)) {
            return false;
        }
        if (target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100), this);
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100), this);
        }
        this.setLastHurtMob(target);
        this.playAttackSound();
        return true;
    }

    private static final class ApostleAttackGoal extends Goal {
        private final ShadowApostle apostle;
        private int attackStep;
        private int attackTime;
        private int lastSeen;

        private ApostleAttackGoal(ShadowApostle apostle) {
            this.apostle = apostle;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = this.apostle.getTarget();
            return target != null && target.isAlive() && this.apostle.canAttack(target);
        }

        @Override
        public void start() {
            this.attackStep = 0;
            this.attackTime = 0;
        }

        @Override
        public void stop() {
            this.apostle.setCharging(false);
            this.lastSeen = 0;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            this.attackTime--;
            LivingEntity target = this.apostle.getTarget();
            if (target == null) {
                return;
            }
            boolean visible = this.apostle.getSensing().hasLineOfSight(target);
            if (visible) {
                this.lastSeen = 0;
            } else {
                this.lastSeen++;
            }

            double distance = this.apostle.distanceToSqr(target);
            if (distance < 4.0D) {
                if (visible && this.attackTime <= 0) {
                    this.attackTime = 20;
                    this.apostle.doHurtTarget(target);
                }
                this.apostle.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0D);
            } else if (distance < this.getFollowDistance() * this.getFollowDistance() && visible) {
                double dx = target.getX() - this.apostle.getX();
                double dy = target.getY(0.5D) - this.apostle.getY(0.5D);
                double dz = target.getZ() - this.apostle.getZ();
                if (this.attackTime <= 0) {
                    this.attackStep++;
                    if (this.attackStep == 1) {
                        this.attackTime = 60;
                        this.apostle.setCharging(true);
                    } else if (this.attackStep <= 4) {
                        this.attackTime = 6;
                    } else {
                        this.attackTime = 100;
                        this.attackStep = 0;
                        this.apostle.setCharging(false);
                    }
                    if (this.attackStep > 1) {
                        double spread = Math.sqrt(Math.sqrt(distance)) * 0.5D;
                        if (!this.apostle.isSilent()) {
                            this.apostle.level().levelEvent(null, 1018, this.apostle.blockPosition(), 0);
                        }
                        for (int i = 0; i < 3; i++) {
                            Vec3 direction = new Vec3(
                                    this.apostle.getRandom().triangle(dx, 2.297D * spread),
                                    dy,
                                    this.apostle.getRandom().triangle(dz, 2.297D * spread)).normalize();
                            WitherCharge charge = new WitherCharge(this.apostle, this.apostle.level(), direction);
                            charge.setPos(this.apostle.getX(), this.apostle.getY(0.5D) + 0.5D, this.apostle.getZ());
                            charge.launch(direction);
                            this.apostle.level().addFreshEntity(charge);
                        }
                    }
                }
                this.apostle.getLookControl().setLookAt(target, 10.0F, 10.0F);
            } else if (this.lastSeen < 5) {
                this.apostle.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0D);
            }
        }

        private double getFollowDistance() {
            return this.apostle.getAttributeValue(Attributes.FOLLOW_RANGE);
        }
    }
}
