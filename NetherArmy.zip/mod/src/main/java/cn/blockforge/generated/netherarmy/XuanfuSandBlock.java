package cn.blockforge.generated.netherarmy;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

/**
 * 萱浮的沙子：非重力方块，可以悬空摆放（普通 {@link HorizontalDirectionalBlock}，
 * 不接 {@code FallingBlock}，沙子落地逻辑与它无关）。
 * <ul>
 *   <li>猫脸朝北，摆放时随玩家朝向旋转（不是固定朝向）。</li>
 *   <li>悬空（正下方不是实心方块）时持续从底面漏下沙子粒子。</li>
 *   <li>空手右键：随机播放一声原版猫叫，并在方块上掉出一个糖，方块本身不消失。</li>
 *   <li>像基岩一样不可挖掘（{@code strength(-1)}，爆炸抗性同基岩），生存里唯一的
 *       收取方式：手持糖按住 Shift 右键——方块立即掉落为物品，糖不会被消耗。</li>
 * </ul>
 */
public final class XuanfuSandBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<XuanfuSandBlock> CODEC = simpleCodec(XuanfuSandBlock::new);

    /** “猫叫”候选池：从原版猫的环境音/讨食/呼噜等叫声里随机挑一声。 */
    private static final SoundEvent[] CAT_SOUNDS = {
            SoundEvents.CAT_AMBIENT,
            SoundEvents.CAT_BEG_FOR_FOOD,
            SoundEvents.CAT_PURR,
            SoundEvents.CAT_PURREOW,
            SoundEvents.CAT_STRAY_AMBIENT,
    };

    public XuanfuSandBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    /**
     * 1.21.1 的 {@link HorizontalDirectionalBlock} 不会自动声明 FACING 属性，
     * 必须由子类自己加进状态定义——漏掉会导致 blockstate 变体全部加载失败，
     * 摆放时 setValue(FACING) 直接抛 IllegalArgumentException 崩溃。
     */
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        // 猫脸转向玩家：与玩家视线水平方向相反（参照原版熔炉的摆放逻辑）
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            RandomSource random = level.getRandom();
            SoundEvent meow = CAT_SOUNDS[random.nextInt(CAT_SOUNDS.length)];
            level.playSound(null, pos, meow, SoundSource.NEUTRAL, 1.0F, 0.9F + random.nextFloat() * 0.3F);
            ItemEntity sugar = new ItemEntity(level,
                    pos.getX() + 0.5, pos.getY() + 0.7, pos.getZ() + 0.5, new ItemStack(Items.SUGAR));
            sugar.setDeltaMovement((random.nextDouble() - 0.5) * 0.1, 0.1, (random.nextDouble() - 0.5) * 0.1);
            sugar.setDefaultPickUpDelay();
            level.addFreshEntity(sugar);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * 生存收取入口：方块本身不可挖掘（基岩同款硬度），必须手持糖（主手或副手均可）
     * 并按住 Shift 右键。潜行持物时原版会跳过方块交互，由
     * {@link XuanfuSandInteractionHandler} 通过 {@code PlayerInteractEvent.RightClickBlock}
     * 显式放行，使这里能被调用。糖不消耗，方块按战利品表掉落为物品。
     */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (player.isSecondaryUseActive() && isHoldingSugar(player)) {
            if (!level.isClientSide) {
                Block.dropResources(state, level, pos);
                level.playSound(null, pos,
                        state.getSoundType(level, pos, player).getBreakSound(),
                        SoundSource.BLOCKS, 1.0F, 0.9F);
                level.destroyBlock(pos, false, player);
            }
            return ItemInteractionResult.SUCCESS;
        }
        // 其余情况走原版链路：不潜行时继续落到空手交互（猫叫 + 掉糖）
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    /** 主手或副手任一持有糖即算“手持糖”。 */
    public static boolean isHoldingSugar(Player player) {
        return player.getMainHandItem().is(Items.SUGAR) || player.getOffhandItem().is(Items.SUGAR);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        // 只有悬空时才漏沙：正下方是实心方块就安静地待着
        if (level.getBlockState(pos.below()).isSolid()) {
            return;
        }
        if (random.nextFloat() < 0.35F) {
            level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SAND.defaultBlockState()),
                    pos.getX() + random.nextDouble(), pos.getY() - 0.05, pos.getZ() + random.nextDouble(),
                    0.0, -0.05, 0.0);
        }
    }
}
