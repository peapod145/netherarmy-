package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;

/**
 * 凋灵阵营施法者共用的魔法伤害抗性，按比例折减魔法伤害。
 *
 * <h3>判定口径</h3>
 * <p>只看本模组的 {@code #netherarmy:is_magic} 伤害类型标签，成员是
 * {@code minecraft:magic}（药水即时伤害、凋灵之首、守卫者光束、唤魔者尖牙以及本模组
 * 自己造的魔法伤害）与 {@code minecraft:indirect_magic}（滞留药水云）。原版 1.21.1
 * 没有现成的"魔法伤害"标签，这里沿用原版女巫 {@code #minecraft:witch_resistant_to}
 * 的口径；整合包想再收编别的伤害类型（龙息、音波等）只需往标签里追加一行，
 * 所有使用者一起生效。</p>
 *
 * <h3>接入方式</h3>
 * <p>挡在 {@code hurt(DamageSource, float)} 入口：近战、抛射物、持续伤害、药水云、
 * 爆炸都会经过它，一条覆写覆盖全部来源，也避免逐个订阅
 * {@code LivingIncomingDamageEvent} 时的结算顺序问题。</p>
 *
 * <p>现有使用者：御首者 50%、反逆者 50%（{@link #reduce(DamageSource, float, float)} 传入 0.5）、
 * 怨灵 75%、反转士 75%、凋灵魔导师 75%（{@link #reduce(DamageSource, float)}，默认比例）。</p>
 */
public final class MagicDamageResistance {
    /** 魔法伤害标签（本模组命名空间）：{@code minecraft:magic} + {@code minecraft:indirect_magic}。 */
    public static final TagKey<DamageType> IS_MAGIC = TagKey.create(
            Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "is_magic"));

    /** 怨灵／反转士／凋灵魔导师三只施法者统一 75% 抗性（需求值）。 */
    public static final float CASTER_RESISTANCE = 0.75F;

    private MagicDamageResistance() {
    }

    /**
     * 按 {@link #CASTER_RESISTANCE}（75%）折减魔法伤害；非魔法伤害原样返回。
     *
     * @param source 伤害来源，用于查 {@link #IS_MAGIC} 标签
     * @param amount 原始伤害
     * @return 折减后的伤害
     */
    public static float reduce(DamageSource source, float amount) {
        return reduce(source, amount, CASTER_RESISTANCE);
    }

    /**
     * 按指定比例折减魔法伤害；非魔法伤害、非正伤害、非法比例都原样返回。
     *
     * @param resistance 抗性比例，0（无抗性）~1（完全免疫）
     */
    public static float reduce(DamageSource source, float amount, float resistance) {
        if (amount <= 0.0F || resistance <= 0.0F || source == null) {
            return amount;
        }
        if (!source.is(IS_MAGIC)) {
            return amount;
        }
        return amount * (1.0F - Math.min(1.0F, resistance));
    }

    /** 该伤害来源是否算作魔法伤害（供需要额外处理的调用方复用同一口径）。 */
    public static boolean isMagic(DamageSource source) {
        return source != null && source.is(IS_MAGIC);
    }
}
