package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingEvent;

/**
 * 反逆者的"军团视野"：隐身暴露与怪物头颅伪装豁免。
 *
 * <h3>两条规则</h3>
 * <ol>
 *   <li>隐身只对单个生物有效，对整支军团无效。只要潜行的敌人落进<b>任意一个</b>反逆者的
 *       索敌半径（{@value Mesmerizer#MESMERIZER_FOLLOW_RANGE} 格），凋灵骷髅阵营的全部
 *       成员就把它当成没有隐身一样去发现它。</li>
 *   <li>玩家戴怪物头颅（原版 {@code #minecraft:skulls} 里的任何一颗）不会缩短反逆者的
 *       索敌范围。</li>
 * </ol>
 *
 * <h3>为什么钩 {@link LivingEvent.LivingVisibilityEvent}</h3>
 * <p>1.21.1 里"能不能发现一个活着的、没躲墙的实体"这件事，视线与距离各自有判定，
 * 而<b>隐身</b>与<b>头颅伪装</b>这两条只走同一个闸口：
 * {@code LivingEntity#getVisibilityPercent(Entity)} 返回一个 0~1 的比例，
 * {@code TargetingConditions#test} 把观察者的 {@code FOLLOW_RANGE} 乘以它再和实际距离比
 * （隐身且无护甲覆盖时只有 0.07，于是 32 格索敌塌成原版的 2 格保底；头颅伪装再腰斩一半）。
 * 所有走 {@code NearestAttackableTargetGoal}/{@code TargetingConditions} 的索敌——原版凋灵骷髅、
 * 本模组的狂战士/猎手/无头骑士/尸鬼/衰翼/传令兵/运兵车、以及 {@link Witherphantom}
 * 自己写的 128 格空袭判定——最后都汇到这一个比例上。NeoForge 在原版算完之后把结果
 * 交给 {@code LivingVisibilityEvent} 复核（{@code CommonHooks#getEntityVisibilityMultiplier}），
 * 所以只改这一个数，就能同时修好全部阵营成员的索敌，不必给每个子类塞目标选择器。</p>
 *
 * <p>反过来说：{@code canBeSeenByAnyone} 只看存活与旁观者模式，{@code Sensing#hasLineOfSight}
 * 是纯射线，两者都不掺隐身判定，因此不需要额外动手。</p>
 *
 * <h3>头颅伪装为什么要"重算"而不是"补偿"</h3>
 * <p>原版的伪装写死在 {@code getVisibilityPercent} 内部，且只认观察者是不是
 * {@code skeleton/zombie/piglin/piglin_brute/creeper} 这五种{@code EntityType}：反逆者的类型是
 * 自己注册的，压根不在这张表里，所以"除以 0.5"式的补偿会误把隐身带来的折扣也放大。
 * 这里按原版的公式把<b>没有头颅折扣</b>时应得的比例重算一遍（{@code isDiscrete} ×0.8、
 * 隐身 ×0.7×护甲覆盖率），只在事件收到的值低于它时才抬上去——即只还原头颅这一项，
 * 隐身照常生效（除非命中规则 1）。这样无论以后原版把凋零骷髅加进伪装表、还是别的模组
 * 往同一个事件里塞头颅折扣，反逆者都不受影响。</p>
 *
 * <h3>反逆者名册的缓存</h3>
 * <p>可见性事件是热路径（每个生物的每个索敌周期都会触发），逐次扫维度代价不可接受，
 * 因此按维度缓存一份活着的反逆者名单，每 {@value #ROSTER_REFRESH_TICKS} tick 重取一次：
 * 名单只存实体引用并在使用时校验存活，最坏延迟半秒，对"反逆者刚死/刚进圈"这种边界足够。
 * 与 {@link LegionAuraHandler} 的传令兵光环同一套路子。</p>
 */
public final class LegionVisionHandler {
    /** 反逆者名单的重取间隔（tick）。 */
    private static final int ROSTER_REFRESH_TICKS = 10;

    /** 维度 → 反逆者名单快照（纯内存，弱键随维度卸载自动消失）。 */
    private static final Map<ServerLevel, Roster> ROSTERS = new java.util.WeakHashMap<>();

    private LegionVisionHandler() {
    }

    private record Roster(long refreshedAtGameTime, List<Mesmerizer> mesmerizers) {
    }

    @SubscribeEvent
    public static void onLivingVisibility(LivingEvent.LivingVisibilityEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide() || !(target.level() instanceof ServerLevel level)) {
            return;
        }
        double modifier = event.getVisibilityModifier();
        // 快路径：目标本来就完全可见（绝大多数调用都是这种），不做任何扫描。
        if (modifier >= 1.0D) {
            return;
        }
        Entity observer = event.getLookingEntity();
        if (observer == null || observer == target) {
            return;
        }
        boolean mesmerizer = observer instanceof Mesmerizer;
        if (!mesmerizer && !MesmerizerControl.isWitherSkeletonFaction(observer)) {
            return;
        }

        // 规则 1：隐身敌人只要落在任一反逆者的索敌圈内，对整个凋灵骷髅阵营都不再有效。
        if (target.isInvisible() && isWithinAnyMesmerizerFollowRange(target, level)) {
            raiseVisibility(event, modifier, 1.0D);
            return;
        }

        // 规则 2：怪物头颅伪装不缩短反逆者的索敌范围。
        if (mesmerizer && wearsMonsterHead(target)) {
            raiseVisibility(event, modifier, visibilityWithoutHeadDisguise(target));
        }
    }

    /**
     * 把可见性比例抬到 {@code want}。
     *
     * <p>NeoForge 的 {@code modifyVisibility(double)} 是<b>再乘一次</b>（事件内部
     * {@code visibilityModifier *= value}），不是赋值，所以想拿到确定值必须乘上
     * {@code want / current} 这个补正系数。{@code current} 为 0 时（别的模组已经彻底抹掉
     * 可见性）不做处理——乘法补偿救不回 0，硬改成非 0 反而会盖掉别人的规则。</p>
     */
    private static void raiseVisibility(LivingEvent.LivingVisibilityEvent event, double current, double want) {
        if (want <= current || current <= 0.0D) {
            return;
        }
        event.modifyVisibility(want / current);
    }

    /** 目标是否落在某个活着的反逆者的索敌半径内（按反逆者的 FOLLOW_RANGE 属性取）。 */
    private static boolean isWithinAnyMesmerizerFollowRange(LivingEntity target, ServerLevel level) {
        for (Mesmerizer mesmerizer : activeRoster(level)) {
            // 名单最多 10 tick 一换，缓存里可能留有刚死的反逆者：尸体不再充当灯塔。
            if (mesmerizer.isAlive() && mesmerizer.distanceToSqr(target) <= followRangeSqr(mesmerizer)) {
                return true;
            }
        }
        return false;
    }

    private static double followRangeSqr(Mesmerizer mesmerizer) {
        double range = mesmerizer.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
        if (range <= 0.0D) {
            range = Mesmerizer.MESMERIZER_FOLLOW_RANGE;
        }
        return range * range;
    }

    private static List<Mesmerizer> activeRoster(ServerLevel level) {
        long gameTime = level.getGameTime();
        Roster cached = ROSTERS.get(level);
        if (cached != null && gameTime - cached.refreshedAtGameTime() < ROSTER_REFRESH_TICKS) {
            return cached.mesmerizers();
        }
        List<Mesmerizer> fresh = new ArrayList<>();
        for (Mesmerizer mesmerizer : level.getEntities(
                EntityTypeTest.forClass(Mesmerizer.class), Mesmerizer::isAlive)) {
            fresh.add(mesmerizer);
        }
        ROSTERS.put(level, new Roster(gameTime, fresh));
        return fresh;
    }

    /** 头部装备是否是原版意义上的怪物头颅（{@code #minecraft:skulls}：骷髅/凋零骷髅/僵尸/苦力怕/猪灵/龙/玩家头）。 */
    private static boolean wearsMonsterHead(LivingEntity target) {
        ItemStack head = target.getItemBySlot(EquipmentSlot.HEAD);
        return !head.isEmpty() && head.is(ItemTags.SKULLS);
    }

    /**
     * 复刻 {@code LivingEntity#getVisibilityPercent} 的公式，但跳过"头颅伪装 ×0.5"这一步：
     * 显示实体 ×0.8、隐身 ×0.7×max(0.1, 护甲覆盖率)，其余为 1。
     */
    private static double visibilityWithoutHeadDisguise(LivingEntity target) {
        double visibility = 1.0D;
        if (target.isDiscrete()) {
            visibility *= 0.8D;
        }
        if (target.isInvisible()) {
            visibility *= 0.7D * Math.max(0.1D, target.getArmorCoverPercentage());
        }
        return visibility;
    }
}
