package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** 反逆者发射的无伤害、无重力控制光球。 */
public final class MesmerizerOrb extends ThrowableItemProjectile {
    /**
     * 光球最长存在时间：30 秒（600 tick）。无重力且能穿透同阵营实体，
     * 不封顶的话会一直沿弹道飞下去，超过此时限即自动消失。
     */
    private static final int MAX_LIFETIME_TICKS = 20 * 30;

    public MesmerizerOrb(EntityType<MesmerizerOrb> type, Level level) {
        super(type, level);
    }

    public MesmerizerOrb(LivingEntity owner, Level level) {
        super(GeneratedMod.MESMERIZER_ORB.get(), owner, level);
    }

    /**
     * 存在时间超过 30s 自动消失。服务端判定后 discard，
     * 移除包会同步给客户端，无需两端各自计时。
     */
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide() && this.tickCount > MAX_LIFETIME_TICKS) {
            this.discard();
        }
    }

    @Override
    protected Item getDefaultItem() {
        return GeneratedMod.MESMERIZER_ORB_ITEM.get();
    }

    /**
     * 同阵营实体（凋灵骷髅阵营生物、已被反逆者心控的生物，含发射光球的反逆者自己）
     * 直接不进入碰撞判定：光球既不结算控制、也不被消耗，从它们身上无视并穿透过去。
     * ThrowableProjectile 的命中扫描用的正是本方法（{@code this::canHitEntity}），
     * 因此覆写后穿透是逐 tick 连续生效的。
     */
    @Override
    protected boolean canHitEntity(Entity target) {
        if (!super.canHitEntity(target)) {
            return false;
        }
        if (target instanceof LivingEntity living && MesmerizerControl.isControlled(living)) {
            return false;
        }
        return !MesmerizerControl.isWitherSkeletonFaction(target);
    }

    @Override
    protected double getDefaultGravity() {
        return 0.0D;
    }

    @Override
    protected void onHitEntity(EntityHitResult hitResult) {
        if (this.level().isClientSide()) {
            return;
        }
        Entity hit = hitResult.getEntity();
        Entity owner = this.getOwner();
        if (!(owner instanceof Mesmerizer mesmerizer) || !(hit instanceof LivingEntity living)
                || hit == owner || hit instanceof Mesmerizer || hit instanceof WitherBoss || hit instanceof EnderDragon) {
            this.discard();
            return;
        }
        if (MesmerizerControl.isCrownProtected(living)) {
            this.discard();
            return;
        }
        if (living instanceof Player player) {
            player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    GeneratedMod.REBELLION, 20 * 5), mesmerizer);
        } else {
            MesmerizerControl.setControlledBy(living, mesmerizer);
            MesmerizerControl.clearAllTargets(living.level(), living);
            // Brain AI（监守者、猪灵系）的 getTarget 读 ATTACK_TARGET 记忆，
            // 光球命中瞬间就要把旧的敌意记忆清空，否则下一 tick 仍按旧目标行动。
            MesmerizerControl.clearControlledTargetMemories(living);
        }
        this.discard();
    }

    @Override
    protected void onHit(net.minecraft.world.phys.HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide()) {
            // 命中实体或方块、光球消失前播放命中音效（服务端广播，覆盖附近所有玩家）。
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    GeneratedMod.MESMERIZER_ORB_HIT.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
            this.discard();
        }
    }
}
