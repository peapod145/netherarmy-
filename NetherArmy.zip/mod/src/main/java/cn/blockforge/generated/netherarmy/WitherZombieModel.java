package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 尸鬼模型：几何与逐面 UV 按用户上传的 witherzombie.bbmodel 精确复刻。
 *
 * <p>该贴图的左右臂/腿与头部侧面用的是非原版网格式排布（左臂、左腿画在 64×64 下半区，
 * 且多个立方体的东西侧面相对原版网格互换），因此不能用原版 addBox 的单一 texOffs，
 * 每个面单独换算偏移：原版 {@code ModelPart.Cube} 各面的矩形为
 * NORTH=(U+d,V+d)、SOUTH=(U+2d+w,V+d)、WEST=(U,V+d)、EAST=(U+d+w,V+d)、
 * UP=(U+d+w,V)、DOWN=(U+d,V)（U,V 为 texOffs，w/h/d 为立方体尺寸），
 * 反解出使目标面矩形恰好落在贴图上给定坐标的 U、V 即可。</p>
 *
 * <p>bbmodel 中 armorLeftLeg 骨骼带 -180° 偏航旋转：立方体以骨骼轴心为中心，旋转后
 * 几何原位不变，但四个侧面两两互换（世界北侧显示原南面 UV，以此类推），下面
 * right_leg 的面序已按旋转后的最终朝向换算。骨骼里与右腿完全重合的 armorRightBoot
 * 是重复立方体（UV 相同，渲染即闪面），不纳入模型。</p>
 *
 * <p>动画与溺尸一致：僵尸基类的双臂前伸 + 攻击摆臂由 {@code ZombieModel} 提供，
 * 入水/入岩浆时的划水姿态（swimAmount 分支）逐行复刻 {@code DrownedModel#setupAnim}
 * （去掉三叉戟投掷特判）；幼年个体的大头小身比例由 {@code AgeableListModel} 的
 * young 标志自动处理（与小僵尸一致）。</p>
 */
public class WitherZombieModel extends ZombieModel<WitherZombie> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_zombie"), "main");

    public WitherZombieModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(WitherZombie entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (this.swimAmount > 0.0F) {
            // DrownedModel#setupAnim 的游泳姿态分支，参数逐行一致。
            this.rightArm.xRot = this.rotlerpRad(this.swimAmount, this.rightArm.xRot,
                    (float) (-Math.PI * 4.0 / 5.0)) + this.swimAmount * 0.35F * Mth.sin(0.1F * ageInTicks);
            this.leftArm.xRot = this.rotlerpRad(this.swimAmount, this.leftArm.xRot,
                    (float) (-Math.PI * 4.0 / 5.0)) - this.swimAmount * 0.35F * Mth.sin(0.1F * ageInTicks);
            this.rightArm.zRot = this.rotlerpRad(this.swimAmount, this.rightArm.zRot, -0.15F);
            this.leftArm.zRot = this.rotlerpRad(this.swimAmount, this.leftArm.zRot, 0.15F);
            this.leftLeg.xRot = this.leftLeg.xRot - this.swimAmount * 0.55F * Mth.sin(0.1F * ageInTicks);
            this.rightLeg.xRot = this.rightLeg.xRot + this.swimAmount * 0.55F * Mth.sin(0.1F * ageInTicks);
            this.head.xRot = 0.0F;
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // 头：bbmodel armorHead（x -4..4, y 24..32, z -4..4，原版头部尺寸）。
        root.addOrReplaceChild("head", faces(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F,
                        8, 8, 24, 8, 0, 8, 16, 8, 8, 0, 16, 0),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // hat：HumanoidModel 构造器无条件取用该部件（getChild 缺失即抛 NoSuchElementException，
        // 实体渲染器构建发生在客户端启动期，会让游戏卡在加载进不去）。尸鬼贴图没有第二层
        // 头部几何，这里与本模组其他类人模型一样注册一个空部件。
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);

        // 躯干：bbmodel armorBody。东西侧面相对原版网格互换，逐面 UV 原样保留。
        root.addOrReplaceChild("body", faces(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F,
                        20, 20, 32, 20, 16, 20, 28, 20, 20, 16, 28, 16),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // 模型右臂（世界 -x 侧）：bbmodel armorLeftArm 立方体（x -8..-4），UV 在下半区。
        root.addOrReplaceChild("right_arm", faces(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F,
                        7, 52, 15, 52, 3, 52, 11, 52, 7, 48, 11, 48),
                PartPose.offset(-5.0F, 2.0F, 0.0F));

        // 模型左臂（世界 +x 侧）：bbmodel armorRightArm 立方体（x 4..8）。
        root.addOrReplaceChild("left_arm", faces(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F,
                        44, 20, 52, 20, 40, 20, 48, 20, 44, 16, 48, 16),
                PartPose.offset(5.0F, 2.0F, 0.0F));

        // 模型右腿（世界 -x 侧）：bbmodel armorLeftLeg 立方体（x -4..0），
        // 面序已按骨骼 -180° 偏航旋转后的最终朝向换算（南北互换、东西互换）。
        root.addOrReplaceChild("right_leg", faces(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F,
                        35, 52, 27, 52, 31, 52, 23, 52, 27, 48, 31, 48),
                PartPose.offset(-1.9F, 12.0F, 0.0F));

        // 模型左腿（世界 +x 侧）：bbmodel armorRightLeg 立方体（x 0..4）。
        root.addOrReplaceChild("left_leg", faces(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F,
                        4, 20, 12, 20, 8, 20, 0, 20, 4, 16, 8, 16),
                PartPose.offset(1.9F, 12.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    /**
     * 把一个立方体的六个面分别摆到贴图上的指定矩形。
     *
     * <p>原版 Cube 模型空间 Y 轴向下，挂 {@code Direction.DOWN} 标签的面（矩形 (U+d,V)）
     * 是视觉顶面，{@code Direction.UP}（矩形 (U+d+w,V)）是视觉底面，因此 bbmodel 的
     * 顶面喂给 DOWN、底面喂给 UP。</p>
     *
     * @param x,y,z     立方体最小角（部件局部坐标）
     * @param w,h,d     立方体尺寸
     * @param nU,nV     北面矩形左上角；sU,sV 南面；eU,eV 东面；wU,wV 西面；
     *                  uU,uV 顶面；dU,dV 底面（矩形宽高由立方体尺寸决定）
     */
    private static CubeListBuilder faces(float x, float y, float z, float w, float h, float d,
                                         int nU, int nV, int sU, int sV,
                                         int eU, int eV, int wU, int wV,
                                         int uU, int uV, int dU, int dV) {
        int di = (int) d;
        int wi = (int) w;
        CubeListBuilder builder = CubeListBuilder.create();
        face(builder, Direction.NORTH, nU - di, nV - di, x, y, z, w, h, d);
        face(builder, Direction.SOUTH, sU - 2 * di - wi, sV - di, x, y, z, w, h, d);
        face(builder, Direction.WEST, wU, wV - di, x, y, z, w, h, d);
        face(builder, Direction.EAST, eU - di - wi, eV - di, x, y, z, w, h, d);
        face(builder, Direction.DOWN, uU - di, uV, x, y, z, w, h, d);
        face(builder, Direction.UP, dU - di - wi, dV, x, y, z, w, h, d);
        return builder;
    }

    private static void face(CubeListBuilder builder, Direction dir, int texU, int texV,
                             float x, float y, float z, float w, float h, float d) {
        builder.texOffs(texU, texV).addBox(x, y, z, w, h, d, EnumSet.of(dir));
    }
}
