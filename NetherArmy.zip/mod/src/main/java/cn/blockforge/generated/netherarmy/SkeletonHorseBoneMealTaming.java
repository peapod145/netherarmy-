package cn.blockforge.generated.netherarmy;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * 原版骷髅马可以用骨粉驯服，但每次只有三分之一的成功机会。
 *
 * <p>先说清原版为什么"驯不了"：1.21.1 的 {@code SkeletonHorse#mobInteract} 只有两句——
 * 未被驯服时直接返回 {@code PASS}，已驯服时才转交 {@code AbstractHorse#mobInteract}。
 * 所以骑上去反复挣扎那套普通马驯服流程对骷髅马根本走不到入口；它的
 * {@code isFood}/{@code handleEating} 也不吃任何马食，投喂同样无效。结果就是原版骷髅马
 * 除了陷阱闪电生成的那一队"天生已驯服"的个体之外，玩家没有任何手段弄到手。</p>
 *
 * <p>本处理器把骨粉做成驯服道具：手持骨粉右键未驯服的骷髅马，消耗 1 份骨粉做一次判定，
 * 成功率 {@value #TAME_CHANCE}（三分之一，和狼吃骨头驯服同一手感）。判定失败骨粉照样消耗，
 * 只冒烟、打个响鼻，马不会受任何伤害；再撒一次就是重新掷一次。全程不给文字提示——
 * 原版驯服失败本来就没有动作条，玩家看"有没有冒爱心"就够了。
 * 判定成功走 {@code AbstractHorse#tameWithName}，它一次性完成主人 UUID、驯服标记、
 * {@code TAME_ANIMAL} 成就触发，并广播实体事件 7 让客户端掉爱心粒子。</p>
 *
 * <p><b>为什么用事件而不是混入：</b>{@code PlayerInteractEvent.EntityInteract} 在原版
 * {@code Player#interactOn} 之前触发，取消它并给出 {@code SUCCESS} 就等于"这次交互我接管了"，
 * 原版 {@code mobInteract} 不会再看这只马一眼。驯服之后 {@code SkeletonHorse#mobInteract}
 * 走的就是"已驯服"分支，鞍、马铠、骑乘、潜行开背包全部按原版马匹逻辑正常工作。</p>
 *
 * <p><b>随机数用马自己的：</b>{@code horse.getRandom()} 由服务端统一驱动，判定只在
 * {@link ServerLevel} 分支里做，客户端那条早退的路径永远不掷骰子，联机时不会出现
 * "客户端以为驯服了、服务端说没有"的分歧。</p>
 *
 * <p><b>三类马不碰：</b></p>
 * <ol>
 *   <li>已经驯服的（换了主或天生带鞍，没有重复驯服的理由）；</li>
 *   <li>本模组的 {@link DullahanHorse} 及其子类——那是以 {@code Enemy} 身份作战的怪物坐骑，
 *       被骨粉一撒就变成玩家的坐骑显然不对；</li>
 *   <li>本模组 {@link DullahanTrapSpawner} 打上陷阱标记的原版骷髅马——那只是"等着炸出无头骑士
 *       伏击"的诱饵，允许驯服会让玩家白捡一只马上就被引爆的马。</li>
 * </ol>
 *
 * <p>驯服成功后补一次 {@code setPersistenceRequired()}：原版 {@code Mob#removeWhenFarAway} 对马
 * 恒返回 {@code true}，驮着玩家的坐骑在区块边界被"顺手卸掉"是丢马事故，钉死常驻即可。
 * 只有成功的那些会被钉住，判定失败的马仍是普通野马，不会因为有人试过几次就赖着不刷新。</p>
 */
public final class SkeletonHorseBoneMealTaming {
    /** 每份骨粉的成功率，三分之一，与狼吃骨头驯服对齐。 */
    private static final float TAME_CHANCE = 1.0F / 3.0F;

    private SkeletonHorseBoneMealTaming() {
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof SkeletonHorse horse)
                || !event.getItemStack().is(Items.BONE_MEAL)) {
            return;
        }
        if (horse.isTamed()
                || horse instanceof DullahanHorse
                || DullahanTrapSpawner.isTrapHorse(horse)) {
            return;
        }
        // 两侧一起取消：客户端不取消的话会自己往下走原版那条 PASS 分支，白做一次空交互。
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        Player player = event.getEntity();
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        // 成功失败都先吃掉骨粉：失败也有消耗，才有"一次一次试"的分量。
        event.getItemStack().consume(1, player);
        player.swing(event.getHand());
        level.playSound(null, horse, SoundEvents.BONE_MEAL_USE, SoundSource.NEUTRAL, 1.0F, 1.0F);
        if (horse.getRandom().nextFloat() < TAME_CHANCE) {
            // 主人 UUID + 驯服标记 + 成就 + 爱心粒子（实体事件 7）都在这里。
            horse.tameWithName(player);
            horse.setPersistenceRequired();
        } else {
            // 判定失败：只冒几缕骨粉烟、马打个响鼻。不弹动作条——原版生物驯服失败时也不给文字提示，
            // 玩家看"马没冒爱心"就知道没成，再右键就是再掷一次。
            level.sendParticles(ParticleTypes.SMOKE,
                    horse.getX(), horse.getY() + horse.getBbHeight() * 0.85, horse.getZ(),
                    6, 0.35, 0.25, 0.35, 0.01);
            level.playSound(null, horse, SoundEvents.SKELETON_HORSE_HURT,
                    SoundSource.NEUTRAL, 0.7F, 0.8F);
        }
    }
}
