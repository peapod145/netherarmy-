package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Blaze;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/** 烈焰人被凋零伤害或凋灵骷髅阵营击杀时转化为诡影使徒。 */
public final class ShadowApostleConversionHandler {
    private static final TagKey<EntityType<?>> WITHER_SKELETONS = TagKey.create(
            Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    private ShadowApostleConversionHandler() {
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (!(victim instanceof Blaze) || victim.level().isClientSide()
                || !(victim.level() instanceof ServerLevel level)) {
            return;
        }

        DamageSource source = event.getSource();
        Entity killer = source.getEntity();
        Entity direct = source.getDirectEntity();
        boolean witherDamage = source.is(DamageTypes.WITHER);
        boolean witherFaction = (killer != null && killer.getType().is(WITHER_SKELETONS))
                || (direct != null && direct.getType().is(WITHER_SKELETONS));
        if (!witherDamage && !witherFaction) {
            return;
        }

        ShadowApostle apostle = GeneratedMod.SHADOW_APOSTLE.get().create(level);
        if (apostle == null) {
            return;
        }
        apostle.moveTo(victim.getX(), victim.getY(), victim.getZ(), victim.getYRot(), victim.getXRot());
        apostle.finalizeSpawn(level, level.getCurrentDifficultyAt(apostle.blockPosition()),
                net.minecraft.world.entity.MobSpawnType.MOB_SUMMONED, null);
        apostle.setPersistenceRequired();
        victim.discard();
        level.addFreshEntity(apostle);
    }
}
