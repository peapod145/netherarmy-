package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.player.CanPlayerSleepEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 格尔多激活后的服务端状态、灵魂绑定与阵营刷怪逻辑。
 *
 * <p>发放规则：仅在玩家第一次进入世界时发放一个（用 {@link #GRANTED_TAG} 持久化标记），
 * 死亡重生、退出重进均不再补发；但背包里原有的格尔多死亡不会掉出，会原样保留。
 * 右键确认后物品消失（见 {@link GeardleItem#use} 与确认载荷）。</p>
 *
 * <p>激活后这一整套状态（阵营刷怪、夜晚致盲、背后格尔多、床/重生锚失效、随机下界重生）
 * 统称"格尔多效果"，可用 {@code /geardle on|off} 手动开关（{@link #setApocalypse}），
 * 命令入口见 {@link NetherArmyCommands}。</p>
 */
public final class GeardleHandler {
    public static final String GRANTED_TAG = "netherarmy_geardle_granted";
    public static final String APOCALYPSE_TAG = "netherarmy_geardle_apocalypse";
    /** 死亡瞬间从掉落中截下的格尔多暂存键，{@link #onPlayerClone} 读取后清除。 */
    private static final String KEPT_GEARDLE_TAG = "netherarmy_geardle_kept_stacks";
    /** 仅由客户端包处理器写入，服务端不读取。 */
    public static volatile boolean CLIENT_APOCALYPSE;
    /** 待客户端显示确认框的手：0 为主手，1 为副手，-1 表示没有待处理请求。 */
    public static volatile int CLIENT_PENDING_GEARDLE_HAND = -1;

    private static final int SPAWN_MIN_DISTANCE = 24;
    private static final int SPAWN_MAX_DISTANCE = 48;
    private static final int LOCAL_FACTION_CAP = 30;
    private static final TagKey<EntityType<?>> WITHER_SKELETONS = TagKey.create(
            Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    private GeardleHandler() {
    }

    public static boolean isApocalypse(Player player) {
        return player.getPersistentData().getBoolean(APOCALYPSE_TAG);
    }

    /**
     * 格尔多使用的“真正夜晚”判定：原版 {@link Level#isDay()} 在 1.21.1 实际读取
     * skyDarken（天气与天空亮度），不能用它判断昼夜。这里直接按 dayTime 周期计算：
     * 0 为日出，6000 为正午，12000 为日落，18000 为午夜。
     */
    public static boolean isNight(Level level) {
        long time = Math.floorMod(level.getDayTime(), Level.TICKS_PER_DAY);
        return time >= 13750L && time <= 22250L;
    }

    public static void activate(ServerPlayer player) {
        setApocalypse(player, true);
        player.displayClientMessage(Component.literal("D.I.E.").withStyle(ChatFormatting.RED), false);

        var advancement = player.server.getAdvancements().get(
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "depths_of_pain"));
        if (advancement != null) {
            player.getAdvancements().award(advancement, "use_geardle");
        }
    }

    /**
     * 手动开关"格尔多效果"（{@code /geardle on|off} 与右键使用格尔多共用这套状态机）。
     *
     * <p>开：置末日标记、锁定困难、同步客户端（背后格尔多渲染与夜晚遮罩由
     * {@link GeardleSync} 驱动）；关：清标记、撤掉夜晚残留的失明效果、同步客户端，
     * 场上再无任何激活玩家时顺手解开难度锁（数值保持困难，只撤销锁定）。
     * {@code /geardle on} 只复制右键使用产生的状况，不发 "D.I.E."、也不判
     * 【痛苦深处】成就——那枚成就的条件仍是"使用格尔多"物品。</p>
     *
     * @return 状态是否真的发生了翻转（本来就处于目标状态时返回 false）
     */
    public static boolean setApocalypse(ServerPlayer player, boolean active) {
        if (isApocalypse(player) == active) {
            return false;
        }
        player.getPersistentData().putBoolean(APOCALYPSE_TAG, active);
        MinecraftServer server = player.server;
        if (active) {
            server.setDifficulty(Difficulty.HARD, true);
            GeardleSync.sendState(player, true);
        } else {
            player.removeEffect(net.minecraft.world.effect.MobEffects.BLINDNESS);
            GeardleSync.sendState(player, false);
            boolean anyActive = server.getPlayerList().getPlayers().stream()
                    .anyMatch(GeardleHandler::isApocalypse);
            if (!anyActive) {
                // 数值保持不变，只撤销“锁定困难”：这是格尔多激活时顺手加的锁。
                server.setDifficulty(server.getWorldData().getDifficulty(), false);
            }
        }
        return true;
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        // 格尔多只在玩家“第一次进入世界”时发放一次；此后退出重进都不再额外获得。
        CompoundTag data = player.getPersistentData();
        if (!data.contains(GRANTED_TAG)) {
            data.putBoolean(GRANTED_TAG, true);
            player.getInventory().add(new ItemStack(GeneratedMod.GEARDLE.get()));
        }
        GeardleSync.sendState(player, isApocalypse(player));
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        // 死亡重生不再补发格尔多：原有的格尔多由 onLivingDrops + onPlayerClone
        // 原样保留在背包里。
        GeardleSync.sendState(player, isApocalypse(player));
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        Collection<ItemEntity> drops = event.getDrops();
        List<ItemEntity> bound = new ArrayList<>();
        for (ItemEntity drop : drops) {
            if (drop.getItem().is(GeneratedMod.GEARDLE.get())) {
                bound.add(drop);
            }
        }
        if (bound.isEmpty()) {
            return;
        }
        // 灵魂绑定：格尔多不以物品实体形式掉出，暂存进将死玩家的持久化数据，
        // 待 PlayerEvent.Clone 原样放回新背包。
        drops.removeAll(bound);
        ListTag kept = new ListTag();
        for (ItemEntity drop : bound) {
            kept.add(drop.getItem().save(player.server.registryAccess()));
        }
        player.getPersistentData().put(KEPT_GEARDLE_TAG, kept);
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || !(event.getOriginal() instanceof ServerPlayer original)) {
            return;
        }
        boolean apocalypse = original.getPersistentData().getBoolean(APOCALYPSE_TAG);
        boolean granted = original.getPersistentData().getBoolean(GRANTED_TAG);
        player.getPersistentData().putBoolean(APOCALYPSE_TAG, apocalypse);
        player.getPersistentData().putBoolean(GRANTED_TAG, granted || apocalypse);
        // 把死亡瞬间从掉落里截下的格尔多原样放回新背包（不是重新发放）。
        ListTag kept = original.getPersistentData().getList(KEPT_GEARDLE_TAG, Tag.TAG_COMPOUND);
        player.getPersistentData().remove(KEPT_GEARDLE_TAG);
        for (int i = 0; i < kept.size(); i++) {
            ItemStack stack = ItemStack.parseOptional(player.server.registryAccess(), kept.getCompound(i));
            if (!stack.isEmpty()) {
                player.getInventory().add(stack);
            }
        }
        if (event.isWasDeath() && apocalypse
                && original.getRespawnPosition() == null
                && player.getRespawnPosition() == null) {
            BlockPos randomNetherPosition = findRandomNetherPosition(player.server);
            if (randomNetherPosition != null) {
                player.setRespawnPosition(Level.NETHER, randomNetherPosition, 0.0F, true, false);
            }
        }
    }

    @SubscribeEvent
    public static void onItemToss(ItemTossEvent event) {
        ItemEntity itemEntity = event.getEntity();
        if (!itemEntity.getItem().is(GeneratedMod.GEARDLE.get())) {
            return;
        }
        event.setCanceled(true);
        if (event.getPlayer() instanceof ServerPlayer player && player.isAlive()) {
            player.getInventory().add(itemEntity.getItem().copy());
        }
    }

    @SubscribeEvent
    public static void onSleep(CanPlayerSleepEvent event) {
        if (isApocalypse(event.getEntity())) {
            event.setProblem(Player.BedSleepingProblem.NOT_POSSIBLE_NOW);
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !isApocalypse(player)) {
            return;
        }
        BlockState state = event.getLevel().getBlockState(event.getPos());
        if (state.is(BlockTags.BEDS) || state.is(Blocks.RESPAWN_ANCHOR)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!event.getItemStack().is(GeneratedMod.GEARDLE.get())) {
            return;
        }
        if (event.getTarget() instanceof ItemFrame || event.getTarget() instanceof ArmorStand) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        List<ServerPlayer> grantedPlayers = new ArrayList<>();
        List<ServerPlayer> activePlayers = new ArrayList<>();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.getPersistentData().getBoolean(GRANTED_TAG)) {
                grantedPlayers.add(player);
            }
            if (isApocalypse(player)) {
                activePlayers.add(player);
            }
        }
        if (grantedPlayers.isEmpty()) {
            return;
        }

        long tick = server.getTickCount();
        if (tick % 20L == 0L) {
            for (ServerPlayer player : grantedPlayers) {
                recoverFromOpenContainer(player);
            }
        }
        if (activePlayers.isEmpty()) {
            return;
        }
        if (tick % 100L == 0L) {
            var data = server.getWorldData();
            if (data.getDifficulty() != Difficulty.HARD || !data.isDifficultyLocked()) {
                server.setDifficulty(Difficulty.HARD, true);
            }
        }
        if (tick % 10L == 0L) {
            for (ServerPlayer player : activePlayers) {
                updateNightEffect(player);
                trySpawnAround(player);
            }
        }
    }

    private static void updateNightEffect(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        boolean night = level.dimensionType().hasSkyLight() && isNight(level);
        if (night) {
            player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.BLINDNESS, 40, 0));
        } else {
            player.removeEffect(net.minecraft.world.effect.MobEffects.BLINDNESS);
        }
    }

    private static void recoverFromOpenContainer(ServerPlayer player) {
        if (countGeardles(player) > 0 || player.containerMenu == player.inventoryMenu) {
            return;
        }
        for (var slot : player.containerMenu.slots) {
            if (slot.container == player.getInventory() || !slot.getItem().is(GeneratedMod.GEARDLE.get())) {
                continue;
            }
            ItemStack stack = slot.getItem().copy();
            if (player.getInventory().add(stack)) {
                slot.set(ItemStack.EMPTY);
                return;
            }
        }
    }

    private static void trySpawnAround(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (countFactionMobs(level, player) >= LOCAL_FACTION_CAP) {
            return;
        }
        List<EntityType<?>> types = factionSpawnTypes(level);
        if (types.isEmpty()) {
            return;
        }
        for (int attempt = 0; attempt < 2; attempt++) {
            if (countFactionMobs(level, player) >= LOCAL_FACTION_CAP) {
                return;
            }
            var random = level.random;
            EntityType<?> type = types.get(random.nextInt(types.size()));
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = SPAWN_MIN_DISTANCE + random.nextDouble()
                    * (SPAWN_MAX_DISTANCE - SPAWN_MIN_DISTANCE);
            int x = (int) Math.floor(player.getX() + Math.cos(angle) * distance);
            int z = (int) Math.floor(player.getZ() + Math.sin(angle) * distance);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.isLoaded(pos) || !level.getWorldBorder().isWithinBounds(pos)
                    || tooCloseToAnyPlayer(level, pos)) {
                continue;
            }
            if (!SpawnPlacements.isSpawnPositionOk(type, level, pos)
                    || !SpawnPlacements.checkSpawnRules(type, level, MobSpawnType.NATURAL, pos, random)) {
                continue;
            }
            if (!(type.create(level) instanceof Mob mob)) {
                continue;
            }
            mob.moveTo(x + 0.5D, y, z + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            if (!level.noCollision(mob) || level.containsAnyLiquid(mob.getBoundingBox())) {
                mob.discard();
                continue;
            }
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.NATURAL, null);
            level.addFreshEntity(mob);
        }
    }

    private static boolean tooCloseToAnyPlayer(ServerLevel level, BlockPos pos) {
        double minDistanceSquared = SPAWN_MIN_DISTANCE * (double) SPAWN_MIN_DISTANCE;
        for (ServerPlayer other : level.players()) {
            if (other.distanceToSqr(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D) < minDistanceSquared) {
                return true;
            }
        }
        return false;
    }

    private static int countFactionMobs(ServerLevel level, ServerPlayer player) {
        AABB area = player.getBoundingBox().inflate(SPAWN_MAX_DISTANCE);
        return level.getEntitiesOfClass(Mob.class, area,
                mob -> mob.getType().is(WITHER_SKELETONS) || mob instanceof DullhanHead).size();
    }

    /**
     * 格尔多刷怪候选池：{@code #minecraft:wither_skeletons} 标签里的阵营成员。
     *
     * <p>两只 BOSS 性质的实体也挂在这个标签里（为了阵营敌我判定），但它们只能靠祭坛仪式
     * 召唤，绝不允许被格尔多当普通阵营怪刷出来：原版凋灵与霸主凋灵都在这里显式剔除。</p>
     *
     * <p>床战士同样剔除：它是凋灵低血时的仪式性召唤物（数量由凋灵决定），不该被格尔多
     * 当成普通阵营怪成批刷出来。它仍在 {@code #minecraft:wither_skeletons} 标签里，
     * 阵营敌我判定与 {@link #countFactionMobs} 的局部密度统计都不受影响。</p>
     */
    private static List<EntityType<?>> factionSpawnTypes(ServerLevel level) {
        List<EntityType<?>> types = new ArrayList<>();
        var lookup = level.registryAccess().lookupOrThrow(Registries.ENTITY_TYPE);
        for (Holder<EntityType<?>> holder : lookup.getOrThrow(WITHER_SKELETONS)) {
            EntityType<?> type = holder.value();
            if (type == EntityType.WITHER || type == GeneratedMod.OVERLORD_WITHER.get()
                    || type == GeneratedMod.BEDSERKER.get()) {
                continue;
            }
            types.add(type);
        }
        return types;
    }

    private static int countGeardles(ServerPlayer player) {
        return player.getInventory().countItem(GeneratedMod.GEARDLE.get());
    }

    private static BlockPos findRandomNetherPosition(MinecraftServer server) {
        ServerLevel nether = server.getLevel(Level.NETHER);
        if (nether == null) {
            return null;
        }
        for (int i = 0; i < 12; i++) {
            double angle = nether.random.nextDouble() * Math.PI * 2.0D;
            double radius = 200.0D + nether.random.nextDouble() * 1000.0D;
            int x = (int) Math.floor(Math.cos(angle) * radius);
            int z = (int) Math.floor(Math.sin(angle) * radius);
            BlockPos pos = nether.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));
            if (pos.getY() <= nether.getMinBuildHeight() || pos.getY() >= nether.getMaxBuildHeight() - 2) {
                continue;
            }
            if (nether.getFluidState(pos).isEmpty()
                    && nether.getFluidState(pos.above()).isEmpty()
                    && nether.getBlockState(pos.below()).isSolid()) {
                return pos;
            }
        }
        return null;
    }
}
