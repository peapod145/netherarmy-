package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.List;

/**
 * 床战士模型：几何和动画都按用户提供的 bedserker-3.bbmodel 机械烘焙。
 *
 * <p>bbmodel 层级是 bone → skeleton_body → (body/bed/head/arms/legs)。
 * sleep 动画绕 bone 枢轴 [4.25, 19, 1.5] 转 Blockbench +90°X（Java 为 -90°X），
 * 同时 bone 下移 9、skeleton_body 上移 2。walk 只摆腿，符号与 bbmodel 关键帧一致。</p>
 */
public final class BedserkerModel extends SkeletonModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "bedserker"), "main");

    /**
     * bone 骨骼 origin [4.25, 19, 1.5] 换到 Java 坐标：
     * Java_y = 24 - 19 = 5。X 枢轴不参与旋转（绕 X 轴转时 x 不变）。
     */
    private static final float SLEEP_PIVOT_Y = 5.0F;
    private static final float SLEEP_PIVOT_Z = 1.5F;

    private final ModelPart bed;
    private final ModelPart[] sleepParts;

    public BedserkerModel(ModelPart root) {
        super(root);
        this.bed = root.getChild("bed");
        this.sleepParts = new ModelPart[]{
                this.head, this.body, this.bed,
                this.rightArm, this.leftArm, this.rightLeg, this.leftLeg
        };
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), PartPose.ZERO);

        // 手臂元素绕 [0,22,-5] 转了 Blockbench +90°X。Java 侧把旋转放到部件上，
        // cube 用 addBox(-1,-1,-1,2,12,2)，世界占位 z -11..1、y 1..3，手持物也跟着前伸。
        root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(40, 16).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offsetAndRotation(-5.0F, 2.0F, 0.0F, -Mth.HALF_PI, 0.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror()
                .texOffs(40, 16).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offsetAndRotation(5.0F, 2.0F, 0.0F, -Mth.HALF_PI, 0.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror()
                .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(1.9F, 12.0F, 0.0F));

        addRopes(body);

        // 床组挂在根上，sleep 时与 skeleton_body 一起绕 bone 枢轴旋转（新 bbmodel 里
        // bed 是 skeleton_body 的子骨骼，所以也吃 skeleton_body 的 +2 位移）。
        PartDefinition bed = root.addOrReplaceChild("bed", CubeListBuilder.create(), PartPose.ZERO);
        bed.addOrReplaceChild("bed_head", CubeListBuilder.create()
                .texOffs(0, 43).addBox(-8.0F, -10.0F, 2.5F, 16.0F, 16.0F, 6.0F), PartPose.ZERO);
        bed.addOrReplaceChild("bed_foot", CubeListBuilder.create()
                .texOffs(0, 65).addBox(-8.0F, 6.0F, 2.5F, 16.0F, 16.0F, 6.0F), PartPose.ZERO);
        bed.addOrReplaceChild("leg1", CubeListBuilder.create()
                .texOffs(50, 49).addBox(5.0F, -10.0F, 8.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        bed.addOrReplaceChild("leg2", CubeListBuilder.create()
                .texOffs(50, 61).addBox(-8.0F, -10.0F, 8.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        bed.addOrReplaceChild("leg3", CubeListBuilder.create()
                .texOffs(50, 43).addBox(5.0F, 19.0F, 8.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        bed.addOrReplaceChild("leg4", CubeListBuilder.create()
                .texOffs(50, 55).addBox(-8.0F, 19.0F, 8.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 128, 128);
    }

    /** 绑床的两圈绳结，坐标按 bbmodel 世界坐标直接落到 body 局部（body 枢轴在 Java 原点）。 */
    private static void addRopes(PartDefinition body) {
        float[][] upper = {
                {-3, 0, -2.5F, 0}, {0, 0, -2.5F, 0}, {3, 0, -2.5F, 0}, {5, 0, -1.5F, 0},
                {-6, 0, -2.5F, 0}, {-8, 0, -1.5F, 0},
                {-8, 0, -0.5F, 2}, {-9, 0, 1.5F, 2}, {-9, 0, 3.5F, 2}, {-9, 0, 6.5F, 2},
                {-8, 0, 8.5F, 0}, {-6, 0, 8.5F, 0}, {-3, 0, 8.5F, 0}, {0, 0, 8.5F, 0},
                {2, 0, 8.5F, 0}, {5, 0, 8.5F, 0},
                {8, 0, 6.5F, 2}, {8, 0, 3.5F, 2}, {8, 0, 1.5F, 2}, {7, 0, -0.5F, 2}
        };
        int index = 0;
        for (float[] point : upper) {
            addRope(body, "rope_u_" + index++, point, 0.0F);
            addRope(body, "rope_l_" + index++, point, 6.0F);
        }
    }

    private static void addRope(PartDefinition body, String name, float[] point, float y) {
        CubeListBuilder cube = CubeListBuilder.create();
        if (point[3] == 0.0F) {
            cube.texOffs(52, 45).addBox(point[0], y, point[2], 3.0F, 1.0F, 1.0F);
        } else {
            cube.texOffs(52, 43).addBox(point[0], y, point[2], 1.0F, 1.0F, 3.0F);
        }
        body.addOrReplaceChild(name, cube, PartPose.ZERO);
    }

    @Override
    protected Iterable<ModelPart> bodyParts() {
        return List.of(this.body, this.bed, this.rightArm, this.leftArm, this.rightLeg, this.leftLeg);
    }

    @Override
    public void setupAnim(net.minecraft.world.entity.Mob entity, float limbSwing,
                          float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        // 每帧先回到初始姿势，避免 sleep 位移叠在上一帧的 y/z 上。
        for (ModelPart part : this.sleepParts) {
            part.resetPose();
        }
        this.hat.resetPose();

        net.minecraft.world.entity.monster.AbstractSkeleton skeleton =
                (net.minecraft.world.entity.monster.AbstractSkeleton) entity;
        boolean sleeping = entity instanceof Bedserker bedserker && bedserker.isSleepingState();
        // sleep 期间锁死头身转向，避免父类再把脑袋拧向目标。
        super.setupAnim(skeleton, sleeping ? 0.0F : limbSwing, sleeping ? 0.0F : limbSwingAmount,
                ageInTicks, sleeping ? 0.0F : netHeadYaw, sleeping ? 0.0F : headPitch);
        if (!(entity instanceof Bedserker bedserker)) {
            return;
        }

        // 床战士没有攻击动画，双臂始终保持烘焙时的前伸姿态。
        this.rightArm.xRot = -Mth.HALF_PI;
        this.leftArm.xRot = -Mth.HALF_PI;
        this.rightArm.yRot = 0.0F;
        this.leftArm.yRot = 0.0F;
        this.rightArm.zRot = 0.0F;
        this.leftArm.zRot = 0.0F;
        this.rightLeg.yRot = 0.0F;
        this.leftLeg.yRot = 0.0F;
        this.rightLeg.zRot = 0.0F;
        this.leftLeg.zRot = 0.0F;

        // walk：bbmodel 右腿 0s=-25°、0.5s=+25°，Java xRot = -BB，所以右腿 0s=+25°。
        if (!sleeping) {
            float walkPhase = limbSwing * 0.6662F;
            float walk = Mth.cos(walkPhase) * (25.0F * Mth.DEG_TO_RAD) * limbSwingAmount;
            this.rightLeg.xRot = walk;
            this.leftLeg.xRot = -walk;
        } else {
            this.head.xRot = 0.0F;
            this.head.yRot = 0.0F;
            this.hat.copyFrom(this.head);
            this.rightLeg.xRot = 0.0F;
            this.leftLeg.xRot = 0.0F;
        }

        if (!sleeping) {
            return;
        }

        float sleep = bedserker.getSleepProgress(ageInTicks - bedserker.tickCount);
        if (sleep <= 0.0F) {
            return;
        }

        // Blockbench bone.rotation.x = +90° → Java xRot = -90°（向后仰倒）。
        // skeleton_body.position = (0, +2, 0) → Java (0, -2, 0)。
        // bone.position = (0, -9, 0) → Java (0, +9, 0)。
        float rootRotation = -Mth.HALF_PI * sleep;
        float cos = Mth.cos(rootRotation);
        float sin = Mth.sin(rootRotation);
        for (ModelPart part : this.sleepParts) {
            transformForSleep(part, sleep, cos, sin, rootRotation);
        }
        this.hat.copyFrom(this.head);
    }

    private void transformForSleep(ModelPart part, float sleep, float cos, float sin,
                                   float rootRotation) {
        float localY = part.y - 2.0F * sleep;
        float localZ = part.z;
        float relativeY = localY - SLEEP_PIVOT_Y;
        float relativeZ = localZ - SLEEP_PIVOT_Z;
        part.y = SLEEP_PIVOT_Y + relativeY * cos - relativeZ * sin + 9.0F * sleep;
        part.z = SLEEP_PIVOT_Z + relativeY * sin + relativeZ * cos;
        part.xRot += rootRotation;
    }
}
