package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;

/**
 * 结构放置后的容器扫描与洗牌工具。
 *
 * <p>由于 1.21.1 的结构放置按“当前生成 chunk 的列”裁剪（
 * {@code ChunkGenerator#getWritableArea} → {@code StructurePiece#postProcess}），
 * 每个方块只会被所属 chunk 的那趟放置写一次，{@code afterPlace} 也只在同一趟里被
 * 调用一次，因此逐 chunk 扫描不会重复处理，也没有跨线程竞态。
 */
final class StructureContainers {

    /** 容器访问回调。{@code barrel} 为 true 表示木桶，false 表示箱子。 */
    @FunctionalInterface
    interface Visitor {
        void visit(RandomizableContainer container, boolean barrel);
    }

    private StructureContainers() {
    }

    /**
     * 扫描本次放置落在当前可写区域内的箱子/木桶，逐个交给 {@code visitor}。
     * 带战利品表的容器交给原版机制，不会被回调。
     */
    static void forEachFixedContainer(WorldGenLevel level, BoundingBox writableArea,
                                      PiecesContainer pieces, Visitor visitor) {
        for (StructurePiece piece : pieces.pieces()) {
            BoundingBox pieceBox = piece.getBoundingBox();
            int minX = Math.max(writableArea.minX(), pieceBox.minX());
            int minY = Math.max(writableArea.minY(), pieceBox.minY());
            int minZ = Math.max(writableArea.minZ(), pieceBox.minZ());
            int maxX = Math.min(writableArea.maxX(), pieceBox.maxX());
            int maxY = Math.min(writableArea.maxY(), pieceBox.maxY());
            int maxZ = Math.min(writableArea.maxZ(), pieceBox.maxZ());
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        cursor.set(x, y, z);
                        BlockState state = level.getBlockState(cursor);
                        boolean barrel = state.is(Blocks.BARREL);
                        boolean chest = state.is(Blocks.CHEST) || state.is(Blocks.TRAPPED_CHEST);
                        if (!barrel && !chest) {
                            continue;
                        }
                        BlockEntity blockEntity = level.getBlockEntity(cursor);
                        if (!(blockEntity instanceof RandomizableContainer container)) {
                            continue;
                        }
                        if (container.getLootTable() != null) {
                            continue;
                        }
                        visitor.visit(container, barrel);
                    }
                }
            }
        }
    }

    /** 取出容器里所有非空物品堆（复制副本）。 */
    static List<ItemStack> collect(RandomizableContainer container) {
        List<ItemStack> stacks = new ArrayList<>();
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (!stack.isEmpty()) {
                stacks.add(stack.copy());
            }
        }
        return stacks;
    }

    /** 清空后把每堆物品放进互不相同的随机槽位。 */
    static void placeInto(RandomizableContainer container, List<ItemStack> stacks, RandomSource random) {
        int capacity = container.getContainerSize();
        container.clearContent();
        List<Integer> slots = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            slots.add(i);
        }
        fisherYates(slots, random);
        int n = Math.min(stacks.size(), capacity);
        for (int i = 0; i < n; i++) {
            container.setItem(slots.get(i), stacks.get(i));
        }
    }

    static <T> void fisherYates(List<T> list, RandomSource random) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            T tmp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, tmp);
        }
    }
}
