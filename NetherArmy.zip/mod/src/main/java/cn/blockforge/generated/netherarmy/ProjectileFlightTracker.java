package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;

import cn.blockforge.generated.netherarmy.mixin.AbstractArrowInGroundAccessMixin;

/**
 * 抛射物"真的在飞行"判定器，供抛射物闪避目标（下界猎手与衰翼的 ProjectileDodgeGoal）共用。
 *
 * <p><b>要解决的问题：</b>原版箭矢插进方块后（{@code AbstractArrow.onHitBlock}），
 * {@code getDeltaMovement()} 并不清零——它被改写成"命中点相对方块原点的偏移"，作为
 * 插地姿态的渲染提示，是个永久的非零常量向量。因此只按速度大小过滤静止抛射物拦不住
 * 落地箭，且这个假速度还可能通过弹道会合判定，导致生物对着一根钉在地上的箭反复闪避。</p>
 *
 * <p><b>为什么不再用位移历史核验：</b>早期版本按"相邻两次观测之间有没有实际位移"判定，
 * 首观测一律算"未确认"。可 GoalSelector 对未运行的目标每隔 1 tick 才试一次
 * {@code canUse()}，一支新飞来的箭要等到第 2～3 次观测才被承认，等于给每一次闪避
 * 都垫了 2～4 tick 的反应延迟；箭矢飞行寿命本就只有几个 tick，近距离直射干脆不再触发
 * 躲避——观感就是"闪避变迟钝了"。</p>
 *
 * <p><b>现在的判定：</b>直接读原版自己维护的权威状态 {@code AbstractArrow.inGround}
 * （经 {@link AbstractArrowInGroundAccessMixin} 放开）。插地当 tick 即为 true、直到
 * 抛射物移除都不会翻转，误报彻底清零；而飞行中的箭（含三叉戟）零延迟识别，命中方块
 * 前每一 tick 都可信。"插进实体"的箭会随 {@code onHitEntity} 被移除，不在此列。
 * 其余抛射物（雪球、卵、药水、火球、凋灵之首等）命中方块即消失，不存在留场的假速度，
 * 一律放行。静态无状态判定，每只怪不再各持一份观测表。</p>
 */
final class ProjectileFlightTracker {

    private ProjectileFlightTracker() {
    }

    /**
     * 该抛射物此刻是否真的在飞。唯一要剔除的是插进方块的箭/三叉戟
     * （原版用 {@code inGround} 精确标记了这个状态）。
     */
    static boolean isActuallyFlying(Projectile projectile) {
        if (projectile instanceof AbstractArrow) {
            return !((AbstractArrowInGroundAccessMixin) projectile).netherarmy$isInGround();
        }
        return true;
    }
}
