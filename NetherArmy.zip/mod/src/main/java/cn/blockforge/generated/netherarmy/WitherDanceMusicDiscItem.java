package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 凋灵舞曲唱片。
 *
 * <p>播放能力完全走原版通道：物品默认组件 {@code minecraft:jukebox_playable} 在
 * {@link GeneratedMod#MUSIC_DISC_WITHER_DANCE} 注册时指向数据包条目
 * {@code netherarmy:wither_dance}（{@code data/netherarmy/jukebox_song/wither_dance.json}），
 * 唱片机入仓校验、比较器输出、"正在播放"提示都由原版结算。</p>
 *
 * <p>这里唯一的定制点是物品名颜色：需求为淡紫色（§d LIGHT_PURPLE），而原版唱片的
 * 名字颜色来自稀有度（RARE → 青色），稀有度色会盖住语言文件文本，所以直接覆写
 * {@link Item#getName(ItemStack)} 在译名上挂样式。稀有度保持默认 COMMON（颜色为空），
 * 提示框组装时 {@code Rarity#getStyleModifier} 是恒等变换，不会覆盖这里的淡紫色。</p>
 */
public class WitherDanceMusicDiscItem extends Item {

    public WitherDanceMusicDiscItem(Properties properties) {
        super(properties);
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable(this.getDescriptionId(stack)).withStyle(ChatFormatting.LIGHT_PURPLE);
    }

    /** 灰色描述：《Minecraft VS Zombies2》中的音乐。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.music_disc_wither_dance.tooltip")
                .withStyle(ChatFormatting.GRAY));
    }
}
