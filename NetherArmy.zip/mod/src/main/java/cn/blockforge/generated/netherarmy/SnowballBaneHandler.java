package cn.blockforge.generated.netherarmy;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Snowball;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 雪球克制诡影使徒与熔髓：命中时改为 4 点魔法伤害（无视护甲与穿透）。
 *
 * <p>原版 1.21.1 的雪球只对 {@code instanceof Blaze} 的目标结算 3 点投掷伤害，其余目标为 0 点。
 * 诡影使徒虽然继承 Blaze，吃到的也只是这 3 点可被护甲减免的 thrown 伤害，熔髓则完全不痛不痒。
 * 这里把两者统一替换成 4 点 magic 伤害：伤害类型换成魔法后，护甲、刺穿与弹射物保护都不再参与结算
 * （保护附魔与抗性效果按原版规则仍照常减免魔法伤害）。</p>
 */
public final class SnowballBaneHandler {
    private static final float BANE_DAMAGE = 4.0F;

    private SnowballBaneHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled() || event.getEntity().level().isClientSide()) {
            return;
        }

        DamageSource source = event.getSource();
        if (!(source.getDirectEntity() instanceof Snowball)) {
            return;
        }

        LivingEntity target = event.getEntity();
        if (!(target instanceof ShadowApostle) && !(target instanceof Emberbone)) {
            return;
        }

        // 取消原投掷伤害，改结算 4 点魔法伤害。新源只记 thrower 为 cause、不给 direct，
        // 既保留玩家击杀归属（掉落、经验照常计入投掷者），又不会被本 handler 再次命中形成循环。
        event.setCanceled(true);
        Entity owner = source.getEntity();
        DamageSource magic = owner != null
                ? target.level().damageSources().source(DamageTypes.MAGIC, owner)
                : target.level().damageSources().magic();
        target.hurt(magic, BANE_DAMAGE);
    }
}
