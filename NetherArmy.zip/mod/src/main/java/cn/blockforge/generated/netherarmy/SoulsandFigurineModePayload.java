package cn.blockforge.generated.netherarmy;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 客户端请求切换某个灵魂土偶的行为模式。
 *
 * <p>只带实体 id，不带目标模式：由服务端在自己的当前模式上 {@code next()}，
 * 这样连点按钮也不会因为客户端同步延迟而卡在同一档。</p>
 */
public record SoulsandFigurineModePayload(int entityId) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SoulsandFigurineModePayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(
                    GeneratedMod.MOD_ID, "soulsand_figurine_mode"));
    public static final StreamCodec<ByteBuf, SoulsandFigurineModePayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT,
                    SoulsandFigurineModePayload::entityId,
                    SoulsandFigurineModePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
