package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.NetherArmyFortressStructure;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.BuiltinStructures;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureCheck;
import net.minecraft.world.level.levelgen.structure.StructureCheckResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * /locate 的旧存档兼容：把区域文件里已保存的 {@code minecraft:fortress} 起点认作
 * {@code netherarmy:fortress} 的起点。
 *
 * <p>1.21.1 的 {@code /locate structure} 在主线程逐候选区块调用
 * {@code StructureCheck#checkStart}：先查区域文件里存的 {@code structures.starts}，
 * 查不到就按 {@code findGenerationPoint} 预判定、必要时同步生成候选区块再确认。
 * 本模组把要塞换成了新注册 ID {@code netherarmy:fortress}，旧区域文件里保存的起点
 * 键仍是 {@code minecraft:fortress}——新 ID 查不到，旧数据又明明就是同一座要塞，
 * 导致搜索半径 100 格（约 4.3 万区块格）的每个已生成候选都要重新走一遍昂贵的确认
 * 流程，游戏表现为命令一敲整个服务端瞬间停摆。</p>
 *
 * <p>本注入只重定向 {@code checkStructureInfo} 的两个真实调用点（{@code checkStart}
 * 的缓存路径与 {@code tryLoadFromStorage} 的首次区域扫描路径）：两者拿到的都是
 * “该区块已保存的起点引用表”，此时对新 ID 查无的 {@code netherarmy:fortress} 直接
 * 在同一张表里查 {@code minecraft:fortress} 的引用计数，命中即返回
 * {@code START_PRESENT}——locate 于是沿用原版路径即时返回，不加载也不生成任何区块。
 * 未生成的新区块不会到达这两个调用点，其预判由 {@link NetherArmyFortressStructure}
 * 的抽签闸门负责。</p>
 */
@Mixin(StructureCheck.class)
public abstract class NetherFortressLocateAliasMixin {
    @Shadow
    private RegistryAccess registryAccess;

    @Invoker("checkStructureInfo")
    abstract StructureCheckResult netherarmy$invokeCheckStructureInfo(Object2IntMap<Structure> starts,
                                                                      Structure structure,
                                                                      boolean skipGenerated);

    @Redirect(
            method = {"checkStart", "tryLoadFromStorage"},
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/level/levelgen/structure/StructureCheck;checkStructureInfo(Lit/unimi/dsi/fastutil/objects/Object2IntMap;Lnet/minecraft/world/level/levelgen/structure/Structure;Z)Lnet/minecraft/world/level/levelgen/structure/StructureCheckResult;")
    )
    private StructureCheckResult netherarmy$aliasLegacyFortressStart(StructureCheck self,
                                                                     Object2IntMap<Structure> starts,
                                                                     Structure structure,
                                                                     boolean skipGenerated) {
        StructureCheckResult result = this.netherarmy$invokeCheckStructureInfo(starts, structure, skipGenerated);
        if (result != StructureCheckResult.START_NOT_PRESENT
                || !(structure instanceof NetherArmyFortressStructure)) {
            return result;
        }
        Structure legacyFortress =
                this.registryAccess.registryOrThrow(Registries.STRUCTURE).get(BuiltinStructures.FORTRESS);
        if (legacyFortress == null) {
            return result;
        }
        int references = starts.getOrDefault(legacyFortress, -1);
        // 与 checkStructureInfo 对 minecraft:fortress 的判定完全同款：无该键为不存在；
        // skipGenerated 时只认引用计数为 0 的条目。
        if (references == -1 || (skipGenerated && references != 0)) {
            return result;
        }
        return StructureCheckResult.START_PRESENT;
    }
}
