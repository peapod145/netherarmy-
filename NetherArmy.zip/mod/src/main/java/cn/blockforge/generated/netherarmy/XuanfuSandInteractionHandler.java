package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.util.TriState;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * 为萱浮的沙子放行“潜行持物”的方块交互。
 *
 * <p>原版在玩家潜行且手上物品不满足 sneak-bypass 条件时，会直接跳过方块的
 * {@code useItemOn} / {@code useWithoutItem}，因此手持糖潜行右键本来永远摸不到
 * {@link XuanfuSandBlock} 的收取逻辑。这里监听 NeoForge 的
 * {@code PlayerInteractEvent.RightClickBlock}，仅当被点的方块是萱浮的沙子、
 * 玩家处于潜行且主手或副手持有糖时，把 {@code useBlock} 显式置为
 * {@link TriState#TRUE}，强行让方块收到这次右键。除此之外不改动任何交互。</p>
 */
public final class XuanfuSandInteractionHandler {

    private XuanfuSandInteractionHandler() {
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getLevel().getBlockState(event.getPos()).getBlock() instanceof XuanfuSandBlock)) {
            return;
        }
        Player player = event.getEntity();
        if (player.isSecondaryUseActive() && XuanfuSandBlock.isHoldingSugar(player)) {
            event.setUseBlock(TriState.TRUE);
        }
    }
}
