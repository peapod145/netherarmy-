package cn.blockforge.generated.netherarmy;

import net.minecraft.world.damagesource.DamageTypes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** 将标记为灵魂火的实体的持续燃烧伤害提升到灵魂火的 2 点。 */
public final class SoulFireDamageHandler {
    private SoulFireDamageHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!SoulFireBurn.isSoulFlame(event.getEntity())
                || !(event.getSource().is(DamageTypes.ON_FIRE) || event.getSource().is(DamageTypes.IN_FIRE))
                || event.getAmount() <= 0.0F) {
            return;
        }
        event.setAmount(event.getAmount() * 2.0F);
    }
}
