package cn.blockforge.generated.netherarmy;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * 床战士：凋灵骷髅阵营的床形变种。
 *
 * <p>它保留狂战士的阵营身份与头盔（不再自带金斧，也不拾取武器），索敌 30 格，
 * 每存在 1 秒移动速度提高 5%。删除所有攻击目标，只会追近目标。存在 200 tick
 * 后在非主世界进行一次 10.0 威力、带火焰的虚空伤害爆炸；主世界则播放并保持 sleep
 * 动画末帧，动画播完（10 tick）后碰撞箱切换成躺倒模型的外接盒。正常被杀死时沿用
 * 狂战士的死亡爆炸处理。</p>
 */
public class Bedserker extends Berserker {
    private static final int DETONATION_TICKS = 200;
    /** sleep 动画时长（tick）：模型插值和碰撞箱切换都以它为准。 */
    private static final int SLEEP_ANIMATION_TICKS = 10;
    /**
     * 站姿碰撞箱（格），与注册进 {@code EntityType.Builder#sized} 的值同一份常量。
     * 对应站姿模型外接盒：宽 1.2、高 2.55（床头板略高于箱体）。
     */
    public static final EntityDimensions STANDING_DIMENSIONS = EntityDimensions.scalable(1.25F, 2.4F);
    /**
     * 躺倒后的 {@code EntityDimensions}：宽 1.2 取床的实际宽度（比站姿的 1.25 还小，
     * 这样原版"尺寸变大就挤位置"的修正不会被触发），高 1.7 取到模型手臂顶端
     * （1.6875 向上取整）。底面那圈贴合床形的长方形由 {@link #makeBoundingBox()}
     * 按锁定朝向展开成世界轴外接盒，长度方向不在这里体现。
     */
    public static final EntityDimensions LYING_DIMENSIONS = EntityDimensions.scalable(1.2F, 1.7F);
    /**
     * sleep 末帧模型相对实体轴心的底面范围（格，已乘渲染缩放 1.2）：
     * 左右各 0.60；身前 1.1625（伸直的腿）；身后 1.3875（床头板与床腿）。
     * 数值由 tools/bedserker/hitbox_bounds.py 逐顶点量出，脚本末尾还比对了
     * 旋转后的真实外接盒与本类 makeBoundingBox 的公式。
     */
    private static final double LYING_HALF_WIDTH = 0.60D;
    private static final double LYING_FRONT = 1.1625D;
    private static final double LYING_BACK = 1.3875D;
    /** 索敌范围（格）：需求规定 30 格，写进 FOLLOW_RANGE 供原版目标选择器读取。 */
    private static final double FOLLOW_RANGE_BLOCKS = 30.0D;
    /** 初始移速，与狂战士一致；随存在时间按秒复利放大。 */
    private static final double BASE_MOVEMENT_SPEED = 0.375D;
    /** 每存在 1 秒，移速在当前基础上提高 5%（复利：n 秒后为底速 × 1.05^n）。 */
    private static final double SPEED_RAMP_PER_SECOND = 1.05D;
    private static final EntityDataAccessor<Integer> DATA_LIFE_TICKS =
            SynchedEntityData.defineId(Bedserker.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING =
            SynchedEntityData.defineId(Bedserker.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_DETONATED =
            SynchedEntityData.defineId(Bedserker.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DATA_LOCKED_Y_ROT =
            SynchedEntityData.defineId(Bedserker.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_LOCKED_Y_HEAD_ROT =
            SynchedEntityData.defineId(Bedserker.class, EntityDataSerializers.FLOAT);

    private int sleepAnimationTicks;
    /** 当前是否已套用躺倒碰撞箱；只在状态翻转的那一 tick 调 refreshDimensions。 */
    private boolean lyingHitbox;
    /** 已应用的加速秒数；-1 表示本 tick 周期尚未同步过（重载后首 tick 会重算）。 */
    private int appliedSpeedSeconds = -1;

    public Bedserker(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.xpReward = 20;
        this.setPersistenceRequired();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_LIFE_TICKS, 0);
        builder.define(DATA_SLEEPING, false);
        builder.define(DATA_DETONATED, false);
        builder.define(DATA_LOCKED_Y_ROT, 0.0F);
        builder.define(DATA_LOCKED_Y_HEAD_ROT, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.ARMOR, 0.0D)
                .add(Attributes.MOVEMENT_SPEED, BASE_MOVEMENT_SPEED)
                .add(Attributes.ATTACK_DAMAGE, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, FOLLOW_RANGE_BLOCKS);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 狂战士/凋灵骷髅默认的近战目标只负责攻击，必须完全移除。
        this.goalSelector.removeAllGoals(goal -> goal instanceof MeleeAttackGoal);
        // 目标选择仍沿用凋灵骷髅阵营的原生选择器；床战士只向目标靠近，不执行攻击。
        this.goalSelector.addGoal(2, new BedserkerPursuitGoal(this, 1.2D));
    }

    @Override
    public void reassessWeaponGoal() {
        // 防止父类因装备变更重新挂回近战目标。
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        return false;
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.BERSERKER_HELMET.get()));
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        net.minecraft.world.entity.MobSpawnType spawnType,
                                        SpawnGroupData groupData) {
        // 先走狂战士的通用生成流程，再恢复床战士的固定装备：仅头盔，不再自带金斧。
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.BERSERKER_HELMET.get()));
        this.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        return result;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        // 不攻击、不持斧：连拾取地面武器也不行，避免从地上捡回一把金斧。
        return false;
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            if (this.isSleepingState()) {
                this.sleepAnimationTicks = Math.min(SLEEP_ANIMATION_TICKS, this.sleepAnimationTicks + 1);
                this.applyLockedRotation();
            } else {
                this.sleepAnimationTicks = Math.max(0, this.sleepAnimationTicks - 1);
            }
            this.updateLyingHitbox();
            return;
        }

        if (this.isSleepingState()) {
            this.sleepAnimationTicks = Math.min(SLEEP_ANIMATION_TICKS, this.sleepAnimationTicks + 1);
            this.freezeAfterSleep();
            this.updateLyingHitbox();
            return;
        }
        this.sleepAnimationTicks = Math.max(0, this.sleepAnimationTicks - 1);
        this.updateLyingHitbox();

        int age = Math.min(DETONATION_TICKS, this.entityData.get(DATA_LIFE_TICKS) + 1);
        this.entityData.set(DATA_LIFE_TICKS, age);
        this.applySpeedRamp(age);
        if (age < DETONATION_TICKS) {
            return;
        }

        if (this.level().dimension() != Level.OVERWORLD) {
            if (!this.entityData.get(DATA_DETONATED)) {
                this.entityData.set(DATA_DETONATED, true);
                this.detonateVoidBedBlast();
                this.discard();
            }
        } else {
            this.entityData.set(DATA_LOCKED_Y_ROT, this.getYRot());
            this.entityData.set(DATA_LOCKED_Y_HEAD_ROT, this.getYHeadRot());
            this.entityData.set(DATA_SLEEPING, true);
            this.setNoAi(true);
            this.getNavigation().stop();
            this.setDeltaMovement(Vec3.ZERO);
        }
    }

    /**
     * 每存在满 1 秒，把 {@code MOVEMENT_SPEED} 属性底提高 5%（复利：底速 × 1.05^n）。
     * 按已存活 tick 数换算，同一秒内不重复写属性；{@code appliedSpeedSeconds} 为瞬态
     * 字段，重载后首个 tick 会用当前年龄重新写回，与持久化的生命 tick 计数保持一致。
     */
    private void applySpeedRamp(int ageTicks) {
        int seconds = ageTicks / 20;
        if (seconds == this.appliedSpeedSeconds) {
            return;
        }
        this.appliedSpeedSeconds = seconds;
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.setBaseValue(BASE_MOVEMENT_SPEED * Math.pow(SPEED_RAMP_PER_SECOND, seconds));
        }
    }

    private void freezeAfterSleep() {
        this.setNoAi(true);
        this.getNavigation().stop();
        this.setTarget(null);
        this.setLastHurtByMob(null);
        this.setDeltaMovement(Vec3.ZERO);
        this.hasImpulse = false;
        this.applyLockedRotation();
    }

    private void applyLockedRotation() {
        float yaw = this.entityData.get(DATA_LOCKED_Y_ROT);
        float head = this.entityData.get(DATA_LOCKED_Y_HEAD_ROT);
        this.setYRot(yaw);
        this.setYHeadRot(head);
        this.yBodyRot = yaw;
        this.yBodyRotO = yaw;
        this.yHeadRot = head;
        this.yHeadRotO = head;
        this.yRotO = yaw;
        this.setXRot(0.0F);
        this.xRotO = 0.0F;
    }

    /** 非主世界的床爆炸：威力为原版床爆炸的两倍，带火焰，实体伤害使用虚空伤害类型。 */
    private void detonateVoidBedBlast() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        AABB affected = this.getBoundingBox().inflate(10.0D);
        // 原版凋灵和霸主凋灵会在护盾阶段拦截普通伤害；临时清除护盾与无敌帧，
        // 让 out_of_world 伤害确实穿过护盾，爆炸结算后恢复剩余护盾计时。
        java.util.Map<WitherBoss, Integer> shields = new java.util.HashMap<>();
        for (WitherBoss wither : level.getEntitiesOfClass(WitherBoss.class, affected,
                Entity::isAlive)) {
            shields.put(wither, wither.getInvulnerableTicks());
            wither.setInvulnerableTicks(0);
            wither.invulnerableTime = 0;
        }
        try {
            level.explode(this, level.damageSources().fellOutOfWorld(),
                    new ExplosionDamageCalculator(), this.getX(), this.getY(), this.getZ(),
                    10.0F, true, Level.ExplosionInteraction.MOB);
        } finally {
            for (java.util.Map.Entry<WitherBoss, Integer> entry : shields.entrySet()) {
                if (entry.getKey().isAlive()) {
                    entry.getKey().setInvulnerableTicks(entry.getValue());
                    entry.getKey().invulnerableTime = 0;
                }
            }
        }
    }

    public int getLifeTicks() {
        return this.entityData.get(DATA_LIFE_TICKS);
    }

    public boolean isSleepingState() {
        return this.entityData.get(DATA_SLEEPING);
    }

    /** sleep 动画是否已经播完并停在末帧（模型此时完全躺平）。 */
    public boolean isFullyAsleep() {
        return this.isSleepingState() && this.sleepAnimationTicks >= SLEEP_ANIMATION_TICKS;
    }

    /**
     * 动画播完的那一 tick 把碰撞箱换成躺倒模型的外接盒，动画期间沿用站姿箱体。
     * 客户端与服务端各自维护 AABB（客户端那份决定准星选取与视锥裁剪），所以两侧
     * 都要在状态翻转时调一次 {@code refreshDimensions}；躺平期间每 tick 重算一次
     * 底面外接盒，保证它始终跟着锁定的朝向。
     */
    private void updateLyingHitbox() {
        boolean lying = this.isFullyAsleep();
        if (this.level() == null) {
            return;
        }
        if (lying != this.lyingHitbox) {
            this.lyingHitbox = lying;
            this.refreshDimensions();
        } else if (lying) {
            this.reapplyPosition();
        }
    }

    /**
     * 躺平后的底面改成贴合床形的长方形：床的长轴沿实体朝向，而原版 AABB 只能贴世界轴，
     * 所以按朝向把旋转后的长方形展开成最小的世界轴外接盒（斜着躺时才会略微变大）。
     * 站姿沿用父类由尺寸生成的正方形箱。
     */
    @Override
    protected AABB makeBoundingBox() {
        if (!this.lyingHitbox) {
            return super.makeBoundingBox();
        }
        Vec3 pos = this.position();
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        // 朝向单位向量（MC：yaw 0 朝南）与侧向单位向量
        double facingX = -Mth.sin(yaw);
        double facingZ = Mth.cos(yaw);
        double halfLength = (LYING_FRONT + LYING_BACK) / 2.0D;
        // 模型质心比实体轴心靠后一点点，箱体跟着后移，前后两端才都正好贴住模型。
        double backShift = (LYING_BACK - LYING_FRONT) / 2.0D;
        double centerX = pos.x - backShift * facingX;
        double centerZ = pos.z - backShift * facingZ;
        double halfX = halfLength * Math.abs(facingX) + LYING_HALF_WIDTH * Math.abs(facingZ);
        double halfZ = halfLength * Math.abs(facingZ) + LYING_HALF_WIDTH * Math.abs(facingX);
        double height = this.getDimensions(this.getPose()).height();
        return new AABB(centerX - halfX, pos.y, centerZ - halfZ,
                centerX + halfX, pos.y + height, centerZ + halfZ);
    }

    /**
     * 床战士的实时尺寸：{@code LivingEntity#getDimensions(Pose)} 是 final，
     * 官方留的可覆写入口就是这个（父类实现为 {@code 实体类型尺寸 × 年龄缩放}）。
     * 返回值还会被 final 方法再乘一次 SCALE 属性，这里不需要额外处理。
     */
    @Override
    protected EntityDimensions getDefaultDimensions(Pose pose) {
        // 与 makeBoundingBox 读同一个"已生效"标记，保证尺寸和 AABB 不会出现半躺状态。
        if (this.lyingHitbox) {
            return LYING_DIMENSIONS;
        }
        return super.getDefaultDimensions(pose);
    }

    /** 客户端按 sleep 动画的 0.5 秒（10 tick）插值，避免状态切换时瞬间跳帧。 */
    public float getSleepProgress(float partialTick) {
        float progress = (this.sleepAnimationTicks + partialTick) / (float) SLEEP_ANIMATION_TICKS;
        return Math.max(0.0F, Math.min(1.0F, progress));
    }

    public boolean isDetonated() {
        return this.entityData.get(DATA_DETONATED);
    }

    /** 客户端红闪频率随倒计时增加而提高，供渲染层读取。 */
    public boolean shouldRenderRedFlash(float partialTick) {
        int age = this.getLifeTicks();
        if (age <= 0 || age >= DETONATION_TICKS || this.isSleepingState()) {
            return false;
        }
        int interval = Math.max(1, 12 - age / 20);
        return ((this.tickCount + (int) partialTick) / interval) % 2 == 0;
    }

    /**
     * 床战士专属追击目标：只要持有目标就无限逼近，永不攻击。
     *
     * <p>原版 {@code MoveTowardsTargetGoal} 的 {@code canUse} 是
     * {@code distanceToSqr(target) <= within²}，只在目标贴近到 within 格以内才启动，
     * 且启动后不重算路径——床战士删掉近战目标后拿它当唯一移动手段，表现为
     * "锁定了敌人却原地不动"。这里每 tick 直接 {@code moveTo(target)}：
     * {@code PathNavigation} 内部按 tick 节流寻路，重复调用不增加开销，
     * 路径终点还会始终跟随移动中的敌人；配合 {@code doHurtTarget} 恒为 false
     * 与空置的 {@code reassessWeaponGoal}，实现"不能攻击、但一直追击靠近"。</p>
     */
    private static final class BedserkerPursuitGoal extends Goal {
        private final Bedserker bedserker;
        private final double speedModifier;
        private LivingEntity target;

        BedserkerPursuitGoal(Bedserker bedserker, double speedModifier) {
            this.bedserker = bedserker;
            this.speedModifier = speedModifier;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.bedserker.isSleepingState() || this.bedserker.isDetonated()) {
                return false;
            }
            LivingEntity current = this.bedserker.getTarget();
            if (current == null || !current.isAlive() || current.isRemoved()) {
                return false;
            }
            this.target = current;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && !this.target.isRemoved()
                    && this.bedserker.getTarget() == this.target
                    && !this.bedserker.isSleepingState();
        }

        @Override
        public void start() {
            this.bedserker.getNavigation().moveTo(this.target, this.speedModifier);
        }

        @Override
        public void tick() {
            this.bedserker.getNavigation().moveTo(this.target, this.speedModifier);
            Vec3 eye = this.target.getEyePosition();
            this.bedserker.getLookControl().setLookAt(eye.x, eye.y, eye.z);
        }

        @Override
        public void stop() {
            this.target = null;
            this.bedserker.getNavigation().stop();
        }
    }
}
