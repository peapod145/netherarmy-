package cn.blockforge.generated.netherarmy;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 伤害数值与受击异常的统一护栏。
 *
 * <p>本模组在 {@link LivingIncomingDamageEvent} 上挂了一整串"读伤害、乘系数、写回去"
 * 的处理器（发光 1.5 倍、易伤 1.25 倍 × 等级、灵魂火 2 倍、蓝头凋灵之首 2 倍、
 * 圣化附魔加成、水晶套 1.25 倍、狂战士头盔 0.75 倍……）。只要是乘法，就有两个
 * 外部输入会让它们失控：</p>
 *
 * <ul>
 *   <li><b>非有限值。</b>{@code /kill} 用的是 {@code generic_kill} + {@code Float.MAX_VALUE}，
 *       别的模组的"真伤/环境伤"也常直接给 {@code Float.POSITIVE_INFINITY} 或 {@code NaN}。
 *       {@code Float.MAX_VALUE * 1.5F} 溢出成 Infinity，NeoForge 的伤害管线再把
 *       {@code Infinity - Infinity} 算成 NaN 写进血量；血量一旦是 NaN，
 *       {@code isDeadOrDying}（只判断 {@code <= 0}）永远为假，这只怪就再也打不死了。</li>
 *   <li><b>负值。</b>个别模组用负伤害表示"治疗/吸收"，乘上本模组的增伤系数后会变成一个
 *       诡异的负结算量，同样把血量算坏。</li>
 * </ul>
 *
 * <p>因此这里做三件事：</p>
 * <ol>
 *   <li>在 {@link EventPriority#HIGHEST} 与 {@link EventPriority#LOWEST} 两个位置各清洗一次
 *       伤害量——前者挡住外部灌进来的脏数值，后者兜住本模组自己乘完之后的结果
 *       （同一事件上各处理器的先后顺序不作保证，所以两头都要卡）；</li>
 *   <li>在 {@link LivingDamageEvent.Pre}（护甲/抗性结算完、写入血量之前）再卡一次，
 *       任何 NaN/Infinity/负数都不允许落到 {@code setHealth} 上；</li>
 *   <li>提供 {@link #scale(float, float)} 给所有乘系数的地方用：先清洗再乘，
 *       用 {@code double} 中转并把结果封顶在 {@code Float.MAX_VALUE}，溢出不会变成 Infinity。</li>
 * </ol>
 *
 * <p>异常兜底（本模组生物受击时抛异常不再弹窗）在
 * {@code mixin.LivingEntityHurtGuardMixin} 里，日志出口也放在本类。</p>
 */
public final class DamageGuard {
    /** 单次伤害的硬上限：仍然是"必死"级别的量，但留出乘系数的余量，不会立刻变 Infinity。 */
    public static final float MAX_DAMAGE = Float.MAX_VALUE;

    /** 异常伤害量的日志只打前若干条，避免每刻刷屏把日志文件撑爆。 */
    private static final int MAX_WARNINGS = 20;
    private static final AtomicInteger INVALID_AMOUNT_WARNINGS = new AtomicInteger();
    private static final AtomicInteger HURT_FAILURE_WARNINGS = new AtomicInteger();

    /** 实体类型是否属于本模组；判定后缓存，避免每次受击都去查注册表。 */
    private static final Map<EntityType<?>, Boolean> MEMBERSHIP = new ConcurrentHashMap<>();

    private DamageGuard() {
    }

    // ------------------------------------------------------------------ 数值清洗

    /**
     * 把一个伤害量收进 {@code [0, Float.MAX_VALUE]}：NaN 与负数收敛成 0，
     * 正无穷封顶成 {@link #MAX_DAMAGE}。
     */
    public static float clamp(float amount) {
        if (Float.isNaN(amount) || amount <= 0.0F) {
            return 0.0F;
        }
        return amount > MAX_DAMAGE ? MAX_DAMAGE : amount;
    }

    /**
     * 按系数放大/缩小伤害量，全程防溢出：{@code double} 中转，NaN/负数收敛成 0，
     * 超过 {@link Float#MAX_VALUE} 的封顶成 {@link #MAX_DAMAGE}。
     */
    public static float scale(float amount, float multiplier) {
        double scaled = (double) clamp(amount) * (double) multiplier;
        if (Double.isNaN(scaled) || scaled <= 0.0D) {
            return 0.0F;
        }
        return scaled >= (double) MAX_DAMAGE ? MAX_DAMAGE : (float) scaled;
    }

    /** 该伤害量是否已经是一个可以正常结算的有限值。 */
    public static boolean isSane(float amount) {
        return amount >= 0.0F && amount <= MAX_DAMAGE;
    }

    // ------------------------------------------------------------------ 事件钩子

    /**
     * 外部灌进来的脏数值在这里挡掉：别的模组的伤害源、{@code /kill}、命令与数据包
     * 都可能给出 NaN / Infinity / 负数。
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onIncomingDamageHead(LivingIncomingDamageEvent event) {
        sanitize(event);
    }

    /**
     * 本模组自己的处理器乘完之后再卡一次。同一事件上各处理器的先后顺序不作保证，
     * 只在上游卡一次是不够的。
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onIncomingDamageTail(LivingIncomingDamageEvent event) {
        sanitize(event);
    }

    /** 护甲/抗性/吸收都结算完、真正写血量之前的最后一道闸。 */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDamagePre(LivingDamageEvent.Pre event) {
        float damage = event.getNewDamage();
        if (isSane(damage)) {
            return;
        }
        warnInvalidAmount(event.getEntity(), event.getSource(), damage, "结算后");
        // 正无穷说明这是个"必定致死"的量级，封顶保留致死性；NaN/负数解释不了，按 0 落账。
        float replacement = damage > MAX_DAMAGE ? MAX_DAMAGE : 0.0F;
        event.setNewDamage(replacement);
    }

    private static void sanitize(LivingIncomingDamageEvent event) {
        float amount = event.getAmount();
        if (isSane(amount)) {
            return;
        }
        if (amount > MAX_DAMAGE) {
            // 正无穷：封顶成一个"必死但有限"的量，继续正常结算。
            event.setAmount(MAX_DAMAGE);
            return;
        }
        // NaN 或负数：解释不了的量，整条取消——没有伤害，但也不会崩。
        event.setCanceled(true);
        warnInvalidAmount(event.getEntity(), event.getSource(), amount, "进入结算");
    }

    // ------------------------------------------------------------------ 本模组实体判定

    /** 该实体是否属于本模组（按注册名的命名空间判断，覆盖全部自定义生物与载具）。 */
    public static boolean isNetherArmyEntity(LivingEntity entity) {
        EntityType<?> type = entity.getType();
        return MEMBERSHIP.computeIfAbsent(type, t -> {
            ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(t);
            return id != null && GeneratedMod.MOD_ID.equals(id.getNamespace());
        });
    }

    // ------------------------------------------------------------------ 日志

    private static void warnInvalidAmount(LivingEntity entity, DamageSource source, float amount, String stage) {
        if (INVALID_AMOUNT_WARNINGS.incrementAndGet() > MAX_WARNINGS) {
            return;
        }
        GeneratedMod.LOGGER.warn("[netherarmy] {}阶段的异常伤害量已处理：amount={}，victim={}，source={}",
                stage, amount,
                entity.getType().toShortString(),
                source == null ? "null" : source.getMsgId());
    }

    /**
     * 本模组生物受击结算抛出异常时的记录点（由 {@code LivingEntityHurtGuardMixin} 调用）。
     * 只记日志、不让异常继续往上冒：异常一旦逃出 {@code hurt}，服务端刻就会整体失败，
     * 单人游戏直接弹"遇到内部服务器错误"并把世界关掉。
     */
    public static void reportHurtFailure(LivingEntity entity, DamageSource source, Throwable failure) {
        int count = HURT_FAILURE_WARNINGS.incrementAndGet();
        if (count > MAX_WARNINGS) {
            return;
        }
        GeneratedMod.LOGGER.warn("[netherarmy] 受击结算抛出异常，已按未命中处理（第 {} 次）：victim={}，source={}",
                count,
                entity.getType().toShortString(),
                source == null ? "null" : source.getMsgId(),
                failure);
    }
}
