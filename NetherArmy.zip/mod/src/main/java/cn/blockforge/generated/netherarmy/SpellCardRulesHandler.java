package cn.blockforge.generated.netherarmy;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 符卡规则的伤害限制：持有者只吃抛射物伤害，也只能用抛射物伤别人。
 *
 * <p>两条规则都挂在 {@link LivingIncomingDamageEvent}（任何活体受伤的统一入口，
 * 减伤计算之前）上，直接 {@code setCanceled(true)}——取消后原版 {@code hurt}
 * 整个返回 false，伤害、击退、受击动画与音效全部不出现，符合"任何形式的伤害
 * 均无效"的语义（摔落、溺水、火焰、附魔魔法、爆炸等一并无效）。</p>
 *
 * <p>"抛射物"判定用原版 {@code IS_PROJECTILE} 伤害类型标签：箭、三叉戟、火球、
 * 凋灵之首等投掷/弹射类伤害都在标签内；玩家近战、横扫、药水云、TNT 等都不在。
 * 攻击者一侧取 {@code DamageSource#getEntity()}（抛射物会解析到发射者），
 * 因此持有者射出的箭对任何目标都照常生效。</p>
 */
public final class SpellCardRulesHandler {
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            // 抛射物伤害：受击方与攻击方的符卡规则都不拦。
            return;
        }
        if (event.getEntity().hasEffect(GeneratedMod.SPELL_CARD_RULES)) {
            // 持有者不能被非抛射物伤害。
            event.setCanceled(true);
            return;
        }
        if (source.getEntity() instanceof LivingEntity attacker
                && attacker.hasEffect(GeneratedMod.SPELL_CARD_RULES)) {
            // 持有者的非抛射物攻击无法对目标造成伤害。
            event.setCanceled(true);
        }
    }
}
