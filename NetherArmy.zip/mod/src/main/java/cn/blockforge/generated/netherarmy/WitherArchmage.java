package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 凋灵魔导师（Wither Archmage）：凋灵骷髅变种、凋灵骷髅阵营的法术核心。
 *
 * <p>面板：血量 30、护甲 4、移速同凋灵骷髅（0.25）、索敌 50 格；<b>魔法伤害 75% 抗性</b>
 * （{@code #netherarmy:is_magic}，口径见 {@link MagicDamageResistance}）；经验值为凋灵骷髅的
 * 10 倍（5 → 50）。<b>攻击范围与索敌范围严格同源</b>：索敌走原版
 * {@code FOLLOW_RANGE}（半径 50 的球），全部技能的半径在运行时也从同一条
 * {@code FOLLOW_RANGE} 属性读取，并按同一套球面距离判定，见
 * {@link #skillRadius()}、{@link #entitiesWithinSkillRadius(java.util.function.Predicate)}。
 * <b>纯施法者：不会冲上去近战。</b>凋灵骷髅一脉本来自带一条近战目标，
 * 来源是 {@code AbstractSkeleton#reassessWeaponGoal()}"无武器 → {@code MeleeAttackGoal}"
 * 的分支（构造器、{@code finalizeSpawn}、换装时各调一次），这一条已被
 * {@link #reassessWeaponGoal()} 覆写成空实现掐掉；改由 {@link CasterPositionGoal}
 * 在索敌半径内原地站定挥手放法术——目标跑出索敌半径才追、贴到
 * {@value #RETREAT_DISTANCE} 格以内才后撤，绝不会像近战怪那样先走近一段距离
 * （见 {@link BodySpellGoal}）。</p>
 *
 * <p><b>不会自然消失</b>：构造器即 {@link #setPersistenceRequired()}，并覆写
 * {@link #removeWhenFarAway(double)} 恒返回 {@code false}，读档时还会把标记补回来。
 * 玩家跑多远、区块卸载多少次都不会被当成"过期刷怪"清掉。</p>
 *
 * <h3>魔法书</h3>
 * <p>模型里那本悬浮的书有一份独立状态（{@code DATA_BOOK_OPEN} / {@code DATA_BOOK_PHASE}
 * / {@code DATA_BOOK_SPELL}）：<b>刚生成时就是打开的</b>，本书技能用完后播闭合动画并保持
 * 闭合，直到下一次书类施法才重新打开。书类技能与本体技能各有各的计时，互不干涉，
 * 可以同时进行（本体在挥手放陨石时，书照样能开）。</p>
 *
 * <h3>技能</h3>
 * <ul>
 *   <li><b>本体·灵魂陨石</b>（冷却 {@value #BODY_COOLDOWN_TICKS} 刻）：自身正上方
 *       {@value #METEOR_SPAWN_HEIGHT} 格处召唤 {@value #METEOR_COUNT} 颗
 *       {@link SoulMeteorite} 轰击目标区域，落点等同 TNT 爆炸、魔法伤害、范围 8 格
 *       挂 20 秒易伤 I。</li>
 *   <li><b>本体·瞬间伤害波</b>（与上一条共享冷却）：半径 {@value #FOLLOW_RANGE_BLOCKS} 格内
 *       一切活物（含友军与自身）获得瞬间伤害 I。亡灵吃瞬间伤害会被治疗，这是原版规则，
 *       需求点名"含友军"，因此不做友军过滤。<b>闲置（无敌人）时也会主动用它护理同袍</b>：
 *       周围有未满血的凋灵骷髅阵营生物就出手，见 {@link #tryIdleHealWave()}。</li>
 *   <li><b>魔法书·霸主凋灵之首</b>（冷却 10 秒）：书页涌黑烟 2 秒后从书口射出一枚
 *       {@link OverlordWitherSkull}，命中附加的凋零／虚弱固定 2 分钟（不翻倍）；
 *       同时顺带从身边召出 {@value #ESCORT_COUNT} 名 {@link WitherServant}——
 *       主手随机石剑／弓／重锤／弩／三叉戟，身上随机金质盔甲，仇恨跟着魔导师走
 *       （见 {@link #summonBookEscort}）。</li>
 *   <li><b>魔法书·附魔强化</b>（冷却 20 秒）：附魔台粒子 2 秒后，半径 50 格内友军的
 *       每件装备随机获得一项附魔或随机升一级（新附魔随机取等级、升级每次真的 +1，
 *       见 {@link #applyEnchantmentLevel}）；<b>新给的</b>附魔不超过
 *       {@value #MAX_GIFTED_ENCHANTMENT_LEVEL} 级，<b>升级</b>则只受该附魔的原版最高
 *       等级约束（2 级附魔照常升到 III、IV……）。<b>只有半径内存在"带着可附魔武器装备"
 *       的友军时才会起手</b>——周围全是没有武器装备（或装备已无可附魔余地）的友军时
 *       不空放这一次（见 {@link #isEnchantTarget}、{@link #hasEnchantableAllyInRange}）。</li>
 *   <li><b>魔法书·凋零诅咒</b>（冷却 20 秒）：灵魂火苗特效 1 秒后，半径 50 格内敌人
 *       获得 20 秒反胃／虚弱／缓慢，并燃烧 10 秒灵魂火。</li>
 * </ul>
 */
public class WitherArchmage extends WitherSkeleton {
    /**
     * 模型渲染缩放：需求「体型和凋灵骷髅一致」，原版 {@code WitherSkeletonRenderer#scale}
     * 就是 {@code scale(1.2)}，32px 标准人形模型 2.0 格 × 1.2 = 2.4 格，正好等于判定箱高度。
     *
     * <p>渲染器与实体侧共用这一份常量：{@link #bookPosition()}、{@link #armTip(double)}
     * 里那些"模型里量出来的格数"必须一起乘这个倍率，否则放大后的书口／手掌会和
     * 粒子、弹头出生点脱开 20%。</p>
     */
    public static final float MODEL_SCALE = 1.2F;
    /** 本体技能共享冷却：15 秒。 */
    public static final int BODY_COOLDOWN_TICKS = 300;
    /** 本体施法动画总时长／前摇（与唤魔者同款）。 */
    public static final int SPELL_CAST_TICKS = 40;
    public static final int SPELL_WARMUP_TICKS = 20;
    /** 魔法书开／合动画时长：20 刻（与原稿 open／close 动画的 1 秒一致）。 */
    public static final int BOOK_OPEN_TICKS = 20;
    /** 三种书类技能各自的冷却。 */
    public static final int OVERLORD_COOLDOWN_TICKS = 200;
    public static final int ENCHANT_COOLDOWN_TICKS = 400;
    public static final int CURSE_COOLDOWN_TICKS = 400;
    /** 三种书类技能的前摇：陨石之首 2 秒、附魔 2 秒、诅咒 1 秒。 */
    public static final int OVERLORD_CHARGE_TICKS = 40;
    public static final int ENCHANT_CHARGE_TICKS = 40;
    public static final int CURSE_CHARGE_TICKS = 20;
    /**
     * 施法效果时长倍率：需求「魔导师施法带来的 buff 时间翻倍」。
     *
     * <p>只作用于<b>带持续时间的状态效果</b>——陨石命中的易伤、陨石方块的接触易伤、
     * 凋零诅咒的反胃／虚弱／缓慢与灵魂火。瞬间伤害波给的 {@code HARM} 是 1 刻的瞬时伤害，
     * 按"除了瞬间伤害"排除在外，依旧写死 1 刻；书上射出的霸主凋灵之首命中挂的
     * 凋零／虚弱按需求"改回来"，固定 2 分钟，同样不吃这个倍率。</p>
     */
    public static final int EFFECT_DURATION_MULTIPLIER = 2;
    /** 陨石落地给范围内实体的易伤时长：翻倍后 20 秒。 */
    public static final int VULNERABLE_TICKS = 200 * EFFECT_DURATION_MULTIPLIER;
    /** 诅咒负面效果的时长：翻倍后 20 秒；灵魂火 10 秒。 */
    public static final int CURSE_EFFECT_TICKS = 200 * EFFECT_DURATION_MULTIPLIER;
    private static final float CURSE_SOUL_FIRE_SECONDS = 5.0F * EFFECT_DURATION_MULTIPLIER;
    /**
     * 索敌范围（格）：写进 {@code FOLLOW_RANGE}，同时就是全部技能的半径。
     *
     * <p>技能半径不在编译期另写一份，{@link #skillRadius()} 每次直接读实体当前的
     * {@code FOLLOW_RANGE} 属性值，于是"攻击范围"与"索敌范围"永远是同一个数；这个常量
     * 只是属性基准值（{@link #createAttributes()}）与属性缺失时的兜底。</p>
     */
    public static final double FOLLOW_RANGE_BLOCKS = 50.0D;
    /** 陨石召唤点：自身上方 10 格，水平 ±2 格、垂直 ±1 格。 */
    private static final double METEOR_SPAWN_HEIGHT = 10.0D;
    private static final double METEOR_XZ_SPREAD = 2.0D;
    private static final double METEOR_Y_SPREAD = 1.0D;
    /**
     * 陨石发射方向相对"召唤点 → 目标点"的最大偏角。
     *
     * <p>需求写的是"发射角 ≤30° 偏移"，这里取 15° 作为上限：一是满足 ≤30° 的约束，
     * 二是召唤点已经随机散布 ±2 格，再叠加 30° 偏角会让落点飘出十几格，"轰击目标区域"
     * 就名不副实了。</p>
     */
    private static final double METEOR_MAX_DEVIATION_DEGREES = 15.0D;
    private static final int METEOR_COUNT = 3;
    /** 书类技能 1 顺带召唤的凋灵仆役数量。 */
    private static final int ESCORT_COUNT = 3;
    /**
     * 附魔技能<b>新送</b>的附魔等级上限：需求「凋灵魔导师提供的附魔不会超过 2 级」。
     *
     * <p>只管"从无到有"这一半：新加一项附魔时随机等级取
     * {@code [最小等级, min(该附魔最高等级, 2)]}。<b>升级不吃这个上限</b>——升级只受该
     * 附魔在原版的最高等级限制（见 {@link #upgradableEnchantments}），所以一件已经有 2 级
     * 附魔的装备照样能被升到 III、IV、V；已经顶到原版最高等级的附魔则不会被再升，
     * 也不会被降级。</p>
     */
    public static final int MAX_GIFTED_ENCHANTMENT_LEVEL = 2;
    /** 随行仆役的主手武器池：石剑、弓、重锤、弩、三叉戟各一，随机取一件。 */
    private static final Item[] ESCORT_WEAPONS = {
            Items.STONE_SWORD, Items.BOW, Items.MACE, Items.CROSSBOW, Items.TRIDENT,
    };
    /** 随行仆役的金质盔甲槽位：每次随机挑其中 1~4 个穿上。 */
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
    };
    /**
     * 近身后撤距离：目标贴到 {@value #RETREAT_DISTANCE} 格以内才后退。
     *
     * <p><b>没有"站位带"。</b>魔导师的施法半径就是索敌半径（{@value #FOLLOW_RANGE_BLOCKS} 格），
     * 所以只要目标还在索敌半径内，它就该原地施法，而不是先走近一段距离再停——那样
     * "攻击范围 50 格"就成了空话。站位目标因此只有两个动作：目标跑出
     * {@link #skillRadius()} 才追回去，目标贴到 {@value #RETREAT_DISTANCE} 格以内才后撤，
     * 其余情况一律站定（见 {@link CasterPositionGoal}）。</p>
     */
    private static final double RETREAT_DISTANCE = 8.0D;
    private static final double CAST_MOVE_SPEED = 1.0D;
    /** 站位重算间隔：导航每 10 刻重下一次路径，避免每刻抖。 */
    private static final int REPATH_INTERVAL_TICKS = 10;
    /** 目标贴脸到这个距离（平方值）以内时，本体技能优先用瞬伤波保命。 */
    private static final double HARM_PREFERRED_RANGE_SQR = 36.0D;
    /** 闲置期（无敌人）扫同袍的间隔刻数：范围查询有成本，10 刻够用。 */
    private static final int IDLE_ALLY_CHECK_INTERVAL_TICKS = 10;
    /** 施法动作的抬手／放手速度：起手 6 刻抬到位、收手 8 刻放平（避免硬切）。 */
    private static final float CAST_RISE_STEP = 1.0F / 6.0F;
    private static final float CAST_FALL_STEP = 1.0F / 8.0F;

    /** 本体法术 id（同步字节 > 0 即处于施法姿态）。 */
    private static final byte BODY_SPELL_NONE = 0;
    private static final byte BODY_SPELL_METEOR = 1;
    private static final byte BODY_SPELL_HARM = 2;
    /** 书类法术 id。 */
    private static final byte BOOK_SPELL_NONE = 0;
    private static final byte BOOK_SPELL_OVERLORD = 3;
    private static final byte BOOK_SPELL_ENCHANT = 4;
    private static final byte BOOK_SPELL_CURSE = 5;
    /** 魔法书阶段：0 静止、1 开书中、2 蓄力中。 */
    private static final byte BOOK_PHASE_IDLE = 0;
    private static final byte BOOK_PHASE_OPENING = 1;
    private static final byte BOOK_PHASE_CHARGING = 2;

    private static final EntityDataAccessor<Byte> DATA_BODY_SPELL =
            SynchedEntityData.defineId(WitherArchmage.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Boolean> DATA_BOOK_OPEN =
            SynchedEntityData.defineId(WitherArchmage.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Byte> DATA_BOOK_PHASE =
            SynchedEntityData.defineId(WitherArchmage.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> DATA_BOOK_SPELL =
            SynchedEntityData.defineId(WitherArchmage.class, EntityDataSerializers.BYTE);

    /** 本体冷却剩余刻数（两种本体技能共享）。 */
    private int bodyCooldown;
    /** 本体两种技能的轮换开关：不用贴脸判断时轮流出招，保证陨石与瞬伤波都能看到。 */
    private boolean bodySkillToggle;
    /** 本体施法剩余刻数与前摇剩余刻数。 */
    private int bodyCastTicks;
    private int bodyWarmupTicks;
    /** 本次本体技能的结算对象。 */
    private LivingEntity pendingBodyTarget;
    /** 魔法书冷却剩余刻数（按最近一次使用的书类技能决定）。 */
    private int bookCooldown;
    /** 书类蓄力／开书剩余刻数。 */
    private int bookTimer;
    /** 上一次用过的书类技能：下一次尽量换一个，让三类书类技能都能出场。 */
    private byte lastBookSpell = BOOK_SPELL_NONE;
    /** 客户端插值用：0 = 完全合拢、1 = 完全打开（刚生成即 1）。 */
    private float clientBookOpen = 1.0F;
    /** 客户端插值用：0 = 手臂平展、1 = 施法抬手到位。 */
    private float clientCastAmount;

    public WitherArchmage(EntityType<? extends WitherArchmage> type, Level level) {
        super(type, level);
        // 凋灵骷髅基准 5 的 10 倍。
        this.xpReward = 50;
        // 需求「不会自然消失」：构造器里直接钉持久化标记，任何生成方式（刷怪蛋、指令、
        // 刷怪笼、霸主凋灵召唤）出来的个体都带着它，Mob#checkDespawn 里
        // "离玩家太远就 discard" 的分支因此整段跳过。
        this.setPersistenceRequired();
    }

    /**
     * 需求「凋灵魔导师不会自然消失」：离最近的玩家再远也不 despawn。
     *
     * <p>{@link #setPersistenceRequired()} 已经是主手段，这里再覆写一层是为了兜住两种漏网：
     * 一是本特性上线<b>之前</b>就存在的老存档个体——{@code Mob#readAdditionalSaveData}
     * 会按存档里的 {@code PersistenceRequired} 标签把标记读成 {@code false}；二是任何
     * 运行时清掉持久化标记的路径。原版 {@code Mob#checkDespawn} 只有"没持久化且
     * {@code removeWhenFarAway} 返回 true"才会 discard，这里恒返回 {@code false}，
     * 距离判定再也不生效。</p>
     *
     * <p>注意这只挡"自然消失"（远离玩家 despawn）。和平难度下敌对生物被清除走的是
     * {@code shouldDespawnInPeaceful()}，那是难度规则、来自 {@code Monster}，本类没有改它。</p>
     */
    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, FOLLOW_RANGE_BLOCKS);
    }

    /**
     * 魔法伤害 75% 抗性：所有伤害都在 {@code hurt()} 入口过一遍，魔法伤害先按
     * {@link MagicDamageResistance} 的 {@code #netherarmy:is_magic} 口径折到 1/4，
     * 再交给父类做护甲、附魔与无敌帧的常规结算。近战、抛射物、药水、持续伤害全覆盖。
     */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, MagicDamageResistance.reduce(source, amount));
    }

    /** 空手施法：不塞石剑，掉落表里也没有剑。 */
    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random,
                                                 net.minecraft.world.DifficultyInstance difficulty) {
    }

    /**
     * 掐掉骷髅系的近战目标——这就是"魔导师冲上去近战"的根子。
     *
     * <p>原版 {@code AbstractSkeleton} 在构造器、{@code finalizeSpawn}、{@code setItemSlot}
     * 三处都会调本方法：手上不是弓就走"无武器"分支，给 {@code goalSelector} 优先级 4 挂一条
     * {@code MeleeAttackGoal}。凋灵魔导师是空手，所以之前一直被挂上近战目标，冷却一过就
     * 贴脸砍人。覆写成空实现后它不再拥任何近战能力，只会按 {@link CasterPositionGoal}
     * 保持距离施法；索敌照旧走 {@code FactionEnemyTargetGoal}，该打谁不受影响。</p>
     */
    @Override
    public void reassessWeaponGoal() {
    }

    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        // 掉落全部走 dropCustomDeathLoot；不写这一条会再叠一份凋灵骷髅的表
        // （煤／骨头／头颅各掉一次）。
        return BuiltInLootTables.EMPTY;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 优先级 1：施法期间站定挥手（锁 MOVE／LOOK），和唤魔者一致。
        this.goalSelector.addGoal(1, new BodySpellGoal(this));
        // 优先级 2 低于施法：只在两次施法之间挪步，把目标维持到"施法距离"。
        this.goalSelector.addGoal(2, new CasterPositionGoal(this));
        // 原版骷髅系的索敌只认玩家／铁傀儡／猪灵，这里补齐"真正与阵营为敌"的生物。
        this.targetSelector.addGoal(2, new FactionEnemyTargetGoal(this));
    }

    // ================================================================ 同步数据

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_BODY_SPELL, BODY_SPELL_NONE);
        // 刚生成时魔法书就是打开的（需求：生成时不播打开动画）。
        builder.define(DATA_BOOK_OPEN, true);
        builder.define(DATA_BOOK_PHASE, BOOK_PHASE_IDLE);
        builder.define(DATA_BOOK_SPELL, BOOK_SPELL_NONE);
    }

    /** 是否处于本体施法姿态（模型据此抬手）。 */
    public boolean isCastingSpell() {
        return this.entityData.get(DATA_BODY_SPELL) != BODY_SPELL_NONE;
    }

    /** 魔法书是否打开。 */
    public boolean isBookOpen() {
        return this.entityData.get(DATA_BOOK_OPEN);
    }

    private byte getBookPhase() {
        return this.entityData.get(DATA_BOOK_PHASE);
    }

    private byte getBookSpell() {
        return this.entityData.get(DATA_BOOK_SPELL);
    }

    /**
     * 模型用的开合进度：0 = 完全合拢、1 = 完全打开。
     *
     * <p>客户端持有自己的插值值（每刻走 1/{@value #BOOK_OPEN_TICKS}），服务端直接按
     * 同步布尔返回——服务端不渲染，无所谓平滑。</p>
     */
    public float getBookOpenAmount() {
        if (!this.level().isClientSide) {
            return this.isBookOpen() ? 1.0F : 0.0F;
        }
        return this.clientBookOpen;
    }

    /**
     * 施法动作进度：0 = 两臂保持"平展"基准姿态、1 = 抬到前上方施法。
     *
     * <p>服务端只有 0／1（不渲染），客户端每刻朝目标插值：起手
     * {@value #CAST_RISE_STEP} ／收手 {@value #CAST_FALL_STEP} 每刻，于是 40 刻的施法
     * 不再是一开始就把手臂瞬间抬起来、放完又瞬间垂回去。模型与手上的施法粒子共用这个值，
     * 手抬到哪里，粒子就跟到哪里。</p>
     */
    public float getCastAmount() {
        if (!this.level().isClientSide) {
            return this.isCastingSpell() ? 1.0F : 0.0F;
        }
        return this.clientCastAmount;
    }

    // ================================================================ 存档

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ArchmageBodyCooldown", this.bodyCooldown);
        tag.putInt("ArchmageBookCooldown", this.bookCooldown);
        tag.putBoolean("ArchmageBookOpen", this.isBookOpen());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        // 老存档里的个体可能没写 PersistenceRequired 标签，读出来是 false；
        // 需求「不会自然消失」对它们同样成立，这里统一补回标记。
        this.setPersistenceRequired();
        this.bodyCooldown = Math.max(0, tag.getInt("ArchmageBodyCooldown"));
        this.bookCooldown = Math.max(0, tag.getInt("ArchmageBookCooldown"));
        // 半途的施法不保留：阶段归零，书的状态按存档恢复。
        this.bodyCastTicks = 0;
        this.bodyWarmupTicks = 0;
        this.bookTimer = 0;
        this.entityData.set(DATA_BODY_SPELL, BODY_SPELL_NONE);
        this.entityData.set(DATA_BOOK_PHASE, BOOK_PHASE_IDLE);
        this.entityData.set(DATA_BOOK_SPELL, BOOK_SPELL_NONE);
        this.entityData.set(DATA_BOOK_OPEN, tag.getBoolean("ArchmageBookOpen"));
    }

    // ================================================================ 每刻

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.clientTick();
        }
    }

    /** 客户端：书与施法动作的插值 + 三类施法粒子。 */
    private void clientTick() {
        float target = this.isBookOpen() ? 1.0F : 0.0F;
        float step = 1.0F / BOOK_OPEN_TICKS;
        if (this.clientBookOpen < target) {
            this.clientBookOpen = Math.min(target, this.clientBookOpen + step);
        } else if (this.clientBookOpen > target) {
            this.clientBookOpen = Math.max(target, this.clientBookOpen - step);
        }
        float castTarget = this.isCastingSpell() ? 1.0F : 0.0F;
        if (this.clientCastAmount < castTarget) {
            this.clientCastAmount = Math.min(castTarget, this.clientCastAmount + CAST_RISE_STEP);
        } else if (this.clientCastAmount > castTarget) {
            this.clientCastAmount = Math.max(castTarget, this.clientCastAmount - CAST_FALL_STEP);
        }
        if (this.isCastingSpell()) {
            this.spawnArmCastingParticles();
        }
        if (this.getBookPhase() == BOOK_PHASE_CHARGING) {
            this.spawnBookParticles(this.getBookSpell());
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.bodyCooldown > 0) {
            this.bodyCooldown--;
        }
        if (this.bookCooldown > 0) {
            this.bookCooldown--;
        }
        if (this.bodyCastTicks > 0) {
            this.bodyCastTicks--;
            if (this.bodyWarmupTicks > 0) {
                this.bodyWarmupTicks--;
                if (this.bodyWarmupTicks == 0) {
                    this.resolveBodySpell();
                }
            }
            if (this.bodyCastTicks == 0) {
                this.entityData.set(DATA_BODY_SPELL, BODY_SPELL_NONE);
                this.pendingBodyTarget = null;
            }
        }
        switch (this.getBookPhase()) {
            case BOOK_PHASE_OPENING -> {
                if (--this.bookTimer <= 0) {
                    this.entityData.set(DATA_BOOK_PHASE, BOOK_PHASE_CHARGING);
                    this.bookTimer = chargeTicks(this.getBookSpell());
                }
            }
            case BOOK_PHASE_CHARGING -> {
                if (--this.bookTimer <= 0) {
                    this.resolveBookSpell();
                    this.entityData.set(DATA_BOOK_PHASE, BOOK_PHASE_IDLE);
                    this.entityData.set(DATA_BOOK_SPELL, BOOK_SPELL_NONE);
                    // 用后闭合，直到下一次书类施法。
                    this.entityData.set(DATA_BOOK_OPEN, false);
                }
            }
            default -> {
            }
        }
        // 书类技能每 10 刻评估一次（范围查询有成本，且 2 秒前摇本来就慢）。
        if (this.getBookPhase() == BOOK_PHASE_IDLE && this.bookCooldown <= 0 && this.tickCount % 10 == 0) {
            this.tryStartBookSpell();
        }
        this.tryIdleHealWave();
    }

    /**
     * 闲置护理：<b>没有敌人</b>（{@link #getTarget()} 为空）时，若周围有未满血的同阵营生物，
     * 就用本体技能里的瞬伤波给它们回血。
     *
     * <p>这里用的是"造成瞬间伤害效果的那个技能"本身（{@link #castHarmWave()}），不做任何
     * 特判：亡灵吃瞬间伤害会被<b>治疗</b>是原版规则，所以半径 50 格内受伤的凋灵骷髅同袍会
     * 一起回 3 颗心，而同一发波扫到的非亡灵活物照旧吃伤害——这既是用户点名的技能原样，
     * 也顺手成为"被围殴时的应急手段"。冷却与本体两种技能共用同一份 {@link #bodyCooldown}，
     * 因此不会因为多出这条闲置逻辑而刷屏；书类技能正在施放时不插手，避免一处动作同时干两件事。</p>
     */
    private void tryIdleHealWave() {
        if (this.getTarget() != null
                || this.bodyCastTicks > 0
                || this.bodyCooldown > 0
                || this.getBookPhase() != BOOK_PHASE_IDLE
                || this.tickCount % IDLE_ALLY_CHECK_INTERVAL_TICKS != 0) {
            return;
        }
        LivingEntity wounded = this.findWoundedAlly();
        if (wounded == null) {
            return;
        }
        this.startBodySpell(BODY_SPELL_HARM, wounded);
        this.getLookControl().setLookAt(wounded, 30.0F, 30.0F);
    }

    // ================================================================ 本体技能

    private void startBodySpell(byte spell, LivingEntity target) {
        this.pendingBodyTarget = target;
        this.bodyCastTicks = SPELL_CAST_TICKS;
        this.bodyWarmupTicks = SPELL_WARMUP_TICKS;
        this.bodyCooldown = BODY_COOLDOWN_TICKS;
        this.entityData.set(DATA_BODY_SPELL, spell);
    }

    /**
     * 本体技能轮换：贴脸（{@value #HARM_PREFERRED_RANGE_SQR} 平方 = 6 格内）先用瞬伤波保命，
     * 其余情况两颗技能交替出招。
     *
     * <p>两种本体技能共享 15 秒冷却，理论上每种只有一半的出场机会；单纯按距离挑的话，
     * 只要目标一直在 6 格外就永远只放陨石，技能 2 形同不存在。这里改成"远距离轮换"，
     * 30 秒内必定两种都见得到。</p>
     */
    private byte chooseBodySpell(LivingEntity target) {
        if (this.distanceToSqr(target) <= HARM_PREFERRED_RANGE_SQR) {
            return BODY_SPELL_HARM;
        }
        this.bodySkillToggle = !this.bodySkillToggle;
        return this.bodySkillToggle ? BODY_SPELL_METEOR : BODY_SPELL_HARM;
    }

    private void resolveBodySpell() {
        byte spell = this.entityData.get(DATA_BODY_SPELL);
        if (spell == BODY_SPELL_METEOR) {
            this.castSoulMeteors(this.pendingBodyTarget);
        } else if (spell == BODY_SPELL_HARM) {
            this.castHarmWave();
        }
    }

    /** 技能 1：自身上方 10 格召唤 3 颗灵魂陨石，直线轰向目标当前位置。 */
    private void castSoulMeteors(LivingEntity target) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        Vec3 aim = target != null ? target.position() : this.position().add(this.forward().scale(6.0D));
        for (int i = 0; i < METEOR_COUNT; i++) {
            Vec3 spawn = new Vec3(
                    this.getX() + (this.random.nextDouble() * 2.0D - 1.0D) * METEOR_XZ_SPREAD,
                    this.getY() + METEOR_SPAWN_HEIGHT
                            + (this.random.nextDouble() * 2.0D - 1.0D) * METEOR_Y_SPREAD,
                    this.getZ() + (this.random.nextDouble() * 2.0D - 1.0D) * METEOR_XZ_SPREAD);
            Vec3 toAim = aim.subtract(spawn);
            if (toAim.lengthSqr() < 1.0E-4D) {
                continue;
            }
            Vec3 direction = deviate(toAim.normalize(),
                    this.random.nextDouble() * METEOR_MAX_DEVIATION_DEGREES);
            SoulMeteorite meteor = new SoulMeteorite(GeneratedMod.SOUL_METEORITE.get(), serverLevel);
            meteor.setOwner(this);
            meteor.setAim(aim);
            meteor.setPos(spawn.x, spawn.y, spawn.z);
            meteor.setDeltaMovement(direction.scale(SoulMeteorite.SPEED));
            serverLevel.addFreshEntity(meteor);
        }
        this.playSound(SoundEvents.EVOKER_PREPARE_SUMMON, 1.2F, 0.7F);
        this.playSound(SoundEvents.SOUL_ESCAPE.value(), 1.0F, 0.6F);
    }

    /**
     * 技能 2：半径 50 格（= 索敌半径）内一切活物（含友军与自身）获得瞬间伤害 I。
     *
     * <p>闲置期给同袍回血走的也是这一发（见 {@link #tryIdleHealWave()}）：亡灵吃瞬间伤害
     * 会被治疗，所以受伤的凋灵骷髅同袍在波里回血，非亡灵活物照旧吃伤害。</p>
     */
    private void castHarmWave() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        List<LivingEntity> victims = this.entitiesWithinSkillRadius(LivingEntity::isAlive);
        for (LivingEntity victim : victims) {
            victim.addEffect(new MobEffectInstance(MobEffects.HARM, 1, 0), this);
        }
        serverLevel.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0D, this.getZ(),
                40, this.skillRadius() * 0.4D, 1.0D, this.skillRadius() * 0.4D, 0.05D);
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 1.2F, 0.6F);
    }

    // ================================================================ 魔法书技能

    private void tryStartBookSpell() {
        byte spell = this.chooseBookSpell();
        if (spell == BOOK_SPELL_NONE) {
            return;
        }
        this.entityData.set(DATA_BOOK_SPELL, spell);
        this.bookCooldown = cooldownTicks(spell);
        if (this.isBookOpen()) {
            // 已经开着：直接蓄力，不播打开动画。
            this.entityData.set(DATA_BOOK_PHASE, BOOK_PHASE_CHARGING);
            this.bookTimer = chargeTicks(spell);
        } else {
            this.entityData.set(DATA_BOOK_PHASE, BOOK_PHASE_OPENING);
            this.bookTimer = BOOK_OPEN_TICKS;
            this.entityData.set(DATA_BOOK_OPEN, true);
        }
        this.playSound(SoundEvents.BOOK_PAGE_TURN, 1.0F, 0.9F);
    }

    /**
     * 从当前具备条件的书类技能里挑一个，让五个技能都有机会出场。
     *
     * <p>三类书类技能共享冷却，所以每次只能出一个；若同时具备多项条件，会避开上一次刚用过的
     * 那个（≥2 项可选时），否则纯随机很容易连抽两次同一个，看起来像"只实现了一个技能"。</p>
     */
    private byte chooseBookSpell() {
        List<Byte> ready = new ArrayList<>(3);
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive() && this.hasLineOfSight(target)) {
            ready.add(BOOK_SPELL_OVERLORD);
        }
        if (this.hasEnchantableAllyInRange()) {
            ready.add(BOOK_SPELL_ENCHANT);
        }
        if (this.hasEnemyInRange()) {
            ready.add(BOOK_SPELL_CURSE);
        }
        if (ready.isEmpty()) {
            return BOOK_SPELL_NONE;
        }
        if (ready.size() > 1) {
            ready.remove(Byte.valueOf(this.lastBookSpell));
        }
        byte chosen = ready.get(this.random.nextInt(ready.size()));
        this.lastBookSpell = chosen;
        return chosen;
    }

    private void resolveBookSpell() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        switch (this.getBookSpell()) {
            case BOOK_SPELL_OVERLORD -> this.fireOverlordSkull(serverLevel);
            case BOOK_SPELL_ENCHANT -> this.enchantAllies(serverLevel);
            case BOOK_SPELL_CURSE -> this.curseEnemies();
            default -> {
            }
        }
    }

    /** 书类技能 1：从书口射出一枚霸主凋灵之首。 */
    private void fireOverlordSkull(ServerLevel level) {
        Vec3 origin = this.bookPosition();
        LivingEntity target = this.getTarget();
        Vec3 aim = target != null ? target.getEyePosition() : origin.add(this.forward().scale(8.0D));
        Vec3 direction = aim.subtract(origin);
        if (direction.lengthSqr() < 1.0E-6D) {
            direction = this.forward();
        }
        OverlordWitherSkull skull = new OverlordWitherSkull(level, this, direction.normalize(), false);
        skull.setPosRaw(origin.x, origin.y, origin.z);
        level.addFreshEntity(skull);
        this.playSound(SoundEvents.WITHER_SHOOT, 1.0F, 1.2F);
        // 需求：射这一发的同时顺带召出 3 名带武器装备的凋灵仆役。
        this.summonBookEscort(level);
    }

    /**
     * 书类技能 1 的随行召唤：射出霸主凋灵之首的同时，从身边召出
     * {@value #ESCORT_COUNT} 名 {@link WitherServant}。
     *
     * <p>每名仆役的主手从石剑／弓／重锤／弩／三叉戟里随机一件，身上随机穿 1~4 件金质
     * 盔甲（槽位不重复）。仇恨用凋零印记与魔导师保持一致：召唤瞬间就盯上魔导师当前的
     * 目标，之后每刻由 {@code WitherEnhancementHandler#syncSummonedMobTarget} 跟住同一个
     * 目标——这套印记原本只服务霸主凋灵的召唤物，现在召唤者放宽到任意 {@code Mob}。</p>
     */
    private void summonBookEscort(ServerLevel level) {
        for (int i = 0; i < ESCORT_COUNT; i++) {
            WitherServant servant = GeneratedMod.WITHER_SERVANT.get().create(level);
            if (servant == null) {
                continue;
            }
            Vec3 spot = this.findEscortSpot(level, servant);
            servant.moveTo(spot.x, spot.y, spot.z, this.random.nextFloat() * 360.0F, 0.0F);
            servant.finalizeSpawn(level, level.getCurrentDifficultyAt(servant.blockPosition()),
                    MobSpawnType.TRIGGERED, null);
            servant.setItemSlot(EquipmentSlot.MAINHAND,
                    new ItemStack(ESCORT_WEAPONS[this.random.nextInt(ESCORT_WEAPONS.length)]));
            List<EquipmentSlot> armorPool = new ArrayList<>(List.of(ARMOR_SLOTS));
            int armorCount = 1 + this.random.nextInt(armorPool.size());
            for (int n = 0; n < armorCount; n++) {
                EquipmentSlot slot = armorPool.remove(this.random.nextInt(armorPool.size()));
                servant.setItemSlot(slot, new ItemStack(goldenArmorFor(slot)));
            }
            servant.setPersistenceRequired();
            WitherEnhancementHandler.markSummonedBy(servant, this);
            level.addFreshEntityWithPassengers(servant);
        }
        level.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0D, this.getZ(),
                20, 2.0D, 1.0D, 2.0D, 0.02D);
        this.playSound(SoundEvents.EVOKER_PREPARE_SUMMON, 1.0F, 0.8F);
    }

    /** 金质盔甲槽位对应的物品。 */
    private static Item goldenArmorFor(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> Items.GOLDEN_HELMET;
            case CHEST -> Items.GOLDEN_CHESTPLATE;
            case LEGS -> Items.GOLDEN_LEGGINGS;
            default -> Items.GOLDEN_BOOTS;
        };
    }

    /** 在魔导师身边随机找一个站得下的空位；10 次都撞方块的退化成自身位置。 */
    private Vec3 findEscortSpot(ServerLevel level, WitherServant servant) {
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            double distance = 1.5D + this.random.nextDouble() * 2.5D;
            double x = this.getX() + Math.cos(angle) * distance;
            double z = this.getZ() + Math.sin(angle) * distance;
            double y = this.getY();
            AABB box = servant.getBoundingBox()
                    .move(x - servant.getX(), y - servant.getY(), z - servant.getZ());
            if (level.noCollision(servant, box)) {
                return new Vec3(x, y, z);
            }
        }
        return this.position();
    }

    /** 书类技能 2：半径 50 格（= 索敌半径）内友军的每件装备随机附魔一次或升一级。 */
    private void enchantAllies(ServerLevel level) {
        List<LivingEntity> allies = this.entitiesWithinSkillRadius(
                entity -> entity.isAlive() && isAlly(entity));
        for (LivingEntity ally : allies) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                ItemStack stack = ally.getItemBySlot(slot);
                if (isEnchantTarget(level, stack)) {
                    this.enchantRandomly(level, stack);
                }
            }
        }
        this.playSound(SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 0.9F);
    }

    /** 一件装备：随机加一项可附魔的附魔，或把已有附魔随机升一级。 */
    private void enchantRandomly(ServerLevel level, ItemStack stack) {
        Registry<Enchantment> registry = level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        ItemEnchantments existing = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        List<Holder<Enchantment>> upgradable = upgradableEnchantments(existing);
        if (!upgradable.isEmpty() && this.random.nextBoolean()) {
            Holder<Enchantment> pick = upgradable.get(this.random.nextInt(upgradable.size()));
            applyEnchantmentLevel(stack, existing, pick, existing.getLevel(pick) + 1);
            return;
        }
        List<Holder.Reference<Enchantment>> candidates = registry.holders()
                .filter(holder -> existing.getLevel(holder) == 0)
                .filter(holder -> holder.value().getMinLevel() <= giftLevelCap(holder.value()))
                .filter(holder -> holder.value().canEnchant(stack))
                .filter(holder -> existing.keySet().stream()
                        .allMatch(current -> Enchantment.areCompatible(current, holder)))
                .toList();
        if (candidates.isEmpty()) {
            return;
        }
        Holder.Reference<Enchantment> pick = candidates.get(this.random.nextInt(candidates.size()));
        int min = pick.value().getMinLevel();
        int max = giftLevelCap(pick.value());
        int chosenLevel = min + (max > min ? this.random.nextInt(max - min + 1) : 0);
        applyEnchantmentLevel(stack, existing, pick, chosenLevel);
    }

    /**
     * 魔导师<b>新给</b>一项附魔时的最高等级：原版最高等级与
     * {@value #MAX_GIFTED_ENCHANTMENT_LEVEL} 取小。
     *
     * <p>只给"从无到有"那一半用；升级用的是附魔的原版最高等级，见
     * {@link #upgradableEnchantments}。</p>
     */
    private static int giftLevelCap(Enchantment enchantment) {
        return Math.min(enchantment.getMaxLevel(), MAX_GIFTED_ENCHANTMENT_LEVEL);
    }

    /**
     * 这件装备上还能再升一级的附魔：等级 <b>该附魔在原版的最高等级</b> 的那些。
     *
     * <p>这里刻意<b>不用</b> {@link #giftLevelCap}：2 级上限只约束"魔导师新给什么"，
     * 升级只受游戏内最高等级限制。若拿 {@code giftLevelCap} 当可升上限，一件已经有
     * 2 级附魔的装备就永远升不动了（2 < 2 不成立），与"2 级附魔照常升级"的要求相悖。</p>
     */
    private static List<Holder<Enchantment>> upgradableEnchantments(ItemEnchantments existing) {
        List<Holder<Enchantment>> upgradable = new ArrayList<>();
        for (Holder<Enchantment> holder : existing.keySet()) {
            if (existing.getLevel(holder) < holder.value().getMaxLevel()) {
                upgradable.add(holder);
            }
        }
        return upgradable;
    }

    /**
     * 把某项附魔写成指定等级（越界一律夹到<b>该附魔的原版最高等级</b>以内，
     * 新附魔的 2 级上限由 {@link #enchantRandomly} 在算等级时就已经收窄，这里不再重复夹）。
     *
     * <p><b>这里必须走 {@link ItemEnchantments.Mutable#set}，不能用
     * {@link ItemEnchantments.Mutable#upgrade}。</b>1.21.1 的 {@code upgrade} 实现是
     * {@code enchantments.merge(holder, level, Integer::max)}——语义是"至少这么多级"，
     * 对一件已经 1 级的附魔传 {@code 1} 进去是原地不动，所以原先写的"升一级"
     * （{@code upgrade(pick, 1)}）在老装备上永远看不到变化，而"新加一项附魔"走的是
     * {@code set}，所以只有那一半生效。改成 {@code set(等级 + 1)} 才真的加一级。</p>
     *
     * <p>另外这里不走 {@code EnchantmentHelper#updateEnchantments}：那个方法在
     * 装备连附魔组件都没有时直接返回 {@code EMPTY} 什么都不写，而这里用
     * {@code setEnchantments} 把整份结果写回去，空组件装备也一样吃得下。</p>
     */
    private static void applyEnchantmentLevel(ItemStack stack, ItemEnchantments existing,
                                              Holder<Enchantment> pick, int level) {
        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(existing);
        mutable.set(pick, Math.min(level, pick.value().getMaxLevel()));
        EnchantmentHelper.setEnchantments(stack, mutable.toImmutable());
    }

    /**
     * 这件装备是否"吃得到"本次附魔：要么还有能升一级的附魔，要么还能新加一项附魔。
     *
     * <p>判据与 {@link #enchantRandomly} 真正动手的两个分支逐条对齐，所以返回 {@code true}
     * 就必定会改动这件装备；返回 {@code false} 的（空槽、不能附魔的物品、附魔全顶到原版最高
     * 等级且无可兼容的新附魔）一律跳过。附魔技能"周围友军有没有武器装备"的起手判定也读这一份口径。</p>
     */
    private static boolean isEnchantTarget(Level level, ItemStack stack) {
        if (stack.isEmpty() || !EnchantmentHelper.canStoreEnchantments(stack)) {
            return false;
        }
        ItemEnchantments existing = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        if (!upgradableEnchantments(existing).isEmpty()) {
            return true;
        }
        Registry<Enchantment> registry = level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        return registry.holders().anyMatch(holder -> existing.getLevel(holder) == 0
                && holder.value().getMinLevel() <= giftLevelCap(holder.value())
                && holder.value().canEnchant(stack)
                && existing.keySet().stream()
                        .allMatch(current -> Enchantment.areCompatible(current, holder)));
    }

    /** 书类技能 3：半径 50 格（= 索敌半径）内敌人获得 10 秒反胃／虚弱／缓慢 + 5 秒灵魂火。 */
    private void curseEnemies() {
        List<LivingEntity> enemies = this.entitiesWithinSkillRadius(
                entity -> entity.isAlive() && this.isFactionEnemy(entity));
        for (LivingEntity enemy : enemies) {
            enemy.addEffect(new MobEffectInstance(MobEffects.CONFUSION, CURSE_EFFECT_TICKS, 0), this);
            enemy.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CURSE_EFFECT_TICKS, 0), this);
            enemy.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, CURSE_EFFECT_TICKS, 0), this);
            SoulFireBurn.ignite(enemy, CURSE_SOUL_FIRE_SECONDS);
        }
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 1.2F, 0.5F);
    }

    private static int chargeTicks(byte spell) {
        return switch (spell) {
            case BOOK_SPELL_ENCHANT -> ENCHANT_CHARGE_TICKS;
            case BOOK_SPELL_CURSE -> CURSE_CHARGE_TICKS;
            default -> OVERLORD_CHARGE_TICKS;
        };
    }

    private static int cooldownTicks(byte spell) {
        return switch (spell) {
            case BOOK_SPELL_ENCHANT -> ENCHANT_COOLDOWN_TICKS;
            case BOOK_SPELL_CURSE -> CURSE_COOLDOWN_TICKS;
            default -> OVERLORD_COOLDOWN_TICKS;
        };
    }

    // ================================================================ 易伤

    /**
     * 施加／升级易伤：再次获得时等级 +1（上限 {@link VulnerabilityMobEffect#MAX_AMPLIFIER} + 1）。
     *
     * <p>不动持续时间之外的任何字段：粒子交给
     * {@link #spawnVulnerabilityParticles} 手动发给附近玩家——1.21.1 不同步非玩家生物的
     * 状态效果，靠原版效果粒子的话，别的生物身上的易伤在客户端根本看不见。</p>
     */
    public static void applyVulnerability(LivingEntity target, int durationTicks) {
        MobEffectInstance current = target.getEffect(GeneratedMod.VULNERABILITY);
        int amplifier = current == null
                ? 0
                : Math.min(current.getAmplifier() + 1, VulnerabilityMobEffect.MAX_AMPLIFIER);
        target.addEffect(new MobEffectInstance(GeneratedMod.VULNERABILITY, durationTicks, amplifier,
                false, false, true));
    }

    /** 深青色易伤粒子，服务端广播。 */
    public static void spawnVulnerabilityParticles(Level level, LivingEntity entity) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        ColorParticleOption particle = ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT,
                0x11 / 255.0F, 0x66 / 255.0F, 0x6B / 255.0F);
        serverLevel.sendParticles(particle,
                entity.getX(), entity.getY() + entity.getBbHeight() * 0.5D, entity.getZ(),
                12, entity.getBbWidth() * 0.6D, entity.getBbHeight() * 0.4D, entity.getBbWidth() * 0.6D,
                0.0D);
    }

    // ================================================================ 目标筛选

    /** 友军：同阵营（凋灵骷髅及名册成员）。 */
    private static boolean isAlly(LivingEntity entity) {
        return entity instanceof WitherSkeleton || WitherFactionRoster.isMember(entity);
    }

    /**
     * 是否值得出手的敌人：与反转士同一套判据的裁剪版——创造／旁观豁免、同阵营不算、
     * 心控对象不算、玩家／铁傀儡／雪傀儡／猪灵系固定为敌，其余"见谁打谁"的敌对怪也算。
     */
    private boolean isFactionEnemy(LivingEntity entity) {
        if (entity == null || entity == this || !entity.isAlive() || isAlly(entity)
                || !MesmerizerControl.canAttack(this, entity)) {
            return false;
        }
        if (entity instanceof Player player) {
            return !player.isCreative() && !player.isSpectator();
        }
        if (entity instanceof IronGolem || entity instanceof SnowGolem || entity instanceof AbstractPiglin) {
            return true;
        }
        return entity instanceof Enemy && !(entity instanceof NeutralMob);
    }

    /**
     * 附近是否有"带着可附魔武器装备"的友军——附魔技能只在这种情况下才起手。
     *
     * <p>与 {@link #hasEnemyInRange} 一样把自己排除在外：魔导师是纯施法者，自身装备不算
     * "周围的友军"。周围只有没武器装备（或装备已无附魔余地）的友军时返回 {@code false}，
     * 这一次书类技能就不会轮到附魔强化，改去放另外两项。</p>
     */
    private boolean hasEnchantableAllyInRange() {
        List<LivingEntity> allies = this.entitiesWithinSkillRadius(
                entity -> entity != this && entity.isAlive() && isAlly(entity));
        for (LivingEntity ally : allies) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (isEnchantTarget(this.level(), ally.getItemBySlot(slot))) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean hasEnemyInRange() {
        return !this.entitiesWithinSkillRadius(
                entity -> entity.isAlive() && this.isFactionEnemy(entity)).isEmpty();
    }

    /**
     * 闲置期的护理目标：半径内<b>除自己以外</b>、已受伤的同阵营生物里最近的一个，没有则 {@code null}。
     *
     * <p>口径与 {@link #isAlly} 完全一致（原版凋灵骷髅 + {@link WitherFactionRoster} 名册）。
     * 排除自己是有意的：魔导师是纯施法者，只有"周围的同袍"才值得花一次本体冷却；
     * 若把自己也算进来，它掉一点血就会天天对着空气挥手。</p>
     */
    private LivingEntity findWoundedAlly() {
        LivingEntity nearest = null;
        double nearestSqr = Double.MAX_VALUE;
        for (LivingEntity ally : this.entitiesWithinSkillRadius(entity -> entity != this
                && entity.isAlive()
                && isAlly(entity)
                && entity.getHealth() < entity.getMaxHealth())) {
            double distanceSqr = this.distanceToSqr(ally);
            if (distanceSqr < nearestSqr) {
                nearestSqr = distanceSqr;
                nearest = ally;
            }
        }
        return nearest;
    }

    // ================================================================ 攻击半径（= 索敌半径）

    /**
     * 攻击半径（格）：直接读实体当前的 {@code FOLLOW_RANGE} 属性值，也就是索敌半径。
     *
     * <p>这样"攻击范围与索敌范围一致"不是靠两处常量碰巧写同一个数，而是同一条属性的
     * 同一个值：以后无论谁改了 {@code FOLLOW_RANGE}（属性修饰符、难度、别的模组），
     * 技能半径都会跟着变。属性缺失或非正数时退回 {@link #FOLLOW_RANGE_BLOCKS}。</p>
     */
    public double skillRadius() {
        double range = this.getAttributeValue(Attributes.FOLLOW_RANGE);
        return range > 0.0D ? range : FOLLOW_RANGE_BLOCKS;
    }

    /** {@link #skillRadius()} 的平方，供距离比较用。 */
    private double skillRadiusSqr() {
        double radius = this.skillRadius();
        return radius * radius;
    }

    /**
     * 施法半径内满足条件的一切活物。
     *
     * <p>先用包围盒外扩捞候选（查询本身只支持 AABB），再按<b>实体中心距</b>收进球内。
     * 这一步就是"攻击范围 = 索敌范围"的落点：原版索敌量的是球面距离
     * （{@code TargetGoal#getFollowDistance} 交给 {@code TargetingConditions#range}），
     * 若这里只做 {@code inflate(半径)}，攻击范围就成了立方体，斜对角能多够到
     * {@code √3} 倍（50 → 约 86.6 格），刚好会打到索敌看不见的敌人。收回球内之后，
     * 两条边界的圆心与半径完全一致。</p>
     */
    private List<LivingEntity> entitiesWithinSkillRadius(Predicate<LivingEntity> filter) {
        double radius = this.skillRadius();
        double radiusSqr = radius * radius;
        return this.level().getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(radius),
                entity -> this.distanceToSqr(entity) <= radiusSqr && filter.test(entity));
    }

    // ================================================================ 几何辅助

    /** 水平朝向：与实体 yaw 一致的前方（世界坐标）。 */
    private Vec3 forward() {
        float yaw = this.yBodyRot * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0.0D, Mth.cos(yaw));
    }

    /**
     * 魔法书胸口位置：模型里书在身前约 0.84 格、高约 1.41 格（按 {@value #MODEL_SCALE}
     * 放大后为 1.01 / 1.69 格）。
     */
    private Vec3 bookPosition() {
        Vec3 f = this.forward();
        return new Vec3(this.getX() + f.x * 0.84D * MODEL_SCALE,
                this.getY() + 1.41D * MODEL_SCALE,
                this.getZ() + f.z * 0.84D * MODEL_SCALE);
    }

    /**
     * 手掌位置（side = +1 模型左侧、-1 模型右侧），施法粒子贴在这里。
     *
     * <p>数值由模型骨骼算出（臂骨枢轴已在肩关节，抬起就是绕肩旋转）：平展时手掌在身前
     * 约 0.66 格、高约 1.34 格、离中轴 0.33 格；往上抬到位后（臂骨从 -90° 再减 1.00 rad
     * 并向外张 0.30 rad，取挥手颤动的中值）手掌升到高约 1.94 格、身前约 0.31 格、
     * 向外张开到离中轴约 0.50 格。按 {@link #getCastAmount()} 在两者之间插值，
     * 粒子就始终跟着手走。这些都是模型空间格数，最后统一乘 {@value #MODEL_SCALE}。</p>
     */
    private Vec3 armTip(double side) {
        float yaw = this.yBodyRot * Mth.DEG_TO_RAD;
        Vec3 f = new Vec3(-Mth.sin(yaw), 0.0D, Mth.cos(yaw));
        Vec3 leftAxis = new Vec3(Mth.cos(yaw), 0.0D, -Mth.sin(yaw));
        double cast = this.getCastAmount();
        double forward = Mth.lerp(cast, 0.66D, 0.31D) * MODEL_SCALE;
        double height = Mth.lerp(cast, 1.34D, 1.94D) * MODEL_SCALE;
        double lateral = Mth.lerp(cast, 0.33D, 0.50D) * MODEL_SCALE;
        return new Vec3(
                this.getX() + f.x * forward + leftAxis.x * side * lateral,
                this.getY() + height,
                this.getZ() + f.z * forward + leftAxis.z * side * lateral);
    }

    /** 把单位向量随机偏转到锥角内（最多 degrees 度）。 */
    private static Vec3 deviate(Vec3 direction, double degrees) {
        if (degrees <= 0.0D) {
            return direction;
        }
        Vec3 reference = Math.abs(direction.y) > 0.9D ? new Vec3(1.0D, 0.0D, 0.0D)
                : new Vec3(0.0D, 1.0D, 0.0D);
        Vec3 ortho = direction.cross(reference).normalize();
        Vec3 ortho2 = direction.cross(ortho).normalize();
        double angle = Math.toRadians(degrees) * Math.random();
        double roll = Math.random() * Math.PI * 2.0D;
        Vec3 tilt = ortho.scale(Math.cos(roll)).add(ortho2.scale(Math.sin(roll)));
        return direction.scale(Math.cos(angle)).add(tilt.scale(Math.sin(angle))).normalize();
    }

    // ================================================================ 粒子

    /** 本体施法：平展的两只手掌处冒深青色药水粒子。 */
    private void spawnArmCastingParticles() {
        if (this.tickCount % 2 != 0) {
            return;
        }
        ColorParticleOption particle = ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT,
                0x11 / 255.0F, 0x66 / 255.0F, 0x6B / 255.0F);
        for (int side = -1; side <= 1; side += 2) {
            Vec3 tip = this.armTip(side);
            this.level().addParticle(particle,
                    tip.x + (this.random.nextDouble() - 0.5D) * 0.2D,
                    tip.y + (this.random.nextDouble() - 0.5D) * 0.2D,
                    tip.z + (this.random.nextDouble() - 0.5D) * 0.2D,
                    0.0D, 0.02D, 0.0D);
        }
    }

    /** 书类蓄力特效：黑烟上涨／附魔台符文／灵魂火苗。 */
    private void spawnBookParticles(byte spell) {
        Vec3 book = this.bookPosition();
        for (int i = 0; i < 4; i++) {
            double x = book.x + (this.random.nextDouble() - 0.5D) * 0.55D;
            double y = book.y + (this.random.nextDouble() - 0.5D) * 0.35D;
            double z = book.z + (this.random.nextDouble() - 0.5D) * 0.55D;
            switch (spell) {
                case BOOK_SPELL_OVERLORD -> this.level().addParticle(ParticleTypes.SMOKE,
                        x, y, z, 0.0D, 0.06D, 0.0D);
                case BOOK_SPELL_ENCHANT -> this.level().addParticle(ParticleTypes.ENCHANT,
                        x, y, z,
                        book.x - x, book.y - y + 0.3D, book.z - z);
                case BOOK_SPELL_CURSE -> this.level().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                        x, y, z, 0.0D, 0.01D, 0.0D);
                default -> {
                }
            }
        }
    }

    // ================================================================ 掉落

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        RandomSource random = this.getRandom();
        this.spawnAtLocation(new ItemStack(Items.BONE, 1 + random.nextInt(3)));
        this.spawnAtLocation(new ItemStack(Items.COAL, 1 + random.nextInt(3)));
        this.spawnAtLocation(new ItemStack(Items.SOUL_SAND, 1 + random.nextInt(2)));
        this.spawnAtLocation(new ItemStack(Items.GLOWSTONE_DUST, 1 + random.nextInt(3)));
        this.spawnAtLocation(new ItemStack(GeneratedMod.NETHER_CRYSTAL_SHARD.get(), 1 + random.nextInt(2)));
        this.spawnAtLocation(new ItemStack(Items.QUARTZ, 1 + random.nextInt(3)));
        if (random.nextFloat() < 0.5F) {
            this.spawnAtLocation(new ItemStack(Items.GHAST_TEAR, 1 + random.nextInt(2)));
        }
        if (random.nextFloat() < 0.5F) {
            this.spawnAtLocation(new ItemStack(Items.GOLD_INGOT, 1 + random.nextInt(2)));
        }
        if (random.nextFloat() < 0.5F) {
            ItemStack book = EnchantmentHelper.enchantItem(random, new ItemStack(Items.BOOK), 30,
                    level.registryAccess().registryOrThrow(Registries.ENCHANTMENT).holders()
                            .map(holder -> (Holder<Enchantment>) holder));
            this.spawnAtLocation(book);
        }
        // 较低概率
        if (random.nextFloat() < 0.2F) {
            this.spawnAtLocation(new ItemStack(Items.WITHER_SKELETON_SKULL));
        }
        if (random.nextFloat() < 0.15F) {
            this.spawnAtLocation(new ItemStack(Items.NETHERITE_SCRAP));
        }
        // 极低概率
        if (random.nextFloat() < 0.03F) {
            this.spawnAtLocation(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE));
        }
        if (random.nextFloat() < 0.02F) {
            this.spawnAtLocation(new ItemStack(Items.NETHERITE_INGOT));
        }
    }

    // ================================================================ 内部目标

    /**
     * 本体施法目标：冷却就绪且有目标就站定挥手，前摇结束结算。
     *
     * <p>起手距离用 {@link WitherArchmage#skillRadiusSqr()}，也就是 {@code FOLLOW_RANGE}
     * 本身：索敌到多远，本体技能就能在多远出手，不多一格也不少一格。</p>
     */
    private static final class BodySpellGoal extends Goal {
        private final WitherArchmage archmage;
        private LivingEntity target;

        private BodySpellGoal(WitherArchmage archmage) {
            this.archmage = archmage;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (this.archmage.level().isClientSide
                    || this.archmage.bodyCooldown > 0
                    || this.archmage.bodyCastTicks > 0) {
                return false;
            }
            LivingEntity candidate = this.archmage.getTarget();
            if (candidate == null || !candidate.isAlive()
                    || this.archmage.distanceToSqr(candidate) > this.archmage.skillRadiusSqr()) {
                return false;
            }
            this.target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.archmage.bodyCastTicks > 0;
        }

        @Override
        public void start() {
            this.archmage.startBodySpell(this.archmage.chooseBodySpell(this.target), this.target);
        }

        @Override
        public void tick() {
            LivingEntity pending = this.archmage.pendingBodyTarget;
            if (pending != null && pending.isAlive()) {
                this.archmage.getLookControl().setLookAt(pending, 30.0F, 30.0F);
            }
        }

        @Override
        public void stop() {
            this.target = null;
        }
    }

    /**
     * 施法站位：<b>目标在索敌半径内就原地不动</b>，只有目标跑出索敌半径才追回去，
     * 只有被贴到 {@value WitherArchmage#RETREAT_DISTANCE} 格以内才后撤。
     *
     * <p>这里刻意没有"目标太远就靠近到某个更近的距离"这一条。之前版本把站位维持在
     * 9~20 格的"施法距离"上，于是出现"第一次施法在 50 格外就地出手，施法一结束又被
     * 拖到 20 格"的割裂感——那等于索敌半径 50、实际开打距离 20，跟"攻击范围与索敌
     * 范围一致"自相矛盾。现在追与撤的切换点就是 {@link WitherArchmage#skillRadius()}
     * 本身（和本体技能的出手判定同一份数值），所以它在哪儿开始施法就在哪儿施法。</p>
     *
     * <p>优先级 2，低于本体施法（1）：{@link BodySpellGoal} 一旦开始就锁住 MOVE／LOOK，
     * 这条自动让位，于是节奏就是"站定 → 挥手 → 放完继续站着"，而不是近战怪那样一路贴脸。
     * 它也顺带压住骷髅系默认的巡游／近战目标，保证"站定"不会被别的目标打断。</p>
     */
    private static final class CasterPositionGoal extends Goal {
        private final WitherArchmage archmage;
        private LivingEntity target;
        private int repathCooldown;

        private CasterPositionGoal(WitherArchmage archmage) {
            this.archmage = archmage;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (this.archmage.level().isClientSide) {
                return false;
            }
            LivingEntity candidate = this.archmage.getTarget();
            if (candidate == null || !candidate.isAlive()
                    || this.archmage.distanceToSqr(candidate) > this.archmage.skillRadiusSqr()) {
                return false;
            }
            this.target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.canUse();
        }

        @Override
        public void start() {
            this.repathCooldown = 0;
        }

        @Override
        public void tick() {
            LivingEntity candidate = this.target;
            if (candidate == null) {
                return;
            }
            this.archmage.getLookControl().setLookAt(candidate, 30.0F, 30.0F);
            if (this.repathCooldown > 0) {
                this.repathCooldown--;
                return;
            }
            this.repathCooldown = REPATH_INTERVAL_TICKS;
            double distance = Math.sqrt(this.archmage.distanceToSqr(candidate));
            if (distance < RETREAT_DISTANCE) {
                this.retreat(candidate);
            } else if (distance > this.archmage.skillRadius()) {
                // 目标已经跑出索敌半径（被动/援护锁定）：追到贴边为止，多一格都不追。
                this.archmage.getNavigation().moveTo(candidate, CAST_MOVE_SPEED);
            } else {
                // 在索敌半径内就地站定施法：既不靠近也不后退。
                this.archmage.getNavigation().stop();
            }
        }

        /** 沿"目标 → 自己"方向退到贴身距离之外。 */
        private void retreat(LivingEntity candidate) {
            Vec3 away = this.archmage.position().subtract(candidate.position());
            Vec3 flat = new Vec3(away.x, 0.0D, away.z);
            if (flat.lengthSqr() < 1.0E-4D) {
                // 与目标重合／正上方：随便挑一侧退开。
                flat = this.archmage.forward();
            }
            Vec3 destination = this.archmage.position()
                    .add(flat.normalize().scale(RETREAT_DISTANCE));
            this.archmage.getNavigation().moveTo(destination.x, destination.y, destination.z,
                    CAST_MOVE_SPEED);
        }

        @Override
        public void stop() {
            this.target = null;
            this.archmage.getNavigation().stop();
        }
    }

    /**
     * 阵营宿敌索敌：与出手判据同源。
     *
     * <p>索敌半径不在这里写死，走原版 {@code TargetGoal#getFollowDistance()}，即实体的
     * {@code FOLLOW_RANGE}（{@link #FOLLOW_RANGE_BLOCKS} 格）；技能侧读同一条属性的
     * {@link #skillRadius()}，所以"看得见"和"打得到"是同一个球。构造器第 3 个参数 10
     * 是重新搜索目标的间隔刻数，与距离无关。</p>
     */
    private static final class FactionEnemyTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
        private FactionEnemyTargetGoal(WitherArchmage archmage) {
            super(archmage, LivingEntity.class, 10, true, false, archmage::isFactionEnemy);
        }
    }
}
