package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.GeneratedMod;
import cn.blockforge.generated.netherarmy.GravityReversalState;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 重力反转的渲染半边：让带效果的生物模型"头上脚下"。
 *
 * <p><b>不再自己写翻转矩阵。</b>上一版在 {@code LivingEntityRenderer#render} 的
 * {@code pushPose()} 之后手动叠了一串
 * {@code T(0,h/2,0)·Ry(-yaw)·Rz(180°)·Ry(yaw)·T(0,-h/2,0)}，看着是"绕身体朝向轴翻 180°"，
 * 但它只是矩阵上的一次改动，模型坐标系的其他三处配套（俯仰角取负、头身偏航差取负、
 * 按 {@code getBbHeight()} 做的高度补偿）都没跟上，结果不同生物的观感千差万别：
 * 有的几乎看不出颠倒，有的只是整体偏了半格。</p>
 *
 * <p><b>本实现直接走原版 Dinnerbone 通路。</b>原版早就有一套完整的"实体倒置"实现——
 * 给生物命名牌写 {@code Dinnerbone} 或 {@code Grumm} 它就会上下颠倒。开关是
 * {@code LivingEntityRenderer#isEntityUpsideDown(LivingEntity)} 这个静态判定，
 * 三处消费点全都在原版里写好了：</p>
 * <ol>
 *   <li>{@code render} 里把俯仰角 {@code f6} 和头身偏航差 {@code f2} 取负，
 *       所以翻转后生物的抬头、扭头方向是跟着一起反的；</li>
 *   <li>{@code setupRotations} 的倒置分支先
 *       {@code translate(0, (getBbHeight() + 0.1F) / scale, 0)} 再
 *       {@code Rz(180°)}，把不同生物的身高算进支点补偿，牛、苦力怕、末影人、玩家
 *       都不会浮空或陷地；</li>
 *   <li>那次 {@code Rz(180°)} 与渲染器随后自己的
 *       {@code poseStack.scale(-1, -1, 1)}（同轴同角度，矩阵就是 {@code diag(-1,-1,1)}）
 *       相乘为单位阵，等于<b>撤掉这次镜像</b>。而 {@code scale(-1,-1,1)} 正是原版把
 *       {@link net.minecraft.client.model.ModelPart} 的"Y 轴朝下"模型坐标系换成世界
 *       "Y 轴朝上"的那一步——把它抵消掉，模型就按原本的 Y 朝下画出来，也就是上下颠倒。
 *       这就是原版实现颠倒的全部原理：不是加一次翻转，而是减掉一次镜像。</li>
 * </ol>
 *
 * <p>覆盖面：{@code PlayerRenderer}、{@code IronGolemRenderer}、{@code DrownedRenderer}、
 * {@code PhantomRenderer}、{@code FoxRenderer}、{@code PandaRenderer}、{@code CatRenderer}、
 * {@code ShulkerRenderer} 这些覆写了 {@code setupRotations} 的渲染器都会先调
 * {@code super.setupRotations}，所以照常生效；模组自己的实体渲染器没有覆写这条链。
 * 不覆写 super 的只有 {@code SquidRenderer} 和 {@code ArmorStandRenderer} 两个，
 * 它们连 Dinnerbone 命名牌在原版里同样不生效，属于原版既有的限制。
 * {@code render} 方法本身被 {@code EnderDragonRenderer} 整个接管，也在原版限制内。</p>
 *
 * <p>判定读的是服务端播下来的同步附件 {@link GravityReversalState}，不是客户端本地效果表——
 * 1.21.1 的服务端<b>不向客户端同步非玩家生物的状态效果</b>（{@code ClientboundUpdateMobEffectPacket}
 * 只发给玩家自己、玩家正骑乘的生物与进服补发的场合），客户端 {@code hasEffect} 对怪恒为 false，
 * 这正是"只有玩家翻、怪不翻"的原因。附件由 {@code EntityGravityReversalMixin} 每 tick 从
 * 服务端真实效果对齐过来，所以物理与渲染用的是同一份真相，不会出现"物理倒了模型没倒"。</p>
 *
 * <p>与原版命名牌一致的副作用：被倒置的<b>玩家</b>在 Tab 在线列表里名字也会颠倒
 * （{@code PlayerTabOverlay} 同样读这个静态判定）；生物死亡动画期间原版改用翻滚分支，
 * 短暂回到正向，也和 Dinnerbone 表现一致。</p>
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererGravityMixin {

    /**
     * 把重力反转并进原版的"实体倒置"判定。目标是
     * {@code public static boolean isEntityUpsideDown(LivingEntity)}，静态方法只能用静态
     * 注入方法挂钩（实例方法用静态注入会被 Mixin 直接拒绝）。
     */
    @Inject(method = "isEntityUpsideDown", at = @At("HEAD"), cancellable = true)
    private static void netherarmy$gravityReversalUpsideDown(LivingEntity entity,
                                                             CallbackInfoReturnable<Boolean> cir) {
        // 主判据是同步附件而不是效果本身：1.21.1 不同步非玩家生物的效果，客户端
        // hasEffect 对怪恒为 false。玩家的效果本来就会同步，两个判据都留着，附件
        // 尚在路上的那一两帧也不会漏翻。
        if (GravityReversalState.isReversed(entity)
                || entity.hasEffect(GeneratedMod.GRAVITY_REVERSAL)) {
            cir.setReturnValue(true);
        }
    }
}
