package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;

/**
 * 凋灵仆役的弓目标：原版 {@code RangedBowAttackGoal} 在 1.21.1 的
 * {@code canUse()} 只判 {@code getTarget() != null} 与是否持弓，不看目标是否存活；
 * {@code canContinueToUse()} 又是 {@code canUse() || !navigation.isDone()}。
 * 于是目标被打死后、目标槽位被清空前的窗口期里，弓目标会一直续着：继续拉弓、
 * 继续瞄准，蓄力到点还会把箭射向尸体——就是"目标死了还在索敌射击"。
 *
 * <p>本子类补上存活判定：{@code canUse()} 与 {@code canContinueToUse()} 任一条
 * 在目标死亡时返回 false，{@code GoalSelector} 立刻调 {@code stop()}，连带清掉
 * 拉弓姿态（{@code setAggressive(false)}、{@code stopUsingItem()}）与蓄力进度，
 * 之后要么等目标选择器换新目标，要么彻底安静下来。射程/间隔/游走回撤全部沿用
 * 父类实现，只加一道存活闸门。</p>
 */
final class WitherServantBowAttackGoal extends RangedBowAttackGoal<WitherServant> {
    private final WitherServant servant;

    WitherServantBowAttackGoal(WitherServant servant, double speedModifier, int attackInterval,
                               float attackRadius) {
        super(servant, speedModifier, attackInterval, attackRadius);
        this.servant = servant;
    }

    @Override
    public boolean canUse() {
        LivingEntity target = this.servant.getTarget();
        return target != null && target.isAlive() && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity target = this.servant.getTarget();
        return target != null && target.isAlive() && super.canContinueToUse();
    }
}
