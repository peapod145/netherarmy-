package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Turtle;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.function.Predicate;

/** 怨灵：凋灵骷髅阵营的飞行近战生物。 */
public class WitherGhost extends WitherSkeleton {
    public static final ResourceKey<net.minecraft.world.level.storage.loot.LootTable> LOOT_TABLE =
            ResourceKey.create(Registries.LOOT_TABLE,
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "entities/wither_ghost"));
    private static final EntityDataAccessor<Byte> DATA_FLAGS = SynchedEntityData.defineId(
            WitherGhost.class, EntityDataSerializers.BYTE);
    private static final byte FLAG_ETHEREAL = 1;
    private static final int ETHEREAL_RESTORE_DELAY = 20;
    private int etherealRestoreTicks;

    public WitherGhost(EntityType<? extends WitherGhost> entityType, Level level) {
        super(entityType, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.KNOCKBACK_RESISTANCE, -1.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanPassDoors(false);
        navigation.setCanFloat(true);
        return navigation;
    }

    /**
     * 怨灵隔着方块也能索敌。
     *
     * <p>父类（{@code AbstractSkeleton}／{@code WitherSkeleton}）挂的玩家、铁傀儡、海龟、
     * 猪灵四条目标选择器都带「必须看得见」：构造时 {@code mustSee=true}，同时
     * {@code TargetingConditions.forCombat()} 的 {@code checkLineOfSight} 默认为真，
     * 前者在 {@code TargetGoal#canContinueToUse} 里还会累计看不见的刻数、超过 60 刻就丢目标。
     * 怨灵本体是穿墙飞行的虚体，被一面墙挡住就不再索敌显然说不通，因此这里把父类那几条
     * 全部换成关掉这两道视线判定的版本：{@code mustSee=false} 加
     * {@code targetConditions.ignoreLineOfSight()}。</p>
     *
     * <p>目标种类、优先级、{@code mustReach} 与海龟的幼体筛选都保持原版口径，距离仍然是
     * 自己的 {@code FOLLOW_RANGE}（24 格），隐身与头颅伪装照旧走
     * {@code LivingVisibilityEvent}（见 {@link LegionVisionHandler}），
     * 创造／旁观玩家也照旧由 {@code MobTargetCreativeGuardMixin} 拦下。</p>
     *
     * <p>注意 {@code registerGoals()} 由 {@code Mob} 的构造器调用，早于本类字段初始化，
     * 所以这里只能用 {@code this} 和目标选择器，不能读本类的任何字段。</p>
     */
    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector.removeAllGoals(goal -> goal instanceof NearestAttackableTargetGoal<?>);
        this.targetSelector.addGoal(2, new ThroughWallTargetGoal<>(this, Player.class, 10, false, null));
        this.targetSelector.addGoal(3, new ThroughWallTargetGoal<>(this, IronGolem.class, 10, false, null));
        this.targetSelector.addGoal(3, new ThroughWallTargetGoal<>(this, Turtle.class, 10, false,
                Turtle.BABY_ON_LAND_SELECTOR));
        this.targetSelector.addGoal(3, new ThroughWallTargetGoal<>(this, AbstractPiglin.class, 10, false, null));
        this.goalSelector.addGoal(0, new GhostChargeGoal(this));
    }

    /** 与原版 {@link NearestAttackableTargetGoal} 同款，只是关掉「必须看见」与视线射线。 */
    private static final class ThroughWallTargetGoal<T extends LivingEntity> extends NearestAttackableTargetGoal<T> {
        private ThroughWallTargetGoal(Mob mob, Class<T> targetType, int randomInterval,
                                      boolean mustReach, Predicate<LivingEntity> selector) {
            super(mob, targetType, randomInterval, false, mustReach, selector);
            this.targetConditions.ignoreLineOfSight();
        }
    }

    /**
     * 隔着方块直线扑击。
     *
     * <p>光把索敌改成无视视线还不够：飞行寻路用的 {@code FlyNodeEvaluator} 里实心方块是
     * {@code BLOCKED}，被完全封死的房间根本给不出路线，怨灵就会贴着墙原地打转。恼鬼解决同一
     * 问题的办法是它的冲锋目标每 tick 把 move control 的 wanted position 直接设成目标位置，
     * 配合 {@code tick()} 里临时打开的 {@code noPhysics} 穿墙飞过去；怨灵本来就照抄了恼鬼的
     * {@code noPhysics}，这里把同一段直线扑击补上，让「无视障碍」落到实处。</p>
     *
     * <p>只在看不见目标时接管（这里的视线判定只用来区分「墙挡着」和「一马平川」，
     * 与前面的索敌无关）：看得见时交给原版的寻路与 {@code MeleeAttackGoal}，
     * 免得把正常的绕行也变成一头撞墙；进入近战距离立刻让位，伤害仍由父类的近战目标结算。</p>
     */
    private static final class GhostChargeGoal extends Goal {
        private final WitherGhost ghost;

        private GhostChargeGoal(WitherGhost ghost) {
            this.ghost = ghost;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return this.shouldCharge();
        }

        @Override
        public boolean canContinueToUse() {
            return this.shouldCharge();
        }

        @Override
        public void start() {
            this.charge();
        }

        @Override
        public void tick() {
            // FlyingMoveControl 处理完一次 MOVE_TO 就把 operation 复位成 WAIT，
            // 想像恼鬼那样持续直飞，就必须每 tick 重新下发目标点。
            this.charge();
        }

        private boolean shouldCharge() {
            LivingEntity target = this.ghost.getTarget();
            return target != null && target.isAlive()
                    && !this.ghost.isWithinMeleeAttackRange(target)
                    && !this.ghost.getSensing().hasLineOfSight(target);
        }

        private void charge() {
            LivingEntity target = this.ghost.getTarget();
            if (target == null) {
                return;
            }
            Vec3 eyes = target.getEyePosition();
            this.ghost.getMoveControl().setWantedPosition(eyes.x, eyes.y, eyes.z, 1.0D);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_FLAGS, FLAG_ETHEREAL);
    }

    public boolean isEthereal() {
        return (this.entityData.get(DATA_FLAGS) & FLAG_ETHEREAL) != 0;
    }

    private void setEthereal(boolean ethereal) {
        byte flags = this.entityData.get(DATA_FLAGS);
        byte updated = ethereal ? (byte) (flags | FLAG_ETHEREAL) : (byte) (flags & ~FLAG_ETHEREAL);
        if (flags != updated) {
            this.entityData.set(DATA_FLAGS, updated);
        }
    }

    @Override
    public void tick() {
        // 与恼鬼相同：AI 移动阶段无碰撞、无重力，并在移动后检查方块内部效果。
        this.noPhysics = true;
        super.tick();
        this.noPhysics = false;
        this.setNoGravity(true);
    }

    @Override
    public void move(MoverType type, Vec3 movement) {
        super.move(type, movement);
        this.checkInsideBlocks();
    }

    @Override
    protected void customServerAiStep() {
        // 虚化在亮度 >= 10 时破功（原先为 >= 7）：火把/熔炉旁的昏暗角落不再解除虚化，
        // 只有真正明亮的区域才现形。
        boolean breaksEthereal = this.level().getMaxLocalRawBrightness(this.blockPosition()) >= 10
                || this.hasEffect(MobEffects.GLOWING)
                || this.isOnFire();
        if (breaksEthereal) {
            this.etherealRestoreTicks = ETHEREAL_RESTORE_DELAY;
            this.setEthereal(false);
        } else if (!this.isEthereal()) {
            if (this.etherealRestoreTicks > 0) {
                this.etherealRestoreTicks--;
            }
            if (this.etherealRestoreTicks == 0) {
                this.setEthereal(true);
            }
        }
        super.customServerAiStep();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypes.IN_WALL)) {
            return false;
        }
        if (source.is(DamageTypeTags.IS_FIRE)) {
            // 不调用父类伤害结算，避免扣血、击退和受击闪烁；返回 true 让火球保留点燃效果。
            return this.isAlive() && !this.level().isClientSide;
        }
        if (this.isEthereal()) {
            amount *= 0.1F;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        // 不设置 EntityType.fireImmune：这样火焰攻击仍能点燃怨灵，燃烧状态也能解除虚化。
        // 生命扣除在这里跳过，因此火焰、岩浆、燃烧持续伤害全部免疫。
        if (source.is(DamageTypeTags.IS_FIRE)) {
            return;
        }
        super.actuallyHurt(source, amount);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return false;
        }

        float damage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE);
        // netherarmy:void_touch 是原版 out_of_world（掉出世界）的等价克隆：伤害属性相同，
        // 并通过 data/minecraft/tags/damage_type/ 的附加标签拿到 bypasses_armor、
        // bypasses_invulnerability、bypasses_resistance、no_knockback 四项成员资格，
        // 因此这 5 点无视护甲、无视抗性提升、盾牌挡不住、也不给不死图腾救。
        // 这里带上 this 作为致伤实体，保留仇恨与击杀归属。
        DamageSource source = serverLevel.damageSources().source(GeneratedMod.WITHER_GHOST_VOID, this);
        boolean hit = target.hurt(source, damage);
        if (!hit) {
            return false;
        }

        if (target instanceof net.minecraft.world.entity.LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 200), this);
            living.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200), this);
        }
        this.setLastHurtMob(target);
        this.playAttackSound();
        return true;
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        // 怨灵没有装备，死亡时由空掉落表保证只产生经验球。
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                         DifficultyInstance difficulty) {
        // 怨灵没有装备。
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        // 凋灵骷髅父类会在苦力怕击杀时额外掉落头颅；怨灵要求死亡只掉经验。
    }

    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return LOOT_TABLE;
    }
}
