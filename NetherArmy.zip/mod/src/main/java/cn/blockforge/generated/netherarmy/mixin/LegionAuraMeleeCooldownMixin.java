package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.ILegionAuraCarrier;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 军团光环的"攻速 +25%"。
 *
 * <p>1.21.1 原版没有怪物侧的攻击速度属性：近战节奏写死在
 * {@code MeleeAttackGoal#resetAttackCooldown} 的 {@code adjustedTickDelay(20)}
 * 里（{@code adjustedTickDelay} 只是 tick-rate 换算，不吃任何属性）。要覆盖
 * 全部阵营生物（凋灵骷髅/狂战士/下界猎手/尸鬼……的近战都走这个目标或其子类，
 * 如 {@code NetherHunterMeleeAttackGoal}），唯一的公共落点就是这个方法：
 * 有光环时把冷却直接写成 20/1.25 = 16 tick。</p>
 *
 * <p>注入不改变其余逻辑：没光环的实体走原路；冷却递减
 * （{@code tick()} 里的 {@code --ticksUntilNextAttack}）与命中判定完全不动。</p>
 */
@Mixin(MeleeAttackGoal.class)
public abstract class LegionAuraMeleeCooldownMixin {

    @Shadow
    @Final
    private PathfinderMob mob;

    @Shadow
    private int ticksUntilNextAttack;

    @Inject(method = "resetAttackCooldown", at = @At("HEAD"), cancellable = true)
    private void netherarmy$auraHaste(CallbackInfo callback) {
        if (this.mob instanceof ILegionAuraCarrier carrier && carrier.netherarmy$hasLegionAura()) {
            this.ticksUntilNextAttack = 16;
            callback.cancel();
        }
    }
}
