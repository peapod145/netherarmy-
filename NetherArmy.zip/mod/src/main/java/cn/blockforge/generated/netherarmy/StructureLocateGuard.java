package cn.blockforge.generated.netherarmy;

import net.minecraft.world.level.levelgen.structure.Structure;

/**
 * {@code /locate structure} 这类"结构是否存在"查询的预算闸门。
 *
 * <p>1.21.1 的 {@code ChunkGenerator#findNearestMapStructure} 从近到远按环扫描：
 * 第 k 环有 8k 个位置，每个位置经 {@code StructurePlacement#getPotentialStructureChunk}
 * 映射到一个候选区块，一直扫到第 100 环 —— 也就是 <b>40401 个互不相同的候选区块</b>
 * （每个候选落在不同的 spacing 区域里，缓存不到）。每个候选都要走一次
 * {@code StructureCheck#checkStart}：已生成的区块要整段解析一次区域文件里的区块 NBT，
 * 未生成的区块还要经 {@code canCreateStructure} 真跑一遍结构自己的
 * {@code findGenerationPoint}。</p>
 *
 * <p>原版结构之所以感觉不到这一步，是因为它们够常见，扫到第几环就命中了。下界戍城在
 * {@code minecraft:nether_complexes} 里只占 2/17 的权重，外加岩浆海、净空等落位限制，
 * 半径 1600 格内经常一个都没有，于是 /locate 会把 4 万个候选从头扫到尾。本模组的结构
 * 每判定一次都要取十几次下界噪声列（{@code getBaseColumn} 每次都会新建一个 NoiseChunk）
 * 再跑一次拼图放置，4 万次 × 毫秒级开销 = 服务端主线程被钉住几十秒，玩家看到的就是
 * "指令一敲游戏卡住"。</p>
 *
 * <p>本类只在这条查询路径上收紧预算：{@code StructureCheck#checkStart} 进出时记时，
 * 本模组的结构在一批查询里累计最多花 {@link #WORK_BUDGET_NANOS}，超出后
 * {@code checkStart} 直接返回"不存在"——既不解析区域文件，也不会触发同步区块生成，
 * 剩余几万个候选几乎不花时间。</p>
 *
 * <p>真正的区块生成不走 {@code checkStart}（那条路是
 * {@code ChunkGenerator#createStructures}），所以世界中照旧按原规则判定并长出结构，
 * 一个都不会少。状态按线程分开存：{@code checkStart} 都在主线程，万一哪里在别的线程
 * 撞上这批标记，也只会看到它自己那份空白状态，不会把查询期的快速判定带到生成上。</p>
 */
public final class StructureLocateGuard {

    /** 一批查询里允许花在本模组结构存在性判定上的总时间（含区域文件扫描）。 */
    private static final long WORK_BUDGET_NANOS = 1_200_000_000L;
    /**
     * 两次查询之间空闲超过这么久就认为上一批扫描已经结束，预算重置。
     * 一次 /locate 内部相邻两次 {@code checkStart} 只隔微秒级，远小于这里，
     * 所以同一条指令里预算是连续的；换一条指令还会由
     * {@link #beginNewBatch()} 显式重置。
     */
    private static final long IDLE_RESET_NANOS = 3_000_000_000L;
    /**
     * 两条 /locate 指令至少隔这么久才给新预算。
     * 只防一种病态用法：命令方块/宏每 tick 刷一遍 /locate，若每条都给满预算，
     * 主线程会被连续占满；这种情况下让它们共用已经花完的那份预算即可。
     */
    private static final long MIN_BATCH_INTERVAL_NANOS = 250_000_000L;

    private static final ThreadLocal<Batch> BATCH = ThreadLocal.withInitial(Batch::new);

    private StructureLocateGuard() {
    }

    /** 一个线程上的一批查询状态。 */
    private static final class Batch {
        /** 嵌套在 {@code checkStart} 里的层数（0 = 不在查询路径上）。 */
        int queryDepth;
        /** 本模组结构的 {@code checkStart} 嵌套层数（只有它在计时）。 */
        int timedDepth;
        /** 当前这次本模组结构的 {@code checkStart} 起始时间。 */
        long timedStartNanos;
        /** 本批查询已经花掉的时间。 */
        long spentNanos;
        /** 最近一次查询活动的时间。 */
        long lastActivityNanos;
        /** 本批预算的起始时间。 */
        long batchStartedNanos;

        /** 清空一批查询，但不动 {@link #lastActivityNanos}/{@link #batchStartedNanos}。 */
        void clear() {
            queryDepth = 0;
            timedDepth = 0;
            timedStartNanos = 0L;
            spentNanos = 0L;
        }
    }

    /**
     * 这个结构是否吃本类的预算。
     *
     * <p>只覆盖 {@link NetherSurfaceJigsawStructure}（下界戍城、客栈、靶场、小型要塞）：
     * 它们在半径内常常一个都没有，是"扫满 4 万候选"的那一类。
     * {@code netherarmy:fortress} 走的另一套旧存档兼容逻辑（
     * {@code NetherFortressLocateAliasMixin}）需要把已生成区块读完才认得出要塞起点，
     * 不能在这里提前掐断。</p>
     */
    public static boolean budgeted(Structure structure) {
        return structure instanceof NetherSurfaceJigsawStructure;
    }

    /**
     * 新的一条 {@code /locate} 指令开始：清空上一批扫描的累计耗时。
     *
     * <p>由 {@code LocateCommand#locateStructure} 的注入调用。真正进入命令时一定不在
     * 任何 {@code checkStart} 里，所以顺手把计数归零也是安全的——万一上一次查询中途
     * 抛异常没走到 {@code exitQuery}，下一次指令会自动恢复。</p>
     */
    public static void beginNewBatch() {
        Batch batch = BATCH.get();
        long now = System.nanoTime();
        if (now - batch.batchStartedNanos >= MIN_BATCH_INTERVAL_NANOS) {
            batch.clear();
            batch.batchStartedNanos = now;
        }
        batch.lastActivityNanos = now;
    }

    /** 进入一次结构存在性查询（由 {@code StructureCheck#checkStart} 的注入调用）。 */
    public static void enterQuery(Structure structure) {
        Batch batch = BATCH.get();
        long now = System.nanoTime();
        if (now - batch.lastActivityNanos > IDLE_RESET_NANOS) {
            // 上一批扫描早已结束：开一批新的预算
            batch.clear();
            batch.batchStartedNanos = now;
        }
        batch.queryDepth++;
        if (budgeted(structure)) {
            if (batch.timedDepth == 0) {
                batch.timedStartNanos = now;
            }
            batch.timedDepth++;
        }
        batch.lastActivityNanos = now;
    }

    /** 离开一次结构存在性查询，并把这次花掉的时间记进预算。 */
    public static void exitQuery(Structure structure) {
        Batch batch = BATCH.get();
        long now = System.nanoTime();
        if (budgeted(structure) && batch.timedDepth > 0) {
            batch.timedDepth--;
            if (batch.timedDepth == 0) {
                batch.spentNanos += Math.max(0L, now - batch.timedStartNanos);
            }
        }
        if (batch.queryDepth > 0) {
            batch.queryDepth--;
        }
        batch.lastActivityNanos = now;
    }

    /**
     * 本批查询的预算是否已经用完（用完就不要再解析区域文件、也不要再算落位了）。
     *
     * <p>空闲超过 {@link #IDLE_RESET_NANOS} 视为新的一批，预算重新计算。</p>
     */
    public static boolean budgetExhausted() {
        Batch batch = BATCH.get();
        long now = System.nanoTime();
        boolean idle = now - batch.lastActivityNanos > IDLE_RESET_NANOS;
        // 这次调用（哪怕是"预算已用完、直接取消"的那一次）也算查询还活着
        batch.lastActivityNanos = now;
        if (idle) {
            batch.spentNanos = 0L;
            return false;
        }
        return batch.spentNanos >= WORK_BUDGET_NANOS;
    }

    /**
     * 当前是否处于查询路径（/locate 的候选预判）。
     *
     * <p>查询路径下本模组的结构可以少做、甚至不做昂贵判定；生成路径必须原样判定，
     * 否则世界里会少长结构。</p>
     */
    public static boolean inPresenceCheck() {
        return BATCH.get().queryDepth > 0;
    }

    /**
     * 取一次落位判定额度（{@code findGenerationPoint} 内部的二道闸）。
     *
     * @return false 表示本批查询的预算已经用完，调用方应立刻返回"没有结构"
     */
    public static boolean tryBeginWork() {
        if (!inPresenceCheck()) {
            return true;
        }
        return !budgetExhausted();
    }
}
