package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * 无头骑士陷阱：仿原版骷髅马陷阱的事件式生成。
 *
 * <p>刷新规则：下界维度内，每名玩家（旁观除外）每 tick 掷 1/{@value #SPAWN_CHANCE_DENOMINATOR}
 * （0.01%）概率，成功则在以该玩家为圆心 24~96 格（保证不短于 10 格触发距离，不会刷脸即爆）
 * 的随机方位找一处可站立地面，刷一只原版骷髅马并打上陷阱标记。陷阱马强制常驻
 * （{@code setPersistenceRequired}），和平难度与 {@code doMobSpawning=false} 时不刷。
 * 每次成功生成都会写 latest.log（搜 {@code [netherarmy]} 可自证事件确实发生过）。</p>
 *
 * <p>引爆规则：每 {@value #TRAP_SCAN_INTERVAL} tick 扫一遍所有已加载维度的陷阱标记马
 * （指令允许在任意维度放置陷阱马，故扫描不限于下界），任意非旁观玩家进入 10 格
 * （按中心距，与原版骷髅马陷阱同一判定风格）即引爆：
 * ① 陷阱马消失并触发一次与 TNT 等价的爆炸（威力 4、{@code ExplosionInteraction.TNT}）；
 * ② 同 tick 在爆点四周补刷 4 名全副武装的无头骑士（见 {@link #spawnArmedRider}）——
 * 骑士在 {@code level.explode} 调用返回之后才创建，爆炸本身永远伤不到刚刷出的伏击队；
 * ③ 爆点 20 格内的所有玩家获得"地狱强袭"进度。</p>
 *
 * <p>武装规格（每名骑士独立掷骰）：
 * <ul>
 *   <li>躯干：60% 全套铁甲 + 铁剑 / 40% 全套下界合金甲 + 下界合金剑，每件必定附魔，
 *       附魔数量为随机（1~3 条）、类型随机且互不冲突、等级一律取该附魔的最高级；
 *       躯干与头颅的防具共用同一次 60/40 掷骰，永远同款成套；</li>
 *   <li>副手（无头骑士为右手持剑，"左手"即副手）：10% 不死图腾 / 90% 盾牌——
 *       盾牌必带【护主】，另有 50% 概率再随机 1~2 条其他附魔，等级为 1~上限随机
 *       （注意与躯干防具的"必定最高级"不同，这里按需求取任意等级）；</li>
 *   <li>坐骑（{@link DullhanHorse}）：必定装备铁马铠（覆盖常规刷新的 10% 金马铠概率）；</li>
 *   <li>头颅（{@link DullhanHead}）：铁盔 / 下界合金盔，必定附魔、类型与数量
 *       随机、等级最高——材质取哪一档直接沿用躯干那次 60/40 掷骰的结果，两者同款。</li>
 * </ul>
 * 诅咒类附魔（绑定/消失）永不入选。</p>
 *
 * <p>坐骑与头颅的创建不再走 {@code DullhanBody} 首个 tick 的自动补刷（那条链路没有
 * 注入武装的时机），而是在本类同一 tick 内手动创建并直接完成"躯体骑乘马、头颅骑乘
 * 躯体"的三方挂载；{@code DullhanBody#tick} 检测到已有乘客即认定伴侣就绪，不会重复创建。
 * 三名部件共享编组 ID，仇恨同步、目标共享与常规无头骑士完全一致；触发者会被躯干
 * 直接锁定为初始目标（创造/旁观玩家按 {@code DullhanBody#isIgnoredTarget} 规则被无视）。</p>
 */
public final class DullhanTrapSpawner {
    /** 陷阱标记：打在原版骷髅马的 PersistentData 上，随实体存档，重启后依然可引爆。 */
    private static final String TRAP_TAG = "NetherarmyDullhanTrap";
    /** 每名下界玩家每 tick 的刷新分母：1/10000 = 0.01%。 */
    private static final int SPAWN_CHANCE_DENOMINATOR = 10000;
    /** 刷新锚点半径下限/上限（格）：上限 96 在需求的 100 格内，下限 24 防止刷脸即爆。 */
    private static final int MIN_TRAP_DISTANCE = 24;
    private static final int MAX_TRAP_DISTANCE = 96;
    /** 引爆距离 10 格的平方值。 */
    private static final double TRIGGER_DISTANCE_SQR = 100.0D;
    /** 陷阱马巡查间隔（tick）：移动最快的玩家也走不完 10 格，不会漏判。 */
    private static final int TRAP_SCAN_INTERVAL = 20;
    /** 与 TNT 等价的爆炸威力与交互模式。 */
    private static final float TRAP_EXPLOSION_POWER = 4.0F;
    private static final int RIDER_COUNT = 4;
    /** 伏击圈半径：陷阱马周围 3~4 格环形布点。 */
    private static final double RIDER_RING_MIN = 3.0D;
    private static final double RIDER_RING_MAX = 4.0D;
    /** 成就颁发半径（格）。 */
    private static final double AWARD_RADIUS = 20.0D;
    /** 下界顶棚基岩之下，与 {@link NetherPatrolSpawner} 同规则。 */
    private static final int ROOF_SCAN_TOP = 126;

    private static int tickCounter;

    private DullhanTrapSpawner() {
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        tickCounter++;
        boolean scanTick = tickCounter % TRAP_SCAN_INTERVAL == 0;
        for (ServerLevel level : event.getServer().getAllLevels()) {
            if (level.dimension() == Level.NETHER) {
                rollNaturalTraps(level);
            }
            if (scanTick) {
                triggerDueTraps(level);
            }
        }
    }

    /** 概率通道：仅下界、仅非和平、仅 doMobSpawning 开启时掷骰。 */
    private static void rollNaturalTraps(ServerLevel level) {
        if (level.getDifficulty() == Difficulty.PEACEFUL
                || !level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)) {
            return;
        }
        RandomSource random = level.getRandom();
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            if (random.nextInt(SPAWN_CHANCE_DENOMINATOR) != 0) {
                continue;
            }
            double angle = random.nextDouble() * Math.PI * 2.0D;
            int radius = MIN_TRAP_DISTANCE + random.nextInt(MAX_TRAP_DISTANCE - MIN_TRAP_DISTANCE + 1);
            int x = Mth.floor(player.getX() + Math.cos(angle) * radius);
            int z = Mth.floor(player.getZ() + Math.sin(angle) * radius);
            if (!level.hasChunksAt(x - 2, z - 2, x + 2, z + 2)) {
                continue;
            }
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(x, defaultScanTop(level), z);
            if (!findStandableFloor(level, pos)) {
                continue;
            }
            spawnTrapHorse(level, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                    MobSpawnType.EVENT, "自然刷新（目击玩家 " + player.getGameProfile().getName() + "）");
        }
    }

    /**
     * 在指定坐标放置一只陷阱骷髅马（先向下找可站立地面）：自然刷新与
     * {@code /netherarmy dullahan_trap} 指令共用；返回 false 表示找不到落点。
     */
    public static boolean spawnTrapHorseAt(ServerLevel level, Vec3 at, RandomSource random) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(
                Mth.floor(at.x), Math.min(Mth.floor(at.y) + 8, level.getMaxBuildHeight() - 2), Mth.floor(at.z));
        if (!findStandableFloor(level, pos)) {
            // 锚点正下方没有地面（悬空/岩浆湖）：绕锚点 1~3 格再采样 8 次。
            boolean found = false;
            for (int attempt = 0; attempt < 8 && !found; attempt++) {
                double angle = random.nextDouble() * Math.PI * 2.0D;
                double distance = 1.0D + random.nextDouble() * 2.0D;
                pos.setX(Mth.floor(at.x + Math.cos(angle) * distance));
                pos.setZ(Mth.floor(at.z + Math.sin(angle) * distance));
                pos.setY(Mth.floor(at.y) + 8);
                found = findStandableFloor(level, pos);
            }
            if (!found) {
                return false;
            }
        }
        return spawnTrapHorse(level, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                MobSpawnType.COMMAND, "指令");
    }

    private static boolean spawnTrapHorse(ServerLevel level, double x, double y, double z,
                                          MobSpawnType spawnType, String sourceLabel) {
        SkeletonHorse horse = EntityType.SKELETON_HORSE.create(level);
        if (horse == null) {
            return false;
        }
        horse.setPos(x, y, z);
        horse.setPersistenceRequired();
        horse.finalizeSpawn(level, level.getCurrentDifficultyAt(BlockPos.containing(x, y, z)), spawnType, null);
        // 不触碰原版 isTrapped 旗标：那套逻辑会召闪电送骷髅骑手，与本事件的
        // "爆炸 + 无头骑士伏击"互斥；引爆判定完全依赖自定义标记。
        horse.getPersistentData().putBoolean(TRAP_TAG, true);
        if (!level.addFreshEntity(horse)) {
            return false;
        }
        GeneratedMod.LOGGER.info("[netherarmy] 无头骑士陷阱{}落地于 {}（维度 {}）",
                sourceLabel, new BlockPos(Mth.floor(x), Mth.floor(y), Mth.floor(z)).toShortString(),
                level.dimension().location());
        return true;
    }

    /** 扫描所有带陷阱标记的骷髅马，任意玩家进入 10 格即引爆。 */
    private static void triggerDueTraps(ServerLevel level) {
        AABB wholeLevel = new AABB(-3.0E7D, level.getMinBuildHeight(), -3.0E7D,
                3.0E7D, level.getMaxBuildHeight(), 3.0E7D);
        List<SkeletonHorse> traps = level.getEntitiesOfClass(SkeletonHorse.class, wholeLevel,
                horse -> !horse.isRemoved() && horse.getPersistentData().getBoolean(TRAP_TAG));
        for (SkeletonHorse trap : traps) {
            ServerPlayer victim = nearestTriggerPlayer(level, trap);
            if (victim == null) {
                continue;
            }
            detonateTrap(level, trap, victim);
        }
    }

    /** 引爆一只陷阱马：消失 + TNT 等价爆炸 + 四名武装骑士 + 成就。二次调用因标记已摘而无效果。 */
    private static void detonateTrap(ServerLevel level, SkeletonHorse trap, ServerPlayer victim) {
        double x = trap.getX();
        double y = trap.getY();
        double z = trap.getZ();
        // 先摘标记再消失：本 tick 内的重复判定与下一轮扫描都不会二次引爆。
        trap.getPersistentData().remove(TRAP_TAG);
        trap.discard();
        level.explode(null, x, y, z, TRAP_EXPLOSION_POWER, Level.ExplosionInteraction.TNT);
        int riders = summonArmedRiders(level, new Vec3(x, y, z), victim, level.getRandom());
        awardEncounter(level, new Vec3(x, y, z));
        GeneratedMod.LOGGER.info("[netherarmy] 无头骑士陷阱被玩家 {} 引爆于 ({}, {}, {})，伏击骑士 {} 名",
                victim == null ? "（无人）" : victim.getGameProfile().getName(),
                Mth.floor(x), Mth.floor(y), Mth.floor(z), riders);
    }

    /**
     * 供 {@code /netherarmy dullahan_detonate} 使用：引爆 origin 64 格内最近的一只陷阱马，
     * 无视 10 格触发距离（牺牲者取 origin 附近的执行者本人，可为 null）。
     * 返回被引爆陷阱的数量。
     */
    public static int detonateNearbyTraps(ServerLevel level, Vec3 origin, ServerPlayer victim) {
        AABB area = new AABB(origin.x - 64, origin.y - 64, origin.z - 64,
                origin.x + 64, origin.y + 64, origin.z + 64);
        List<SkeletonHorse> traps = level.getEntitiesOfClass(SkeletonHorse.class, area,
                horse -> !horse.isRemoved() && horse.getPersistentData().getBoolean(TRAP_TAG));
        int detonated = 0;
        for (SkeletonHorse trap : traps) {
            if (trap.distanceToSqr(origin) <= 64.0D * 64.0D) {
                detonateTrap(level, trap, victim);
                detonated++;
            }
        }
        return detonated;
    }

    private static ServerPlayer nearestTriggerPlayer(ServerLevel level, SkeletonHorse trap) {
        ServerPlayer nearest = null;
        double nearestDistanceSqr = Double.MAX_VALUE;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            double distanceSqr = trap.distanceToSqr(player);
            if (distanceSqr <= TRIGGER_DISTANCE_SQR && distanceSqr < nearestDistanceSqr) {
                nearest = player;
                nearestDistanceSqr = distanceSqr;
            }
        }
        return nearest;
    }

    /**
     * 引爆后的伏击：4 名全副武装的无头骑士绕爆点 3~4 格均布刷新，并锁定触发玩家。
     * {@code level.explode} 是同步结算的，本方法在其返回后调用，骑士不吃自家爆炸。
     * 返回实际生成的骑士数（个别布点找不到地面时按 3 名放走）。
     * {@code /netherarmy dullahan_ambush} 指令也走这里。
     */
    public static int summonArmedRiders(ServerLevel level, Vec3 center, ServerPlayer victim, RandomSource random) {
        int spawned = 0;
        for (int i = 0; i < RIDER_COUNT; i++) {
            double angle = i * Math.PI / 2.0D + random.nextDouble() * 0.8D;
            double distance = RIDER_RING_MIN + random.nextDouble() * (RIDER_RING_MAX - RIDER_RING_MIN);
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(
                    Mth.floor(center.x + Math.cos(angle) * distance),
                    Mth.floor(center.y) + 2,
                    Mth.floor(center.z + Math.sin(angle) * distance));
            boolean ok = findStandableFloor(level, pos)
                    && spawnArmedRider(level, pos, victim, random) != null;
            if (!ok && i == 0 && spawned == 0) {
                // 首个布点失败时兜底：就在爆点正下方找地面，保证"引爆必出骑士"。
                pos.setZ(Mth.floor(center.z));
                pos.setX(Mth.floor(center.x));
                pos.setY(Mth.floor(center.y) + 2);
                if (findStandableFloor(level, pos)) {
                    ok = spawnArmedRider(level, pos, victim, random) != null;
                }
            }
            if (ok) {
                spawned++;
            }
        }
        return spawned;
    }

    /**
     * 生成一名完整武装的无头骑士（躯体 + 头颅 + 铁铠坐骑，同 tick 手动编组挂载），
     * 装备规格见类注释。失败（实体创建/入世界不成功）时回收已创建的部件并返回 null。
     */
    public static DullhanBody spawnArmedRider(ServerLevel level, BlockPos.MutableBlockPos floorPos,
                                              LivingEntity target, RandomSource random) {
        DullhanBody body = GeneratedMod.DULLHAN_BODY.get().create(level);
        DullhanHorse horse = GeneratedMod.DULLHAN_HORSE.get().create(level);
        DullhanHead head = GeneratedMod.DULLHAN_HEAD.get().create(level);
        if (body == null || horse == null || head == null) {
            return null;
        }
        // 躯干与头颅同款武装：整名骑士只掷一次 60/40，铁/下界合金一套到底。
        boolean netherite = random.nextFloat() < 0.40F;
        double x = floorPos.getX() + 0.5D;
        // 马的碰撞箱 1.4×1.6，贴着可站立格刷新时会被旁边的墙体挤住、卡在墙里窒息。
        // 整组实体在 Y 方向抬高 1 格（掉一格落地即可脱困）；只有抬上去那一格仍然空着
        // （即 pos+1、pos+2 皆可穿过）才抬，免得把"卡墙"换成"卡顶"。
        double y = mountSpawnY(level, floorPos);
        double z = floorPos.getZ() + 0.5D;
        MobSpawnType spawnType = target instanceof ServerPlayer ? MobSpawnType.EVENT : MobSpawnType.MOB_SUMMONED;
        body.moveTo(x, y, z, random.nextFloat() * 360.0F - 180.0F, 0.0F);
        body.finalizeSpawn(level, level.getCurrentDifficultyAt(floorPos), spawnType, null);
        equipTrapBody(level, body, random, netherite);
        if (!level.addFreshEntity(body)) {
            return null;
        }

        horse.moveTo(x, y, z, body.getYRot(), 0.0F);
        horse.setPersistenceRequired();
        horse.finalizeSpawn(level, level.getCurrentDifficultyAt(floorPos), spawnType, null);
        // 必带铁马铠：覆盖 DullhanHorse#finalizeSpawn 的 10% 金马铠随机。
        horse.setBodyArmorItem(new ItemStack(Items.IRON_HORSE_ARMOR));
        if (!level.addFreshEntity(horse)) {
            body.discard();
            return null;
        }

        head.moveTo(x, y + 1.0D, z, body.getYRot(), 0.0F);
        head.setPersistenceRequired();
        head.finalizeSpawn(level, level.getCurrentDifficultyAt(floorPos), spawnType, null);
        equipTrapHead(level, head, random, netherite);
        if (!level.addFreshEntity(head)) {
            horse.discard();
            body.discard();
            return null;
        }

        java.util.UUID groupId = DullhanBody.ensureGroupId(body);
        DullhanBody.setGroupId(horse, groupId);
        DullhanBody.setGroupId(head, groupId);
        // 躯体骑乘马、头颅骑乘躯体；DullhanBody#tick 检测到已有乘客即认可伴侣就绪。
        body.startRiding(horse, true);
        head.startRiding(body, true);
        if (target != null) {
            body.setTarget(target);
            horse.setTarget(target);
        }
        return body;
    }

    /** 躯干武装：铁套+铁剑 / 合金套+合金剑由 {@code netherite} 决定（与头颅同款），全部必定满级随机附魔。 */
    private static void equipTrapBody(ServerLevel level, DullhanBody body, RandomSource random, boolean netherite) {
        ItemStack chest = new ItemStack(netherite ? Items.NETHERITE_CHESTPLATE : Items.IRON_CHESTPLATE);
        ItemStack legs = new ItemStack(netherite ? Items.NETHERITE_LEGGINGS : Items.IRON_LEGGINGS);
        ItemStack feet = new ItemStack(netherite ? Items.NETHERITE_BOOTS : Items.IRON_BOOTS);
        ItemStack sword = new ItemStack(netherite ? Items.NETHERITE_SWORD : Items.IRON_SWORD);
        enchantAtMaxLevel(level, random, chest, EquipmentSlot.CHEST, 1 + random.nextInt(3));
        enchantAtMaxLevel(level, random, legs, EquipmentSlot.LEGS, 1 + random.nextInt(3));
        enchantAtMaxLevel(level, random, feet, EquipmentSlot.FEET, 1 + random.nextInt(3));
        enchantAtMaxLevel(level, random, sword, EquipmentSlot.MAINHAND, 1 + random.nextInt(3));
        body.setItemSlot(EquipmentSlot.CHEST, chest);
        body.setItemSlot(EquipmentSlot.LEGS, legs);
        body.setItemSlot(EquipmentSlot.FEET, feet);
        body.setItemSlot(EquipmentSlot.MAINHAND, sword);
        body.reassessWeaponGoal();
        // 副手（无头骑士固定右手持剑，需求里的"左手"即副手）：10% 图腾 / 90% 护主盾。
        body.setItemSlot(EquipmentSlot.OFFHAND, rollOffhandItem(level, random));
    }

    /** 头颅武装：铁盔 / 下界合金盔由 {@code netherite} 决定（与躯干同款），必定满级随机附魔。 */
    private static void equipTrapHead(ServerLevel level, DullhanHead head, RandomSource random, boolean netherite) {
        ItemStack helmet = new ItemStack(netherite ? Items.NETHERITE_HELMET : Items.IRON_HELMET);
        enchantAtMaxLevel(level, random, helmet, EquipmentSlot.HEAD, 1 + random.nextInt(3));
        head.setItemSlot(EquipmentSlot.HEAD, helmet);
        head.setDropChance(EquipmentSlot.HEAD, 0.0F);
    }

    /** 副手物品：10% 不死图腾；否则盾牌，必带护主，另 50% 概率追加 1~2 条任意等级附魔。 */
    private static ItemStack rollOffhandItem(ServerLevel level, RandomSource random) {
        if (random.nextFloat() < 0.10F) {
            return new ItemStack(Items.TOTEM_OF_UNDYING);
        }
        ItemStack shield = new ItemStack(Items.SHIELD);
        Holder<Enchantment> protector = level.registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT)
                .getOrThrow(GeneratedMod.PROTECTOR);
        shield.enchant(protector, protector.value().getMaxLevel());
        if (random.nextFloat() < 0.50F) {
            enchantAtRandomLevel(level, random, shield, EquipmentSlot.OFFHAND, 1 + random.nextInt(2));
        }
        return shield;
    }

    /** 需求语义"附魔等级均为最高级"：挑选 upTo 条互不冲突、适配槽位的附魔，全部取上限等级。 */
    private static void enchantAtMaxLevel(ServerLevel level, RandomSource random, ItemStack stack,
                                          EquipmentSlot slot, int upTo) {
        applyEnchantments(level, random, stack, slot, upTo, true);
    }

    /** 需求语义"带有任意等级的其他附魔"：等级取 1~上限随机。 */
    private static void enchantAtRandomLevel(ServerLevel level, RandomSource random, ItemStack stack,
                                             EquipmentSlot slot, int upTo) {
        applyEnchantments(level, random, stack, slot, upTo, false);
    }

    private static void applyEnchantments(ServerLevel level, RandomSource random, ItemStack stack,
                                          EquipmentSlot slot, int upTo, boolean maxLevel) {
        HolderLookup.RegistryLookup<Enchantment> registry =
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (Holder.Reference<Enchantment> holder : registry.listElements().toList()) {
            Enchantment enchantment = holder.value();
            if (holder.is(Enchantments.BINDING_CURSE) || holder.is(Enchantments.VANISHING_CURSE)) {
                continue;
            }
            if (enchantment.canEnchant(stack) && enchantment.matchingSlot(slot)) {
                candidates.add(holder);
            }
        }
        List<Holder.Reference<Enchantment>> applied = new ArrayList<>();
        for (int i = 0; i < upTo && !candidates.isEmpty(); i++) {
            Holder.Reference<Enchantment> pick = candidates.remove(random.nextInt(candidates.size()));
            boolean conflict = false;
            for (Holder.Reference<Enchantment> existing : applied) {
                if (!Enchantment.areCompatible(existing, pick)) {
                    conflict = true;
                    break;
                }
            }
            if (conflict) {
                continue;
            }
            int levelValue = maxLevel ? pick.value().getMaxLevel()
                    : 1 + random.nextInt(pick.value().getMaxLevel());
            stack.enchant(pick, levelValue);
            applied.add(pick);
        }
    }

    /** 成就"地狱强袭"：爆点 20 格内所有非旁观玩家均判定"遭遇了一次无头骑士陷阱"。 */
    private static void awardEncounter(ServerLevel level, Vec3 center) {
        var advancement = level.getServer().getAdvancements()
                .get(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "dullahan_ambush"));
        if (advancement == null) {
            return;
        }
        AABB area = new AABB(center.x - AWARD_RADIUS, center.y - AWARD_RADIUS, center.z - AWARD_RADIUS,
                center.x + AWARD_RADIUS, center.y + AWARD_RADIUS, center.z + AWARD_RADIUS);
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, area, p -> !p.isSpectator())) {
            player.getAdvancements().award(advancement, "encountered_trap");
        }
    }

    private static int defaultScanTop(ServerLevel level) {
        return Math.min(ROOF_SCAN_TOP, level.getMaxBuildHeight() - 2);
    }

    /**
     * 骑士整组（躯体＋头颅＋铁铠坐骑）的刷新高度：默认比可站立格再高 1 格，让 1.4×1.6 的马体
     * 不落进旁边墙体的碰撞箱（刷新时 {@code moveTo} 不做碰撞判定，卡进去就是一路窒息）；
     * 抬上去之后头顶两格不够空（会被顶进方块）时才退回原位。
     */
    private static double mountSpawnY(ServerLevel level, BlockPos floorPos) {
        BlockPos above = floorPos.above();
        if (passesThrough(level, above) && passesThrough(level, above.above())) {
            return floorPos.getY() + 1.0D;
        }
        return floorPos.getY();
    }

    /** 自 scanTop 向下找"脚下实心、头脚两格可站"的位置（下界高度图恒为屋顶之上，不可用）。 */
    private static boolean findStandableFloor(ServerLevel level, BlockPos.MutableBlockPos pos) {
        int top = Math.min(pos.getY(), level.getMaxBuildHeight() - 2);
        int bottom = level.getMinBuildHeight() + 1;
        for (int y = top; y >= bottom; y--) {
            pos.setY(y);
            BlockState ground = level.getBlockState(pos.below());
            if (!ground.blocksMotion() || !ground.getFluidState().isEmpty()) {
                continue;
            }
            if (passesThrough(level, pos) && passesThrough(level, pos.above())) {
                return true;
            }
        }
        return false;
    }

    private static boolean passesThrough(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return !state.blocksMotion() && state.getFluidState().isEmpty();
    }
}
