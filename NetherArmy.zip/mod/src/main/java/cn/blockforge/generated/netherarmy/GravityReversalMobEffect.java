package cn.blockforge.generated.netherarmy;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * 重力反转：反转士的范围能力施加的效果。
 *
 * <p>效果本体不做任何逐刻结算，全部落在两处被动钩子上：</p>
 * <ul>
 *   <li>实体物理——{@code EntityGravityReversalMixin} 把
 *       {@code Entity#getGravity()} 的返回值取负再按目标速度缩放，于是 {@code applyGravity} 与
 *       {@code LivingEntity#travel} 里的重力分量一起朝上，实体以原版飘浮 I <b>二倍</b>的
 *       稳态速度向上"坠落"（系数与推导见 {@code EntityGravityReversalMixin}）；
 *       负重力攒速度的起步由 {@code LivingEntityGravityReversalMixin} 绕开原版竖直速度死区，
 *       否则速度攒不起来、只倒立不上浮；客户端玩家的本地预测走同一条钩子（效果是同步的），
 *       不会与服务器打架。</li>
 *   <li>视觉——客户端 {@code LivingEntityRendererGravityMixin} 把本效果并入原版
 *       {@code LivingEntityRenderer#isEntityUpsideDown} 判定，走 Dinnerbone 命名牌那套
 *       倒置通路，模型、俯仰角与头身偏航差一起翻（上下颠倒），
 *       {@link GravityReversalClientHandler} 再把第一人称相机 roll 拉满 180°，
 *       玩家的视野也跟着倒过来。判据不是客户端本地效果表——1.21.1 不同步非玩家生物的
 *       效果，怪那边读的是 {@link GravityReversalState} 的同步附件。</li>
 * </ul>
 *
 * <p>图标 8×8 原稿放大到工程内统一的 16×16（最近邻，不重绘）。</p>
 */
public final class GravityReversalMobEffect extends MobEffect {
    public GravityReversalMobEffect() {
        super(MobEffectCategory.HARMFUL, 0x9B8FD0);
    }
}
