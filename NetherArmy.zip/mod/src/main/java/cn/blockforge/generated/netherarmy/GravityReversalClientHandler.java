package cn.blockforge.generated.netherarmy;

import net.minecraft.client.Camera;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * 重力反转的第一人称视野：相机 roll 拉满 180°，画面上下颠倒。
 *
 * <p>NeoForge 在 {@code Camera#setup} 里把 yaw/pitch/roll 交给
 * {@link ViewportEvent.ComputeCameraAngles} 覆写，再把结果交给
 * {@code Camera#setRotation(yaw, pitch, roll)}；roll 就是绕视线轴的滚转，
 * 置 180° 即上下颠倒，HUD 与准星不受影响（它们不在这条相机位姿栈里）。</p>
 *
 * <p>只在"相机所跟的实体"带效果时生效——第三人称看自己、旁观别的带效果生物
 * 时画面同样会翻，符合"视野上下颠倒"的字面要求。</p>
 */
public final class GravityReversalClientHandler {

    private GravityReversalClientHandler() {
    }

    @SubscribeEvent
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Camera camera = event.getCamera();
        if (camera.getEntity() instanceof LivingEntity living
                && living.hasEffect(GeneratedMod.GRAVITY_REVERSAL)) {
            event.setRoll(180.0F);
        }
    }
}
