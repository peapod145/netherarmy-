package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/** 霸主凋灵的抛射物反弹与击杀馈赠事件。 */
public final class OverlordWitherHandler {
    private OverlordWitherHandler() {
    }

    /** 三阶段起反弹非友方抛射物；无可追溯的生物发射者时至少保证免伤。 */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof OverlordWitherBoss boss)
                || boss.getPhase() < 3 || event.getProjectile().level().isClientSide()) {
            return;
        }
        Projectile projectile = event.getProjectile();
        // 圣光炸弹有自己的强制伤害结算，不能被普通抛射物反弹机制拦截。
        if (projectile instanceof HolyBomb) {
            return;
        }
        Entity attacker = projectile.getOwner();
        if (attacker == boss || (attacker != null && MesmerizerControl.isWitherSkeletonFaction(attacker))) {
            return;
        }
        if (!(attacker instanceof LivingEntity livingAttacker)) {
            return;
        }
        Vec3 direction = livingAttacker.getEyePosition().subtract(boss.getEyePosition());
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        double speed = Math.max(projectile.getDeltaMovement().length(), 0.8D);
        projectile.setPos(boss.getEyePosition().add(direction.scale(1.6D)));
        projectile.setDeltaMovement(direction.scale(speed));
        projectile.hasImpulse = true;
        event.setCanceled(true);
    }

    /** 三阶段起击杀生物时回血 10，并在尸体处留下凋灵玫瑰与凋灵骷髅。 */
    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || victim instanceof WitherBoss
                || !(victim.level() instanceof ServerLevel level)) {
            return;
        }

        OverlordWitherBoss boss = findBoss(event.getSource().getEntity(), event.getSource().getDirectEntity());
        if (boss == null || !boss.isAlive() || boss.getPhase() < 3 || boss.level() != victim.level()) {
            return;
        }

        boss.heal(10.0F);
        if (level.isEmptyBlock(victim.blockPosition())) {
            level.setBlockAndUpdate(victim.blockPosition(), Blocks.WITHER_ROSE.defaultBlockState());
        }

        WitherSkeleton skeleton = EntityType.WITHER_SKELETON.create(level);
        if (skeleton == null) {
            return;
        }
        skeleton.setPos(victim.getX(), victim.getY(), victim.getZ());
        skeleton.finalizeSpawn(level, level.getCurrentDifficultyAt(skeleton.blockPosition()),
                MobSpawnType.MOB_SUMMONED, null);
        skeleton.setPersistenceRequired();
        WitherEnhancementHandler.markSummonedBy(skeleton, boss);
        level.addFreshEntity(skeleton);
    }

    private static OverlordWitherBoss findBoss(Entity causing, Entity direct) {
        if (causing instanceof OverlordWitherBoss boss) {
            return boss;
        }
        if (direct instanceof OverlordWitherBoss boss) {
            return boss;
        }
        if (causing instanceof OverlordWitherSkull skull
                && skull.getOwner() instanceof OverlordWitherBoss boss) {
            return boss;
        }
        if (direct instanceof OverlordWitherSkull skull
                && skull.getOwner() instanceof OverlordWitherBoss boss) {
            return boss;
        }
        return null;
    }
}
