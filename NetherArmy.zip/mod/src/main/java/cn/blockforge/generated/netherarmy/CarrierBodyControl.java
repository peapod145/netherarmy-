package cn.blockforge.generated.netherarmy;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.control.BodyRotationControl;

/**
 * 运兵车的身体朝向控制：车身<b>恒等于</b>车体朝向 {@code yRot}，绝不被头向带着转。
 *
 * <h2>为什么非覆盖不可</h2>
 * <p>需求"静止时无法转向"光靠 {@link CarrierSteeringControl} 拦服务端是不够的：
 * 渲染读的是 {@code Mob#yBodyRot}（{@code LivingEntityRenderer} 用它转整个模型），
 * 而原版 {@code BodyRotationControl#clientTick} 在<b>车停着</b>时走的是另一套——
 * 只要头偏得超过 15°，先 {@code rotateBodyIfNecessary()} 把车身往头那边拧，
 * 头稳住 10 tick 之后再 {@code rotateHeadTowardsFront()} 把车身慢慢摇到头上。</p>
 * <p>这条对本车是<b>实际生效</b>的：{@code clientTick} 的停车分支先要过
 * {@code notCarryingMobPassengers()}，判据是"最上面的乘客是不是 {@code Mob}"，
 * 而 {@link CarrierHitbox} 刻意继承自 {@code Entity}（不是 Mob，见其类注释），
 * 于是判据恒为真。结果就是：运兵车站着不动时，{@code LookAtPlayerGoal} /
 * {@code RandomLookAroundGoal} 一掰头，车身照样会跟着转过去——正是需求要禁掉的
 * "原地转向"。1.21.1 的 {@code bodyRotationControl} 字段是 {@code private final}，
 * 换不掉，但 {@code Mob#createBodyControl()} 是 {@code protected} 的工厂方法，
 * 在 {@code Mob} 构造器里被调用，覆盖它即可（本构造器只存引用、不读实体字段，
 * 所以在这个"对象还没构造完"的时机也安全）。</p>
 *
 * <h2>换成什么</h2>
 * <p>一行钉死：{@code yBodyRot = getYRot()}。车体朝向本身已经被
 * {@link NetherCarrier#steerTowards} 管住（静止禁转、运动中每 tick 左右最多 15°、
 * 船式渐变），所以车身从此只跟这条弧线走，动画插值（{@code yBodyRotO → yBodyRot}）
 * 照旧由原版负责，≤15°/tick 的台阶在渲染端被 partial tick 抹平成连续的转弯。</p>
 * <p>头部（驾驶室）仍按原版的"相对车身 ±{@code getMaxHeadYRot()}"收拢，只是不再
 * 反过来驱动车身：本车模型根本不读 {@code netHeadYaw}
 * （{@link NetherCarrierModel#setupAnim} 里没有它），收拢只是让 {@code yHeadRot}
 * 保持一个讲得通的值，免得别处（未来接的瞄准、音效方位等）取到离谱的朝向。</p>
 */
public class CarrierBodyControl extends BodyRotationControl {

    private final Mob carrier;

    public CarrierBodyControl(Mob carrier) {
        super(carrier);
        this.carrier = carrier;
    }

    @Override
    public void clientTick() {
        this.carrier.yBodyRot = this.carrier.getYRot();
        this.carrier.yHeadRot = Mth.rotateIfNecessary(this.carrier.yHeadRot, this.carrier.yBodyRot,
                this.carrier.getMaxHeadYRot());
    }
}
