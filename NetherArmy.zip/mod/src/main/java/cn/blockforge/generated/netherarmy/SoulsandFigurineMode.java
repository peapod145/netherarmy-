package cn.blockforge.generated.netherarmy;

import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;

/**
 * 灵魂土偶的三种行为模式，在土偶界面里点按钮循环切换（和调难度一样按一次换一档）。
 *
 * <ul>
 *   <li>{@link #GUARD} 警戒：不跟随召唤者、待在原地；发现敌对生物就追，敌人死后回到岗位。</li>
 *   <li>{@link #ESCORT} 保镖（默认）：跟随召唤者，自动攻击靠近的敌对生物。</li>
 *   <li>{@link #ATTENDANT} 侍从：跟随召唤者但不主动出手，只打召唤者攻击过的、攻击过召唤者的，
 *       以及打自己的目标（挨打还手不算"主动攻击"）。</li>
 * </ul>
 */
public enum SoulsandFigurineMode implements StringRepresentable {
    GUARD("guard"),
    ESCORT("escort"),
    ATTENDANT("attendant");

    private static final SoulsandFigurineMode[] VALUES = values();
    public static final SoulsandFigurineMode DEFAULT = ESCORT;

    private final String name;

    SoulsandFigurineMode(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return this.name;
    }

    /** 按钮每按一次就前进一档。 */
    public SoulsandFigurineMode next() {
        return VALUES[(this.ordinal() + 1) % VALUES.length];
    }

    /** 是否跟随召唤者：警戒模式原地驻守。 */
    public boolean followsOwner() {
        return this != GUARD;
    }

    /** 是否主动搜索并攻击敌对生物：侍从模式只打"玩家招惹过"的目标。 */
    public boolean huntsHostiles() {
        return this != ATTENDANT;
    }

    public static SoulsandFigurineMode byOrdinal(int ordinal) {
        return ordinal >= 0 && ordinal < VALUES.length ? VALUES[ordinal] : DEFAULT;
    }

    public static SoulsandFigurineMode byName(String name) {
        for (SoulsandFigurineMode mode : VALUES) {
            if (mode.name.equals(name)) {
                return mode;
            }
        }
        return DEFAULT;
    }

    /** 按钮上的短标签。 */
    public Component shortName() {
        return Component.translatable("entity.netherarmy.soulsand_figurine.mode." + this.name + ".short");
    }

    public Component displayName() {
        return Component.translatable("entity.netherarmy.soulsand_figurine.mode." + this.name);
    }

    public Component description() {
        return Component.translatable("entity.netherarmy.soulsand_figurine.mode." + this.name + ".desc");
    }
}
