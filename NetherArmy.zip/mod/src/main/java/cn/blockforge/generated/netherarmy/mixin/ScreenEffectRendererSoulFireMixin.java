package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireBurn;
import cn.blockforge.generated.netherarmy.SoulFireFlareRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.Material;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** 第一人称燃烧覆盖层使用与第三人称相同的灵魂火贴图。 */
@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererSoulFireMixin {
    @Redirect(method = "renderFire", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/resources/model/Material;" 
                    + "sprite()Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;"))
    private static TextureAtlasSprite netherarmy$useSoulFireSprite(Material fireMaterial) {
        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;
        if (player != null && SoulFireBurn.isSoulFlame(player)) {
            return SoulFireFlareRenderer.firstPersonSoulFireSprite();
        }
        return fireMaterial.sprite();
    }
}
