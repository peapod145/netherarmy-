package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;

/**
 * 灵魂土偶模型：几何与逐面 UV 按用户上传的 soulsand_figurine.bbmodel 精确复刻。
 *
 * <p>枢轴沿用原版玩家/HumanoidModel 网格（头/躯干 0、臂 2、腿 12），
 * 所以拉弓、举盾、挥臂这些姿势通道可以直接走 HumanoidModel。
 * 本体方块由 ImmortalWarriorQuads 按烘焙数组发射，护甲层走标准 64x32 人形甲。</p>
 */
public class SoulsandFigurineModel extends HumanoidModel<SoulsandFigurine> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soulsand_figurine"), "main");
    public static final ModelLayerLocation INNER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soulsand_figurine"), "inner_armor");
    public static final ModelLayerLocation OUTER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soulsand_figurine"), "outer_armor");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 64;
    private final ModelPart root;
    private final boolean armorLayer;

    private static final float[] HEAD = {
        4.0F, -8.0F, -4.0F, -4.0F, -8.0F, -4.0F, -4.0F, 0.0F, -4.0F, 4.0F,
        0.0F, -4.0F, 8.0F, 8.0F, 16.0F, 16.0F, 0.0F, 0.0F, -1.0F, -4.0F,
        -8.0F, 4.0F, 4.0F, -8.0F, 4.0F, 4.0F, 0.0F, 4.0F, -4.0F, 0.0F,
        4.0F, 24.0F, 8.0F, 32.0F, 16.0F, 0.0F, 0.0F, 1.0F, 4.0F, -8.0F,
        4.0F, 4.0F, -8.0F, -4.0F, 4.0F, 0.0F, -4.0F, 4.0F, 0.0F, 4.0F,
        0.0F, 8.0F, 8.0F, 16.0F, 1.0F, 0.0F, 0.0F, -4.0F, -8.0F, -4.0F,
        -4.0F, -8.0F, 4.0F, -4.0F, 0.0F, 4.0F, -4.0F, 0.0F, -4.0F, 16.0F,
        8.0F, 24.0F, 16.0F, -1.0F, 0.0F, 0.0F, -4.0F, -8.0F, -4.0F, 4.0F,
        -8.0F, -4.0F, 4.0F, -8.0F, 4.0F, -4.0F, -8.0F, 4.0F, 16.0F, 8.0F,
        8.0F, 0.0F, 0.0F, -1.0F, 0.0F, -4.0F, 0.0F, 4.0F, 4.0F, 0.0F,
        4.0F, 4.0F, 0.0F, -4.0F, -4.0F, 0.0F, -4.0F, 24.0F, 0.0F, 16.0F,
        8.0F, 0.0F, 1.0F, 0.0F, -1.0F, -3.0F, -4.4F, -2.0F, -3.0F, -4.4F,
        -2.0F, -1.0F, -4.4F, -1.0F, -1.0F, -4.4F, 57.0F, 33.0F, 58.0F, 35.0F,
        0.0F, 0.0F, -1.0F, -2.0F, -3.0F, -3.4F, -1.0F, -3.0F, -3.4F, -1.0F,
        -1.0F, -3.4F, -2.0F, -1.0F, -3.4F, 59.0F, 33.0F, 60.0F, 35.0F, 0.0F,
        0.0F, 1.0F, -1.0F, -3.0F, -3.4F, -1.0F, -3.0F, -4.4F, -1.0F, -1.0F,
        -4.4F, -1.0F, -1.0F, -3.4F, 56.0F, 33.0F, 57.0F, 35.0F, 1.0F, 0.0F,
        0.0F, -2.0F, -3.0F, -4.4F, -2.0F, -3.0F, -3.4F, -2.0F, -1.0F, -3.4F,
        -2.0F, -1.0F, -4.4F, 58.0F, 33.0F, 59.0F, 35.0F, -1.0F, 0.0F, 0.0F,
        -2.0F, -3.0F, -4.4F, -1.0F, -3.0F, -4.4F, -1.0F, -3.0F, -3.4F, -2.0F,
        -3.0F, -3.4F, 58.0F, 33.0F, 57.0F, 32.0F, 0.0F, -1.0F, 0.0F, -2.0F,
        -1.0F, -3.4F, -1.0F, -1.0F, -3.4F, -1.0F, -1.0F, -4.4F, -2.0F, -1.0F,
        -4.4F, 59.0F, 32.0F, 58.0F, 33.0F, 0.0F, 1.0F, 0.0F, -3.999F, -2.999F,
        -4.399F, -3.999F, -2.001F, -4.399F, -2.001F, -2.001F, -4.399F, -2.001F, -2.999F, -4.399F,
        57.0F, 36.0F, 58.0F, 38.0F, 0.0F, 0.0F, -1.0F, -3.999F, -2.001F, -3.401F,
        -3.999F, -2.999F, -3.401F, -2.001F, -2.999F, -3.401F, -2.001F, -2.001F, -3.401F, 59.0F,
        36.0F, 60.0F, 38.0F, 0.0F, 0.0F, 1.0F, -3.999F, -2.999F, -3.401F, -3.999F,
        -2.999F, -4.399F, -2.001F, -2.999F, -4.399F, -2.001F, -2.999F, -3.401F, 56.0F, 36.0F,
        57.0F, 38.0F, 0.0F, -1.0F, 0.0F, -3.999F, -2.001F, -4.399F, -3.999F, -2.001F,
        -3.401F, -2.001F, -2.001F, -3.401F, -2.001F, -2.001F, -4.399F, 58.0F, 36.0F, 59.0F,
        38.0F, 0.0F, 1.0F, 0.0F, -3.999F, -2.001F, -4.399F, -3.999F, -2.999F, -4.399F,
        -3.999F, -2.999F, -3.401F, -3.999F, -2.001F, -3.401F, 58.0F, 36.0F, 57.0F, 35.0F,
        -1.0F, 0.0F, 0.0F, -2.001F, -2.001F, -3.401F, -2.001F, -2.999F, -3.401F, -2.001F,
        -2.999F, -4.399F, -2.001F, -2.001F, -4.399F, 59.0F, 35.0F, 58.0F, 36.0F, 1.0F,
        0.0F, 0.0F, -1.0F, -6.0F, -4.4F, -2.0F, -6.0F, -4.4F, -2.0F, -4.0F,
        -4.4F, -1.0F, -4.0F, -4.4F, 39.0F, 57.0F, 40.0F, 59.0F, 0.0F, 0.0F,
        -1.0F, -2.0F, -6.0F, -3.4F, -1.0F, -6.0F, -3.4F, -1.0F, -4.0F, -3.4F,
        -2.0F, -4.0F, -3.4F, 41.0F, 57.0F, 42.0F, 59.0F, 0.0F, 0.0F, 1.0F,
        -1.0F, -6.0F, -3.4F, -1.0F, -6.0F, -4.4F, -1.0F, -4.0F, -4.4F, -1.0F,
        -4.0F, -3.4F, 38.0F, 57.0F, 39.0F, 59.0F, 1.0F, 0.0F, 0.0F, -2.0F,
        -6.0F, -4.4F, -2.0F, -6.0F, -3.4F, -2.0F, -4.0F, -3.4F, -2.0F, -4.0F,
        -4.4F, 40.0F, 57.0F, 41.0F, 59.0F, -1.0F, 0.0F, 0.0F, -2.0F, -6.0F,
        -4.4F, -1.0F, -6.0F, -4.4F, -1.0F, -6.0F, -3.4F, -2.0F, -6.0F, -3.4F,
        40.0F, 57.0F, 39.0F, 56.0F, 0.0F, -1.0F, 0.0F, -2.0F, -4.0F, -3.4F,
        -1.0F, -4.0F, -3.4F, -1.0F, -4.0F, -4.4F, -2.0F, -4.0F, -4.4F, 41.0F,
        56.0F, 40.0F, 57.0F, 0.0F, 1.0F, 0.0F, -2.001F, -6.999F, -4.399F, -3.999F,
        -6.999F, -4.399F, -3.999F, -5.001F, -4.399F, -2.001F, -5.001F, -4.399F, 33.0F, 56.0F,
        35.0F, 58.0F, 0.0F, 0.0F, -1.0F, -3.999F, -6.999F, -3.401F, -2.001F, -6.999F,
        -3.401F, -2.001F, -5.001F, -3.401F, -3.999F, -5.001F, -3.401F, 36.0F, 56.0F, 38.0F,
        58.0F, 0.0F, 0.0F, 1.0F, -2.001F, -6.999F, -3.401F, -2.001F, -6.999F, -4.399F,
        -2.001F, -5.001F, -4.399F, -2.001F, -5.001F, -3.401F, 32.0F, 56.0F, 33.0F, 58.0F,
        1.0F, 0.0F, 0.0F, -3.999F, -6.999F, -4.399F, -3.999F, -6.999F, -3.401F, -3.999F,
        -5.001F, -3.401F, -3.999F, -5.001F, -4.399F, 35.0F, 56.0F, 36.0F, 58.0F, -1.0F,
        0.0F, 0.0F, -3.999F, -6.999F, -4.399F, -2.001F, -6.999F, -4.399F, -2.001F, -6.999F,
        -3.401F, -3.999F, -6.999F, -3.401F, 35.0F, 56.0F, 33.0F, 55.0F, 0.0F, -1.0F,
        0.0F, -3.999F, -5.001F, -3.401F, -2.001F, -5.001F, -3.401F, -2.001F, -5.001F, -4.399F,
        -3.999F, -5.001F, -4.399F, 37.0F, 55.0F, 35.0F, 56.0F, 0.0F, 1.0F, 0.0F,
        2.0F, -3.0F, -4.4F, 1.0F, -3.0F, -4.4F, 1.0F, -1.0F, -4.4F, 2.0F,
        -1.0F, -4.4F, 57.0F, 39.0F, 58.0F, 41.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        -3.0F, -3.4F, 2.0F, -3.0F, -3.4F, 2.0F, -1.0F, -3.4F, 1.0F, -1.0F,
        -3.4F, 59.0F, 39.0F, 60.0F, 41.0F, 0.0F, 0.0F, 1.0F, 2.0F, -3.0F,
        -3.4F, 2.0F, -3.0F, -4.4F, 2.0F, -1.0F, -4.4F, 2.0F, -1.0F, -3.4F,
        56.0F, 39.0F, 57.0F, 41.0F, 1.0F, 0.0F, 0.0F, 1.0F, -3.0F, -4.4F,
        1.0F, -3.0F, -3.4F, 1.0F, -1.0F, -3.4F, 1.0F, -1.0F, -4.4F, 58.0F,
        39.0F, 59.0F, 41.0F, -1.0F, 0.0F, 0.0F, 1.0F, -3.0F, -4.4F, 2.0F,
        -3.0F, -4.4F, 2.0F, -3.0F, -3.4F, 1.0F, -3.0F, -3.4F, 58.0F, 39.0F,
        57.0F, 38.0F, 0.0F, -1.0F, 0.0F, 1.0F, -1.0F, -3.4F, 2.0F, -1.0F,
        -3.4F, 2.0F, -1.0F, -4.4F, 1.0F, -1.0F, -4.4F, 59.0F, 38.0F, 58.0F,
        39.0F, 0.0F, 1.0F, 0.0F, 3.999F, -2.001F, -4.399F, 3.999F, -2.999F, -4.399F,
        2.001F, -2.999F, -4.399F, 2.001F, -2.001F, -4.399F, 57.0F, 42.0F, 58.0F, 44.0F,
        0.0F, 0.0F, -1.0F, 3.999F, -2.999F, -3.401F, 3.999F, -2.001F, -3.401F, 2.001F,
        -2.001F, -3.401F, 2.001F, -2.999F, -3.401F, 59.0F, 42.0F, 60.0F, 44.0F, 0.0F,
        0.0F, 1.0F, 3.999F, -2.001F, -3.401F, 3.999F, -2.001F, -4.399F, 2.001F, -2.001F,
        -4.399F, 2.001F, -2.001F, -3.401F, 56.0F, 42.0F, 57.0F, 44.0F, 0.0F, 1.0F,
        0.0F, 3.999F, -2.999F, -4.399F, 3.999F, -2.999F, -3.401F, 2.001F, -2.999F, -3.401F,
        2.001F, -2.999F, -4.399F, 58.0F, 42.0F, 59.0F, 44.0F, 0.0F, -1.0F, 0.0F,
        3.999F, -2.999F, -4.399F, 3.999F, -2.001F, -4.399F, 3.999F, -2.001F, -3.401F, 3.999F,
        -2.999F, -3.401F, 58.0F, 42.0F, 57.0F, 41.0F, 1.0F, 0.0F, 0.0F, 2.001F,
        -2.999F, -3.401F, 2.001F, -2.001F, -3.401F, 2.001F, -2.001F, -4.399F, 2.001F, -2.999F,
        -4.399F, 59.0F, 41.0F, 58.0F, 42.0F, -1.0F, 0.0F, 0.0F, 2.0F, -6.0F,
        -4.4F, 1.0F, -6.0F, -4.4F, 1.0F, -4.0F, -4.4F, 2.0F, -4.0F, -4.4F,
        43.0F, 57.0F, 44.0F, 59.0F, 0.0F, 0.0F, -1.0F, 1.0F, -6.0F, -3.4F,
        2.0F, -6.0F, -3.4F, 2.0F, -4.0F, -3.4F, 1.0F, -4.0F, -3.4F, 45.0F,
        57.0F, 46.0F, 59.0F, 0.0F, 0.0F, 1.0F, 2.0F, -6.0F, -3.4F, 2.0F,
        -6.0F, -4.4F, 2.0F, -4.0F, -4.4F, 2.0F, -4.0F, -3.4F, 42.0F, 57.0F,
        43.0F, 59.0F, 1.0F, 0.0F, 0.0F, 1.0F, -6.0F, -4.4F, 1.0F, -6.0F,
        -3.4F, 1.0F, -4.0F, -3.4F, 1.0F, -4.0F, -4.4F, 44.0F, 57.0F, 45.0F,
        59.0F, -1.0F, 0.0F, 0.0F, 1.0F, -6.0F, -4.4F, 2.0F, -6.0F, -4.4F,
        2.0F, -6.0F, -3.4F, 1.0F, -6.0F, -3.4F, 44.0F, 57.0F, 43.0F, 56.0F,
        0.0F, -1.0F, 0.0F, 1.0F, -4.0F, -3.4F, 2.0F, -4.0F, -3.4F, 2.0F,
        -4.0F, -4.4F, 1.0F, -4.0F, -4.4F, 45.0F, 56.0F, 44.0F, 57.0F, 0.0F,
        1.0F, 0.0F, 3.999F, -6.999F, -4.399F, 2.001F, -6.999F, -4.399F, 2.001F, -5.001F,
        -4.399F, 3.999F, -5.001F, -4.399F, 55.0F, 56.0F, 57.0F, 58.0F, 0.0F, 0.0F,
        -1.0F, 2.001F, -6.999F, -3.401F, 3.999F, -6.999F, -3.401F, 3.999F, -5.001F, -3.401F,
        2.001F, -5.001F, -3.401F, 58.0F, 56.0F, 60.0F, 58.0F, 0.0F, 0.0F, 1.0F,
        3.999F, -6.999F, -3.401F, 3.999F, -6.999F, -4.399F, 3.999F, -5.001F, -4.399F, 3.999F,
        -5.001F, -3.401F, 54.0F, 56.0F, 55.0F, 58.0F, 1.0F, 0.0F, 0.0F, 2.001F,
        -6.999F, -4.399F, 2.001F, -6.999F, -3.401F, 2.001F, -5.001F, -3.401F, 2.001F, -5.001F,
        -4.399F, 57.0F, 56.0F, 58.0F, 58.0F, -1.0F, 0.0F, 0.0F, 2.001F, -6.999F,
        -4.399F, 3.999F, -6.999F, -4.399F, 3.999F, -6.999F, -3.401F, 2.001F, -6.999F, -3.401F,
        57.0F, 56.0F, 55.0F, 55.0F, 0.0F, -1.0F, 0.0F, 2.001F, -5.001F, -3.401F,
        3.999F, -5.001F, -3.401F, 3.999F, -5.001F, -4.399F, 2.001F, -5.001F, -4.399F, 59.0F,
        55.0F, 57.0F, 56.0F, 0.0F, 1.0F, 0.0F, 1.0F, -4.0F, -4.4F, -1.0F,
        -4.0F, -4.4F, -1.0F, -1.0F, -4.4F, 1.0F, -1.0F, -4.4F, 1.0F, 1.0F,
        3.0F, 4.0F, 0.0F, 0.0F, -1.0F, -1.0F, -4.0F, -3.4F, 1.0F, -4.0F,
        -3.4F, 1.0F, -1.0F, -3.4F, -1.0F, -1.0F, -3.4F, 4.0F, 1.0F, 6.0F,
        4.0F, 0.0F, 0.0F, 1.0F, 1.0F, -4.0F, -3.4F, 1.0F, -4.0F, -4.4F,
        1.0F, -1.0F, -4.4F, 1.0F, -1.0F, -3.4F, 0.0F, 1.0F, 1.0F, 4.0F,
        1.0F, 0.0F, 0.0F, -1.0F, -4.0F, -4.4F, -1.0F, -4.0F, -3.4F, -1.0F,
        -1.0F, -3.4F, -1.0F, -1.0F, -4.4F, 3.0F, 1.0F, 4.0F, 4.0F, -1.0F,
        0.0F, 0.0F, -1.0F, -4.0F, -4.4F, 1.0F, -4.0F, -4.4F, 1.0F, -4.0F,
        -3.4F, -1.0F, -4.0F, -3.4F, 3.0F, 1.0F, 1.0F, 0.0F, 0.0F, -1.0F,
        0.0F, -1.0F, -1.0F, -3.4F, 1.0F, -1.0F, -3.4F, 1.0F, -1.0F, -4.4F,
        -1.0F, -1.0F, -4.4F, 5.0F, 0.0F, 3.0F, 1.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] BODY = {
        4.0F, 0.0F, -2.0F, -4.0F, 0.0F, -2.0F, -4.0F, 12.0F, -2.0F, 4.0F,
        12.0F, -2.0F, 4.0F, 20.0F, 12.0F, 32.0F, 0.0F, 0.0F, -1.0F, -4.0F,
        0.0F, 2.0F, 4.0F, 0.0F, 2.0F, 4.0F, 12.0F, 2.0F, -4.0F, 12.0F,
        2.0F, 16.0F, 20.0F, 24.0F, 32.0F, 0.0F, 0.0F, 1.0F, 4.0F, 0.0F,
        2.0F, 4.0F, 0.0F, -2.0F, 4.0F, 12.0F, -2.0F, 4.0F, 12.0F, 2.0F,
        0.0F, 20.0F, 4.0F, 32.0F, 1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F,
        -4.0F, 0.0F, 2.0F, -4.0F, 12.0F, 2.0F, -4.0F, 12.0F, -2.0F, 12.0F,
        20.0F, 16.0F, 32.0F, -1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F, 4.0F,
        0.0F, -2.0F, 4.0F, 0.0F, 2.0F, -4.0F, 0.0F, 2.0F, 12.0F, 20.0F,
        4.0F, 16.0F, 0.0F, -1.0F, 0.0F, -4.0F, 12.0F, 2.0F, 4.0F, 12.0F,
        2.0F, 4.0F, 12.0F, -2.0F, -4.0F, 12.0F, -2.0F, 20.0F, 16.0F, 12.0F,
        20.0F, 0.0F, 1.0F, 0.0F, 4.1F, -0.1F, -2.1F, -4.1F, -0.1F, -2.1F,
        -4.1F, 12.1F, -2.1F, 4.1F, 12.1F, -2.1F, 28.0F, 20.0F, 36.0F, 32.0F,
        0.0F, 0.0F, -1.0F, -4.1F, -0.1F, 2.1F, 4.1F, -0.1F, 2.1F, 4.1F,
        12.1F, 2.1F, -4.1F, 12.1F, 2.1F, 40.0F, 20.0F, 48.0F, 32.0F, 0.0F,
        0.0F, 1.0F, 4.1F, -0.1F, 2.1F, 4.1F, -0.1F, -2.1F, 4.1F, 12.1F,
        -2.1F, 4.1F, 12.1F, 2.1F, 24.0F, 20.0F, 28.0F, 32.0F, 1.0F, 0.0F,
        0.0F, -4.1F, -0.1F, -2.1F, -4.1F, -0.1F, 2.1F, -4.1F, 12.1F, 2.1F,
        -4.1F, 12.1F, -2.1F, 36.0F, 20.0F, 40.0F, 32.0F, -1.0F, 0.0F, 0.0F,
        -4.1F, -0.1F, -2.1F, 4.1F, -0.1F, -2.1F, 4.1F, -0.1F, 2.1F, -4.1F,
        -0.1F, 2.1F, 36.0F, 20.0F, 28.0F, 16.0F, 0.0F, -1.0F, 0.0F, -4.1F,
        12.1F, 2.1F, 4.1F, 12.1F, 2.1F, 4.1F, 12.1F, -2.1F, -4.1F, 12.1F,
        -2.1F, 44.0F, 16.0F, 36.0F, 20.0F, 0.0F, 1.0F, 0.0F, 1.0F, 5.0F,
        -3.0F, -1.0F, 5.0F, -3.0F, -1.0F, 7.0F, -3.0F, 1.0F, 7.0F, -3.0F,
        55.0F, 53.0F, 57.0F, 55.0F, 0.0F, 0.0F, -1.0F, -1.0F, 5.0F, -2.0F,
        1.0F, 5.0F, -2.0F, 1.0F, 7.0F, -2.0F, -1.0F, 7.0F, -2.0F, 58.0F,
        53.0F, 60.0F, 55.0F, 0.0F, 0.0F, 1.0F, 1.0F, 5.0F, -2.0F, 1.0F,
        5.0F, -3.0F, 1.0F, 7.0F, -3.0F, 1.0F, 7.0F, -2.0F, 54.0F, 53.0F,
        55.0F, 55.0F, 1.0F, 0.0F, 0.0F, -1.0F, 5.0F, -3.0F, -1.0F, 5.0F,
        -2.0F, -1.0F, 7.0F, -2.0F, -1.0F, 7.0F, -3.0F, 57.0F, 53.0F, 58.0F,
        55.0F, -1.0F, 0.0F, 0.0F, -1.0F, 5.0F, -3.0F, 1.0F, 5.0F, -3.0F,
        1.0F, 5.0F, -2.0F, -1.0F, 5.0F, -2.0F, 57.0F, 53.0F, 55.0F, 52.0F,
        0.0F, -1.0F, 0.0F, -1.0F, 7.0F, -2.0F, 1.0F, 7.0F, -2.0F, 1.0F,
        7.0F, -3.0F, -1.0F, 7.0F, -3.0F, 59.0F, 52.0F, 57.0F, 53.0F, 0.0F,
        1.0F, 0.0F, 1.999F, 5.001F, -2.599F, -1.999F, 5.001F, -2.599F, -1.999F, 6.999F,
        -2.599F, 1.999F, 6.999F, -2.599F, 33.0F, 49.0F, 37.0F, 51.0F, 0.0F, 0.0F,
        -1.0F, -1.999F, 5.001F, -1.601F, 1.999F, 5.001F, -1.601F, 1.999F, 6.999F, -1.601F,
        -1.999F, 6.999F, -1.601F, 38.0F, 49.0F, 42.0F, 51.0F, 0.0F, 0.0F, 1.0F,
        1.999F, 5.001F, -1.601F, 1.999F, 5.001F, -2.599F, 1.999F, 6.999F, -2.599F, 1.999F,
        6.999F, -1.601F, 32.0F, 49.0F, 33.0F, 51.0F, 1.0F, 0.0F, 0.0F, -1.999F,
        5.001F, -2.599F, -1.999F, 5.001F, -1.601F, -1.999F, 6.999F, -1.601F, -1.999F, 6.999F,
        -2.599F, 37.0F, 49.0F, 38.0F, 51.0F, -1.0F, 0.0F, 0.0F, -1.999F, 5.001F,
        -2.599F, 1.999F, 5.001F, -2.599F, 1.999F, 5.001F, -1.601F, -1.999F, 5.001F, -1.601F,
        37.0F, 49.0F, 33.0F, 48.0F, 0.0F, -1.0F, 0.0F, -1.999F, 6.999F, -1.601F,
        1.999F, 6.999F, -1.601F, 1.999F, 6.999F, -2.599F, -1.999F, 6.999F, -2.599F, 41.0F,
        48.0F, 37.0F, 49.0F, 0.0F, 1.0F, 0.0F, 1.001F, 3.999F, -2.601F, -1.001F,
        3.999F, -2.601F, -1.001F, 8.001F, -2.601F, 1.001F, 8.001F, -2.601F, 49.0F, 53.0F,
        51.0F, 57.0F, 0.0F, 0.0F, -1.0F, -1.001F, 3.999F, -1.599F, 1.001F, 3.999F,
        -1.599F, 1.001F, 8.001F, -1.599F, -1.001F, 8.001F, -1.599F, 52.0F, 53.0F, 54.0F,
        57.0F, 0.0F, 0.0F, 1.0F, 1.001F, 3.999F, -1.599F, 1.001F, 3.999F, -2.601F,
        1.001F, 8.001F, -2.601F, 1.001F, 8.001F, -1.599F, 48.0F, 53.0F, 49.0F, 57.0F,
        1.0F, 0.0F, 0.0F, -1.001F, 3.999F, -2.601F, -1.001F, 3.999F, -1.599F, -1.001F,
        8.001F, -1.599F, -1.001F, 8.001F, -2.601F, 51.0F, 53.0F, 52.0F, 57.0F, -1.0F,
        0.0F, 0.0F, -1.001F, 3.999F, -2.601F, 1.001F, 3.999F, -2.601F, 1.001F, 3.999F,
        -1.599F, -1.001F, 3.999F, -1.599F, 51.0F, 53.0F, 49.0F, 52.0F, 0.0F, -1.0F,
        0.0F, -1.001F, 8.001F, -1.599F, 1.001F, 8.001F, -1.599F, 1.001F, 8.001F, -2.601F,
        -1.001F, 8.001F, -2.601F, 53.0F, 52.0F, 51.0F, 53.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_ARM = {
        13.0F, -2.0F, -2.0F, 9.0F, -2.0F, -2.0F, 9.0F, 10.0F, -2.0F, 13.0F,
        10.0F, -2.0F, 4.0F, 36.0F, 8.0F, 48.0F, 0.0F, 0.0F, -1.0F, 9.0F,
        -2.0F, 2.0F, 13.0F, -2.0F, 2.0F, 13.0F, 10.0F, 2.0F, 9.0F, 10.0F,
        2.0F, 12.0F, 36.0F, 16.0F, 48.0F, 0.0F, 0.0F, 1.0F, 13.0F, -2.0F,
        2.0F, 13.0F, -2.0F, -2.0F, 13.0F, 10.0F, -2.0F, 13.0F, 10.0F, 2.0F,
        0.0F, 36.0F, 4.0F, 48.0F, 1.0F, 0.0F, 0.0F, 9.0F, -2.0F, -2.0F,
        9.0F, -2.0F, 2.0F, 9.0F, 10.0F, 2.0F, 9.0F, 10.0F, -2.0F, 8.0F,
        36.0F, 12.0F, 48.0F, -1.0F, 0.0F, 0.0F, 9.0F, -2.0F, -2.0F, 13.0F,
        -2.0F, -2.0F, 13.0F, -2.0F, 2.0F, 9.0F, -2.0F, 2.0F, 8.0F, 36.0F,
        4.0F, 32.0F, 0.0F, -1.0F, 0.0F, 9.0F, 10.0F, 2.0F, 13.0F, 10.0F,
        2.0F, 13.0F, 10.0F, -2.0F, 9.0F, 10.0F, -2.0F, 12.0F, 32.0F, 8.0F,
        36.0F, 0.0F, 1.0F, 0.0F, 13.2F, -2.2F, -2.2F, 8.8F, -2.2F, -2.2F,
        8.8F, 1.2F, -2.2F, 13.2F, 1.2F, -2.2F, 52.0F, 22.0F, 56.0F, 25.0F,
        0.0F, 0.0F, -1.0F, 8.8F, -2.2F, 2.2F, 13.2F, -2.2F, 2.2F, 13.2F,
        1.2F, 2.2F, 8.8F, 1.2F, 2.2F, 60.0F, 22.0F, 64.0F, 25.0F, 0.0F,
        0.0F, 1.0F, 13.2F, -2.2F, 2.2F, 13.2F, -2.2F, -2.2F, 13.2F, 1.2F,
        -2.2F, 13.2F, 1.2F, 2.2F, 48.0F, 22.0F, 52.0F, 25.0F, 1.0F, 0.0F,
        0.0F, 8.8F, -2.2F, -2.2F, 8.8F, -2.2F, 2.2F, 8.8F, 1.2F, 2.2F,
        8.8F, 1.2F, -2.2F, 56.0F, 22.0F, 60.0F, 25.0F, -1.0F, 0.0F, 0.0F,
        8.8F, -2.2F, -2.2F, 13.2F, -2.2F, -2.2F, 13.2F, -2.2F, 2.2F, 8.8F,
        -2.2F, 2.2F, 56.0F, 22.0F, 52.0F, 18.0F, 0.0F, -1.0F, 0.0F, 8.8F,
        1.2F, 2.2F, 13.2F, 1.2F, 2.2F, 13.2F, 1.2F, -2.2F, 8.8F, 1.2F,
        -2.2F, 60.0F, 18.0F, 56.0F, 22.0F, 0.0F, 1.0F, 0.0F, 13.2F, 3.8F,
        -2.2F, 8.8F, 3.8F, -2.2F, 8.8F, 9.2F, -2.2F, 13.2F, 9.2F, -2.2F,
        20.0F, 52.0F, 24.0F, 57.0F, 0.0F, 0.0F, -1.0F, 8.8F, 3.8F, 2.2F,
        13.2F, 3.8F, 2.2F, 13.2F, 9.2F, 2.2F, 8.8F, 9.2F, 2.2F, 28.0F,
        52.0F, 32.0F, 57.0F, 0.0F, 0.0F, 1.0F, 13.2F, 3.8F, 2.2F, 13.2F,
        3.8F, -2.2F, 13.2F, 9.2F, -2.2F, 13.2F, 9.2F, 2.2F, 16.0F, 52.0F,
        20.0F, 57.0F, 1.0F, 0.0F, 0.0F, 8.8F, 3.8F, -2.2F, 8.8F, 3.8F,
        2.2F, 8.8F, 9.2F, 2.2F, 8.8F, 9.2F, -2.2F, 24.0F, 52.0F, 28.0F,
        57.0F, -1.0F, 0.0F, 0.0F, 8.8F, 3.8F, -2.2F, 13.2F, 3.8F, -2.2F,
        13.2F, 3.8F, 2.2F, 8.8F, 3.8F, 2.2F, 24.0F, 52.0F, 20.0F, 48.0F,
        0.0F, -1.0F, 0.0F, 8.8F, 9.2F, 2.2F, 13.2F, 9.2F, 2.2F, 13.2F,
        9.2F, -2.2F, 8.8F, 9.2F, -2.2F, 28.0F, 48.0F, 24.0F, 52.0F, 0.0F,
        1.0F, 0.0F, 13.5F, -0.5F, -0.5F, 12.5F, -0.5F, -0.5F, 12.5F, 0.5F,
        -0.5F, 13.5F, 0.5F, -0.5F, 50.0F, 34.0F, 52.0F, 36.0F, 0.0F, 0.0F,
        -1.0F, 12.5F, -0.5F, 0.5F, 13.5F, -0.5F, 0.5F, 13.5F, 0.5F, 0.5F,
        12.5F, 0.5F, 0.5F, 54.0F, 34.0F, 56.0F, 36.0F, 0.0F, 0.0F, 1.0F,
        13.5F, -0.5F, 0.5F, 13.5F, -0.5F, -0.5F, 13.5F, 0.5F, -0.5F, 13.5F,
        0.5F, 0.5F, 48.0F, 34.0F, 50.0F, 36.0F, 1.0F, 0.0F, 0.0F, 12.5F,
        -0.5F, -0.5F, 12.5F, -0.5F, 0.5F, 12.5F, 0.5F, 0.5F, 12.5F, 0.5F,
        -0.5F, 52.0F, 34.0F, 54.0F, 36.0F, -1.0F, 0.0F, 0.0F, 12.5F, -0.5F,
        -0.5F, 13.5F, -0.5F, -0.5F, 13.5F, -0.5F, 0.5F, 12.5F, -0.5F, 0.5F,
        52.0F, 34.0F, 50.0F, 32.0F, 0.0F, -1.0F, 0.0F, 12.5F, 0.5F, 0.5F,
        13.5F, 0.5F, 0.5F, 13.5F, 0.5F, -0.5F, 12.5F, 0.5F, -0.5F, 54.0F,
        32.0F, 52.0F, 34.0F, 0.0F, 1.0F, 0.0F, 13.1F, 4.7F, -2.3F, 12.1F,
        4.7F, -2.3F, 12.1F, 5.7F, -2.3F, 13.1F, 5.7F, -2.3F, 50.0F, 42.0F,
        52.0F, 44.0F, 0.0F, 0.0F, -1.0F, 12.1F, 4.7F, -1.3F, 13.1F, 4.7F,
        -1.3F, 13.1F, 5.7F, -1.3F, 12.1F, 5.7F, -1.3F, 54.0F, 42.0F, 56.0F,
        44.0F, 0.0F, 0.0F, 1.0F, 13.1F, 4.7F, -1.3F, 13.1F, 4.7F, -2.3F,
        13.1F, 5.7F, -2.3F, 13.1F, 5.7F, -1.3F, 48.0F, 42.0F, 50.0F, 44.0F,
        1.0F, 0.0F, 0.0F, 12.1F, 4.7F, -2.3F, 12.1F, 4.7F, -1.3F, 12.1F,
        5.7F, -1.3F, 12.1F, 5.7F, -2.3F, 52.0F, 42.0F, 54.0F, 44.0F, -1.0F,
        0.0F, 0.0F, 12.1F, 4.7F, -2.3F, 13.1F, 4.7F, -2.3F, 13.1F, 4.7F,
        -1.3F, 12.1F, 4.7F, -1.3F, 52.0F, 42.0F, 50.0F, 40.0F, 0.0F, -1.0F,
        0.0F, 12.1F, 5.7F, -1.3F, 13.1F, 5.7F, -1.3F, 13.1F, 5.7F, -2.3F,
        12.1F, 5.7F, -2.3F, 54.0F, 40.0F, 52.0F, 42.0F, 0.0F, 1.0F, 0.0F,
        10.9F, 6.0F, -2.3F, 9.9F, 6.0F, -2.3F, 9.9F, 7.0F, -2.3F, 10.9F,
        7.0F, -2.3F, 44.0F, 50.0F, 46.0F, 52.0F, 0.0F, 0.0F, -1.0F, 9.9F,
        6.0F, -1.3F, 10.9F, 6.0F, -1.3F, 10.9F, 7.0F, -1.3F, 9.9F, 7.0F,
        -1.3F, 48.0F, 50.0F, 50.0F, 52.0F, 0.0F, 0.0F, 1.0F, 10.9F, 6.0F,
        -1.3F, 10.9F, 6.0F, -2.3F, 10.9F, 7.0F, -2.3F, 10.9F, 7.0F, -1.3F,
        42.0F, 50.0F, 44.0F, 52.0F, 1.0F, 0.0F, 0.0F, 9.9F, 6.0F, -2.3F,
        9.9F, 6.0F, -1.3F, 9.9F, 7.0F, -1.3F, 9.9F, 7.0F, -2.3F, 46.0F,
        50.0F, 48.0F, 52.0F, -1.0F, 0.0F, 0.0F, 9.9F, 6.0F, -2.3F, 10.9F,
        6.0F, -2.3F, 10.9F, 6.0F, -1.3F, 9.9F, 6.0F, -1.3F, 46.0F, 50.0F,
        44.0F, 48.0F, 0.0F, -1.0F, 0.0F, 9.9F, 7.0F, -1.3F, 10.9F, 7.0F,
        -1.3F, 10.9F, 7.0F, -2.3F, 9.9F, 7.0F, -2.3F, 48.0F, 48.0F, 46.0F,
        50.0F, 0.0F, 1.0F, 0.0F, 12.1F, 8.1F, -2.3F, 11.5F, 8.1F, -2.3F,
        11.5F, 8.7F, -2.3F, 12.1F, 8.7F, -2.3F, 50.0F, 46.0F, 52.0F, 48.0F,
        0.0F, 0.0F, -1.0F, 11.5F, 8.1F, -1.7F, 12.1F, 8.1F, -1.7F, 12.1F,
        8.7F, -1.7F, 11.5F, 8.7F, -1.7F, 54.0F, 46.0F, 56.0F, 48.0F, 0.0F,
        0.0F, 1.0F, 12.1F, 8.1F, -1.7F, 12.1F, 8.1F, -2.3F, 12.1F, 8.7F,
        -2.3F, 12.1F, 8.7F, -1.7F, 48.0F, 46.0F, 50.0F, 48.0F, 1.0F, 0.0F,
        0.0F, 11.5F, 8.1F, -2.3F, 11.5F, 8.1F, -1.7F, 11.5F, 8.7F, -1.7F,
        11.5F, 8.7F, -2.3F, 52.0F, 46.0F, 54.0F, 48.0F, -1.0F, 0.0F, 0.0F,
        11.5F, 8.1F, -2.3F, 12.1F, 8.1F, -2.3F, 12.1F, 8.1F, -1.7F, 11.5F,
        8.1F, -1.7F, 52.0F, 46.0F, 50.0F, 44.0F, 0.0F, -1.0F, 0.0F, 11.5F,
        8.7F, -1.7F, 12.1F, 8.7F, -1.7F, 12.1F, 8.7F, -2.3F, 11.5F, 8.7F,
        -2.3F, 54.0F, 44.0F, 52.0F, 46.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_ARM = {
        -9.0F, -2.0F, -2.0F, -13.0F, -2.0F, -2.0F, -13.0F, 10.0F, -2.0F, -9.0F,
        10.0F, -2.0F, 36.0F, 4.0F, 40.0F, 16.0F, 0.0F, 0.0F, -1.0F, -13.0F,
        -2.0F, 2.0F, -9.0F, -2.0F, 2.0F, -9.0F, 10.0F, 2.0F, -13.0F, 10.0F,
        2.0F, 44.0F, 4.0F, 48.0F, 16.0F, 0.0F, 0.0F, 1.0F, -9.0F, -2.0F,
        2.0F, -9.0F, -2.0F, -2.0F, -9.0F, 10.0F, -2.0F, -9.0F, 10.0F, 2.0F,
        32.0F, 4.0F, 36.0F, 16.0F, 1.0F, 0.0F, 0.0F, -13.0F, -2.0F, -2.0F,
        -13.0F, -2.0F, 2.0F, -13.0F, 10.0F, 2.0F, -13.0F, 10.0F, -2.0F, 40.0F,
        4.0F, 44.0F, 16.0F, -1.0F, 0.0F, 0.0F, -13.0F, -2.0F, -2.0F, -9.0F,
        -2.0F, -2.0F, -9.0F, -2.0F, 2.0F, -13.0F, -2.0F, 2.0F, 40.0F, 4.0F,
        36.0F, 0.0F, 0.0F, -1.0F, 0.0F, -13.0F, 10.0F, 2.0F, -9.0F, 10.0F,
        2.0F, -9.0F, 10.0F, -2.0F, -13.0F, 10.0F, -2.0F, 44.0F, 0.0F, 40.0F,
        4.0F, 0.0F, 1.0F, 0.0F, -8.8F, -2.2F, -2.2F, -13.2F, -2.2F, -2.2F,
        -13.2F, 1.2F, -2.2F, -8.8F, 1.2F, -2.2F, 52.0F, 29.0F, 56.0F, 32.0F,
        0.0F, 0.0F, -1.0F, -13.2F, -2.2F, 2.2F, -8.8F, -2.2F, 2.2F, -8.8F,
        1.2F, 2.2F, -13.2F, 1.2F, 2.2F, 60.0F, 29.0F, 64.0F, 32.0F, 0.0F,
        0.0F, 1.0F, -8.8F, -2.2F, 2.2F, -8.8F, -2.2F, -2.2F, -8.8F, 1.2F,
        -2.2F, -8.8F, 1.2F, 2.2F, 48.0F, 29.0F, 52.0F, 32.0F, 1.0F, 0.0F,
        0.0F, -13.2F, -2.2F, -2.2F, -13.2F, -2.2F, 2.2F, -13.2F, 1.2F, 2.2F,
        -13.2F, 1.2F, -2.2F, 56.0F, 29.0F, 60.0F, 32.0F, -1.0F, 0.0F, 0.0F,
        -13.2F, -2.2F, -2.2F, -8.8F, -2.2F, -2.2F, -8.8F, -2.2F, 2.2F, -13.2F,
        -2.2F, 2.2F, 56.0F, 29.0F, 52.0F, 25.0F, 0.0F, -1.0F, 0.0F, -13.2F,
        1.2F, 2.2F, -8.8F, 1.2F, 2.2F, -8.8F, 1.2F, -2.2F, -13.2F, 1.2F,
        -2.2F, 60.0F, 25.0F, 56.0F, 29.0F, 0.0F, 1.0F, 0.0F, -8.8F, 3.8F,
        -2.2F, -13.2F, 3.8F, -2.2F, -13.2F, 9.2F, -2.2F, -8.8F, 9.2F, -2.2F,
        52.0F, 13.0F, 56.0F, 18.0F, 0.0F, 0.0F, -1.0F, -13.2F, 3.8F, 2.2F,
        -8.8F, 3.8F, 2.2F, -8.8F, 9.2F, 2.2F, -13.2F, 9.2F, 2.2F, 60.0F,
        13.0F, 64.0F, 18.0F, 0.0F, 0.0F, 1.0F, -8.8F, 3.8F, 2.2F, -8.8F,
        3.8F, -2.2F, -8.8F, 9.2F, -2.2F, -8.8F, 9.2F, 2.2F, 48.0F, 13.0F,
        52.0F, 18.0F, 1.0F, 0.0F, 0.0F, -13.2F, 3.8F, -2.2F, -13.2F, 3.8F,
        2.2F, -13.2F, 9.2F, 2.2F, -13.2F, 9.2F, -2.2F, 56.0F, 13.0F, 60.0F,
        18.0F, -1.0F, 0.0F, 0.0F, -13.2F, 3.8F, -2.2F, -8.8F, 3.8F, -2.2F,
        -8.8F, 3.8F, 2.2F, -13.2F, 3.8F, 2.2F, 56.0F, 13.0F, 52.0F, 9.0F,
        0.0F, -1.0F, 0.0F, -13.2F, 9.2F, 2.2F, -8.8F, 9.2F, 2.2F, -8.8F,
        9.2F, -2.2F, -13.2F, 9.2F, -2.2F, 60.0F, 9.0F, 56.0F, 13.0F, 0.0F,
        1.0F, 0.0F, -12.5F, -1.5F, -0.5F, -13.5F, -1.5F, -0.5F, -13.5F, -0.5F,
        -0.5F, -12.5F, -0.5F, -0.5F, 50.0F, 38.0F, 52.0F, 40.0F, 0.0F, 0.0F,
        -1.0F, -13.5F, -1.5F, 0.5F, -12.5F, -1.5F, 0.5F, -12.5F, -0.5F, 0.5F,
        -13.5F, -0.5F, 0.5F, 54.0F, 38.0F, 56.0F, 40.0F, 0.0F, 0.0F, 1.0F,
        -12.5F, -1.5F, 0.5F, -12.5F, -1.5F, -0.5F, -12.5F, -0.5F, -0.5F, -12.5F,
        -0.5F, 0.5F, 48.0F, 38.0F, 50.0F, 40.0F, 1.0F, 0.0F, 0.0F, -13.5F,
        -1.5F, -0.5F, -13.5F, -1.5F, 0.5F, -13.5F, -0.5F, 0.5F, -13.5F, -0.5F,
        -0.5F, 52.0F, 38.0F, 54.0F, 40.0F, -1.0F, 0.0F, 0.0F, -13.5F, -1.5F,
        -0.5F, -12.5F, -1.5F, -0.5F, -12.5F, -1.5F, 0.5F, -13.5F, -1.5F, 0.5F,
        52.0F, 38.0F, 50.0F, 36.0F, 0.0F, -1.0F, 0.0F, -13.5F, -0.5F, 0.5F,
        -12.5F, -0.5F, 0.5F, -12.5F, -0.5F, -0.5F, -13.5F, -0.5F, -0.5F, 54.0F,
        36.0F, 52.0F, 38.0F, 0.0F, 1.0F, 0.0F, -12.2F, 5.0F, -2.3F, -13.0F,
        5.0F, -2.3F, -13.0F, 5.8F, -2.3F, -12.2F, 5.8F, -2.3F, 52.0F, 50.0F,
        54.0F, 52.0F, 0.0F, 0.0F, -1.0F, -13.0F, 5.0F, -1.5F, -12.2F, 5.0F,
        -1.5F, -12.2F, 5.8F, -1.5F, -13.0F, 5.8F, -1.5F, 56.0F, 50.0F, 58.0F,
        52.0F, 0.0F, 0.0F, 1.0F, -12.2F, 5.0F, -1.5F, -12.2F, 5.0F, -2.3F,
        -12.2F, 5.8F, -2.3F, -12.2F, 5.8F, -1.5F, 50.0F, 50.0F, 52.0F, 52.0F,
        1.0F, 0.0F, 0.0F, -13.0F, 5.0F, -2.3F, -13.0F, 5.0F, -1.5F, -13.0F,
        5.8F, -1.5F, -13.0F, 5.8F, -2.3F, 54.0F, 50.0F, 56.0F, 52.0F, -1.0F,
        0.0F, 0.0F, -13.0F, 5.0F, -2.3F, -12.2F, 5.0F, -2.3F, -12.2F, 5.0F,
        -1.5F, -13.0F, 5.0F, -1.5F, 54.0F, 50.0F, 52.0F, 48.0F, 0.0F, -1.0F,
        0.0F, -13.0F, 5.8F, -1.5F, -12.2F, 5.8F, -1.5F, -12.2F, 5.8F, -2.3F,
        -13.0F, 5.8F, -2.3F, 56.0F, 48.0F, 54.0F, 50.0F, 0.0F, 1.0F, 0.0F,
        -11.4F, 8.3F, -2.3F, -12.0F, 8.3F, -2.3F, -12.0F, 8.9F, -2.3F, -11.4F,
        8.9F, -2.3F, 34.0F, 53.0F, 36.0F, 55.0F, 0.0F, 0.0F, -1.0F, -12.0F,
        8.3F, -1.7F, -11.4F, 8.3F, -1.7F, -11.4F, 8.9F, -1.7F, -12.0F, 8.9F,
        -1.7F, 38.0F, 53.0F, 40.0F, 55.0F, 0.0F, 0.0F, 1.0F, -11.4F, 8.3F,
        -1.7F, -11.4F, 8.3F, -2.3F, -11.4F, 8.9F, -2.3F, -11.4F, 8.9F, -1.7F,
        32.0F, 53.0F, 34.0F, 55.0F, 1.0F, 0.0F, 0.0F, -12.0F, 8.3F, -2.3F,
        -12.0F, 8.3F, -1.7F, -12.0F, 8.9F, -1.7F, -12.0F, 8.9F, -2.3F, 36.0F,
        53.0F, 38.0F, 55.0F, -1.0F, 0.0F, 0.0F, -12.0F, 8.3F, -2.3F, -11.4F,
        8.3F, -2.3F, -11.4F, 8.3F, -1.7F, -12.0F, 8.3F, -1.7F, 36.0F, 53.0F,
        34.0F, 51.0F, 0.0F, -1.0F, 0.0F, -12.0F, 8.9F, -1.7F, -11.4F, 8.9F,
        -1.7F, -11.4F, 8.9F, -2.3F, -12.0F, 8.9F, -2.3F, 38.0F, 51.0F, 36.0F,
        53.0F, 0.0F, 1.0F, 0.0F, -9.7F, 6.0F, -2.3F, -10.5F, 6.0F, -2.3F,
        -10.5F, 6.8F, -2.3F, -9.7F, 6.8F, -2.3F, 42.0F, 54.0F, 44.0F, 56.0F,
        0.0F, 0.0F, -1.0F, -10.5F, 6.0F, -1.5F, -9.7F, 6.0F, -1.5F, -9.7F,
        6.8F, -1.5F, -10.5F, 6.8F, -1.5F, 46.0F, 54.0F, 48.0F, 56.0F, 0.0F,
        0.0F, 1.0F, -9.7F, 6.0F, -1.5F, -9.7F, 6.0F, -2.3F, -9.7F, 6.8F,
        -2.3F, -9.7F, 6.8F, -1.5F, 40.0F, 54.0F, 42.0F, 56.0F, 1.0F, 0.0F,
        0.0F, -10.5F, 6.0F, -2.3F, -10.5F, 6.0F, -1.5F, -10.5F, 6.8F, -1.5F,
        -10.5F, 6.8F, -2.3F, 44.0F, 54.0F, 46.0F, 56.0F, -1.0F, 0.0F, 0.0F,
        -10.5F, 6.0F, -2.3F, -9.7F, 6.0F, -2.3F, -9.7F, 6.0F, -1.5F, -10.5F,
        6.0F, -1.5F, 44.0F, 54.0F, 42.0F, 52.0F, 0.0F, -1.0F, 0.0F, -10.5F,
        6.8F, -1.5F, -9.7F, 6.8F, -1.5F, -9.7F, 6.8F, -2.3F, -10.5F, 6.8F,
        -2.3F, 46.0F, 52.0F, 44.0F, 54.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_LEG = {
        5.9F, 0.0F, -2.0F, 1.9F, 0.0F, -2.0F, 1.9F, 12.0F, -2.0F, 5.9F,
        12.0F, -2.0F, 20.0F, 36.0F, 24.0F, 48.0F, 0.0F, 0.0F, -1.0F, 1.9F,
        0.0F, 2.0F, 5.9F, 0.0F, 2.0F, 5.9F, 12.0F, 2.0F, 1.9F, 12.0F,
        2.0F, 28.0F, 36.0F, 32.0F, 48.0F, 0.0F, 0.0F, 1.0F, 5.9F, 0.0F,
        2.0F, 5.9F, 0.0F, -2.0F, 5.9F, 12.0F, -2.0F, 5.9F, 12.0F, 2.0F,
        16.0F, 36.0F, 20.0F, 48.0F, 1.0F, 0.0F, 0.0F, 1.9F, 0.0F, -2.0F,
        1.9F, 0.0F, 2.0F, 1.9F, 12.0F, 2.0F, 1.9F, 12.0F, -2.0F, 24.0F,
        36.0F, 28.0F, 48.0F, -1.0F, 0.0F, 0.0F, 1.9F, 0.0F, -2.0F, 5.9F,
        0.0F, -2.0F, 5.9F, 0.0F, 2.0F, 1.9F, 0.0F, 2.0F, 24.0F, 36.0F,
        20.0F, 32.0F, 0.0F, -1.0F, 0.0F, 1.9F, 12.0F, 2.0F, 5.9F, 12.0F,
        2.0F, 5.9F, 12.0F, -2.0F, 1.9F, 12.0F, -2.0F, 28.0F, 32.0F, 24.0F,
        36.0F, 0.0F, 1.0F, 0.0F, 6.0001F, 6.2999F, -2.1001F, 1.7999F, 6.2999F, -2.1001F,
        1.7999F, 11.5001F, -2.1001F, 6.0001F, 11.5001F, -2.1001F, 4.0F, 52.0F, 8.0F, 57.0F,
        0.0F, 0.0F, -1.0F, 1.7999F, 6.2999F, 2.1001F, 6.0001F, 6.2999F, 2.1001F, 6.0001F,
        11.5001F, 2.1001F, 1.7999F, 11.5001F, 2.1001F, 12.0F, 52.0F, 16.0F, 57.0F, 0.0F,
        0.0F, 1.0F, 6.0001F, 6.2999F, 2.1001F, 6.0001F, 6.2999F, -2.1001F, 6.0001F, 11.5001F,
        -2.1001F, 6.0001F, 11.5001F, 2.1001F, 0.0F, 52.0F, 4.0F, 57.0F, 1.0F, 0.0F,
        0.0F, 1.7999F, 6.2999F, -2.1001F, 1.7999F, 6.2999F, 2.1001F, 1.7999F, 11.5001F, 2.1001F,
        1.7999F, 11.5001F, -2.1001F, 8.0F, 52.0F, 12.0F, 57.0F, -1.0F, 0.0F, 0.0F,
        1.7999F, 6.2999F, -2.1001F, 6.0001F, 6.2999F, -2.1001F, 6.0001F, 6.2999F, 2.1001F, 1.7999F,
        6.2999F, 2.1001F, 8.0F, 52.0F, 4.0F, 48.0F, 0.0F, -1.0F, 0.0F, 1.7999F,
        11.5001F, 2.1001F, 6.0001F, 11.5001F, 2.1001F, 6.0001F, 11.5001F, -2.1001F, 1.7999F, 11.5001F,
        -2.1001F, 12.0F, 48.0F, 8.0F, 52.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_LEG = {
        -1.9F, 0.0F, -2.0F, -5.9F, 0.0F, -2.0F, -5.9F, 12.0F, -2.0F, -1.9F,
        12.0F, -2.0F, 36.0F, 36.0F, 40.0F, 48.0F, 0.0F, 0.0F, -1.0F, -5.9F,
        0.0F, 2.0F, -1.9F, 0.0F, 2.0F, -1.9F, 12.0F, 2.0F, -5.9F, 12.0F,
        2.0F, 44.0F, 36.0F, 48.0F, 48.0F, 0.0F, 0.0F, 1.0F, -1.9F, 0.0F,
        2.0F, -1.9F, 0.0F, -2.0F, -1.9F, 12.0F, -2.0F, -1.9F, 12.0F, 2.0F,
        32.0F, 36.0F, 36.0F, 48.0F, 1.0F, 0.0F, 0.0F, -5.9F, 0.0F, -2.0F,
        -5.9F, 0.0F, 2.0F, -5.9F, 12.0F, 2.0F, -5.9F, 12.0F, -2.0F, 40.0F,
        36.0F, 44.0F, 48.0F, -1.0F, 0.0F, 0.0F, -5.9F, 0.0F, -2.0F, -1.9F,
        0.0F, -2.0F, -1.9F, 0.0F, 2.0F, -5.9F, 0.0F, 2.0F, 40.0F, 36.0F,
        36.0F, 32.0F, 0.0F, -1.0F, 0.0F, -5.9F, 12.0F, 2.0F, -1.9F, 12.0F,
        2.0F, -1.9F, 12.0F, -2.0F, -5.9F, 12.0F, -2.0F, 44.0F, 32.0F, 40.0F,
        36.0F, 0.0F, 1.0F, 0.0F, -1.8F, 6.3F, -2.1F, -6.0F, 6.3F, -2.1F,
        -6.0F, 11.5F, -2.1F, -1.8F, 11.5F, -2.1F, 52.0F, 4.0F, 56.0F, 9.0F,
        0.0F, 0.0F, -1.0F, -6.0F, 6.3F, 2.1F, -1.8F, 6.3F, 2.1F, -1.8F,
        11.5F, 2.1F, -6.0F, 11.5F, 2.1F, 60.0F, 4.0F, 64.0F, 9.0F, 0.0F,
        0.0F, 1.0F, -1.8F, 6.3F, 2.1F, -1.8F, 6.3F, -2.1F, -1.8F, 11.5F,
        -2.1F, -1.8F, 11.5F, 2.1F, 48.0F, 4.0F, 52.0F, 9.0F, 1.0F, 0.0F,
        0.0F, -6.0F, 6.3F, -2.1F, -6.0F, 6.3F, 2.1F, -6.0F, 11.5F, 2.1F,
        -6.0F, 11.5F, -2.1F, 56.0F, 4.0F, 60.0F, 9.0F, -1.0F, 0.0F, 0.0F,
        -6.0F, 6.3F, -2.1F, -1.8F, 6.3F, -2.1F, -1.8F, 6.3F, 2.1F, -6.0F,
        6.3F, 2.1F, 56.0F, 4.0F, 52.0F, 0.0F, 0.0F, -1.0F, 0.0F, -6.0F,
        11.5F, 2.1F, -1.8F, 11.5F, 2.1F, -1.8F, 11.5F, -2.1F, -6.0F, 11.5F,
        -2.1F, 60.0F, 0.0F, 56.0F, 4.0F, 0.0F, 1.0F, 0.0F
    };

    /**
     * 把一份逐面几何沿 x 平移 {@code dx}（单位：模型像素）。
     *
     * <p>每面 19 个 float：0/3/6/9 是四个顶点的 x，12..15 是 UV，16..18 是法线，
     * 所以只动这四个下标。</p>
     */
    private static float[] shiftX(float[] faces, float dx) {
        float[] shifted = faces.clone();
        for (int face = 0; face < shifted.length; face += 19) {
            shifted[face] += dx;
            shifted[face + 3] += dx;
            shifted[face + 6] += dx;
            shifted[face + 9] += dx;
        }
        return shifted;
    }

    /**
     * 肢体几何归位：生成器把 bbmodel 的左右肢体接到了名字相反的部分上——
     * {@code RIGHT_ARM} 里其实是 bbmodel 左臂（世界 x +4..8），{@code LEFT_ARM}
     * 里是右臂（-8..-4），腿同理。世界坐标本身没错，但 {@code rightArm/leftArm}
     * 这些部件既驱动挥臂姿势、又是 {@code ItemInHandLayer} 的持物锚点，还决定
     * 护甲层贴在哪条腿上：部件与几何错位就表现为"右手的武器跟着左手甩、靴子
     * 与腿脱节"。
     *
     * <p>这里把几何搬回同名部件，并按枢轴差平移 x（臂 ±10px、腿 ±3.8px），
     * 世界坐标保持原样，外观静置时不变。</p>
     */
    private static final float[] RIGHT_ARM_MESH = shiftX(LEFT_ARM, 10.0F);
    private static final float[] LEFT_ARM_MESH = shiftX(RIGHT_ARM, -10.0F);
    private static final float[] RIGHT_LEG_MESH = shiftX(LEFT_LEG, 3.8F);
    private static final float[] LEFT_LEG_MESH = shiftX(RIGHT_LEG, -3.8F);

    public SoulsandFigurineModel(ModelPart root) {
        this(root, false);
    }

    public SoulsandFigurineModel(ModelPart root, boolean armorLayer) {
        super(root);
        this.root = root;
        this.armorLayer = armorLayer;
    }

    @Override
    public void prepareMobModel(SoulsandFigurine entity, float limbSwing, float limbSwingAmount,
                                float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        this.rightArmPose = ArmPose.EMPTY;
        this.leftArmPose = ArmPose.EMPTY;
        HumanoidArm mainArm = entity.getMainArm();
        ArmPose mainPose = mainHandPose(entity);
        if (mainPose != ArmPose.EMPTY) {
            if (mainArm == HumanoidArm.RIGHT) {
                this.rightArmPose = mainPose;
            } else {
                this.leftArmPose = mainPose;
            }
        }
        if (entity.isBlockingShield()) {
            if (mainArm == HumanoidArm.RIGHT) {
                this.leftArmPose = ArmPose.BLOCK;
            } else {
                this.rightArmPose = ArmPose.BLOCK;
            }
        }
    }

    private static ArmPose mainHandPose(SoulsandFigurine entity) {
        ItemStack main = entity.getMainHandItem();
        if (entity.isUsingItem()) {
            UseAnim anim = main.getUseAnimation();
            if (anim == UseAnim.BOW) {
                return ArmPose.BOW_AND_ARROW;
            }
            if (anim == UseAnim.CROSSBOW) {
                return CrossbowItem.isCharged(main) ? ArmPose.CROSSBOW_HOLD : ArmPose.CROSSBOW_CHARGE;
            }
        }
        if (entity.isChargingCrossbow() && main.is(Items.CROSSBOW)) {
            return ArmPose.CROSSBOW_CHARGE;
        }
        if (main.is(Items.CROSSBOW) && CrossbowItem.isCharged(main)) {
            return ArmPose.CROSSBOW_HOLD;
        }
        if (main.is(Items.TRIDENT) && entity.isAggressive()) {
            return ArmPose.THROW_SPEAR;
        }
        if (entity.isHoldingBowForShooting()) {
            return ArmPose.BOW_AND_ARROW;
        }
        return ArmPose.EMPTY;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        if (this.armorLayer) {
            super.renderToBuffer(poseStack, buffer, packedLight, packedOverlay, color);
            return;
        }
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.head, HEAD,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.body, BODY,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.rightArm, RIGHT_ARM_MESH,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.leftArm, LEFT_ARM_MESH,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.rightLeg, RIGHT_LEG_MESH,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.leftLeg, LEFT_LEG_MESH,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }

    public static LayerDefinition createInnerArmorLayer() {
        return createArmorLayer(new CubeDeformation(0.5F));
    }

    public static LayerDefinition createOuterArmorLayer() {
        return createArmorLayer(new CubeDeformation(1.0F));
    }

    private static LayerDefinition createArmorLayer(CubeDeformation deform) {
        MeshDefinition mesh = HumanoidModel.createMesh(deform, 0.0F);
        return LayerDefinition.create(mesh, 64, 32);
    }
}
