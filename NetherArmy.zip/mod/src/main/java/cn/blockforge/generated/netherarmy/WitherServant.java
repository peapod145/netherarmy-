package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.CrossbowAttackMob;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TieredItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 凋灵仆役：凋灵骷髅阵营的幼年体拾荒兵（{@link WitherSkeleton} 变种）。
 *
 * <p>血量 15、护甲 0、移速与小僵尸一致（0.23 × 1.5 = 0.345）、近战伤害同小僵尸（3 点）、
 * 索敌范围同凋灵骷髅（16 格）。凋灵骷髅的"一切特性"由继承直接获得：近战附凋零、
 * 免疫凋零（阵营名册 {@code minecraft:wither_skeletons} 统一判定，含亡灵三标签）、
 * 免疫火焰、主动攻击猪灵系、骷髅同款弓 AI（{@code AbstractSkeleton} 的
 * {@code RangedBowAttackGoal}，带游走回撤）。模型按用户上传的 wither_servant.bbmodel
 * 逐面复刻，渲染器不做凋灵骷髅式 1.2 倍放大。</p>
 *
 * <p>拾荒：100% 可捡装备；{@link BetterGearPickupGoal} 会主动走向附近"更好"的
 * 盔甲/盾牌/武器掉落物（评分 = 材质 + 耐久 + 附魔等级之和，炼狱晶护甲为最高材质）。
 * 武器使用 AI：近战常规；三叉戟溺尸同款远程投掷，敌人贴近 2 格内改近战挥砍；
 * 弓/弩骷髅同款游走回撤；
 * 重锤跳跃攻击；盾牌姿态逐行移植强袭骑士躯体（{@link BlitzDullhanBody}）的举盾
 * 反应/格挡/耐久链路，格挡走原版结算。收盾走 {@link #stopShieldUse()}：
 * 只结束副手的 use，不掐断主手弓/弩蓄力；举盾姿态经 {@code DATA_SHIELD_BLOCKING}
 * 同步给客户端（原版的 usedItemHand/useItem 字段不下发，怪物侧姿势必须自报）。</p>
 *
 * <p>性格（生成时六选一，仅行为差异，熊猫式）：安静无特性；乖巧追随阵营生物
 * （{@link FollowFactionGoal}）；调皮爬上阵营生物的头（{@link MountHeadGoal}）；
 * 专注远程射程更远；莽撞举盾频率更低；胆怯受击后撤（{@link FleeOnHurtGoal}，
 * 套用下界传令兵的后撤算法）。</p>
 */
public class WitherServant extends WitherSkeleton implements CrossbowAttackMob {

    /** 六种性格，生成时均匀随机（同熊猫的加权表退化为均匀）。 */
    public enum Personality {
        QUIET, OBEDIENT, MISCHIEVOUS, FOCUSED, RECKLESS, TIMID;

        public static Personality byId(int id) {
            Personality[] values = values();
            return id >= 0 && id < values.length ? values[id] : QUIET;
        }
    }

    private static final EntityDataAccessor<Integer> DATA_PERSONALITY =
            SynchedEntityData.defineId(WitherServant.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_CHARGING_CROSSBOW =
            SynchedEntityData.defineId(WitherServant.class, EntityDataSerializers.BOOLEAN);
    /**
     * 盾牌是否处于"举起姿态"。原版 usedItemHand/useItem 两个字段只写在服务端
     * （同步到客户端的只有 isUsingItem 一个标志位），客户端模型读不到"用的是哪只手、
     * 用的什么物品"，举盾姿势必须由这个位自己广播。
     */
    private static final EntityDataAccessor<Boolean> DATA_SHIELD_BLOCKING =
            SynchedEntityData.defineId(WitherServant.class, EntityDataSerializers.BOOLEAN);

    /**
     * 三叉戟投掷间隔与投掷半径：逐参数取自溺尸
     * {@code Drowned#addBehaviourGoals} 的 {@code DrownedTridentAttackGoal(this, 1.0, 40, 10.0F)}，
     * 即 40 刻（2 秒）一发、10 格内出手（专注性格 24 格）。
     */
    private static final int TRIDENT_ATTACK_INTERVAL = 40;
    private static final float TRIDENT_THROW_RADIUS = 10.0F;
    private static final float TRIDENT_THROW_RADIUS_FOCUSED = 24.0F;
    /**
     * 三叉戟近战切换：敌人贴近到 2 格内时改用挥砍。1.21.1 的
     * {@code RangedAttackGoal.canUse()} 只看目标是否存活、没有最小距离闸门（溺尸贴脸
     * 照样投掷），所以只能在本类挂一个优先级更高的近战目标（见 {@link TridentMeleeGoal}）
     * 顶掉投掷目标；退出用 2.5 格做滞回，避免在 2 格边界反复抖动。
     */
    private static final double TRIDENT_MELEE_ENTER_SQR = 2.0D * 2.0D;
    private static final double TRIDENT_MELEE_EXIT_SQR = 2.5D * 2.5D;
    /** 近战出手间隔，与原版 {@code MeleeAttackGoal} 的 20 刻一致（1 秒一击）。 */
    private static final int TRIDENT_MELEE_INTERVAL = 20;
    /**
     * 起跳竖直初速 0.8，实测顶点约 3.2 格、滞空 18 刻：原版判"砸击"要求
     * {@code fallDistance > 1.5}，而目标先于移动结算，普通跳跃（约 1.5 格）只有
     * 落地那一帧勉强够线、根本来不及出手，必须跳得够高才有一段可用的下落窗口。
     */
    private static final double MACE_LEAP_UP = 0.8D;
    /** 18 刻滞空、水平每刻衰减到 0.91，累计位移约为初速的 9.0 倍（用于反推初速）。 */
    private static final double MACE_LEAP_TRAVEL_FACTOR = 9.0D;
    /** 下落时判定"砸在目标身上"的水平距离（平方）。 */
    private static final double MACE_SMASH_HORIZONTAL_SQR = 1.5D * 1.5D;
    /** 两次跳跃攻击之间的间隔，避免落地即起跳把近战完全顶掉。 */
    private static final int MACE_LEAP_COOLDOWN = 40;
    /** 拾荒扫描半径与"更好"判定后的寻路速度。 */
    private static final double LOOT_SCAN_RADIUS = 16.0D;
    /** 远程射程（RangedCrossbowAttackGoal 第三个参数是半径，内部再平方）。 */
    private static final float RANGED_RADIUS = 16.0F;
    private static final float RANGED_RADIUS_FOCUSED = 24.0F;
    /** PersistentData：凋零腐蚀催生时钉给这只仆役的专属猎物（UUID），跨重载保留。 */
    private static final String CORRUPTION_ENEMY_KEY = "netherarmy_servant_corruption_enemy";

    // ---------------------------------------------------------------- 盾牌姿态常量（移植自强袭骑士躯体）
    private static final int SHIELD_REACT_TICKS = 14;
    private static final int SHIELD_COMBAT_GUARD_TICKS = 6;
    private static final double SHIELD_COMBAT_GUARD_RANGE_SQR = 49.0D;
    private static final int SHIELD_ON_HURT_GUARD_TICKS = 24;
    private static final float SHIELD_WEAR_DAMAGE_FLOOR = 3.0F;
    private static final int ATTACK_SWING_LOCK_TICKS = 10;
    private static final double PROJECTILE_LOOKAHEAD = 8.0D;
    private static final double PROJECTILE_CORRIDOR = 0.8D;

    // ---------------------------------------------------------------- 胆怯后撤常量（移植自下界传令兵）
    private static final double FLEE_DISTANCE = 5.0D;
    private static final int FLEE_TIMEOUT_TICKS = 160;

    private int shieldHoldTicks;
    private int shieldSwingLockTicks;
    private int attackIntervalEndTick;
    private boolean fleeing;
    private Vec3 fleeTargetPos;
    private long fleeDeadline;
    private int fleeRepathCooldown;
    /** 三叉戟远程目标：与溺尸同一条 {@code RangedAttackGoal} 链路，性格变射程时要重建。 */
    private TridentAttackGoal tridentGoal;
    private float tridentRadius = TRIDENT_THROW_RADIUS;
    private RangedCrossbowAttackGoal crossbowGoal;

    public WitherServant(EntityType<? extends WitherServant> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 15.0D)
                .add(Attributes.ARMOR, 0.0D)
                // 小僵尸：0.23 基础 × (1 + 0.5 幼年修饰) = 0.345。
                .add(Attributes.MOVEMENT_SPEED, 0.345D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                // 凋灵骷髅未覆写索敌，取 Mob 基类 16。
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    // ================================================================ 性格

    public Personality getPersonality() {
        return Personality.byId(this.entityData.get(DATA_PERSONALITY));
    }

    public boolean isChargingCrossbow() {
        return this.entityData.get(DATA_CHARGING_CROSSBOW);
    }

    /** 举盾姿态（服务端判定、同步位广播，供客户端模型出 BLOCK 姿势）。 */
    public boolean isBlockingShield() {
        return this.entityData.get(DATA_SHIELD_BLOCKING);
    }

    /**
     * 骷髅式"该常举弓"判定：与 SkeletonModel#prepareMobModel 同款只看
     * 主手弓 + 进攻标志（isAggressive 走实体数据位，客户端可读），
     * 不看使用槽——拉弓瞬间与否姿势相同。
     */
    public boolean isHoldingBowForShooting() {
        return this.isAggressive() && this.getMainHandItem().is(Items.BOW);
    }

    public void setPersonality(Personality personality) {
        this.entityData.set(DATA_PERSONALITY, personality.ordinal());
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_PERSONALITY, Personality.QUIET.ordinal());
        builder.define(DATA_CHARGING_CROSSBOW, false);
        builder.define(DATA_SHIELD_BLOCKING, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ServantPersonality", this.getPersonality().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("ServantPersonality")) {
            this.entityData.set(DATA_PERSONALITY, tag.getInt("ServantPersonality"));
        }
        this.applyRangedFocus();
    }

    @Override
    protected void populateDefaultEquipmentSlots(net.minecraft.util.RandomSource random,
                                                DifficultyInstance difficulty) {
        // 不自带石剑：仆役是拾荒兵，空手生成，靠捡装备武装自己。
    }

    @Override
    protected boolean canReplaceCurrentItem(ItemStack candidate, ItemStack current) {
        EquipmentSlot slot = lootSlot(candidate);
        if (slot == null) {
            return super.canReplaceCurrentItem(candidate, current);
        }
        // 接触到掉落物时：近战武器即使自己正持远程也会替换（需求明确写了接触替换）。
        if (slot == EquipmentSlot.MAINHAND) {
            return gearScore(candidate) > gearScore(current);
        }
        return gearScore(candidate) > gearScore(this.getItemBySlot(slot));
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        if (!this.level().isClientSide) {
            // 父类 WitherSkeleton#finalizeSpawn 把攻击力钉成 4；这里改回小僵尸的 3。
            var attack = this.getAttribute(Attributes.ATTACK_DAMAGE);
            if (attack != null) {
                attack.setBaseValue(3.0D);
            }
            // 与熊猫同款：生成瞬间均匀掷一次性格；读档实体不走 finalizeSpawn，
            // 已存盘的性格由 NBT（ServantPersonality）原样恢复。
            Personality[] values = Personality.values();
            this.setPersonality(values[this.random.nextInt(values.length)]);
            // 100% 拾荒。
            this.setCanPickUpLoot(true);
            this.applyRangedFocus();
        }
        return result;
    }

    // ================================================================ 目标装配

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 父类 reassessWeaponGoal 只认弓；这里补齐弩（游走回撤同款）、三叉戟、重锤。
        this.tridentGoal = new TridentAttackGoal(this, this.tridentRadius);
        this.goalSelector.addGoal(3, this.tridentGoal);
        // 优先级 2 压过上面的投掷目标：目标贴近 2 格内时改近战挥砍。
        this.goalSelector.addGoal(2, new TridentMeleeGoal(this));
        this.crossbowGoal = new RangedCrossbowAttackGoal(this, 1.0D, RANGED_RADIUS);
        this.goalSelector.addGoal(4, this.crossbowGoal);
        // 重锤跳跃攻击必须压过近战目标（优先级 4）：近战占着 MOVE 标志时低优先级
        // 的起跳目标永远轮不上，这正是之前"跳跃攻击没实装"的根因。
        this.goalSelector.addGoal(2, new MaceLeapGoal(this));
        this.goalSelector.addGoal(6, new BetterGearPickupGoal(this));
        this.goalSelector.addGoal(7, new FollowFactionGoal(this));
        this.goalSelector.addGoal(7, new MountHeadGoal(this));
        this.goalSelector.addGoal(1, new FleeOnHurtGoal(this));
    }

    @Override
    public void reassessWeaponGoal() {
        // 父类按"是否持弓"在弓目标与近战目标间二选一。持弩时父类会挂近战兜底，
        // 装填期间会冲上去，所以把近战卸掉，让 crossbowGoal 独占。
        super.reassessWeaponGoal();
        if (this.isHolding(stack -> stack.getItem() instanceof CrossbowItem)) {
            this.goalSelector.getAvailableGoals().stream()
                    .map(wrapped -> wrapped.getGoal())
                    .filter(goal -> goal instanceof net.minecraft.world.entity.ai.goal.MeleeAttackGoal)
                    .findFirst()
                    .ifPresent(this.goalSelector::removeGoal);
        }
        this.applyRangedFocus();
    }

    // ================================================================ 凋零腐蚀催生的专属猎物

    /**
     * 把某个生物钉成这只仆役的唯一猎物，由
     * {@link WitherServantCorruptionHandler} 在凋零腐蚀催生时调用。
     *
     * <p>只把 UUID 写进 PersistentData，由 {@link #syncCorruptionEnemy()} 每 tick
     * 把仇恨钉回目标位。理由是父类的目标表在注册期就装好了玩家/铁傀儡/猪灵三条
     * {@code NearestAttackableTargetGoal}，只在这里 {@code setTarget} 一次，最多
     * 10 tick 后就会被它们的随机索敌抢走；而运行时往目标表里插一个优先级 0 的
     * {@code TargetGoal} 又得自己复刻一套目标条件判定。走每 tick 同步既不用碰
     * 目标表，也让 UUID 落了盘——重载之后这只仆役照样认得这个猎物。</p>
     */
    public void becomeHostileTo(LivingEntity enemy) {
        if (enemy == null || enemy == this || !MesmerizerControl.canAttack(this, enemy)) {
            return;
        }
        this.getPersistentData().putUUID(CORRUPTION_ENEMY_KEY, enemy.getUUID());
        this.setTarget(enemy);
    }

    /**
     * 把 PersistentData 里的腐蚀猎物钉回目标位。猎物死亡、被移除、换了维度
     * （{@code getEntity} 查不到）或变得不可攻击时清掉印记，之后按普通索敌走；
     * 猎物跑出索敌范围时只是暂时不追，印记留着——它回来还会重新盯上。
     */
    private void syncCorruptionEnemy() {
        CompoundTag data = this.getPersistentData();
        if (!data.hasUUID(CORRUPTION_ENEMY_KEY)) {
            return;
        }
        if (!(this.level() instanceof ServerLevel level)) {
            data.remove(CORRUPTION_ENEMY_KEY);
            return;
        }
        Entity enemy = level.getEntity(data.getUUID(CORRUPTION_ENEMY_KEY));
        if (!(enemy instanceof LivingEntity living) || !living.isAlive()
                || !MesmerizerControl.canAttack(this, living)) {
            data.remove(CORRUPTION_ENEMY_KEY);
            return;
        }
        if (this.getTarget() == living) {
            return;
        }
        double range = this.getAttributeValue(Attributes.FOLLOW_RANGE);
        if (this.distanceToSqr(living) <= range * range) {
            this.setTarget(living);
        }
    }

    // ================================================================ 近战与三叉戟

    /** 溺尸同款投掷参数：初速 1.6、散布随难度、+0.2 提前量修正。 */
    @Override
    public boolean canFireProjectileWeapon(net.minecraft.world.item.ProjectileWeaponItem weapon) {
        return weapon instanceof BowItem || weapon instanceof CrossbowItem
                || super.canFireProjectileWeapon(weapon);
    }

    @Override
    public void performRangedAttack(LivingEntity target, float pullProgress) {
        // 目标在蓄力期间被打死时原版弓目标仍可能补一发：这里直接掐掉。
        if (target == null || !target.isAlive()) {
            return;
        }
        // 弩目标装填完毕后会调这里。父类 AbstractSkeleton 只认弓：找不到弓就拿
        // 空副手当武器，AbstractArrow 构造抛 Invalid weapon firing an arrow。
        if (this.isHolding(stack -> stack.getItem() instanceof CrossbowItem)) {
            this.performCrossbowAttack(this, 1.6F);
            return;
        }
        InteractionHand hand = this.tridentHand();
        if (hand != null) {
            ItemStack held = this.getItemInHand(hand);
            ThrownTrident thrown = new ThrownTrident(this.level(), this, held.copy());
            double dx = target.getX() - this.getX();
            double dy = target.getY(0.3333333333333333D) - thrown.getY();
            double dz = target.getZ() - this.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            thrown.shoot(dx, dy + horizontal * 0.2D, dz, 1.6F,
                    (float) (14 - this.level().getDifficulty().getId() * 4));
            this.playSound(SoundEvents.DROWNED_SHOOT, 1.0F,
                    1.0F / (this.random.nextFloat() * 0.4F + 0.8F));
            this.level().addFreshEntity(thrown);
            return;
        }
        if (this.isHolding(stack -> stack.getItem() instanceof BowItem)) {
            super.performRangedAttack(target, pullProgress);
        }
    }

    @Override
    public void setChargingCrossbow(boolean charging) {
        this.entityData.set(DATA_CHARGING_CROSSBOW, charging);
    }

    @Override
    public void onCrossbowAttackPerformed() {
        // 与掠夺者一致：射击后记一次挥臂。
        this.attackAnim = 0.0F;
    }

    @Override
    public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
        // 专注性格：换武器后重算远程射程（弓目标与弩目标的攻击半径）。
        super.setItemSlot(slot, stack);
        if (!this.level().isClientSide && (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND)) {
            this.applyRangedFocus();
        }
    }

    /** 专注性格远程射程 24 格，其余 16 格（凋灵骷髅索敌同款）。 */
    private void applyRangedFocus() {
        float radius = this.getPersonality() == Personality.FOCUSED
                ? RANGED_RADIUS_FOCUSED : RANGED_RADIUS;
        boolean radiusChanged = Float.compare(this.rangedRadius, radius) != 0;
        this.rangedRadius = radius;
        // 弩目标由本类持有：半径没变就不用拆装。
        if (this.crossbowGoal != null && radiusChanged) {
            this.goalSelector.removeGoal(this.crossbowGoal);
            this.crossbowGoal = new RangedCrossbowAttackGoal(this, 1.0D, radius);
            this.goalSelector.addGoal(4, this.crossbowGoal);
        }
        // 弓目标是父类私有字段：reassessWeaponGoal 每次都会把 15 格原版实例加回来，
        // 所以只要当前在用弓，就必须按专注性格重装一份。
        this.applyBowRadius(radius);
        // 三叉戟半径是 RangedAttackGoal 的 final 字段，只能照弩那样换实例。
        // 其余性格保持溺尸原值 10 格，专注才拉到 24 格。
        float tridentR = this.getPersonality() == Personality.FOCUSED
                ? TRIDENT_THROW_RADIUS_FOCUSED : TRIDENT_THROW_RADIUS;
        if (this.tridentGoal != null && Float.compare(this.tridentRadius, tridentR) != 0) {
            this.goalSelector.removeGoal(this.tridentGoal);
            this.tridentGoal = new TridentAttackGoal(this, tridentR);
            this.goalSelector.addGoal(3, this.tridentGoal);
            this.tridentRadius = tridentR;
        }
    }

    private float rangedRadius = RANGED_RADIUS;

    /** 把 AbstractSkeleton 的弓目标换成相同射程的新实例（父类 bowGoal 字段是私有的）。 */
    private void applyBowRadius(float radius) {
        this.goalSelector.getAvailableGoals().stream()
                .map(wrapped -> wrapped.getGoal())
                .filter(goal -> goal instanceof net.minecraft.world.entity.ai.goal.RangedBowAttackGoal)
                .findFirst()
                .ifPresent(old -> {
                    this.goalSelector.removeGoal(old);
                    int interval = this.level().getDifficulty() == net.minecraft.world.Difficulty.HARD
                            ? this.getHardAttackInterval() : this.getAttackInterval();
                    // 用带存活判定的子类，替掉原版那只不看 isAlive 的弓目标。
                    WitherServantBowAttackGoal bow = new WitherServantBowAttackGoal(this, 1.0D, interval, radius);
                    this.goalSelector.addGoal(4, bow);
                });
    }

    private boolean isHoldingTrident() {
        return this.tridentHand() != null;
    }

    /** 目标是否已进入三叉戟近战距离：投掷目标据此让位给 {@link TridentMeleeGoal}。 */
    private boolean isTridentMeleeTarget() {
        LivingEntity target = this.getTarget();
        return target != null && this.distanceToSqr(target) <= TRIDENT_MELEE_ENTER_SQR;
    }

    private InteractionHand tridentHand() {
        if (this.getMainHandItem().is(Items.TRIDENT)) {
            return InteractionHand.MAIN_HAND;
        }
        if (this.getOffhandItem().is(Items.TRIDENT)) {
            return InteractionHand.OFF_HAND;
        }
        return null;
    }

    /** 三叉戟远程目标：完全走原版 RangedAttackGoal（溺尸同款调度与间隔）。 */
    private static final class TridentAttackGoal extends RangedAttackGoal {
        private final WitherServant servant;

        TridentAttackGoal(WitherServant servant, float radius) {
            super(servant, 1.0D, TRIDENT_ATTACK_INTERVAL, radius);
            this.servant = servant;
        }

        @Override
        public boolean canUse() {
            return super.canUse() && this.servant.isHoldingTrident()
                    && !this.servant.isTridentMeleeTarget();
        }

        @Override
        public boolean canContinueToUse() {
            return super.canContinueToUse() && this.servant.isHoldingTrident()
                    && !this.servant.isTridentMeleeTarget();
        }

        @Override
        public void start() {
            super.start();
            // 与 DrownedTridentAttackGoal#start 同款：进投掷姿态。三叉戟
            // getUseDuration=72000 且 releaseUsing 只对 Player 生效，所以这里
            // 只是撑住姿势与"正在使用"标志，不会额外抛第二发。
            this.servant.setAggressive(true);
            this.servant.startUsingItem(InteractionHand.MAIN_HAND);
        }

        @Override
        public void stop() {
            super.stop();
            if (this.servant.isUsingItem()) {
                this.servant.stopUsingItem();
            }
            this.servant.setAggressive(false);
        }
    }

    /**
     * 三叉戟近战：目标进入 2 格内时接管（优先级 2，压过优先级 3 的 {@link TridentAttackGoal}）。
     *
     * <p>原版 1.21.1 的 {@code RangedAttackGoal} 没有最小投掷距离，溺尸贴脸也会投；
     * 这里用 MOVE/LOOK 占用把投掷目标挤下去，改走"追到攻击距离内挥砍"的循环。
     * 进入 2 格触发、2.5 格退出（滞回），出手间隔 20 刻与原版 {@code MeleeAttackGoal} 一致。
     * 因为 {@code GoalSelector} 允许更高优先级目标抢占低优先级的锁定标志位，这个
     * 目标一旦 canUse 就会立刻让投掷目标 stop（清掉投掷姿态与蓄力进度）。</p>
     */
    private static final class TridentMeleeGoal extends Goal {
        private final WitherServant servant;
        private int attackCooldown;

        TridentMeleeGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = this.servant.getTarget();
            return target != null && target.isAlive()
                    && this.servant.isHoldingTrident()
                    && this.servant.distanceToSqr(target) <= TRIDENT_MELEE_ENTER_SQR;
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity target = this.servant.getTarget();
            return target != null && target.isAlive()
                    && this.servant.isHoldingTrident()
                    && this.servant.distanceToSqr(target) <= TRIDENT_MELEE_EXIT_SQR;
        }

        @Override
        public void start() {
            this.attackCooldown = 0;
            // 与投掷目标同款进攻姿态，客户端模型据此抬手。
            this.servant.setAggressive(true);
        }

        @Override
        public void stop() {
            this.servant.setAggressive(false);
            this.servant.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.servant.getTarget();
            if (target == null) {
                return;
            }
            this.servant.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (this.attackCooldown > 0) {
                this.attackCooldown--;
            }
            if (this.servant.isWithinMeleeAttackRange(target)) {
                this.servant.getNavigation().stop();
                if (this.attackCooldown <= 0
                        && this.servant.getSensing().hasLineOfSight(target)) {
                    // 挥哪只手由三叉戟在哪只手上决定；doHurtTarget 原样走原版结算。
                    InteractionHand hand = this.servant.tridentHand();
                    this.servant.swing(hand != null ? hand : InteractionHand.MAIN_HAND);
                    this.servant.doHurtTarget(target);
                    this.attackCooldown = TRIDENT_MELEE_INTERVAL;
                }
            } else {
                this.servant.getNavigation().moveTo(target, 1.2D);
            }
        }
    }

    /**
     * 重锤跳跃攻击：持重锤、目标已进入重锤攻击范围且贴地时朝目标起跳，下落途中砸中目标。
     *
     * <p>起跳条件用 {@code Mob#isWithinMeleeAttackRange} 而不是固定距离窗口：这一跳的
     * 作用是把普通挥砍抬成"带坠落距离的砸击"，不是位移技，所以目标够不着时不起跳，
     * 交给近战目标先把距离拉近。判定走原版那套包围盒膨胀
     * （{@code DEFAULT_ATTACK_REACH = √2.04 − 0.6 ≈ 0.83}），重锤自身不带
     * {@code ENTITY_INTERACTION_RANGE} 修饰符，所以就是怪物基础够手范围；在贴身那一帧
     * 判定、又按 9 倍衰减反推水平初速，能保证起跳后的下落窗口里目标仍在砸击判定内。</p>
     *
     * <p>原版的重锤砸击只服务玩家：伤害加成 {@code Item#getAttackDamageBonus} 仅在
     * {@code Player#attack} 里被调用，范围击退与砸击音效的 {@code MaceItem#hurtEnemy}
     * 又先判 {@code instanceof ServerPlayer}——怪物就算真的跳起来砸下去也拿不到任何效果。
     * 所以这里自己起跳（原版 {@code LeapAtTargetGoal} 的水平初速与距离窗口带不到足够
     * 的下落距离，也不用它），下落途中调用 {@link WitherServant#doHurtTarget}，
     * 由后者补上砸击伤害与击退。</p>
     */
    private static final class MaceLeapGoal extends Goal {
        private final WitherServant servant;
        private int cooldown;
        private boolean smashed;

        MaceLeapGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.cooldown > 0) {
                this.cooldown--;
                return false;
            }
            LivingEntity target = this.servant.getTarget();
            if (target == null || !target.isAlive() || this.servant.isPassenger()) {
                return false;
            }
            if (!(this.servant.getMainHandItem().getItem() instanceof MaceItem)) {
                return false;
            }
            if (!this.servant.onGround()) {
                return false;
            }
            // 只在目标已进入重锤攻击范围时起跳：起跳是"把挥砍升级成砸击"，
            // 不是位移技。够不着时交给近战目标先把距离拉近。
            return this.servant.isWithinMeleeAttackRange(target)
                    && this.servant.getSensing().hasLineOfSight(target);
        }

        @Override
        public void start() {
            LivingEntity target = this.servant.getTarget();
            if (target == null) {
                return;
            }
            this.smashed = false;
            double dx = target.getX() - this.servant.getX();
            double dz = target.getZ() - this.servant.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            // 起跳时的水平间距已经 ≤ 攻击范围（约 1.4 格），按 9 倍衰减反推的初速
            // 会在下落窗口里正好压住目标；这里不再给下限，否则一个最小推力就会把
            // 贴身砸击变成从目标头顶越过去的飞扑。
            double speed = Mth.clamp(horizontal / MACE_LEAP_TRAVEL_FACTOR, 0.0D, 0.7D);
            Vec3 motion = this.servant.getDeltaMovement();
            double mx = horizontal > 1.0E-4D ? dx / horizontal * speed : 0.0D;
            double mz = horizontal > 1.0E-4D ? dz / horizontal * speed : 0.0D;
            this.servant.setDeltaMovement(mx + motion.x * 0.2D, MACE_LEAP_UP, mz + motion.z * 0.2D);
            this.servant.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity target = this.servant.getTarget();
            return target != null && target.isAlive() && !this.servant.onGround();
        }

        @Override
        public void stop() {
            this.cooldown = MACE_LEAP_COOLDOWN;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.servant.getTarget();
            if (target == null) {
                return;
            }
            this.servant.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (this.smashed || this.servant.getDeltaMovement().y >= 0.0D) {
                return;
            }
            double dx = target.getX() - this.servant.getX();
            double dz = target.getZ() - this.servant.getZ();
            if (dx * dx + dz * dz > MACE_SMASH_HORIZONTAL_SQR
                    || this.servant.fallDistance <= MaceItem.SMASH_ATTACK_FALL_THRESHOLD) {
                return;
            }
            // 空中砸击：doHurtTarget 内部会按 fallDistance 补上加成、范围击退与音效。
            this.servant.swing(InteractionHand.MAIN_HAND);
            this.smashed = this.servant.doHurtTarget(target);
        }
    }

    // ================================================================ 拾荒

    /**
     * 装备评分：材质 + 耐久 + 附魔等级之和。炼狱晶护甲为最高材质（+1000），
     * 其余材质用可用性/效率/附魔值合成代理，耐久按剩余比例给 0..10 分。
     * 三叉戟与重锤不按弓类小分计，改用钻石档材质分（见 {@link #tierScore}）。
     */
    static int gearScore(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0;
        }
        int score = 0;
        if (stack.getItem() instanceof NetherCrystalArmorItem) {
            // 炼狱晶装备 = 最好材质。
            score += 1000;
        } else if (stack.getItem() instanceof ArmorItem armorItem) {
            score += armorItem.getDefense() * 2 + (int) (armorItem.getToughness() * 4.0F);
        } else if (stack.getItem() instanceof TieredItem tiered) {
            score += tierScore(tiered.getTier());
        } else if (stack.getItem() instanceof ShieldItem) {
            score += 8;
        } else if (stack.getItem() instanceof MaceItem || stack.is(Items.TRIDENT)) {
            // 三叉戟/重锤：材料分取钻石档，与钻石剑持平、高于铁剑。两者都不是
            // TieredItem，拿不到自身材质档，只能显式按需求定级。
            score += tierScore(Tiers.DIAMOND);
        } else if (stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem) {
            score += 6;
        }
        int maxDamage = stack.getMaxDamage();
        if (maxDamage > 0) {
            score += (int) (10.0D * (1.0D - (double) stack.getDamageValue() / (double) maxDamage));
        }
        ItemEnchantments enchantments = stack.getEnchantments();
        for (Holder<net.minecraft.world.item.enchantment.Enchantment> enchantment : enchantments.keySet()) {
            score += enchantments.getLevel(enchantment) * 4;
        }
        return score;
    }

    /** 材质档代理分：速度、攻击加成、附魔值、最大耐久合成，铁剑约 66、钻石剑约 85。 */
    private static int tierScore(Tier tier) {
        return (int) (tier.getSpeed() * 4.0F + tier.getAttackDamageBonus() * 6.0F
                + tier.getEnchantmentValue() * 2.0F + tier.getUses() / 100.0F);
    }

    /** 掉落物是否属于"盔甲、盾牌或武器"三类拾荒对象，以及它对应的装备槽。 */
    private static EquipmentSlot lootSlot(ItemStack stack) {
        if (stack.isEmpty()) {
            return null;
        }
        if (stack.getItem() instanceof ArmorItem armorItem) {
            return armorItem.getEquipmentSlot();
        }
        if (stack.getItem() instanceof ShieldItem) {
            return EquipmentSlot.OFFHAND;
        }
        if (stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem
                || stack.getItem() instanceof MaceItem || stack.getItem() instanceof TieredItem
                || stack.is(Items.TRIDENT)) {
            return EquipmentSlot.MAINHAND;
        }
        return null;
    }

    /** 主动走向"比自己现有的更好"的装备掉落物；接触后由原版拾取管线换装。 */
    private static final class BetterGearPickupGoal extends Goal {
        private final WitherServant servant;
        private ItemEntity wanted;
        private int repathCooldown;

        BetterGearPickupGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!this.servant.canPickUpLoot() || this.servant.getVehicle() != null) {
                return false;
            }
            this.wanted = this.findBestLoot();
            return this.wanted != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.wanted != null && this.wanted.isAlive()
                    && this.servant.distanceToSqr(this.wanted) > 0.6D
                    && this.gearStillBetter(this.wanted);
        }

        @Override
        public void start() {
            this.repathCooldown = 0;
        }

        @Override
        public void stop() {
            this.wanted = null;
        }

        @Override
        public void tick() {
            if (this.repathCooldown-- > 0 && this.servant.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = 10;
            ItemEntity loot = this.wanted;
            this.servant.getNavigation().moveTo(loot.getX(), loot.getY(), loot.getZ(), 1.2D);
        }

        private boolean gearStillBetter(ItemEntity loot) {
            EquipmentSlot slot = lootSlot(loot.getItem());
            return slot != null && gearScore(loot.getItem()) > gearScore(this.servant.getItemBySlot(slot));
        }

        private ItemEntity findBestLoot() {
            List<ItemEntity> items = this.servant.level().getEntitiesOfClass(ItemEntity.class,
                    this.servant.getBoundingBox().inflate(LOOT_SCAN_RADIUS),
                    entity -> entity.isAlive() && !entity.getItem().isEmpty());
            ItemEntity best = null;
            int bestScore = 0;
            boolean rangedUser = isRangedWeapon(this.servant.getMainHandItem());
            for (ItemEntity item : items) {
                EquipmentSlot slot = lootSlot(item.getItem());
                if (slot == null) {
                    continue;
                }
                // 持有远程武器时不主动去捡近战武器（接触换装仍由原版拾取管线完成）。
                if (rangedUser && slot == EquipmentSlot.MAINHAND && !isRangedWeapon(item.getItem())) {
                    continue;
                }
                int gain = gearScore(item.getItem()) - gearScore(this.servant.getItemBySlot(slot));
                if (gain > 0) {
                    int score = gain * 100 - (int) this.servant.distanceToSqr(item);
                    if (score > bestScore) {
                        bestScore = score;
                        best = item;
                    }
                }
            }
            return best;
        }

        private static boolean isRangedWeapon(ItemStack stack) {
            return stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem
                    || stack.is(Items.TRIDENT);
        }
    }

    // ================================================================ 盾牌（移植强袭骑士躯体）

    // 骑乘位不在这里特判：原版公式是「被骑者乘客挂点 − 骑乘者自身 VEHICLE 挂点」，
    // 未显式注册乘客挂点的生物，其挂点默认就落在被骑者判定箱顶（头顶）。仆役的
    // VEHICLE 挂点已在 EntityType 注册处按模型烘焙值设为髋高 0.5625（脚底 24px、
    // 腿枢轴 15px，相差 9px）：坐上去胯部落在被骑者头顶、两腿垂在脸前，与小僵尸骑鸡、
    // 掠夺者骑劫掠兽同一套“髋部锚点”约定。此前这里曾按「被骑者身高 − 自身眼高×0.35」
    // 覆写 getVehicleAttachmentPoint——方向整个反了，被骑者越高反而把仆役压得越深
    // （骑 1.95 米的尸鬼时脚底只剩离地 0.46 格，几乎整只埋进躯干），故删除。

    /**
     * 骑上别的实体时不交出控制权。
     *
     * <p>{@code Mob#getControllingPassenger()} 的规则是：坐骑的第一个乘客若是生物，
     * 且该生物 {@code canControlVehicle()} 为真，就把这个乘客当作操控者，坐骑随后
     * 用乘客的移动输入（xxa/zza/跳跃）驱动自己。仆役的调皮性格会骑到阵营生物头上，
     * 骑上之后它自己的寻路、目标移动会顺着这条链路去开被骑者的车——这就是
     * "骑乘时还能操控别人"的成因。</p>
     *
     * <p>覆写成 false（与原版 {@code non_controlling_rider} 标签里的生物同款）后，
     * 坐骑拿不到操控者，只会跑自己的 AI；仆役只当乘客，不能再左右被骑者。</p>
     */
    @Override
    public boolean canControlVehicle() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            this.syncCorruptionEnemy();
            this.updateShieldStance();
            // 举盾姿态同步给客户端（值没变时 set 不会标脏，不产生多余广播）。
            this.entityData.set(DATA_SHIELD_BLOCKING, this.isShieldRaised());
        }
    }

    /**
     * 只收"副手盾牌"的使用。LivingEntity#stopUsingItem 不分手脚，直接把
     * isUsingItem 关掉——主手正在拉弓/上弩时若照收，会把弓目标的蓄力周期掐断
     * （RangedBowAttackGoal 靠 startUsingItem→shootTask 倒计时→release 出箭，
     * 中途被掐就永远射不出去）。盾牌姿态逻辑里所有"结束使用"都走这个方法。
     */
    private void stopShieldUse() {
        if (this.isUsingItem() && this.getUsedItemHand() == InteractionHand.OFF_HAND) {
            this.stopUsingItem();
        }
    }

    private void updateShieldStance() {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            this.shieldHoldTicks = 0;
            this.shieldSwingLockTicks = 0;
            this.stopShieldUse();
            return;
        }
        if (this.shieldSwingLockTicks > 0) {
            this.shieldSwingLockTicks--;
            this.stopShieldUse();
            return;
        }
        // 莽撞性格：举盾频率更低——反应窗口减半、近身缠斗不再自动续盾。
        boolean reckless = this.getPersonality() == Personality.RECKLESS;
        Projectile incoming = this.detectIncomingProjectile();
        if (incoming != null) {
            this.raiseShield(reckless ? SHIELD_REACT_TICKS / 2 : SHIELD_REACT_TICKS);
            this.getLookControl().setLookAt(
                    incoming.getX(), incoming.getY() + incoming.getBbHeight() * 0.5D, incoming.getZ(),
                    90.0F, 30.0F);
        }
        int intervalLeft = this.attackIntervalEndTick - this.tickCount;
        if (intervalLeft > 0 && !reckless) {
            this.raiseShield(intervalLeft + 1);
        }
        LivingEntity target = this.getTarget();
        if (!reckless && target != null && target.isAlive()
                && this.distanceToSqr(target) <= SHIELD_COMBAT_GUARD_RANGE_SQR) {
            this.raiseShield(SHIELD_COMBAT_GUARD_TICKS);
        }
        if (this.shieldHoldTicks > 0) {
            this.shieldHoldTicks--;
            if (!this.isUsingItem()) {
                this.startUsingItem(InteractionHand.OFF_HAND);
            }
        } else {
            this.stopShieldUse();
        }
    }

    private void raiseShield(int ticks) {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            return;
        }
        this.shieldHoldTicks = Math.max(this.shieldHoldTicks, ticks);
        if (this.shieldSwingLockTicks > 0) {
            return;
        }
        if (!this.isUsingItem()) {
            this.startUsingItem(InteractionHand.OFF_HAND);
        }
    }

    private boolean isShieldRaised() {
        return this.shieldSwingLockTicks <= 0
                && this.shieldHoldTicks > 0
                && this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem;
    }

    @Override
    public boolean isDamageSourceBlocked(DamageSource source) {
        if (this.isShieldRaised() && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            return this.isAttackFromFront(source);
        }
        return super.isDamageSourceBlocked(source);
    }

    private boolean isAttackFromFront(DamageSource source) {
        Vec3 sourcePos = source.getSourcePosition();
        if (sourcePos == null) {
            Entity attacker = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
            if (attacker == null) {
                return false;
            }
            sourcePos = attacker.getEyePosition();
        }
        Vec3 toSelf = sourcePos.vectorTo(this.position());
        Vec3 flat = new Vec3(toSelf.x, 0.0D, toSelf.z);
        if (flat.lengthSqr() < 1.0E-6D) {
            return true;
        }
        Vec3 towards = flat.normalize();
        return towards.dot(this.calculateViewVector(0.0F, this.getYHeadRot())) < 0.0D
                || towards.dot(this.calculateViewVector(0.0F, this.getYRot())) < 0.0D;
    }

    @Override
    protected void hurtCurrentlyUsedShield(float amount) {
        if (this.level().isClientSide() || amount < SHIELD_WEAR_DAMAGE_FLOOR) {
            return;
        }
        EquipmentSlot slot = EquipmentSlot.OFFHAND;
        ItemStack stack = this.getItemBySlot(slot);
        if (!(stack.getItem() instanceof ShieldItem)) {
            return;
        }
        stack.hurtAndBreak(1 + Mth.floor(amount), this, slot);
        if (stack.isEmpty()) {
            this.setItemSlot(slot, ItemStack.EMPTY);
            this.shieldHoldTicks = 0;
            this.stopShieldUse();
            this.playSound(SoundEvents.SHIELD_BREAK, 0.8F,
                    0.8F + this.level().random.nextFloat() * 0.4F);
        }
    }

    private Projectile detectIncomingProjectile() {
        AABB area = this.getBoundingBox().inflate(16.0D);
        Vec3 center = this.getBoundingBox().getCenter();
        Projectile best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Projectile projectile : this.level().getEntitiesOfClass(Projectile.class, area)) {
            if (!ProjectileFlightTracker.isActuallyFlying(projectile) || projectile.getOwner() == this) {
                continue;
            }
            Vec3 toMe = center.subtract(projectile.position());
            Vec3 velocity = projectile.getDeltaMovement();
            double speed = velocity.length();
            if (speed < 1.0E-3D) {
                continue;
            }
            Vec3 direction = velocity.scale(1.0D / speed);
            double along = toMe.dot(direction);
            if (along < 0.0D || along > PROJECTILE_LOOKAHEAD) {
                continue;
            }
            double perpendicular = toMe.subtract(direction.scale(along)).length();
            double corridor = Math.max(PROJECTILE_CORRIDOR, this.getBbWidth());
            if (perpendicular <= corridor && along < bestDistance) {
                best = projectile;
                bestDistance = along;
            }
        }
        return best;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        // 原版重锤砸击的加成只在 Player#attack 里并入伤害，怪物走 Mob#doHurtTarget
        // 永远拿不到。这里在命中前把加成分临时加进攻击力基础值，让伤害照常走
        // 附魔/护甲结算（与原版"先加成再 hurt"的顺序一致）。
        ItemStack weapon = this.getMainHandItem();
        AttributeInstance attack = this.getAttribute(Attributes.ATTACK_DAMAGE);
        boolean smash = attack != null
                && weapon.getItem() instanceof MaceItem
                && MaceItem.canSmashAttack(this);
        double bonus = 0.0D;
        if (smash) {
            DamageSource source = this.damageSources().mobAttack(this);
            bonus = weapon.getItem().getAttackDamageBonus(target, (float) attack.getValue(), source);
            attack.setBaseValue(attack.getBaseValue() + bonus);
        }
        boolean hurt;
        try {
            hurt = super.doHurtTarget(target);
        } finally {
            if (bonus != 0.0D) {
                attack.setBaseValue(attack.getBaseValue() - bonus);
            }
        }
        if (hurt) {
            this.shieldSwingLockTicks = ATTACK_SWING_LOCK_TICKS;
            this.attackIntervalEndTick = this.tickCount + this.getAttackInterval();
            this.shieldHoldTicks = 0;
            if (smash) {
                this.applyMaceSmash(target);
            }
        }
        return hurt;
    }

    /**
     * 重锤砸击的附加效果：范围击退、砸击音效、抵消自身坠落伤害。
     *
     * <p>逐条对齐原版 {@code MaceItem#hurtEnemy}（它只对 {@code ServerPlayer} 生效）：
     * 以命中点为中心 3.5 格内的非友方生物被推离，推力随距离递减、坠落超过 5 格翻倍、
     * 再乘目标的击退抗性；脚下落地音随目标是否着地切换。军团阵营成员不参与，
     * 免得自家拾荒兵一锤子把同伴掀飞。</p>
     */
    private void applyMaceSmash(Entity target) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        float fallen = this.fallDistance;
        SoundEvent sound = target.onGround()
                ? (fallen > 5.0F ? SoundEvents.MACE_SMASH_GROUND_HEAVY : SoundEvents.MACE_SMASH_GROUND)
                : SoundEvents.MACE_SMASH_AIR;
        serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(), sound,
                this.getSoundSource(), 1.0F, 1.0F);
        double radius = MaceItem.SMASH_ATTACK_KNOCKBACK_RADIUS;
        List<LivingEntity> affected = serverLevel.getEntitiesOfClass(LivingEntity.class,
                target.getBoundingBox().inflate(radius),
                entity -> entity != this && entity != target && !entity.isSpectator()
                        && !LegionAuraHandler.isFactionMember(entity));
        for (LivingEntity entity : affected) {
            Vec3 offset = entity.position().subtract(target.position());
            double power = (radius - offset.length()) * 0.7D
                    * (fallen > 5.0F ? 2.0D : 1.0D)
                    * (1.0D - entity.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
            if (power > 0.0D) {
                Vec3 push = offset.normalize().scale(power);
                entity.push(push.x, 0.7D, push.z);
            }
        }
        // 与玩家砸击一致：命中即抵消坠落伤害。
        this.resetFallDistance();
    }

    // ================================================================ 胆怯后撤（传令兵同款）

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean damaged = super.hurt(source, amount);
        if (damaged && !this.level().isClientSide && amount > 0.0F
                && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            this.raiseShield(SHIELD_ON_HURT_GUARD_TICKS);
        }
        if (damaged && !this.level().isClientSide && this.getPersonality() == Personality.TIMID) {
            Entity attacker = source.getEntity() != null ? source.getEntity() : source.getDirectEntity();
            if (attacker instanceof LivingEntity living && living != this && living.isAlive()) {
                this.startFleeFrom(living);
            }
        }
        return damaged;
    }

    private void startFleeFrom(LivingEntity threat) {
        Vec3 away = this.position().subtract(threat.position());
        away = new Vec3(away.x, 0.0D, away.z);
        if (away.lengthSqr() < 1.0E-4D) {
            away = this.getLookAngle().multiply(-1.0D, 0.0D, -1.0D);
        }
        away = away.normalize();
        this.fleeTargetPos = this.position().add(away.scale(FLEE_DISTANCE));
        this.fleeDeadline = this.level().getGameTime() + FLEE_TIMEOUT_TICKS;
        this.fleeing = true;
        this.getNavigation().stop();
    }

    boolean isFleeing() {
        return this.fleeing && this.getPersonality() == Personality.TIMID;
    }

    Vec3 getFleeTargetPos() {
        return this.fleeTargetPos;
    }

    long getFleeDeadline() {
        return this.fleeDeadline;
    }

    void stopFleeing() {
        this.fleeing = false;
        this.fleeTargetPos = null;
    }

    /** 胆怯受击后撤：与 {@link CourierFleeGoal} 同一套落点/时限/标志占用。 */
    private static final class FleeOnHurtGoal extends Goal {
        private final WitherServant servant;

        FleeOnHurtGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return this.servant.isFleeing();
        }

        @Override
        public boolean canContinueToUse() {
            if (!this.servant.isFleeing()) {
                return false;
            }
            Vec3 target = this.servant.getFleeTargetPos();
            if (target == null || this.servant.position().distanceTo(target) < 0.6D
                    || this.servant.level().getGameTime() > this.servant.getFleeDeadline()) {
                this.servant.stopFleeing();
                return false;
            }
            return true;
        }

        @Override
        public void tick() {
            if (this.servant.fleeRepathCooldown-- > 0 && this.servant.getNavigation().isInProgress()) {
                return;
            }
            this.servant.fleeRepathCooldown = 5;
            Vec3 target = this.servant.getFleeTargetPos();
            if (target != null) {
                this.servant.getNavigation().moveTo(target.x, target.y, target.z, 1.6D);
            }
        }
    }

    // ================================================================ 乖巧追随 / 调皮骑头

    /** 乖巧：主动追随周围的凋灵骷髅阵营生物（16 格内最近的阵营成员）。 */
    private static final class FollowFactionGoal extends Goal {
        private final WitherServant servant;
        private Mob leader;
        private int repathCooldown;

        FollowFactionGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.servant.getPersonality() != Personality.OBEDIENT
                    || this.servant.getTarget() != null || this.servant.getVehicle() != null) {
                return false;
            }
            this.leader = this.findLeader();
            return this.leader != null && this.servant.distanceToSqr(this.leader) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return this.leader != null && this.leader.isAlive()
                    && this.servant.getTarget() == null
                    && this.servant.distanceToSqr(this.leader) > 6.0D;
        }

        @Override
        public void tick() {
            if (this.repathCooldown-- > 0 && this.servant.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = 10;
            this.servant.getNavigation().moveTo(this.leader.getX(), this.leader.getY(),
                    this.leader.getZ(), 1.1D);
        }

        private Mob findLeader() {
            Mob best = null;
            double bestDistance = Double.MAX_VALUE;
            for (Mob mob : this.servant.level().getEntitiesOfClass(Mob.class,
                    this.servant.getBoundingBox().inflate(16.0D),
                    LegionAuraHandler::isFactionMember)) {
                if (mob == this.servant || !mob.isAlive() || mob.getPassengers().size() > 1) {
                    continue;
                }
                double distance = this.servant.distanceToSqr(mob);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = mob;
                }
            }
            return best;
        }
    }

    /** 调皮：跑到阵营生物身边骑上它的头（位 = 被骑者乘客挂点 − 自身髋部挂点，见注册处 ridingOffset）。 */
    private static final class MountHeadGoal extends Goal {
        private final WitherServant servant;
        private Mob mount;
        private int repathCooldown;

        MountHeadGoal(WitherServant servant) {
            this.servant = servant;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.servant.getPersonality() != Personality.MISCHIEVOUS
                    || this.servant.getVehicle() != null || this.servant.getTarget() != null) {
                return false;
            }
            this.mount = this.findMount();
            return this.mount != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.mount != null && this.mount.isAlive() && this.servant.getVehicle() == null
                    && this.servant.distanceToSqr(this.mount) > 1.2D;
        }

        @Override
        public void tick() {
            if (this.servant.distanceToSqr(this.mount) < 1.6D && this.servant.startRiding(this.mount)) {
                return;
            }
            if (this.repathCooldown-- > 0 && this.servant.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = 10;
            this.servant.getNavigation().moveTo(this.mount.getX(), this.mount.getY(),
                    this.mount.getZ(), 1.3D);
        }

        @Override
        public void stop() {
            this.mount = null;
        }

        private Mob findMount() {
            List<Mob> mobs = this.servant.level().getEntitiesOfClass(Mob.class,
                    this.servant.getBoundingBox().inflate(12.0D),
                    mob -> mob != this.servant && mob.isAlive() && LegionAuraHandler.isFactionMember(mob)
                            && mob.getVehicle() == null && mob.getPassengers().isEmpty()
                            && mob.getBbHeight() >= 1.4D);
            return mobs.isEmpty() ? null : mobs.get(this.servant.random.nextInt(mobs.size()));
        }
    }
}
