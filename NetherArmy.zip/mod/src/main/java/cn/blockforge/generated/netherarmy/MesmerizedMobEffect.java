package cn.blockforge.generated.netherarmy;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** 仅用于同步和渲染被心灵控制的实体。 */
public final class MesmerizedMobEffect extends MobEffect {
    public MesmerizedMobEffect() {
        super(MobEffectCategory.BENEFICIAL, 0x9B35D1);
    }
}
