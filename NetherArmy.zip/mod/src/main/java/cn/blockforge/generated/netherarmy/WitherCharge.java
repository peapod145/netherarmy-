package cn.blockforge.generated.netherarmy;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** 诡影使徒使用的凋零飞弹，也可由玩家投掷。 */
public final class WitherCharge extends ThrowableItemProjectile {
    private static final int MAX_LIFETIME_TICKS = 30 * 20;

    /** 爆炸半径：只够打穿命中点所在的一个方块，见 {@link ImpactRestrictedCalculator}。 */
    private static final float EXPLOSION_RADIUS = 1.0F;

    private static final float DIRECT_DAMAGE = 5.0F;

    private static final float SOUL_FIRE_SECONDS = 10.0F;

    /**
     * 恶魂火球的冲击力基准倍率。原版 {@code ExplosionDamageCalculator#getKnockbackMultiplier}
     * 默认返回 1.0，恶魂火球（{@code LargeFireball}，爆炸威力 1）走的就是这个默认值。
     * 本模组爆炸半径同样是 1.0，{@code Explosion} 的归一化距离取
     * {@code distance / (半径 × 2)}，因此两弹之间完全可比。
     */
    private static final float GHAST_FIREBALL_KNOCKBACK_MULTIPLIER = 1.0F;

    /**
     * 爆炸击退倍率 = 恶魂火球的 25%。
     *
     * <p>原版 {@code Explosion.explode} 的冲击波与 {@code shouldDamageEntity} 无关，只要距离
     * &le; 半径就按 {@code (1 - 归一化距离) × 视野系数 × 本倍率} 推人，冲击与倍率严格线性。
     * 半径与恶魂火球一致时取恶魂的 0.25 倍，即"恶魂火球冲击力的 25%"。</p>
     *
     * <p>此前用 0.35 仍能把铁傀儡掀飞，本轮按要求再压到 0.25，保留轻微的推挤手感。</p>
     */
    private static final float EXPLOSION_KNOCKBACK_MULTIPLIER =
            GHAST_FIREBALL_KNOCKBACK_MULTIPLIER * 0.25F;

    /**
     * 命中点周围结算直伤与灵魂火的距离。按<b>实体碰撞箱到命中点的最近距离</b>计，
     * 而不是实体原点，这样凋灵之类大体型的生物、以及命中点落在长条碰撞箱一端的场合都不会漏判。
     */
    private static final double DAMAGE_RADIUS = 1.0D;

    /**
     * 是否为"凋灵骷髅阵营同袍豁免"的飞弹：起爆时跳过阵营成员，连伤害与灵魂火都不结算。
     *
     * <p>诡影使徒没有同袍，玩家投掷的飞弹也该能伤到凋灵骷髅（那是敌对势力），所以这个
     * 开关默认关闭，只由 {@link Suppressor} 发射时打开——反转士是凋灵骷髅阵营成员，
     * 身边常有自己的同袍，飞弹起爆不该溅射它们。</p>
     */
    private boolean factionPassthrough;

    /**
     * 逐次爆炸用的硬度过滤器：只有<b>命中点所在的那一个方块</b>允许被炸掉。
     *
     * <p>原版爆炸是沿 16×16×16 条射线收集方块，半径 1 也能在命中点四周拆掉好几个方块；
     * 这里直接在 {@code shouldBlockExplode} 上按坐标放行，等价于过去"炸完再裁剪 toBlow"，
     * 但裁剪发生在爆炸内部，因此客户端收到的 {@code ClientboundExplodePacket} 里也只剩这一个
     * 方块——不会出现"服务端只掉一格、客户端却炸出一圈"的两端不一致。</p>
     */
    private static final class ImpactRestrictedCalculator extends ExplosionDamageCalculator {
        private final BlockPos impact;

        private ImpactRestrictedCalculator(BlockPos impact) {
            this.impact = impact;
        }

        @Override
        public Optional<Float> getBlockExplosionResistance(Explosion explosion, BlockGetter level,
                                                            BlockPos pos, BlockState state,
                                                            FluidState fluid) {
            if (state.isAir() || fluid.isEmpty()) {
                return Optional.empty();
            }
            return state.getDestroySpeed(level, pos) >= 0.0F && state.getDestroySpeed(level, pos) <= 1.0F
                    ? super.getBlockExplosionResistance(explosion, level, pos, state, fluid)
                    : Optional.of(Float.MAX_VALUE);
        }

        @Override
        public boolean shouldBlockExplode(Explosion explosion, BlockGetter level,
                                          BlockPos pos, BlockState state, float power) {
            if (!pos.equals(this.impact)) {
                return false;
            }
            float hardness = state.getDestroySpeed(level, pos);
            return hardness >= 0.0F && hardness <= 1.0F;
        }

        @Override
        public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
            // 生物伤害由 damageNearby 单独结算，这里关掉原版爆炸直伤，避免同一发打两遍。
            return false;
        }

        @Override
        public float getKnockbackMultiplier(Entity entity) {
            // 关掉直伤并不会关掉击退：冲击波在这条路径上单独结算，见 EXPLOSION_KNOCKBACK_MULTIPLIER。
            return EXPLOSION_KNOCKBACK_MULTIPLIER;
        }
    }

    public WitherCharge(EntityType<? extends WitherCharge> type, Level level) {
        super(type, level);
    }

    public WitherCharge(LivingEntity owner, Level level, Vec3 direction) {
        super(GeneratedMod.WITHER_CHARGE.get(), owner, level);
    }

    public void launch(Vec3 direction) {
        this.shoot(direction.x, direction.y, direction.z, 1.5F, 1.0F);
    }

    /** 打开/关闭"同袍豁免"：打开后起爆只伤非凋灵骷髅阵营生物（供反转士使用）。 */
    public void setFactionPassthrough(boolean value) {
        this.factionPassthrough = value;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("FactionPassthrough", this.factionPassthrough);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.factionPassthrough = tag.getBoolean("FactionPassthrough");
    }

    public WitherCharge(Level level, double x, double y, double z) {
        super(GeneratedMod.WITHER_CHARGE.get(), x, y, z, level);
    }

    @Override
    protected Item getDefaultItem() {
        return GeneratedMod.WITHER_CHARGE_ITEM.get();
    }

    @Override
    protected double getDefaultGravity() {
        return 0.0D;
    }

    /** 凋零飞弹本身持续显示实体包裹式灵魂火，而不是灵魂火把粒子。 */
    @Override
    public boolean displayFireAnimation() {
        return true;
    }

    /** 复用衰翼发射的原版凋灵之首烟雾尾迹。 */
    @Override
    public void tick() {
        super.tick();
        if (this.tickCount >= MAX_LIFETIME_TICKS) {
            this.discard();
            return;
        }
        if (this.level().isClientSide() && this.isAlive()) {
            this.level().addParticle(ParticleTypes.SMOKE,
                    this.getX(), this.getY() + 0.5D, this.getZ(), 0.0D, 0.0D, 0.0D);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        if (this.level().isClientSide()) {
            return;
        }
        this.explode(result);
        this.discard();
    }

    /**
     * 起爆。爆炸中心取<b>命中点的真实坐标</b> {@link HitResult#getLocation()}，不再用弹体位置。
     *
     * <p>{@code ThrowableProjectile#tick} 的顺序是"先按本 tick 的位移扫命中、再把自己挪过去"，
     * 所以命中回调触发时弹体还停在上一刻坐标，速度 1.5 格/tick 时最多落后命中点 1.5 格。
     * 旧实现拿弹体位置当中心、又只用 {@code getBoundingBox().inflate(1.0)}（弹体半宽 0.156）找人，
     * 这一格半的偏差刚好能把被打中的生物甩出判定范围——玩家看到的就是"弹体命中后消失，
     * 却没有伤害、没有灵魂火，爆炸也不在命中点上"。改成以命中点结算后，三者重新对齐。</p>
     *
     * <p>另外必须走 {@link Level#explode} 的服务端分发路径：直接
     * {@code new Explosion(...)} 再 {@code finalizeExplosion(true)} 只在服务端本地推进，
     * {@code Explosion} 的粒子走的是 {@code Level.addParticle}——它在服务端是空实现，
     * {@code ServerLevel} 也不会补发 {@code ClientboundExplodePacket}，于是附近客户端既看不到
     * 爆炸粒子也听不到爆炸声，只剩一枚"哑弹"。</p>
     */
    private void explode(HitResult result) {
        Vec3 center = result.getLocation();
        BlockPos impact = result instanceof BlockHitResult blockHit
                ? blockHit.getBlockPos()
                : BlockPos.containing(center);
        Entity owner = this.getOwner();

        this.level().explode(this, null, new ImpactRestrictedCalculator(impact),
                center.x(), center.y(), center.z(), EXPLOSION_RADIUS, true,
                Level.ExplosionInteraction.BLOCK, ParticleTypes.EXPLOSION,
                ParticleTypes.EXPLOSION_EMITTER, SoundEvents.GENERIC_EXPLODE);

        this.damageNearby(center, result, owner);
    }

    /**
     * 命中点半径 {@value #DAMAGE_RADIUS} 格内的生物结算直伤与灵魂火。
     *
     * <p>被直接命中的那个生物无条件进名单：它的碰撞箱上就含着 {@code getLocation()}，
     * 距离判定本来也必然通过，这里显式补一条只是保证"命中 ⇒ 必有结算"这条硬约束。</p>
     */
    private void damageNearby(Vec3 center, HitResult result, Entity owner) {
        Set<LivingEntity> victims = new LinkedHashSet<>();
        if (result instanceof EntityHitResult entityHit
                && entityHit.getEntity() instanceof LivingEntity direct) {
            victims.add(direct);
        }
        AABB search = new AABB(center, center).inflate(DAMAGE_RADIUS + 1.0D);
        for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class, search,
                Entity::isAlive)) {
            if (living.getBoundingBox().distanceToSqr(center) <= DAMAGE_RADIUS * DAMAGE_RADIUS) {
                victims.add(living);
            }
        }

        DamageSource source = this.level().damageSources().explosion(this, owner);
        for (LivingEntity living : victims) {
            if (!living.isAlive() || living == owner) {
                continue;
            }
            if (this.factionPassthrough && MesmerizerControl.isWitherSkeletonFaction(living)) {
                continue;
            }
            living.hurt(source, DIRECT_DAMAGE);
            SoulFireBurn.ignite(living, SOUL_FIRE_SECONDS);
        }
    }
}
