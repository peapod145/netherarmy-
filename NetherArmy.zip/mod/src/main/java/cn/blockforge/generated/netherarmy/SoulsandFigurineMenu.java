package cn.blockforge.generated.netherarmy;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.SwordItem;

/**
 * 灵魂土偶装备界面：坐标体系完全照原版马（驴）界面 {@code HorseInventoryMenu} 排布。
 *
 * <p>上半区（原版放 saddle / body armor / chest 的那块）：
 * 最左一列 4 格盔甲（x=8, y=8/26/44/62，与原版玩家背包的盔甲列同位）；
 * 中间留给实体预览（原版马预览区 x=26..78）；
 * 主手、副手两格落在原版副手格的位置（x=77, y=44/62）；
 * 2×2 物品栏在原版合成格的位置（x=98/116, y=18/36）。
 * 下半区是玩家背包（x=8+18c, y=84/102/120）与快捷栏（y=142），
 * 与 {@code HorseInventoryMenu} 的玩家背包坐标一字不差。</p>
 */
public final class SoulsandFigurineMenu extends AbstractContainerMenu {
    /** 盔甲列：0=头盔 1=胸甲 2=护腿 3=靴子，原版玩家背包的坐标。 */
    public static final int ARMOR_SLOT_START = 0;
    public static final int ARMOR_SLOT_COUNT = 4;
    /** 主手格，位于原版副手格正上方。 */
    public static final int MAINHAND_SLOT = 4;
    /** 副手格，原版副手格的坐标。 */
    public static final int OFFHAND_SLOT = 5;
    /** 2×2 自带物品栏，原版 2×2 合成格的坐标。 */
    public static final int STORAGE_SLOT_START = 6;
    public static final int STORAGE_SLOT_COUNT = 4;

    public static final int FIGURINE_SLOT_COUNT = 10;
    public static final int PLAYER_INV_START = FIGURINE_SLOT_COUNT;
    public static final int PLAYER_INV_END = PLAYER_INV_START + 27;
    public static final int PLAYER_HOTBAR_START = PLAYER_INV_END;
    public static final int PLAYER_HOTBAR_END = PLAYER_HOTBAR_START + 9;

    private static final ResourceLocation[] ARMOR_SLOT_ICONS = {
            InventoryMenu.EMPTY_ARMOR_SLOT_HELMET,
            InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE,
            InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS,
            InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS
    };
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private final SoulsandFigurine figurine;
    private final Container storage;

    public SoulsandFigurineMenu(int containerId, Inventory playerInventory, SoulsandFigurine figurine) {
        super(GeneratedMod.SOULSAND_FIGURINE_MENU.get(), containerId);
        this.figurine = figurine;
        this.storage = figurine.getInventory();

        for (int i = 0; i < ARMOR_SLOT_COUNT; i++) {
            this.addSlot(new FigurineEquipmentSlot(ARMOR_SLOTS[i], 8, 8 + i * 18, ARMOR_SLOT_ICONS[i]));
        }
        this.addSlot(new FigurineEquipmentSlot(EquipmentSlot.MAINHAND, 77, 44, null));
        this.addSlot(new FigurineEquipmentSlot(EquipmentSlot.OFFHAND, 77, 62,
                InventoryMenu.EMPTY_ARMOR_SLOT_SHIELD));
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                this.addSlot(new Slot(this.storage, row * 2 + col, 98 + col * 18, 18 + row * 18));
            }
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + (row + 1) * 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }
    }

    public SoulsandFigurine getFigurine() {
        return this.figurine;
    }

    /** 土偶自身区域（盔甲 + 双手 + 2×2 物品栏）的格子数，客户端据此决定画多少槽位框。 */
    public int getFigurineSlotCount() {
        return FIGURINE_SLOT_COUNT;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.figurine.isAlive() && this.figurine.canConfigure(player)
                && player.canInteractWithEntity(this.figurine, 4.0D);
    }

    /**
     * Shift 点击：土偶身上的东西一律回玩家背包；玩家背包里的东西先试盔甲格，
     * 再试盾牌/武器，最后落进 2×2 物品栏，都放不下时才在背包与快捷栏之间整理
     * （这一段和 {@code HorseInventoryMenu#quickMoveStack} 的思路一致）。
     */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < FIGURINE_SLOT_COUNT) {
            if (!this.moveItemStackTo(stack, PLAYER_INV_START, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            int armorIndex = armorIndex(this.figurine.getEquipmentSlotForItem(stack));
            if (armorIndex >= 0 && this.getSlot(armorIndex).mayPlace(stack) && !this.getSlot(armorIndex).hasItem()) {
                if (!this.moveItemStackTo(stack, armorIndex, armorIndex + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (isShieldStack(stack) && !this.getSlot(OFFHAND_SLOT).hasItem()) {
                if (!this.moveItemStackTo(stack, OFFHAND_SLOT, OFFHAND_SLOT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (isWeaponStack(stack) && !this.getSlot(MAINHAND_SLOT).hasItem()) {
                if (!this.moveItemStackTo(stack, MAINHAND_SLOT, MAINHAND_SLOT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (!this.moveItemStackTo(stack, STORAGE_SLOT_START, FIGURINE_SLOT_COUNT, false)) {
                int from = index < PLAYER_HOTBAR_START ? PLAYER_HOTBAR_START : PLAYER_INV_START;
                int to = index < PLAYER_HOTBAR_START ? PLAYER_HOTBAR_END : PLAYER_INV_END;
                if (!this.moveItemStackTo(stack, from, to, false)) {
                    return ItemStack.EMPTY;
                }
            }
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return original;
    }

    private static int armorIndex(EquipmentSlot slot) {
        for (int i = 0; i < ARMOR_SLOT_COUNT; i++) {
            if (ARMOR_SLOTS[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private static boolean isShieldStack(ItemStack stack) {
        return stack.getItem() instanceof ShieldItem;
    }

    private static boolean isWeaponStack(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (stack.is(Items.TRIDENT)) {
            return true;
        }
        return stack.getItem() instanceof SwordItem
                || stack.getItem() instanceof AxeItem
                || stack.getItem() instanceof BowItem
                || stack.getItem() instanceof CrossbowItem
                || stack.getItem() instanceof MaceItem;
    }

    /** 读写实体装备槽的 1 格界面槽，禁止把盔甲塞进手里。 */
    private final class FigurineEquipmentSlot extends Slot {
        private final EquipmentSlot slot;
        private final ResourceLocation emptyIcon;

        private FigurineEquipmentSlot(EquipmentSlot slot, int x, int y, ResourceLocation emptyIcon) {
            super(new EquipmentContainer(SoulsandFigurineMenu.this.figurine, slot), 0, x, y);
            this.slot = slot;
            this.emptyIcon = emptyIcon;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            if (stack.isEmpty()) {
                return false;
            }
            EquipmentSlot target = SoulsandFigurineMenu.this.figurine.getEquipmentSlotForItem(stack);
            if (this.slot.isArmor()) {
                return target == this.slot;
            }
            // 主手/副手：盔甲只能进盔甲列，其余物品（武器、盾牌、图腾、方块）都可以放
            return !target.isArmor();
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }

        @Override
        public void setChanged() {
            super.setChanged();
            SoulsandFigurineMenu.this.figurine.onEquipmentChanged();
        }

        @Override
        public com.mojang.datafixers.util.Pair<ResourceLocation, ResourceLocation> getNoItemIcon() {
            return this.emptyIcon == null ? null
                    : com.mojang.datafixers.util.Pair.of(InventoryMenu.BLOCK_ATLAS, this.emptyIcon);
        }
    }

    /** 把单个装备槽包装成 1 格容器，让 Slot 读写实体装备。 */
    private static final class EquipmentContainer implements Container {
        private final SoulsandFigurine figurine;
        private final EquipmentSlot slot;

        private EquipmentContainer(SoulsandFigurine figurine, EquipmentSlot slot) {
            this.figurine = figurine;
            this.slot = slot;
        }

        @Override
        public int getContainerSize() {
            return 1;
        }

        @Override
        public boolean isEmpty() {
            return this.figurine.getItemBySlot(this.slot).isEmpty();
        }

        @Override
        public ItemStack getItem(int index) {
            return this.figurine.getItemBySlot(this.slot);
        }

        @Override
        public ItemStack removeItem(int index, int count) {
            ItemStack current = this.figurine.getItemBySlot(this.slot);
            if (current.isEmpty()) {
                return ItemStack.EMPTY;
            }
            ItemStack split = current.split(count);
            this.figurine.setItemSlot(this.slot, current);
            this.setChanged();
            return split;
        }

        @Override
        public ItemStack removeItemNoUpdate(int index) {
            ItemStack current = this.figurine.getItemBySlot(this.slot);
            this.figurine.setItemSlot(this.slot, ItemStack.EMPTY);
            return current;
        }

        @Override
        public void setItem(int index, ItemStack stack) {
            this.figurine.setItemSlot(this.slot, stack);
            this.setChanged();
        }

        @Override
        public void setChanged() {
            this.figurine.onEquipmentChanged();
        }

        @Override
        public boolean stillValid(Player player) {
            return this.figurine.isAlive() && this.figurine.canConfigure(player);
        }

        @Override
        public void clearContent() {
            this.figurine.setItemSlot(this.slot, ItemStack.EMPTY);
        }
    }
}
