package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.BodyRotationControl;
import net.minecraft.world.entity.ai.control.LookControl;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.Vec3;

/**
 * 不死武士残骸：正常不死武士死亡后在原位置生成的解体形态。
 *
 * <p>残骸没有 AI：不移动、不转向、不攻击、不能被击退。生成后立刻播放解体动画并停在
 * 末帧；末帧停留 5 秒仍未死亡时倒放动画，转成正常不死武士并带上原武器。残骸自身的
 * 死亡才会掉落经验与掉落物。</p>
 */
public class ImmortalWarriorRemains extends ImmortalWarrior {
    public static final ResourceKey<LootTable> LOOT_TABLE = ResourceKey.create(
            Registries.LOOT_TABLE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "entities/immortal_warrior_remains"));

    public ImmortalWarriorRemains(EntityType<? extends ImmortalWarriorRemains> type, Level level) {
        super(type, level);
        this.lookControl = new FrozenLookControl(this);
        this.setNoAi(true);
        this.setPersistenceRequired();
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.monster.WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.ATTACK_DAMAGE, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void registerGoals() {
        // 残骸没有移动、攻击或转向行为。
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        this.setNoAi(true);
        this.setTarget(null);
        this.setLastHurtByMob(null);
        this.setLastHurtMob(null);
        this.getNavigation().stop();

        if (warriorState == 0) {
            lockedYRot = this.getYRot();
            lockedYHeadRot = this.getYHeadRot();
            setWarriorState(1, FALL_APART_TICKS);
        }

        Vec3 movement = this.getDeltaMovement();
        // setNoAi(true) 会跳过 Mob 的 AI 移动步骤；这里显式执行实体重力和位移，
        // 同时继续锁定水平速度，避免残骸被推动或自行漂移。
        if (!this.onGround() && !this.isNoGravity()) {
            this.applyGravity();
        }
        movement = this.getDeltaMovement();
        this.move(MoverType.SELF, new Vec3(0.0D, movement.y, 0.0D));
        this.setDeltaMovement(0.0D, this.onGround() ? 0.0D : this.getDeltaMovement().y, 0.0D);
        this.hasImpulse = false;
        this.setYRot(lockedYRot);
        this.setXRot(0.0F);
        this.setYHeadRot(lockedYHeadRot);
        this.setYBodyRot(lockedYRot);

        if (stateTicks > 0) {
            stateTicks--;
            this.entityData.set(DATA_STATE_TICKS, stateTicks);
        }
        if (stateTicks == 0) {
            if (warriorState == 1) {
                setWarriorState(2, DISINTEGRATED_HOLD_TICKS);
            } else if (warriorState == 2) {
                setWarriorState(3, RECOVER_TICKS);
            } else if (warriorState == 3) {
                convertToNormalWarrior();
            }
        }
    }

    /** 残骸在解体、停留和复原全过程都可以被正常攻击。 */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, amount);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void knockback(double strength, double x, double z) {
        // 无法被击退。
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        return false;
    }

    /**
     * 残骸不是生物索敌目标。原版 {@code TargetingConditions} 会通过这个方法过滤候选目标，
     * 因此新生物不会把残骸选为攻击目标；tick() 中的目标清理则负责清除已经存在的旧仇恨。
     */
    @Override
    public boolean canBeSeenAsEnemy() {
        return false;
    }

    @Override
    public void swing(net.minecraft.world.InteractionHand hand, boolean fromFallSource) {
        // 不播放挥手动作。
    }

    @Override
    protected BodyRotationControl createBodyControl() {
        return new FrozenBodyRotationControl(this);
    }

    @Override
    protected boolean transformsIntoRemainsOnDeath() {
        return false;
    }

    @Override
    protected boolean shouldDropLoot() {
        return true;
    }

    @Override
    public boolean shouldDropExperience() {
        return true;
    }

    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return LOOT_TABLE;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        if (this.getRandom().nextFloat() < 0.01F) {
            ItemStack sword = new ItemStack(GeneratedMod.ROYAL_LONGSWORD.get());
            sword.setDamageValue(this.getRandom().nextInt(Math.max(1, sword.getMaxDamage())));
            this.spawnAtLocation(sword);
        }
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("WarriorState")) {
            warriorState = tag.getInt("WarriorState");
            this.entityData.set(DATA_WARRIOR_STATE, warriorState);
        }
        if (tag.contains("StateTicks")) {
            stateTicks = tag.getInt("StateTicks");
            this.entityData.set(DATA_STATE_TICKS, stateTicks);
        }
        if (tag.contains("LockedYRot")) {
            lockedYRot = tag.getFloat("LockedYRot");
        }
        if (tag.contains("LockedYHeadRot")) {
            lockedYHeadRot = tag.getFloat("LockedYHeadRot");
        }
        if (warriorState == 0) {
            lockedYRot = this.getYRot();
            lockedYHeadRot = this.getYHeadRot();
        }
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("WarriorState", warriorState);
        tag.putInt("StateTicks", stateTicks);
        tag.putFloat("LockedYRot", lockedYRot);
        tag.putFloat("LockedYHeadRot", lockedYHeadRot);
    }

    private void convertToNormalWarrior() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        ImmortalWarrior warrior = GeneratedMod.IMMORTAL_WARRIOR.get().create(serverLevel);
        if (warrior == null) {
            return;
        }
        ItemStack weapon = this.getMainHandItem().copy();
        warrior.moveTo(this.getX(), this.getY(), this.getZ(), lockedYRot, 0.0F);
        warrior.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(warrior.blockPosition()),
                MobSpawnType.CONVERSION, null);
        warrior.setYRot(lockedYRot);
        warrior.setXRot(0.0F);
        warrior.setYHeadRot(lockedYHeadRot);
        warrior.setYBodyRot(lockedYRot);
        warrior.setItemSlot(EquipmentSlot.MAINHAND, weapon);
        warrior.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        warrior.reassessWeaponGoal();
        serverLevel.addFreshEntity(warrior);
        this.discard();
    }

    private static final class FrozenBodyRotationControl extends BodyRotationControl {
        FrozenBodyRotationControl(Mob mob) {
            super(mob);
        }

        @Override
        public void clientTick() {
            // 不更新躯干或头部朝向。
        }
    }

    private static final class FrozenLookControl extends LookControl {
        FrozenLookControl(Mob mob) {
            super(mob);
        }

        @Override
        public void tick() {
            // 不转向任何目标。
        }
    }
}
