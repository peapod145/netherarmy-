package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.BodyRotationControl;
import net.minecraft.world.entity.ai.control.LookControl;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * 不死武士残骸：正常不死武士死亡后在原位置生成的解体形态。
 *
 * <p>残骸没有 AI：不移动、不转向、不攻击、不能被击退。生成后立刻播放解体动画并停在
 * 末帧；末帧停留 5 秒仍未死亡时倒放动画，转成正常不死武士并带上原武器。残骸自身的
 * 死亡才会掉落经验与掉落物。</p>
 *
 * <p>解体与复原全程保留原先的仇恨：死前锁定的目标、以及"谁打过我""我打过谁"两条互殴
 * 记录都以 UUID 形式记在残骸上（残骸本身不因此获得目标，仍然不索敌、不被视作敌人），
 * 复原成正常不死武士时一次性兑现；残骸期间挨的打也会补进反击记忆里。</p>
 */
public class ImmortalWarriorRemains extends ImmortalWarrior {
    public static final ResourceKey<LootTable> LOOT_TABLE = ResourceKey.create(
            Registries.LOOT_TABLE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "entities/immortal_warrior_remains"));

    private static final String TAG_PENDING_TARGET = "PendingTargetId";
    private static final String TAG_PENDING_REVENGE = "PendingRevengeId";
    private static final String TAG_PENDING_LAST_HURT_MOB = "PendingLastHurtMobId";

    /** 解体前锁定的仇恨目标，复原后原样交还给新的不死武士。 */
    private UUID pendingTargetId;
    /** 最后攻击过自己的生物（死前的，或残骸期间补上的），复原后作为反击记忆兑现。 */
    private UUID pendingRevengeId;
    /** 自己最后攻击过的生物，保留原有的互殴记录。 */
    private UUID pendingLastHurtMobId;

    /**
     * 解体那一刻整套装备（六格，含空槽占位）与每格掉落率的快照。
     *
     * <p>残骸进世界后会被别的流程（原版追踪、其它模组的装备接管等）碰到装备槽，
     * 只靠入世界时复制一次并不保险；tick 首帧会用这份快照把被清掉的槽补回来。</p>
     */
    private ItemStack[] gearSnapshot;
    private float[] gearDropChances;

    public ImmortalWarriorRemains(EntityType<? extends ImmortalWarriorRemains> type, Level level) {
        super(type, level);
        this.lookControl = new FrozenLookControl(this);
        this.setNoAi(true);
        this.setPersistenceRequired();
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.monster.WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.ATTACK_DAMAGE, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void registerGoals() {
        // 残骸没有移动、攻击或转向行为。
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        this.setNoAi(true);
        // 残骸期间挨的打先记进待恢复仇恨，再清空自身目标：残骸依旧不索敌、不还手。
        this.captureInterimHostility();
        this.setTarget(null);
        this.setLastHurtByMob(null);
        this.setLastHurtMob(null);
        this.getNavigation().stop();
        // 入世界后的每一 tick 都按解体瞬间的快照兜底：装备槽被清掉就补回。
        this.ensureGearIntact();

        if (warriorState == 0) {
            lockedYRot = this.getYRot();
            lockedYHeadRot = this.getYHeadRot();
            setWarriorState(1, FALL_APART_TICKS);
        }

        Vec3 movement = this.getDeltaMovement();
        // setNoAi(true) 会跳过 Mob 的 AI 移动步骤；这里显式执行实体重力和位移，
        // 同时继续锁定水平速度，避免残骸被推动或自行漂移。
        if (!this.onGround() && !this.isNoGravity()) {
            this.applyGravity();
        }
        movement = this.getDeltaMovement();
        this.move(MoverType.SELF, new Vec3(0.0D, movement.y, 0.0D));
        this.setDeltaMovement(0.0D, this.onGround() ? 0.0D : this.getDeltaMovement().y, 0.0D);
        this.hasImpulse = false;
        this.setYRot(lockedYRot);
        this.setXRot(0.0F);
        this.setYHeadRot(lockedYHeadRot);
        this.setYBodyRot(lockedYRot);

        if (stateTicks > 0) {
            stateTicks--;
            this.entityData.set(DATA_STATE_TICKS, stateTicks);
        }
        if (stateTicks == 0) {
            if (warriorState == 1) {
                setWarriorState(2, DISINTEGRATED_HOLD_TICKS);
            } else if (warriorState == 2) {
                setWarriorState(3, RECOVER_TICKS);
            } else if (warriorState == 3) {
                convertToNormalWarrior();
            }
        }
    }

    /** 残骸在解体、停留和复原全过程都可以被正常攻击。 */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, amount);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void knockback(double strength, double x, double z) {
        // 无法被击退。
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        return false;
    }

    /**
     * 残骸不是生物索敌目标。原版 {@code TargetingConditions} 会通过这个方法过滤候选目标，
     * 因此新生物不会把残骸选为攻击目标；tick() 中的目标清理则负责清除已经存在的旧仇恨。
     */
    @Override
    public boolean canBeSeenAsEnemy() {
        return false;
    }

    @Override
    public void swing(net.minecraft.world.InteractionHand hand, boolean fromFallSource) {
        // 不播放挥手动作。
    }

    /**
     * 由 {@link ImmortalWarrior#die} 在生成残骸时调用：把解体前的仇恨关系以 UUID 形式记到残骸身上。
     *
     * <p>这些记录只在复原时兑现，不参与残骸自身的行为——残骸全程 {@code setNoAi(true)} 且每 tick
     * 清空目标，解体期间依旧不索敌、不还手、也不会被别的生物视作敌人。</p>
     */
    void carryHostilityFrom(ImmortalWarrior fallen) {
        this.pendingTargetId = uuidOf(fallen.getTarget());
        this.pendingRevengeId = uuidOf(fallen.getLastHurtByMob());
        this.pendingLastHurtMobId = uuidOf(fallen.getLastHurtMob());
    }

    /**
     * 由 {@link ImmortalWarrior#die} 在生成残骸时调用：把解体那一刻的整套装备拍成快照。
     *
     * <p>入世界时复制过去的装备可能被入世界流程或别的模组的装备接管清掉，快照是
     * 解体那一刻的真值，{@link #ensureGearIntact()} 每 tick 拿它兜底。</p>
     */
    void carryGearFrom(ImmortalWarrior fallen) {
        this.gearSnapshot = fallen.snapshotEquipment();
        this.gearDropChances = fallen.snapshotDropChances();
    }

    /**
     * 按解体瞬间的快照补齐装备：只补"快照里有、现在空了"的槽。
     *
     * <p>非空槽一律保留现况，这样玩家在残骸期间往它身上放的东西不会被覆盖；
     * 快照里本来就是空的槽也保持空，不会凭空长出一件装备。</p>
     */
    private void ensureGearIntact() {
        if (this.gearSnapshot == null) {
            return;
        }
        for (int i = 0; i < ImmortalWarrior.CARRIED_EQUIPMENT_SLOTS.length && i < this.gearSnapshot.length; i++) {
            EquipmentSlot slot = ImmortalWarrior.CARRIED_EQUIPMENT_SLOTS[i];
            if (!this.getItemBySlot(slot).isEmpty()) {
                continue;
            }
            ItemStack wanted = this.gearSnapshot[i];
            if (wanted == null || wanted.isEmpty()) {
                continue;
            }
            this.setItemSlot(slot, wanted.copy());
            if (this.gearDropChances != null && i < this.gearDropChances.length) {
                this.setDropChance(slot, this.gearDropChances[i]);
            }
        }
    }

    /**
     * 残骸期间挨的打并入反击记忆，由 {@link #tick()} 在清空自身目标之前调用。
     * 打残骸的仇记下来，复原成不死武士后照样会追。
     */
    private void captureInterimHostility() {
        LivingEntity attacker = this.getLastHurtByMob();
        if (attacker != null && attacker != this) {
            this.pendingRevengeId = attacker.getUUID();
        }
        LivingEntity victim = this.getLastHurtMob();
        if (victim != null && victim != this) {
            this.pendingLastHurtMobId = victim.getUUID();
        }
    }

    /**
     * 复原成正常不死武士时兑现保留的仇恨：原目标仍在就继续追杀原目标，原目标已经消失
     * （死亡、区块卸载、跑出追踪范围）时退而追打量过自己的那一个。
     */
    private void restoreHostility(ImmortalWarrior warrior) {
        LivingEntity original = this.resolvePending(warrior, this.pendingTargetId);
        LivingEntity attacker = this.resolvePending(warrior, this.pendingRevengeId);
        LivingEntity target = original != null ? original : attacker;
        if (target == null) {
            return;
        }
        LivingEntity lastVictim = this.resolvePending(warrior, this.pendingLastHurtMobId);
        if (lastVictim != null) {
            warrior.setLastHurtMob(lastVictim);
        }
        // 只在原目标失效时才动用反击记忆。"谁打过我"写成 lastHurtByMob 之后，
        // 原版 HurtByTargetGoal（目标组优先级 1）会在下一 tick 用它抢掉目标组，
        // 所以原目标还在时只挂目标、不写被打记录，避免刚恢复的仇恨被覆盖。
        if (original == null) {
            warrior.setLastHurtByMob(attacker);
        }
        // 必须在实体加入世界之后再挂目标：目标选择器只在实体开始 tick 后才会接管。
        warrior.setTarget(target);
    }

    /** 按 UUID 找回仍然有效的仇恨对象；失效（不存在、已死、是别的残骸、超出追踪范围）时返回 null。 */
    private LivingEntity resolvePending(Mob owner, UUID id) {
        if (id == null || id.equals(owner.getUUID()) || !(owner.level() instanceof ServerLevel level)) {
            return null;
        }
        if (!(level.getEntity(id) instanceof LivingEntity living) || !living.isAlive()) {
            return null;
        }
        if (living instanceof ImmortalWarriorRemains) {
            return null;
        }
        double range = owner.getAttributeValue(Attributes.FOLLOW_RANGE);
        return owner.distanceToSqr(living) <= range * range ? living : null;
    }

    private static UUID uuidOf(LivingEntity entity) {
        return entity == null ? null : entity.getUUID();
    }

    @Override
    protected BodyRotationControl createBodyControl() {
        return new FrozenBodyRotationControl(this);
    }

    @Override
    protected boolean transformsIntoRemainsOnDeath() {
        return false;
    }

    @Override
    protected boolean shouldDropLoot() {
        return true;
    }

    @Override
    public boolean shouldDropExperience() {
        return true;
    }

    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return LOOT_TABLE;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        if (this.getRandom().nextFloat() < 0.01F) {
            ItemStack sword = new ItemStack(GeneratedMod.ROYAL_LONGSWORD.get());
            sword.setDamageValue(this.getRandom().nextInt(Math.max(1, sword.getMaxDamage())));
            this.spawnAtLocation(sword);
        }
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("WarriorState")) {
            warriorState = tag.getInt("WarriorState");
            this.entityData.set(DATA_WARRIOR_STATE, warriorState);
        }
        if (tag.contains("StateTicks")) {
            stateTicks = tag.getInt("StateTicks");
            this.entityData.set(DATA_STATE_TICKS, stateTicks);
        }
        if (tag.contains("LockedYRot")) {
            lockedYRot = tag.getFloat("LockedYRot");
        }
        if (tag.contains("LockedYHeadRot")) {
            lockedYHeadRot = tag.getFloat("LockedYHeadRot");
        }
        if (warriorState == 0) {
            lockedYRot = this.getYRot();
            lockedYHeadRot = this.getYHeadRot();
        }
        if (tag.hasUUID(TAG_PENDING_TARGET)) {
            this.pendingTargetId = tag.getUUID(TAG_PENDING_TARGET);
        }
        if (tag.hasUUID(TAG_PENDING_REVENGE)) {
            this.pendingRevengeId = tag.getUUID(TAG_PENDING_REVENGE);
        }
        if (tag.hasUUID(TAG_PENDING_LAST_HURT_MOB)) {
            this.pendingLastHurtMobId = tag.getUUID(TAG_PENDING_LAST_HURT_MOB);
        }
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("WarriorState", warriorState);
        tag.putInt("StateTicks", stateTicks);
        tag.putFloat("LockedYRot", lockedYRot);
        tag.putFloat("LockedYHeadRot", lockedYHeadRot);
        // 仇恨记录要跟着存盘：区块重载、存档重启都不能把死前的目标忘掉。
        if (this.pendingTargetId != null) {
            tag.putUUID(TAG_PENDING_TARGET, this.pendingTargetId);
        }
        if (this.pendingRevengeId != null) {
            tag.putUUID(TAG_PENDING_REVENGE, this.pendingRevengeId);
        }
        if (this.pendingLastHurtMobId != null) {
            tag.putUUID(TAG_PENDING_LAST_HURT_MOB, this.pendingLastHurtMobId);
        }
    }

    private void convertToNormalWarrior() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        ImmortalWarrior warrior = GeneratedMod.IMMORTAL_WARRIOR.get().create(serverLevel);
        if (warrior == null) {
            return;
        }
        warrior.moveTo(this.getX(), this.getY(), this.getZ(), lockedYRot, 0.0F);
        warrior.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(warrior.blockPosition()),
                MobSpawnType.CONVERSION, null);
        warrior.setYRot(lockedYRot);
        warrior.setXRot(0.0F);
        warrior.setYHeadRot(lockedYHeadRot);
        warrior.setYBodyRot(lockedYRot);
        // 复原前先按解体瞬间的快照把残骸身上的装备补齐，再整套搬给新武士。
        this.ensureGearIntact();
        warrior.reassessWeaponGoal();
        serverLevel.addFreshEntity(warrior);
        // 入世界之后再戴装备：与残骸的生成同理，入世界前挂的装备可能不发给客户端。
        this.copyEquipmentTo(warrior);
        // 重生不丢仇恨：把解体前（以及残骸期间挨打）记下的目标原样接回新武士身上。
        this.restoreHostility(warrior);
        this.discard();
    }

    private static final class FrozenBodyRotationControl extends BodyRotationControl {
        FrozenBodyRotationControl(Mob mob) {
            super(mob);
        }

        @Override
        public void clientTick() {
            // 不更新躯干或头部朝向。
        }
    }

    private static final class FrozenLookControl extends LookControl {
        FrozenLookControl(Mob mob) {
            super(mob);
        }

        @Override
        public void tick() {
            // 不转向任何目标。
        }
    }
}
