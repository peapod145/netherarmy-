package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;

/**
 * 御首者三件套模型共用的姿态结算与逐面 UV 工具。
 *
 * <h3>为什么单独成类</h3>
 * <p>御首者的几何横跨三张贴图（本体 64x32、法杖 32x32、披风 16x32），必须拆成三个
 * {@code EntityModel} 分层渲染；而 bbmodel 的骨骼树是一体的——走路摆腿、施法抬杖、
 * 杖头旋转这些姿态要同时作用在不同层的同名骨骼上。姿态只依赖实体状态
 * （{@link HeadDominator#castAnimationTime(float)} 走同步实体数据），所以三个模型
 * 各自调用本类同一份结算，天然同帧同姿势，不需要层间拷贝。</p>
 *
 * <h3>动画数值（bbmodel 原样，未增删关键帧）</h3>
 * <ul>
 *   <li>walk（1s 循环）：左右腿 X ±25° 反相；</li>
 *   <li>cast spell（1.25s 单次）：左臂 X 0→50°（1s）→0（0.25s 回位）；
 *       staff 骨位移 (0, 8.75, -2) 同款三角波；group2（杖头）Y 轴 0→1440° 再回零。</li>
 * </ul>
 * <h3>换算口径（与 NetherCarrierModel 同一套，HELL ARM 铭牌游戏内验证过）</h3>
 * <p>渲染管线实证：{@code LivingEntityRenderer} 在模型上应用
 * {@code YP(180°−yaw)·scale(−1,−1,1)}，即 java(x,y,z)→world(x,−y,−z)。
 * 若 bb→java 只做 y 翻（x 恒等），复合变换是镜像（det=−1），游戏里看到的
 * 会是 Blockbench 预览的左右镜像——持杖手换边、披风/腰带图案左右反。
 * 正确换算必须再取反 x，使复合成为真旋转（det=+1）：</p>
 * <ul>
 *   <li>位置：java = (−x_bb, 24−y_bb, z_bb)；</li>
 *   <li>旋转：java(xRot,yRot,zRot) = (−rx, −ry, +rz)；</li>
 *   <li>位移：Δjava = (−dx, −dy, +dz)。</li>
 * </ul>
 * <p>例：腿向后摆 bb X=−25 ↔ java xRot=+25°；杖头自旋 bb Y +1440° ↔
 * java yRot −1440°。</p>
 * <p>注意：部件名（left_arm/right_arm 等）跟随 bbmodel 骨骼名。经 x 取反后，
 * 名为 left_arm 的持杖骨落在 java −5（原版 rightArm 槽位）——这是作者
 * Blockbench 预览里看到的持杖手，属预期结果，不要按 vanilla 槽位语义"纠正"。</p>
 */
final class HeadDominatorPose {
    /** bbmodel walk：腿 X ±25°。 */
    private static final float WALK_AMPLITUDE = 25.0F * Mth.DEG_TO_RAD;
    /** bbmodel 左臂的静态持杖姿势：X=+50°，Java y-down 空间取反为 -50°。 */
    private static final float BASE_LEFT_ARM_ANGLE = -50.0F * Mth.DEG_TO_RAD;
    /** bbmodel cast：左臂动画在静态姿势上叠加 X 0→50°（Java 取反）。 */
    private static final float CAST_ARM_ANGLE = 50.0F * Mth.DEG_TO_RAD;
    /** bbmodel cast：杖头 Y 轴 4 圈 = 1440°；java yRot 按口径取反（见类注释）。 */
    private static final float CAST_SPIN_ANGLE = 1440.0F * Mth.DEG_TO_RAD;
    /** bbmodel cast：staff 骨位移 (0, 8.75, -2)；java Δ=(−dx,−dy,+dz)。 */
    private static final float CAST_STAFF_LIFT = 8.75F;
    private static final float CAST_STAFF_FORWARD = 2.0F;

    private HeadDominatorPose() {
    }

    /**
     * 对一层模型应用完整姿态。不参与本层的骨骼传 {@code null}（例如法杖层没有腿）。
     * 只写动画真正驱动的通道，PartPose 里烘死的静态旋转（杖头 X-25°、杖尖 X-45°、
     * 装饰簇）绝不触碰。
     */
    static void apply(ModelPart body, ModelPart head, ModelPart rightLeg, ModelPart leftLeg,
                      ModelPart rightArm, ModelPart leftArm, ModelPart staff, ModelPart group2,
                      HeadDominator entity, float limbSwing, float limbSwingAmount,
                      float ageInTicks, float netHeadYaw, float headPitch) {
        float swing = Mth.cos(limbSwing * 0.6662F) * WALK_AMPLITUDE * limbSwingAmount;
        if (body != null) {
            body.setPos(0.0F, 12.0F, 0.0F);
        }
        if (head != null) {
            head.setPos(0.0F, 0.0F, 0.0F);
            head.xRot = headPitch * Mth.DEG_TO_RAD;
            head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
            head.zRot = 0.0F;
        }
        if (rightLeg != null) {
            rightLeg.setPos(1.9F, 12.0F, 0.0F);
            rightLeg.xRot = swing;
        }
        if (leftLeg != null) {
            leftLeg.setPos(-1.9F, 12.0F, 0.0F);
            leftLeg.xRot = -swing;
        }
        if (rightArm != null) {
            rightArm.setPos(5.0F, 2.0F, 0.0F);
            rightArm.xRot = 0.0F;
        }
        if (leftArm != null) {
            leftArm.setPos(-5.0F, 2.0F, 0.0F);
            // bbmodel left_arm 的基础 rotation=[50,0,0] 必须保留；否则手臂与法杖错位。
            leftArm.xRot = BASE_LEFT_ARM_ANGLE;
        }
        if (staff != null) {
            staff.setPos(-5.0F, 24.0F, -8.0F);
        }
        if (group2 != null) {
            group2.yRot = 0.0F;
        }
        float t = entity.castAnimationTime(ageInTicks);
        if (t >= 0.0F) {
            // 三角波：0→1（前 1s），1→0（后 0.25s），与关键帧线性段一致。
            float f = t <= 1.0F ? t : 1.0F - (t - 1.0F) * 4.0F;
            if (f > 0.0F) {
                if (leftArm != null) {
                    leftArm.xRot -= f * CAST_ARM_ANGLE;
                }
                if (staff != null) {
                    staff.y -= f * CAST_STAFF_LIFT;
                    staff.z -= f * CAST_STAFF_FORWARD;
                }
                if (group2 != null) {
                    group2.yRot -= f * CAST_SPIN_ANGLE;
                }
            }
        }
    }

    /**
     * 把一个立方体的单个面摆到贴图矩形左上角 (u,v)。
     * 原版 ModelPart$Cube 的面矩形（w,h,d 为取整后的盒尺寸）：
     * WEST=(U,V+d)、NORTH=(U+d,V+d)、EAST=(U+d+w,V+d)、SOUTH=(U+2d+w,V+d)、
     * UP=(U+d,V)、DOWN=(U+d+w,V)（与原版凋灵骷髅 64x32 人形网格逐面核对过：
     * 8x8x8 头盒 texOffs(0,0) 时 UP 落在 (8,0)、DOWN 落在 (16,0)），
     * 反解 texOffs 即可让该面精确落在 (u,v)。每个面单独 addBox，只点亮该面。
     */
    static void face(CubeListBuilder builder, Direction dir, float u, float v,
                     float x, float y, float z, float w, float h, float d) {
        int wi = (int) w;
        int hi = (int) h;
        int di = (int) d;
        int tu;
        int tv;
        switch (dir) {
            case WEST -> { tu = (int) u; tv = (int) (v - di); }
            case NORTH -> { tu = (int) (u - di); tv = (int) (v - di); }
            case EAST -> { tu = (int) (u - di - wi); tv = (int) (v - di); }
            case SOUTH -> { tu = (int) (u - 2 * di - wi); tv = (int) (v - di); }
            case UP -> { tu = (int) (u - di); tv = (int) v; }
            default -> { tu = (int) (u - di - wi); tv = (int) v; } // DOWN
        }
        builder.texOffs(tu, tv).addBox(x, y, z, w, h, d, EnumSet.of(dir));
    }
}
