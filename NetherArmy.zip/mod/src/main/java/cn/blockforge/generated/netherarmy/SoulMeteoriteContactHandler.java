package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 灵魂陨石方块"站上去就得易伤"的兜底扫描：每 {@value #SCAN_INTERVAL_TICKS} 刻查一次每个活物
 * 脚下的方块，是灵魂陨石就照 {@link SoulMeteoriteBlock#applyContactVulnerability} 挂易伤。
 *
 * <p>方块的 {@code stepOn}／{@code entityInside} 钩子只覆盖"实体确实从这一格挪动过"的情形：
 * 击退、被别的实体顶着走、上下半砖卡位、{@code noPhysics} 的追逐目标等等都可能让某个活物
 * 明明站在方块上却没有脚步声回调。需求是"接触就生效，且对一切活物生效（不只是玩家）"，
 * 所以再加一条不依赖任何钩子的路径：直接看脚下是什么方块。两条路径都调用同一个结算函数，
 * 且函数本身在"已有易伤"时直接返回，重复触发不会把等级一路顶高。</p>
 *
 * <p>脚下取的 {@code getOnPosLegacy()}（{@code y - 0.2} 所在一格），与 {@code stepOn} 判定
 * 站立面的口径一致；每 5 刻扫一次是为了开销——全球实体逐刻查方块没必要，10 秒的易伤
 * 也不差这 4 刻。</p>
 */
public final class SoulMeteoriteContactHandler {
    /** 扫描间隔：5 刻。 */
    public static final int SCAN_INTERVAL_TICKS = 5;

    private SoulMeteoriteContactHandler() {
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        if (!(event.getEntity() instanceof LivingEntity living) || living.level().isClientSide()) {
            return;
        }
        if (living.tickCount % SCAN_INTERVAL_TICKS != 0
                || living.getEffect(GeneratedMod.VULNERABILITY) != null) {
            return;
        }
        BlockPos standingOn = living.getOnPosLegacy();
        BlockState state = living.level().getBlockState(standingOn);
        if (state.is(GeneratedMod.SOUL_METEORITE_BLOCK.get())) {
            SoulMeteoriteBlock.applyContactVulnerability(living.level(), living);
        }
    }
}
