package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.phys.AABB;

import java.util.List;

/** 皇家长剑的剑类行为：保留原版剑的横扫、耐久和附魔行为。 */
public final class RoyalLongswordItem extends SwordItem {
    /** 皇家长剑的横扫宽度比原版剑类扩大 10%。 */
    public static final double SWEEP_WIDTH_MULTIPLIER = 1.10D;

    public RoyalLongswordItem(Tier tier, Item.Properties properties) {
        super(tier, properties);
    }

    /**
     * 伤害 7、攻击速度 1.4、主手攻击距离 3.6 格（比铁剑的 3.0 格远 20%）。
     * 直接提供物品属性组件，确保玩家与持剑怪物使用同一组数值。
     */
    @Override
    public ItemAttributeModifiers getDefaultAttributeModifiers() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID,
                        6.0D, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID,
                        1.4D - 4.0D, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                        ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "royal_longsword_reach"),
                        0.20D, AttributeModifier.Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.MAINHAND)
                .build();
    }

    /** 皇家长剑命中钩子走原版剑的耐久扣除与命中统计。 */
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public AABB getSweepHitBox(ItemStack stack, Player player, Entity target) {
        AABB defaultBox = target.getBoundingBox().inflate(1.0D, 0.25D, 1.0D);
        double centerX = (defaultBox.minX + defaultBox.maxX) * 0.5D;
        double centerZ = (defaultBox.minZ + defaultBox.maxZ) * 0.5D;
        double halfWidthX = (defaultBox.maxX - defaultBox.minX) * 0.5D * SWEEP_WIDTH_MULTIPLIER;
        double halfWidthZ = (defaultBox.maxZ - defaultBox.minZ) * 0.5D * SWEEP_WIDTH_MULTIPLIER;
        return new AABB(
                centerX - halfWidthX, defaultBox.minY, centerZ - halfWidthZ,
                centerX + halfWidthX, defaultBox.maxY, centerZ + halfWidthZ);
    }

    /** 灰色描述：攻击无视护甲。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.royal_longsword.tooltip.pierce_armor")
                .withStyle(ChatFormatting.GRAY));
    }

    /** 皇家长剑的工具材料：耐久 864，附魔值与铁剑一致，炼狱晶碎片可修复。 */
    public static final class RoyalTier implements Tier {
        @Override
        public int getUses() {
            return 864;
        }

        @Override
        public float getSpeed() {
            return 6.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 0.0F;
        }

        @Override
        public net.minecraft.tags.TagKey<Block> getIncorrectBlocksForDrops() {
            return BlockTags.INCORRECT_FOR_IRON_TOOL;
        }

        @Override
        public int getEnchantmentValue() {
            return 14;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(GeneratedMod.NETHER_CRYSTAL_SHARD.get());
        }
    }
}
