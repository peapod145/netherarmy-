package cn.blockforge.generated.netherarmy;

import java.util.List;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;

/**
 * 下界客栈容器随机化。
 *
 * <p>模板 {@code nether_inn.nbt} 里的箱子和木桶存的是一份固定的 {@code Items}
 * 列表（没有 LootTable），原版直接按槽位原样放置，每间客栈内容完全相同。
 * 本类在结构放置完成（{@link NetherSurfaceJigsawStructure#afterPlace}）后按 chunk
 * 就地改写容器内容：
 * <ul>
 *   <li>木桶：物品堆的位置随机打乱，堆数与每堆数量不变；</li>
 *   <li>箱子：位置随机打乱，堆数再随机增加或减少 1~3 堆（增加时从箱内已有物品中
 *       随机抽取并给 1~4 个的数量，减少时随机移除整堆，至少保留 1 堆）。</li>
 * </ul>
 *
 * <p>扫描与洗牌细节见 {@link StructureContainers}。
 */
public final class NetherInnContainerRandomizer {

    private NetherInnContainerRandomizer() {
    }

    /** 扫描本次放置落在当前可写区域内的容器并随机化内容。 */
    public static void randomizePieces(WorldGenLevel level, BoundingBox writableArea,
                                       PiecesContainer pieces, RandomSource random) {
        StructureContainers.forEachFixedContainer(level, writableArea, pieces, (container, barrel) -> {
            if (barrel) {
                shuffleOnly(container, random);
            } else {
                shuffleAndResizeChest(container, random);
            }
            container.setChanged();
        });
    }

    /** 木桶：槽位随机打乱，堆数与数量完全不变。 */
    private static void shuffleOnly(RandomizableContainer container, RandomSource random) {
        List<ItemStack> stacks = StructureContainers.collect(container);
        if (stacks.size() < 2) {
            return;
        }
        StructureContainers.fisherYates(stacks, random);
        StructureContainers.placeInto(container, stacks, random);
    }

    /** 箱子：槽位随机打乱，堆数随机 ±1~3。 */
    private static void shuffleAndResizeChest(RandomizableContainer container, RandomSource random) {
        List<ItemStack> stacks = StructureContainers.collect(container);
        if (stacks.isEmpty()) {
            return;
        }
        int capacity = container.getContainerSize();
        int delta = 1 + random.nextInt(3);
        if (random.nextBoolean()) {
            int toAdd = Math.min(delta, capacity - stacks.size());
            for (int i = 0; i < toAdd; i++) {
                ItemStack source = stacks.get(random.nextInt(stacks.size()));
                int count = Math.min(1 + random.nextInt(4), source.getMaxStackSize());
                stacks.add(new ItemStack(source.getItem(), count));
            }
        } else {
            int toRemove = Math.min(delta, stacks.size() - 1);
            for (int i = 0; i < toRemove; i++) {
                stacks.remove(random.nextInt(stacks.size()));
            }
        }
        StructureContainers.fisherYates(stacks, random);
        StructureContainers.placeInto(container, stacks, random);
    }
}
