package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;

/**
 * 下界客栈容器随机化。
 *
 * <p>模板 {@code nether_inn.nbt} 里的箱子和木桶存的是一份固定的 {@code Items}
 * 列表（没有 LootTable），原版直接按槽位原样放置，每间客栈内容完全相同。
 * 本类在结构放置完成（{@link NetherSurfaceJigsawStructure#afterPlace}）后按 chunk
 * 就地改写容器内容：
 * <ul>
 *   <li>木桶：物品堆的位置随机打乱，堆数与每堆数量不变；</li>
 *   <li>箱子：位置随机打乱，堆数再随机增加或减少 1~3 堆（增加时从箱内已有物品中
 *       随机抽取并给 1~4 个的数量，减少时随机移除整堆，至少保留 1 堆）。</li>
 * </ul>
 *
 * <p>由于 1.21.1 的结构放置按“当前生成 chunk 的列”裁剪（
 * {@code ChunkGenerator#getWritableArea} → {@code StructurePiece#postProcess}），
 * 每个方块只会被所属 chunk 的那趟放置写一次，{@code afterPlace} 也只在同一趟里被
 * 调用一次，因此这里逐 chunk 扫描不会重复洗牌，也没有跨线程竞态。
 */
public final class NetherInnContainerRandomizer {

    private NetherInnContainerRandomizer() {
    }

    /**
     * 扫描本次放置落在当前可写区域内的容器并随机化内容。
     *
     * @param writableArea 当前生成 chunk 的可写区域（afterPlace 收到的 box）
     */
    public static void randomizePieces(WorldGenLevel level, BoundingBox writableArea,
                                       PiecesContainer pieces, RandomSource random) {
        for (StructurePiece piece : pieces.pieces()) {
            BoundingBox pieceBox = piece.getBoundingBox();
            int minX = Math.max(writableArea.minX(), pieceBox.minX());
            int minY = Math.max(writableArea.minY(), pieceBox.minY());
            int minZ = Math.max(writableArea.minZ(), pieceBox.minZ());
            int maxX = Math.min(writableArea.maxX(), pieceBox.maxX());
            int maxY = Math.min(writableArea.maxY(), pieceBox.maxY());
            int maxZ = Math.min(writableArea.maxZ(), pieceBox.maxZ());
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        cursor.set(x, y, z);
                        BlockState state = level.getBlockState(cursor);
                        boolean barrel = state.is(Blocks.BARREL);
                        boolean chest = state.is(Blocks.CHEST) || state.is(Blocks.TRAPPED_CHEST);
                        if (!barrel && !chest) {
                            continue;
                        }
                        BlockEntity blockEntity = level.getBlockEntity(cursor);
                        if (!(blockEntity instanceof RandomizableContainer container)) {
                            continue;
                        }
                        // 带战利品表的容器交给原版机制，不改动
                        if (container.getLootTable() != null) {
                            continue;
                        }
                        if (barrel) {
                            shuffleOnly(container, random);
                        } else {
                            shuffleAndResizeChest(container, random);
                        }
                        container.setChanged();
                    }
                }
            }
        }
    }

    /** 木桶：槽位随机打乱，堆数与数量完全不变。 */
    private static void shuffleOnly(RandomizableContainer container, RandomSource random) {
        List<ItemStack> stacks = collect(container);
        if (stacks.size() < 2) {
            return;
        }
        fisherYates(stacks, random);
        placeInto(container, stacks, random);
    }

    /** 箱子：槽位随机打乱，堆数随机 ±1~3。 */
    private static void shuffleAndResizeChest(RandomizableContainer container, RandomSource random) {
        List<ItemStack> stacks = collect(container);
        if (stacks.isEmpty()) {
            return;
        }
        int capacity = container.getContainerSize();
        int delta = 1 + random.nextInt(3);
        if (random.nextBoolean()) {
            int toAdd = Math.min(delta, capacity - stacks.size());
            for (int i = 0; i < toAdd; i++) {
                ItemStack source = stacks.get(random.nextInt(stacks.size()));
                int count = Math.min(1 + random.nextInt(4), source.getMaxStackSize());
                stacks.add(new ItemStack(source.getItem(), count));
            }
        } else {
            int toRemove = Math.min(delta, stacks.size() - 1);
            for (int i = 0; i < toRemove; i++) {
                stacks.remove(random.nextInt(stacks.size()));
            }
        }
        fisherYates(stacks, random);
        placeInto(container, stacks, random);
    }

    private static List<ItemStack> collect(RandomizableContainer container) {
        List<ItemStack> stacks = new ArrayList<>();
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (!stack.isEmpty()) {
                stacks.add(stack.copy());
            }
        }
        return stacks;
    }

    /** 清空后把每堆物品放进互不相同的随机槽位。 */
    private static void placeInto(RandomizableContainer container, List<ItemStack> stacks,
                                  RandomSource random) {
        int capacity = container.getContainerSize();
        container.clearContent();
        List<Integer> slots = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            slots.add(i);
        }
        fisherYates(slots, random);
        int n = Math.min(stacks.size(), capacity);
        for (int i = 0; i < n; i++) {
            container.setItem(slots.get(i), stacks.get(i));
        }
    }

    private static <T> void fisherYates(List<T> list, RandomSource random) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            T tmp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, tmp);
        }
    }
}
