package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/**
 * 节肢杀手强化：消灭节肢生物的最后一击额外结算三项收益。
 *
 * <ul>
 *   <li>在尸体位置额外掉落（附魔等级 × 50%）点经验值，奇数等级按 0.5 期望随机取整；</li>
 *   <li>攻击者获得持续（附魔等级 × 2）秒的生命恢复 I；</li>
 *   <li>有（附魔等级 × 10%）的概率为这件武器恢复（附魔等级 × 1）点耐久。</li>
 * </ul>
 *
 * <p>节肢生物判定沿用原版附魔效果的同一标签
 * {@code #minecraft:sensitive_to_bane_of_arthropods}；攻击者不限玩家，
 * 任何持有该附魔武器的生物完成最后一击都会结算。</p>
 */
public final class BaneOfArthropodsKillHandler {

    private BaneOfArthropodsKillHandler() {
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !victim.getType().is(EntityTypeTags.SENSITIVE_TO_BANE_OF_ARTHROPODS)) {
            return;
        }

        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == victim) {
            return;
        }

        // 与原版武器附魔判定一致：箭矢取发射它的武器，其余取攻击者主手。
        ItemStack weapon = event.getSource().getDirectEntity() instanceof AbstractArrow arrow
                ? arrow.getWeaponItem()
                : attacker.getMainHandItem();
        if (weapon == null || weapon.isEmpty()) {
            return;
        }

        Holder<Enchantment> bane = victim.level().registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT)
                .get(Enchantments.BANE_OF_ARTHROPODS)
                .orElse(null);
        if (bane == null) {
            return;
        }
        int level = EnchantmentHelper.getItemEnchantmentLevel(bane, weapon);
        if (level <= 0) {
            return;
        }

        // 额外经验：期望值为 等级 × 50%，奇数等级以 0.5 的概率多掉 1 点。
        int experience = level / 2;
        if ((level & 1) == 1 && victim.getRandom().nextBoolean()) {
            experience++;
        }
        if (experience > 0 && victim.level() instanceof ServerLevel serverLevel) {
            ExperienceOrb.award(serverLevel, victim.position(), experience);
        }

        // 生命恢复 I，持续 等级 × 2 秒。
        attacker.addEffect(new MobEffectInstance(MobEffects.REGENERATION, level * 2 * 20, 0));

        // 等级 × 10% 概率恢复 等级 × 1 点耐久。
        if (victim.getRandom().nextFloat() < level * 0.1F
                && weapon.isDamageableItem()
                && weapon.getDamageValue() > 0) {
            weapon.setDamageValue(Math.max(0, weapon.getDamageValue() - level));
        }
    }
}
