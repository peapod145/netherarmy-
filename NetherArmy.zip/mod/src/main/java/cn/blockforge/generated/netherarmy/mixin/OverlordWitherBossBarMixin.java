package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import cn.blockforge.generated.netherarmy.OverlordWitherBoss;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 阻止 WitherBoss 私有 bossEvent 给霸主凋灵重复添加原版血条。 */
@Mixin(WitherBoss.class)
public abstract class OverlordWitherBossBarMixin {
    @Inject(method = "startSeenByPlayer", at = @At("HEAD"), cancellable = true)
    private void netherarmy$skipVanillaBar(ServerPlayer player, CallbackInfo callback) {
        if ((Object) this instanceof OverlordWitherBoss) {
            callback.cancel();
        }
    }

    @Inject(method = "stopSeenByPlayer", at = @At("HEAD"), cancellable = true)
    private void netherarmy$skipVanillaBarRemove(ServerPlayer player, CallbackInfo callback) {
        if ((Object) this instanceof OverlordWitherBoss) {
            callback.cancel();
        }
    }
}
