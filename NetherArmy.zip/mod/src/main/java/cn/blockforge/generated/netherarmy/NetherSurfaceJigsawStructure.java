package cn.blockforge.generated.netherarmy;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.WorldGenerationContext;
import net.minecraft.world.level.levelgen.heightproviders.HeightProvider;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;
import net.minecraft.world.level.levelgen.structure.pools.DimensionPadding;
import net.minecraft.world.level.levelgen.structure.pools.JigsawPlacement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;
import net.minecraft.world.level.levelgen.structure.pools.alias.PoolAliasLookup;
import net.minecraft.world.level.levelgen.structure.templatesystem.LiquidSettings;

/**
 * 下界专用的拼图（jigsaw）结构。
 *
 * <p>原版 {@code minecraft:jigsaw} 的 {@code project_start_to_heightmap} 走的是
 * {@code ChunkGenerator#getBaseHeight}，它从世界顶向下扫描噪声列。下界顶部是整片
 * 实心噪声屋顶（y≈126），所以在下界里任何 heightmap 都会返回屋顶高度，建筑被钉在
 * 世界顶被裁掉——这正是 /locate 能找到坐标、地面却看不到下界客栈的原因。
 * 这也是原版从不在下界使用数据驱动 jigsaw 结构的原因。
 *
 * <p>本类改为像下界要塞那样，从 {@code minBuildHeight} 向上扫描噪声列，找到真正的
 * 下界地面（岩浆湖面也算实体，会跳过），把结构放到地面之上。
 */
public class NetherSurfaceJigsawStructure extends Structure {
    public static final MapCodec<NetherSurfaceJigsawStructure> CODEC =
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    settingsCodec(instance),
                    StructureTemplatePool.CODEC.fieldOf("start_pool").forGetter(s -> s.startPool),
                    ExtraCodecs.POSITIVE_INT.optionalFieldOf("max_depth", 1).forGetter(s -> s.maxDepth),
                    HeightProvider.CODEC.fieldOf("start_height").forGetter(s -> s.startHeight),
                    Codec.BOOL.optionalFieldOf("use_expansion_hack", false).forGetter(s -> s.useExpansionHack),
                    ExtraCodecs.POSITIVE_INT.optionalFieldOf("max_distance_from_center", 80)
                            .forGetter(s -> s.maxDistanceFromCenter),
                    Codec.STRING.validate(s -> switch (s) {
                            case "surface", "ceiling", "buried" -> com.mojang.serialization.DataResult.success(s);
                            default -> com.mojang.serialization.DataResult.error(
                                    () -> "Unknown attach mode '" + s + "' (expected surface/ceiling/buried)");
                        }).optionalFieldOf("attach", "surface").forGetter(s -> s.attach),
                    ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("template_height", 0)
                            .forGetter(s -> s.templateHeight)
            ).apply(instance, NetherSurfaceJigsawStructure::new));

    private final Holder<StructureTemplatePool> startPool;
    private final int maxDepth;
    private final HeightProvider startHeight;
    private final boolean useExpansionHack;
    private final int maxDistanceFromCenter;
    /** 放置模式：surface=立在地面上（默认）；ceiling=从洞穴顶板垂下；buried=沉入地面。 */
    private final String attach;
    /**
     * 模板高度，含义随模式变化：
     * <ul>
     *   <li>surface：所需的最小净空高度（0 表示不检查），洞穴高度不足则跳过放置；</li>
     *   <li>ceiling：模板竖向高度，顶排落在顶板固体下 2 格（对应原 Formations 库
     *       {@code ground_level = 高度 + 3} 的悬挂量）；</li>
     *   <li>buried：模板竖向高度，整体向下沉入地面这么多格。</li>
     * </ul>
     */
    private final int templateHeight;

    public NetherSurfaceJigsawStructure(
            Structure.StructureSettings settings,
            Holder<StructureTemplatePool> startPool,
            int maxDepth,
            HeightProvider startHeight,
            boolean useExpansionHack,
            int maxDistanceFromCenter,
            String attach,
            int templateHeight) {
        super(settings);
        this.startPool = startPool;
        this.maxDepth = maxDepth;
        this.startHeight = startHeight;
        this.useExpansionHack = useExpansionHack;
        this.maxDistanceFromCenter = maxDistanceFromCenter;
        this.attach = attach;
        this.templateHeight = templateHeight;
    }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        BlockPos blockpos = this.getBasePosition(context);
        if (blockpos == null) {
            return Optional.empty();
        }
        return JigsawPlacement.addPieces(
                context,
                this.startPool,
                Optional.empty(),
                this.maxDepth,
                blockpos,
                this.useExpansionHack,
                Optional.empty(),
                this.maxDistanceFromCenter,
                PoolAliasLookup.EMPTY,
                DimensionPadding.ZERO,
                LiquidSettings.IGNORE_WATERLOGGING);
    }

    /**
     * 结构落进世界后（1.21.1 里按当前生成 chunk 的可写区域逐 chunk 回调一次），
     * 把模板里固定内容的箱子/木桶随机化：木桶只打乱槽位、总数不变；箱子在打乱
     * 槽位的同时随机增减 1~3 堆物品。
     */
    @Override
    public void afterPlace(WorldGenLevel level, StructureManager structureManager,
                           ChunkGenerator generator, RandomSource random, BoundingBox box,
                           ChunkPos chunkPos, PiecesContainer pieces) {
        super.afterPlace(level, structureManager, generator, random, box, chunkPos, pieces);
        NetherInnContainerRandomizer.randomizePieces(level, box, pieces, random);
    }

    /**
     * 在起始 chunk 的四角与中心共 5 个点探测下界地面/顶板高度，按放置模式取中位数，
     * 避免把建筑放在陡坡一侧导致整栋埋进地里。
     */
    private BlockPos getBasePosition(GenerationContext context) {
        ChunkPos chunkpos = context.chunkPos();
        int minX = chunkpos.getMinBlockX();
        int minZ = chunkpos.getMinBlockZ();
        LevelHeightAccessor heightAccessor = context.heightAccessor();
        int[][] samplePoints = {{0, 0}, {15, 0}, {0, 15}, {15, 15}, {8, 8}};
        int[] floors = new int[samplePoints.length];
        int[] roofs = new int[samplePoints.length];
        for (int i = 0; i < samplePoints.length; i++) {
            NoiseColumn column = context.chunkGenerator().getBaseColumn(
                    minX + samplePoints[i][0], minZ + samplePoints[i][1],
                    heightAccessor, context.randomState());
            floors[i] = firstAirAboveFloor(column, heightAccessor);
            roofs[i] = firstSolidAbove(column, heightAccessor, floors[i]);
        }

        int baseY;
        switch (this.attach) {
            case "ceiling" -> {
                // 从洞穴顶板垂下（矿晶坠簇）：要求顶板大致平整，否则跳过
                int[] sorted = roofs.clone();
                Arrays.sort(sorted);
                int roofY = sorted[sorted.length / 2];
                if (roofY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null; // 头顶没有顶板，无处可挂
                }
                for (int roof : roofs) {
                    if (Math.abs(roof - roofY) > 6) {
                        return null; // 各采样点顶板高低差过大，挂出来会穿顶
                    }
                }
                // 顶排放到顶板固体下 2 格（与原 Formations ground_level=高度+3 的悬挂量一致）
                baseY = roofY - this.templateHeight - 2;
                if (baseY < heightAccessor.getMinBuildHeight()) {
                    return null; // 洞穴太矮，放不下坠簇
                }
            }
            case "buried" -> {
                // 沉入地面（球笼）：整体下移一个模板高度，顶部与地面齐平
                int[] sorted = floors.clone();
                Arrays.sort(sorted);
                int floorY = sorted[sorted.length / 2];
                if (floorY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null;
                }
                int sink = Math.min(this.templateHeight,
                        floorY - heightAccessor.getMinBuildHeight());
                baseY = floorY - sink;
            }
            default -> {
                // 立在地面上（默认，含原下界客栈/靶场逻辑）
                Arrays.sort(floors);
                int surfaceY = floors[floors.length / 2];
                if (surfaceY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null; // 整列都是实心（大概率顶到了噪声屋顶），放弃本次放置
                }
                // 保证结构顶部不与下界屋顶（约 y=118 起）重叠
                baseY = Math.min(surfaceY, heightAccessor.getMaxBuildHeight() - 26);
                baseY = Math.max(baseY, heightAccessor.getMinBuildHeight());
                if (this.templateHeight > 0) {
                    // 净空检查：取最矮的一段顶板，模板必须能完整放进地面与顶板之间
                    int[] sortedRoofs = roofs.clone();
                    Arrays.sort(sortedRoofs);
                    int lowestRoof = sortedRoofs[0];
                    if (lowestRoof - baseY < this.templateHeight) {
                        return null;
                    }
                }
            }
        }
        int offset = this.startHeight.sample(
                context.random(),
                new WorldGenerationContext(context.chunkGenerator(), heightAccessor));
        return new BlockPos(minX, baseY + offset, minZ);
    }

    /**
     * 从最低高度向上扫描噪声列，返回第一个空气方块的高度（岩浆、方块都算实体，
     * 会停在它们上方，让建筑落在地面或岩浆面上而不是泡在里面）。
     */
    private static int firstAirAboveFloor(NoiseColumn column, LevelHeightAccessor heightAccessor) {
        int y = heightAccessor.getMinBuildHeight();
        int top = heightAccessor.getMaxBuildHeight();
        while (y < top && !column.getBlock(y).isAir()) {
            y++;
        }
        return y;
    }

    /** 从地面空气继续向上扫描，返回第一个固体方块的高度（即洞穴顶板）。 */
    private static int firstSolidAbove(NoiseColumn column, LevelHeightAccessor heightAccessor, int fromY) {
        int y = Math.max(fromY, heightAccessor.getMinBuildHeight());
        int top = heightAccessor.getMaxBuildHeight();
        while (y < top && column.getBlock(y).isAir()) {
            y++;
        }
        return y;
    }

    @Override
    public StructureType<?> type() {
        return GeneratedMod.NETHER_SURFACE_JIGSAW_TYPE.get();
    }
}
