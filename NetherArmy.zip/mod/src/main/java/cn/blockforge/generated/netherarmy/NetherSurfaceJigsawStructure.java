package cn.blockforge.generated.netherarmy;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.WorldGenerationContext;
import net.minecraft.world.level.levelgen.heightproviders.HeightProvider;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;
import net.minecraft.world.level.levelgen.structure.pools.DimensionPadding;
import net.minecraft.world.level.levelgen.structure.pools.JigsawPlacement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;
import net.minecraft.world.level.levelgen.structure.pools.alias.PoolAliasLookup;
import net.minecraft.world.level.levelgen.structure.templatesystem.LiquidSettings;

/**
 * 下界专用的拼图（jigsaw）结构。
 *
 * <p>原版 {@code minecraft:jigsaw} 的 {@code project_start_to_heightmap} 走的是
 * {@code ChunkGenerator#getBaseHeight}，它从世界顶向下扫描噪声列。下界顶部是整片
 * 实心噪声屋顶（y≈126），所以在下界里任何 heightmap 都会返回屋顶高度，建筑被钉在
 * 世界顶被裁掉——这正是 /locate 能找到坐标、地面却看不到下界客栈的原因。
 * 这也是原版从不在下界使用数据驱动 jigsaw 结构的原因。
 *
 * <p>本类改为像下界要塞那样，从 {@code minBuildHeight} 向上扫描噪声列，找到真正的
 * 下界地面（岩浆湖面也算实体，会跳过），把结构放到地面之上。
 */
public class NetherSurfaceJigsawStructure extends Structure {
    /** 下界戍城模板占地 56×57，岩浆海采样跨度按它取（相对起始 chunk 最小角）。 */
    private static final int LAVA_CHECK_SPAN_X = 55;
    private static final int LAVA_CHECK_SPAN_Z = 56;
    /** 查询路径上做群系预判用的固定高度（下界的生物群系不分层，取中间高度即可）。 */
    private static final int BIOME_SAMPLE_Y = 64;

    public static final MapCodec<NetherSurfaceJigsawStructure> CODEC =
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    settingsCodec(instance),
                    StructureTemplatePool.CODEC.fieldOf("start_pool").forGetter(s -> s.startPool),
                    ExtraCodecs.POSITIVE_INT.optionalFieldOf("max_depth", 1).forGetter(s -> s.maxDepth),
                    HeightProvider.CODEC.fieldOf("start_height").forGetter(s -> s.startHeight),
                    Codec.BOOL.optionalFieldOf("use_expansion_hack", false).forGetter(s -> s.useExpansionHack),
                    ExtraCodecs.POSITIVE_INT.optionalFieldOf("max_distance_from_center", 80)
                            .forGetter(s -> s.maxDistanceFromCenter),
                    Codec.STRING.validate(s -> switch (s) {
                            case "surface", "ceiling", "buried" -> com.mojang.serialization.DataResult.success(s);
                            default -> com.mojang.serialization.DataResult.error(
                                    () -> "Unknown attach mode '" + s + "' (expected surface/ceiling/buried)");
                        }).optionalFieldOf("attach", "surface").forGetter(s -> s.attach),
                    ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("template_height", 0)
                            .forGetter(s -> s.templateHeight),
                    Codec.BOOL.optionalFieldOf("avoid_lava", false).forGetter(s -> s.avoidLava),
                    Codec.STRING.validate(s -> switch (s) {
                            case "inn", "garrison", "none" -> com.mojang.serialization.DataResult.success(s);
                            default -> com.mojang.serialization.DataResult.error(
                                    () -> "Unknown container mode '" + s + "' (expected inn/garrison/none)");
                        }).optionalFieldOf("container_mode", "inn").forGetter(s -> s.containerMode)
            ).apply(instance, NetherSurfaceJigsawStructure::new));

    private final Holder<StructureTemplatePool> startPool;
    private final int maxDepth;
    private final HeightProvider startHeight;
    private final boolean useExpansionHack;
    private final int maxDistanceFromCenter;
    /** 放置模式：surface=立在地面上（默认）；ceiling=从洞穴顶板垂下；buried=沉入地面。 */
    private final String attach;
    /**
     * 模板高度，含义随模式变化：
     * <ul>
     *   <li>surface：所需的最小净空高度（0 表示不检查），洞穴高度不足则跳过放置；</li>
     *   <li>ceiling：模板竖向高度，顶排落在顶板固体下 2 格（对应原 Formations 库
     *       {@code ground_level = 高度 + 3} 的悬挂量）；</li>
     *   <li>buried：模板竖向高度，整体向下沉入地面这么多格。</li>
     * </ul>
     */
    private final int templateHeight;
    /** 是否避开岩浆海：模板覆盖范围内任意采样列的地面是岩浆就不生成。 */
    private final boolean avoidLava;
    /**
     * 放置完成后的容器处理方式：
     * <ul>
     *   <li>{@code inn}（默认）：下界客栈规则，木桶只洗槽位、箱子洗槽位并增减堆数；</li>
     *   <li>{@code garrison}：戍城规则，箱子与木桶都洗槽位并让每堆数量 ±3，木桶另有
     *       0.1% 概率刷出炼狱晶马铠；</li>
     *   <li>{@code none}：保持模板原样。</li>
     * </ul>
     */
    private final String containerMode;

    public NetherSurfaceJigsawStructure(
            Structure.StructureSettings settings,
            Holder<StructureTemplatePool> startPool,
            int maxDepth,
            HeightProvider startHeight,
            boolean useExpansionHack,
            int maxDistanceFromCenter,
            String attach,
            int templateHeight,
            boolean avoidLava,
            String containerMode) {
        super(settings);
        this.startPool = startPool;
        this.maxDepth = maxDepth;
        this.startHeight = startHeight;
        this.useExpansionHack = useExpansionHack;
        this.maxDistanceFromCenter = maxDistanceFromCenter;
        this.attach = attach;
        this.templateHeight = templateHeight;
        this.avoidLava = avoidLava;
        this.containerMode = containerMode;
    }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        boolean query = StructureLocateGuard.inPresenceCheck();
        if (query && !StructureLocateGuard.tryBeginWork()) {
            // /locate 这批扫描的判定预算已经用完：立刻判空。
            // 原版把结果记成"不存在"，不会触发同步区块生成，4 万个候选剩余部分
            // 几乎不花时间——这是"指令一敲游戏卡住几十秒"的直接解药。
            return Optional.empty();
        }
        if (!StructureSetSelection.isSelectedForThisChunk(context, this, query)) {
            return Optional.empty();
        }
        if (query && !isBiomePlausible(context)) {
            // 在别的维度里 /locate 本结构：连噪声列都不用取，直接判空。
            // 原版最后的 isValidBiome 还会再按真实落点判一次，这里只是提前砍掉
            // 确定不可能的那一类候选（下层判定只会更严，不会多报）。
            return Optional.empty();
        }
        BlockPos blockpos = this.getBasePosition(context);
        if (blockpos == null) {
            return Optional.empty();
        }
        return JigsawPlacement.addPieces(
                context,
                this.startPool,
                Optional.empty(),
                this.maxDepth,
                blockpos,
                this.useExpansionHack,
                Optional.empty(),
                this.maxDistanceFromCenter,
                PoolAliasLookup.EMPTY,
                DimensionPadding.ZERO,
                LiquidSettings.IGNORE_WATERLOGGING);
    }

    /**
     * 廉价的生物群系预判：按起始 chunk 的最小角、在固定高度上取一次生物群系，
     * 用结构自己的群系集合过一遍。
     *
     * <p>原版 {@code Structure#findValidGenerationPoint} 是在拼图放置<b>之后</b>才按
     * 真实落点抽样判群系的，也就是说在下界以外的维度里 /locate 本结构时会先把
     * 4 万个候选的噪声列与拼图全算一遍、再逐个否掉。这里把"群系不对"提前到最前面，
     * 每个候选只剩一次群系抽样。</p>
     *
     * <p>固定用 {@link #BIOME_SAMPLE_Y}：下界的生物群系在竖直方向上没有分层，
     * 这个近似足够；而且预判只在查询路径生效，生成路径仍由原版按真实落点判定。</p>
     */
    private static boolean isBiomePlausible(GenerationContext context) {
        ChunkPos chunkPos = context.chunkPos();
        Holder<Biome> biome = context.biomeSource().getNoiseBiome(
                QuartPos.fromBlock(chunkPos.getMinBlockX()),
                QuartPos.fromBlock(BIOME_SAMPLE_Y),
                QuartPos.fromBlock(chunkPos.getMinBlockZ()),
                context.randomState().sampler());
        return context.validBiome().test(biome);
    }

    /**
     * 结构落进世界后（1.21.1 里按当前生成 chunk 的可写区域逐 chunk 回调一次），
     * 按 {@code container_mode} 改写模板里固定内容的箱子/木桶。
     */
    @Override
    public void afterPlace(WorldGenLevel level, StructureManager structureManager,
                           ChunkGenerator generator, RandomSource random, BoundingBox box,
                           ChunkPos chunkPos, PiecesContainer pieces) {
        super.afterPlace(level, structureManager, generator, random, box, chunkPos, pieces);
        switch (this.containerMode) {
            case "garrison" -> NetherGarrisonContainerRandomizer.randomizePieces(level, box, pieces, random);
            case "none" -> {
                // 保持模板原样
            }
            default -> NetherInnContainerRandomizer.randomizePieces(level, box, pieces, random);
        }
    }

    /**
     * 在起始 chunk 的四角与中心共 5 个点探测下界地面/顶板高度，按放置模式取中位数，
     * 避免把建筑放在陡坡一侧导致整栋埋进地里。
     */
    private BlockPos getBasePosition(GenerationContext context) {
        ChunkPos chunkpos = context.chunkPos();
        int minX = chunkpos.getMinBlockX();
        int minZ = chunkpos.getMinBlockZ();
        LevelHeightAccessor heightAccessor = context.heightAccessor();
        int[][] samplePoints = {{0, 0}, {15, 0}, {0, 15}, {15, 15}, {8, 8}};
        int[] floors = new int[samplePoints.length];
        int[] roofs = new int[samplePoints.length];
        // 起始角落那一列与岩浆海采样的 (0,0) 是同一个点，留一份给 isOverLavaSea 复用
        NoiseColumn cornerColumn = null;
        for (int i = 0; i < samplePoints.length; i++) {
            NoiseColumn column = context.chunkGenerator().getBaseColumn(
                    minX + samplePoints[i][0], minZ + samplePoints[i][1],
                    heightAccessor, context.randomState());
            floors[i] = firstAirAboveFloor(column, heightAccessor);
            roofs[i] = firstSolidAbove(column, heightAccessor, floors[i]);
            if (i == 0) {
                cornerColumn = column;
                // 起始角落就压在岩浆海上：整块模板必然落在岩浆层，直接放弃。
                // 判定结果与下面 isOverLavaSea 的九点采样完全一致（(0,0) 是它的第一个点），
                // 但省掉了另外 4 条地面列与 8 条岩浆列——/locate 每秒要跑上千次。
                if (this.avoidLava && usesSurfaceAttach()
                        && floors[0] > heightAccessor.getMinBuildHeight()
                        && column.getBlock(floors[0] - 1).is(Blocks.LAVA)) {
                    return null;
                }
            }
        }

        int baseY;
        switch (this.attach) {
            case "ceiling" -> {
                // 从洞穴顶板垂下（矿晶坠簇）：要求顶板大致平整，否则跳过
                int[] sorted = roofs.clone();
                Arrays.sort(sorted);
                int roofY = sorted[sorted.length / 2];
                if (roofY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null; // 头顶没有顶板，无处可挂
                }
                for (int roof : roofs) {
                    if (Math.abs(roof - roofY) > 6) {
                        return null; // 各采样点顶板高低差过大，挂出来会穿顶
                    }
                }
                // 顶排放到顶板固体下 2 格（与原 Formations ground_level=高度+3 的悬挂量一致）
                baseY = roofY - this.templateHeight - 2;
                if (baseY < heightAccessor.getMinBuildHeight()) {
                    return null; // 洞穴太矮，放不下坠簇
                }
            }
            case "buried" -> {
                // 沉入地面（球笼）：整体下移一个模板高度，顶部与地面齐平
                int[] sorted = floors.clone();
                Arrays.sort(sorted);
                int floorY = sorted[sorted.length / 2];
                if (floorY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null;
                }
                int sink = Math.min(this.templateHeight,
                        floorY - heightAccessor.getMinBuildHeight());
                baseY = floorY - sink;
            }
            default -> {
                // 立在地面上（默认，含原下界客栈/靶场逻辑）
                if (this.avoidLava && this.isOverLavaSea(context, cornerColumn, floors[0])) {
                    return null; // 压在岩浆海上，让给同结构集里的其他结构
                }
                Arrays.sort(floors);
                int surfaceY = floors[floors.length / 2];
                if (surfaceY >= heightAccessor.getMaxBuildHeight() - 1) {
                    return null; // 整列都是实心（大概率顶到了噪声屋顶），放弃本次放置
                }
                // 保证结构顶部不与下界屋顶（约 y=118 起）重叠
                baseY = Math.min(surfaceY, heightAccessor.getMaxBuildHeight() - 26);
                baseY = Math.max(baseY, heightAccessor.getMinBuildHeight());
                if (this.templateHeight > 0) {
                    // 净空检查：取最矮的一段顶板，模板必须能完整放进地面与顶板之间
                    int[] sortedRoofs = roofs.clone();
                    Arrays.sort(sortedRoofs);
                    int lowestRoof = sortedRoofs[0];
                    if (lowestRoof - baseY < this.templateHeight) {
                        return null;
                    }
                }
            }
        }
        int offset = this.startHeight.sample(
                context.random(),
                new WorldGenerationContext(context.chunkGenerator(), heightAccessor));
        return new BlockPos(minX, baseY + offset, minZ);
    }

    /** 是否走"立在地面上"的默认放置分支（ceiling / buried 两种模式不吃岩浆海规则）。 */
    private boolean usesSurfaceAttach() {
        return !"ceiling".equals(this.attach) && !"buried".equals(this.attach);
    }

    /**
     * 判断结构占地是否压在岩浆海上（下界岩浆海湖面只是一层岩浆，噪声列会把岩浆
     * 当成实体，建筑就会"漂"在岩浆面上）。
     *
     * <p>从起始 chunk 的最小角出发，按模板占地 56×57 在 3×3 个位置采样：任一列的
     * 地面方块是岩浆即判定为岩浆海，本次候选区块放弃生成。只对 {@code avoid_lava}
     * 的结构生效，其他结构不受影响。</p>
     *
     * <p>3×3 里的第一个点 (0,0) 与 {@code getBasePosition} 的角落采样点是同一个方块坐标，
     * 那一列已经取过（{@code cornerColumn}/{@code cornerFloorY}），这里直接复用，
     * 少一次 {@code getBaseColumn}——每次调用都会新建一个 NoiseChunk，是这条热路径上
     * 最贵的一步。</p>
     */
    private boolean isOverLavaSea(GenerationContext context, NoiseColumn cornerColumn, int cornerFloorY) {
        ChunkPos chunkPos = context.chunkPos();
        int minX = chunkPos.getMinBlockX();
        int minZ = chunkPos.getMinBlockZ();
        LevelHeightAccessor heightAccessor = context.heightAccessor();
        int[] xs = {0, LAVA_CHECK_SPAN_X / 2, LAVA_CHECK_SPAN_X};
        int[] zs = {0, LAVA_CHECK_SPAN_Z / 2, LAVA_CHECK_SPAN_Z};
        for (int dx : xs) {
            for (int dz : zs) {
                NoiseColumn column;
                int floorY;
                if (dx == 0 && dz == 0) {
                    column = cornerColumn;
                    floorY = cornerFloorY;
                } else {
                    column = context.chunkGenerator().getBaseColumn(
                            minX + dx, minZ + dz, heightAccessor, context.randomState());
                    floorY = firstAirAboveFloor(column, heightAccessor);
                }
                if (floorY <= heightAccessor.getMinBuildHeight()) {
                    continue; // 整列实心，没有可落脚的地面
                }
                if (column.getBlock(floorY - 1).is(Blocks.LAVA)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 从最低高度向上扫描噪声列，返回第一个空气方块的高度（岩浆、方块都算实体，
     * 会停在它们上方，让建筑落在地面或岩浆面上而不是泡在里面）。
     */
    private static int firstAirAboveFloor(NoiseColumn column, LevelHeightAccessor heightAccessor) {
        int y = heightAccessor.getMinBuildHeight();
        int top = heightAccessor.getMaxBuildHeight();
        while (y < top && !column.getBlock(y).isAir()) {
            y++;
        }
        return y;
    }

    /** 从地面空气继续向上扫描，返回第一个固体方块的高度（即洞穴顶板）。 */
    private static int firstSolidAbove(NoiseColumn column, LevelHeightAccessor heightAccessor, int fromY) {
        int y = Math.max(fromY, heightAccessor.getMinBuildHeight());
        int top = heightAccessor.getMaxBuildHeight();
        while (y < top && column.getBlock(y).isAir()) {
            y++;
        }
        return y;
    }

    @Override
    public StructureType<?> type() {
        return GeneratedMod.NETHER_SURFACE_JIGSAW_TYPE.get();
    }
}
