package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Unique;

/**
 * 怪物近战够得着多远，也吃主手武器的 {@code ENTITY_INTERACTION_RANGE} 加成。
 *
 * <p>下界军团旗帜（+15%）与地煞战斧（+25%）的攻击距离都落在
 * {@code minecraft:entity_interaction_range}（玩家基线 3.0 格）的主手修饰符上，
 * 但 1.21.1 原版这个属性<b>只有玩家读</b>：玩家近战走
 * {@code Player#attack}（交互距离校验），怪物近战走
 * {@code Mob#isWithinMeleeAttackRange} → {@code getAttackBoundingBox()}，
 * 后者是包围盒固定 inflate {@code DEFAULT_ATTACK_REACH} 的几何判定，全程不碰
 * 任何属性——而怪物也没有注册这条属性，即便注册，原版也不会把物品修饰符
 * 结算进怪物的属性实例。结果就是"玩家持旗打得到、下界传令兵持旗打不到"。</p>
 *
 * <p>修复方式：HEAD 注入 {@code isWithinMeleeAttackRange}，按玩家侧同一套公式
 * （基线 3.0，先 {@code ADD_VALUE}/{@code ADD_MULTIPLIED_BASE} 加算、再
 * {@code ADD_MULTIPLIED_TOTAL} 连乘）从主手物品的修饰符里现算出加成量，
 * 把它追加到攻击包围盒的水平膨胀上再判相交。只放宽、不收紧：加成 ≤ 0
 * （空手或武器不带距离修饰符）时直接走原版逻辑，其余生物行为分毫不动。</p>
 */
@Mixin(Mob.class)
public abstract class MobMeleeAttackRangeMixin {

    /** 玩家侧 {@code entity_interaction_range} 基线，物品加成以此为参照。 */
    @Unique
    private static final double netherarmy$INTERACTION_BASE = 3.0D;

    /** 桥接 {@code Mob#getAttackBoundingBox()}（protected，虚调用语义）。 */
    @Invoker("getAttackBoundingBox")
    protected abstract AABB netherarmy$callAttackBoundingBox();

    @Inject(method = "isWithinMeleeAttackRange", at = @At("HEAD"), cancellable = true)
    private void netherarmy$weaponReachBonus(LivingEntity target, CallbackInfoReturnable<Boolean> callback) {
        double bonus = netherarmy$mainhandReachBonus(((Mob) (Object) this).getMainHandItem());
        if (bonus > 0.0D && this.netherarmy$callAttackBoundingBox()
                .inflate(bonus, 0.0D, bonus).intersects(target.getHitbox())) {
            callback.setReturnValue(true);
        }
    }

    /**
     * 主手物品对 {@code ENTITY_INTERACTION_RANGE} 的净加成（相对基线 3.0）。
     * 与 {@code AttributeInstance#getValue} 同序：加法与乘基在基线上结算，
     * 乘总最后连乘。物品侧（{@code ItemAttributeModifiers}）不查实体属性表，
     * 所以怪物哪怕没注册这条属性也拿得到武器距离。
     */
    @Unique
    private static double netherarmy$mainhandReachBonus(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0.0D;
        }
        double[] parts = new double[]{0.0D, 0.0D, 1.0D}; // ADD_VALUE、Σ乘基、Π乘总
        stack.forEachModifier(EquipmentSlot.MAINHAND,
                (Holder<Attribute> attribute, AttributeModifier modifier) -> {
                    if (attribute.value() != Attributes.ENTITY_INTERACTION_RANGE.value()) {
                        return;
                    }
                    switch (modifier.operation()) {
                        case ADD_VALUE -> parts[0] += modifier.amount();
                        case ADD_MULTIPLIED_BASE -> parts[1] += modifier.amount();
                        case ADD_MULTIPLIED_TOTAL -> parts[2] *= 1.0D + modifier.amount();
                    }
                });
        double value = (netherarmy$INTERACTION_BASE + parts[0]) * (1.0D + parts[1]) * parts[2];
        return Math.max(0.0D, value - netherarmy$INTERACTION_BASE);
    }
}
