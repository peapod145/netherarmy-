package cn.blockforge.generated.netherarmy;

import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * 下界传令兵（Nether Courier）。
 *
 * <ul>
 *   <li>血量 30、自带 10 点护甲；移速不覆盖，与凋灵骷髅一致（0.25）；索敌范围
 *       （FOLLOW_RANGE）与反逆者同为 32 格。</li>
 *   <li>凋灵骷髅阵营：直接继承 {@link WitherSkeleton}——亡灵判定、猪灵互仇
 *       （{@code PiglinAi} 认 {@code instanceof WitherSkeleton}，反方向的
 *       {@code NearestAttackableTargetGoal(AbstractPiglin)} 也在父类目标列表里）、
 *       近战附凋零（{@code WitherSkeleton#doHurtTarget}）全部白捡。</li>
 *   <li>生成时右手必持下界军团旗帜，不可掉落、不可捡拾替换。持旗近战顺带触发
 *       旗帜的范围凋零波（{@link NetherArmyFlagWitherAoeHandler} 上一轮已把
 *       触发通道泛化到怪物）。</li>
 *   <li>30 格追随/护卫与军团光环分别由 {@link CourierFollowGoal}、
 *       {@link CourierProtectTargetGoal}（挂在阵营成员身上）与
 *       {@link LegionAuraHandler}（服务端集中结算）实现。</li>
 *   <li>受击反应：被有主伤害打中时立刻向伤害来源的反方向后撤 5 格
 *       （{@link CourierFleeGoal}，优先级 1，压过近战/游走；近战目标被移动标志
 *       挡着，后撤期间下不了手，但仇恨全程保留，退完立刻反打），
 *       同时 30 格内全体追随者的仇恨<b>立刻</b>转向伤害来源（不等
 *       {@link CourierProtectTargetGoal} 的轮询周期）。环境伤害（火烧中毒等）
 *       不触发后撤。</li>
 *   <li>外观模型自带胸甲：本体与甲片分属两张贴图、两个模型层，甲片层固定白
 *       色着色，受击闪红只作用于本体（见 {@code GeneratedModClient} 的渲染器）；
 *       双臂恒前平举、攻击时右臂叠加原版节拍的挥手见
 *       {@link NetherCourierModel#setupAnim} 与 {@link CourierArmAnimation}。</li>
 *   <li>穿戴装备：允许拾取并穿着地面掉落的四槽盔甲（含炼狱晶套），发射器/NBT
 *       穿戴同样可见；盔甲袖子随"双臂前平举"姿态联动（护甲层直接拷贝本体姿态）。
 *       武器一律拒收，右手军团旗不可被替换（见 {@link #canHoldItem}）。</li>
 *   <li>掉落：凋灵骷髅同款（煤炭+骨头，见 {@code netherarmy:entities/nether_courier}
 *       掉落表；手中旗帜掉落概率钉死为 0，故不会掉石剑也不会多掉一面旗），另有
 *       1% 概率掉落下界军团旗帜；经验基准 10（凋灵骷髅的 2 倍）。</li>
 * </ul>
 */
public class NetherCourier extends WitherSkeleton {
    /** 追随与光环的判定半径（格）。 */
    public static final double FOLLOW_RADIUS = 30.0D;
    /** 触发军团光环所需的最少追随者数量（不含传令兵自己）。 */
    public static final int MIN_FOLLOWERS_FOR_AURA = 3;
    /** 受击后撤的直线距离（格）。 */
    private static final double FLEE_DISTANCE = 5.0D;
    /** 后撤兜底超时（tick）：寻路被卡住时到点自动恢复战斗。 */
    private static final int FLEE_TIMEOUT_TICKS = 160;

    /** 服务端：受击后撤状态（{@link CourierFleeGoal} 消费）。 */
    private boolean fleeing;
    private Vec3 fleeTargetPos;
    private long fleeDeadline;

    public NetherCourier(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        // 凋灵骷髅同款掉落物（煤炭+骨头，见 netherarmy:entities/nether_courier 掉落表，
        // 另含 1% 下界军团旗帜）；经验基准 5 → 10（2 倍）。装备的随机经验加成沿用
        // Mob#getBaseExperienceReward 原逻辑，与凋灵骷髅持剑时完全一致。
        this.xpReward = 10;
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ARMOR, 10.0D)
                // 索敌范围与反逆者一致（凋灵骷髅基线只有 16 格）：父类的
                // NearestAttackableTargetGoal/Piglin 仇恨判定都读这一条属性，
                // 视线感知与近战判定随之整体扩到 32 格。
                .add(Attributes.FOLLOW_RANGE, Mesmerizer.MESMERIZER_FOLLOW_RANGE);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 优先级 1：压过父类的游走(2)/近战(4)，且 MOVE 标志冲突时低优先级目标
        // 无法抢占（WrappedGoal.canBeReplacedBy：新目标优先级数值必须更小）。
        this.goalSelector.addGoal(1, new CourierFleeGoal(this));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean damaged = super.hurt(source, amount);
        if (!damaged || this.level().isClientSide) {
            return damaged;
        }
        Entity attacker = source.getEntity() != null ? source.getEntity() : source.getDirectEntity();
        if (attacker instanceof LivingEntity living && living != this && living.isAlive()) {
            redirectFollowersAggro(living);
            startFleeFrom(living);
        }
        return damaged;
    }

    /** 30 格内全体合法追随者立刻把仇恨转向伤害来源（友军伤害不记仇）。 */
    private void redirectFollowersAggro(LivingEntity threat) {
        if (LegionAuraHandler.isFactionMember(threat)) {
            return;
        }
        for (Mob follower : this.level().getEntitiesOfClass(
                Mob.class, this.getBoundingBox().inflate(FOLLOW_RADIUS),
                LegionAuraHandler::isFollowerCandidate)) {
            LivingEntity currentTarget = follower.getTarget();
            if (currentTarget != null && currentTarget.isAlive()) {
                continue;
            }
            if (follower.distanceToSqr(this) > FOLLOW_RADIUS * FOLLOW_RADIUS
                    || !follower.getSensing().hasLineOfSight(this)
                    || !MesmerizerControl.canAttack(follower, threat)
                    || WitherFactionCreativePassivityHandler.isIgnoredPlayer(threat)) {
                continue;
            }
            follower.setTarget(threat);
        }
    }

    /** 向"伤害来源→自己"的方向后撤 {@value #FLEE_DISTANCE} 格。 */
    private void startFleeFrom(LivingEntity threat) {
        Vec3 away = this.position().subtract(threat.position());
        away = new Vec3(away.x, 0.0D, away.z);
        if (away.lengthSqr() < 1.0E-4D) {
            // 贴脸重叠等退化情形：朝面朝的反方向退。
            away = this.getLookAngle().multiply(-1.0D, 0.0D, -1.0D);
        }
        away = away.normalize();
        this.fleeTargetPos = this.position().add(away.scale(FLEE_DISTANCE));
        this.fleeDeadline = this.level().getGameTime() + FLEE_TIMEOUT_TICKS;
        this.fleeing = true;
        // 只让出导航控制权给后撤目标；仇恨保持不动——后撤期间近战目标被
        // MOVE/JUMP 标志挡着打不出手，退完最后一步则拿着现成仇恨立刻反打。
        // （旧实现在这里连同 CourierFleeGoal 每 tick 清一次 target，导致
        // "受击逃跑后自身仇恨被清空"，退完还得重新索敌才肯还手。）
        this.getNavigation().stop();
    }

    /** {@link CourierFleeGoal} 用：是否处于后撤状态。 */
    public boolean isFleeing() {
        return this.fleeing;
    }

    /** {@link CourierFleeGoal} 用：后撤落点（服务端）。 */
    public Vec3 getFleeTargetPos() {
        return this.fleeTargetPos;
    }

    /** {@link CourierFleeGoal} 用：后撤兜底截止时刻（游戏 tick）。 */
    public long getFleeDeadline() {
        return this.fleeDeadline;
    }

    /** {@link CourierFleeGoal} 用：结束/中断后撤。 */
    public void stopFleeing() {
        this.fleeing = false;
        this.fleeTargetPos = null;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.fleeing && this.level().getGameTime() > this.fleeDeadline) {
            this.stopFleeing();
        }
    }

    @Override
    protected void populateDefaultEquipmentSlots(net.minecraft.util.RandomSource random,
                                                 DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.NETHER_ARMY_FLAG.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        net.minecraft.world.entity.MobSpawnType spawnType,
                                        SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 原版 Mob 会随机设置左撇子；旗帜必须钉死在右手。父类的默认装备（石剑）
        // 也在这里统一覆盖掉，任何生成路径（刷怪蛋、巡逻队、指令）都走这一条。
        this.setLeftHanded(false);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.NETHER_ARMY_FLAG.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setDropChance(EquipmentSlot.CHEST, 0.0F);
        // 允许穿戴装备：开启拾取，地面掉落的盔甲会被捡起并穿进对应槽位
        // （拾取/换装门槛见下方 canHoldItem——只放行四槽盔甲，武器换不掉旗帜）。
        // 发射器发射盔甲、NBT 直接写入装备栏同样生效；渲染由客户端
        // NetherCourierRenderer 挂的 HumanoidArmorLayer 负责。
        this.setCanPickUpLoot(true);
        this.reassessWeaponGoal();
        return result;
    }

    /**
     * 穿戴门禁：只允许四槽人形盔甲（头盔/胸甲/护腿/靴子）进入装备栏。
     * 1.21.1 的 {@code Mob#equipItemIfPossible} 对盔甲槽走"该槽为空 + canHoldItem"
     * 判定、对主手走"武器更强则替换"判定，而 {@code Mob#wantsToPickUp} 的默认
     * 实现就是转调本方法——因此把这里收窄为纯盔甲后，掉落的刀剑斧永远不会顶掉
     * 右手的下界军团旗帜，发射器也无法给它塞武器。
     */
    @Override
    public boolean canHoldItem(ItemStack stack) {
        return stack.getItem() instanceof ArmorItem armor
                && armor.getEquipmentSlot() != EquipmentSlot.BODY
                && super.canHoldItem(stack);
    }
}
