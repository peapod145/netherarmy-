package cn.blockforge.generated.netherarmy;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** 客户端返回格尔多确认结果。 */
public record GeardleConfirmationResponsePayload(int hand, boolean confirmed) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GeardleConfirmationResponsePayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(
                    GeneratedMod.MOD_ID, "geardle_confirmation_response"));
    public static final StreamCodec<ByteBuf, GeardleConfirmationResponsePayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT,
                    GeardleConfirmationResponsePayload::hand,
                    ByteBufCodecs.BOOL,
                    GeardleConfirmationResponsePayload::confirmed,
                    GeardleConfirmationResponsePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
