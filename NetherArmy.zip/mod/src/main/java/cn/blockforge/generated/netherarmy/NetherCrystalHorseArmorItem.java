package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.AnimalArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 炼狱晶锁链马铠物品。穿戴与渲染完全沿用原版马铠链路（AnimalArmorItem EQUESTRIAN、
 * HorseArmorLayer / DullhanHorseArmorLayer），本类只负责提示框。
 *
 * <p>三项"穿戴在坐骑身上"的增益（移速 +25%、跳跃 +25%）走 BODY 槽组的属性修饰符
 * 组件（马铠经 {@code Mob#setBodyArmorItem} 挂进 {@code EquipmentSlot.BODY}，
 * LivingEntity 的装备属性收集会自动挂载）；繁殖冷却 -25% 没有对应属性，
 * 由 {@code HorseBreedingCooldownMixin} 在 {@code Animal#finalizeSpawnChildFromBreeding}
 * 尾部把刚写入的亲代冷却缩短四分之一。</p>
 *
 * <p>注意：NeoForge 1.21.1 的属性组件与 ArmorItem 默认护甲修饰符是"非空即替换"关系
 * （见 {@code IItemStackExtension#getAttributeModifiers}），所以 +30 护甲值也显式写进了
 * 注册处的属性组件。组件整体 {@code withTooltip(false)}，提示框三行特性统一用
 * 深红色（{@link ChatFormatting#DARK_RED}）手写，护甲值一行用灰色补显示。</p>
 */
public final class NetherCrystalHorseArmorItem extends AnimalArmorItem {

    public NetherCrystalHorseArmorItem(Holder<ArmorMaterial> material, boolean hasOverlay,
                                      Properties properties) {
        super(material, BodyType.EQUESTRIAN, hasOverlay, properties);
    }

    /**
     * 掉落物免疫爆炸：{@code ItemEntity#hurt} 扣血前先问 {@code ItemStack#canBeHurtBy}，
     * 这里把 {@code IS_EXPLOSION} 挡掉（与炼狱晶锭 / 四件套同款写法）；
     * 火焰/岩浆免疫由注册处的 {@code fireResistant} 组件负责。
     */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        // 属性组件被整体隐藏（withTooltip(false)），护甲值一行按原版灰色样式补上。
        tooltip.add(Component.translatable("item.netherarmy.nether_crystal_horse_armor.tooltip.armor")
                .withStyle(ChatFormatting.GRAY));
        // 三项坐骑特性：深红色，与炼狱晶套单件能力的提示样式一致。
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable("item.netherarmy.nether_crystal_horse_armor.tooltip.ability." + i)
                    .withStyle(ChatFormatting.DARK_RED));
        }
    }
}
