package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 下界军团旗帜：无限耐久、伤害 4、持有速度 +25%、不可附魔、攻击间隔 0.25 秒、
 * 攻击距离比剑远 15%、击退为剑 50% 的旗帜武器。
 *
 * <p>数值落点（属性修饰符见 {@link GeneratedMod#NETHER_ARMY_FLAG}）：</p>
 * <ul>
 *   <li>无限耐久：物品不带 {@code minecraft:durability} 组件，{@code hurtAndBreak}
 *       对无耐久物品是空操作，攻击扣耐久路径整体失效，也不显示耐久条。</li>
 *   <li>伤害 4：{@code Attributes.ATTACK_DAMAGE} 基线 1.0，修饰符 +3.0。</li>
 *   <li>攻击间隔 0.25 秒：玩家 {@code ATTACK_SPEED} 基线即 4.0，
 *       {@code getCurrentItemAttackStrengthDelay} = 20/4 = 5 刻 = 0.25 秒；
 *       注册处带一条加值为 0 的 {@code base_attack_speed} 修饰符，数值不变，
 *       只为在提示框按原版近战武器同款格式显示"攻击速度"。</li>
 *   <li>不可附魔：普通 {@link Item} 不在任何 {@code #minecraft:enchantable/*}
 *       物品标签里，附魔台、经验书、铁砧与 {@code /enchant} 的
 *       {@code Enchantment#canEnchant} 判定全部拒绝。</li>
 *   <li>攻击距离比剑远 15%：{@code ENTITY_INTERACTION_RANGE} 基线 3.0 格，
 *       主手 {@code ADD_MULTIPLIED_BASE} +0.15 → 3.45 格。</li>
 *   <li>击退 50%：见 {@link NetherArmyFlagKnockbackHandler}。</li>
 *   <li>不可合成：不提供任何配方，仅创造模式战斗栏目获取。</li>
 * </ul>
 *
 * <p>命中效果（攻击点黑烟 + 半径 5 格内非凋灵骷髅阵营生物 10 秒凋零 I）的实现体在
 * {@link NetherArmyFlagWitherAoeHandler}。那里并列挂了 {@code AttackEntityEvent}、
 * {@code LivingIncomingDamageEvent}、本类 {@link #postHurtEnemy}、以及
 * {@link cn.blockforge.generated.netherarmy.mixin.MobMeleeSwingMixin} 转发的
 * {@code Mob#doHurtTarget} 四条互补通道，谁先走到谁结算、同一次挥击只结算一次。
 * 后两条里，本类的物品钩子只覆盖玩家：它要等 {@code Entity#hurt} 返回 {@code true} 才会被
 * {@code Player#attack} 调到，命中免伤/无敌目标时整段被跳过——只挂这一个钩子，就是前两版
 * "代码看着没问题、进游戏却完全没效果"的直接原因；而它连怪物都覆盖不到，因为
 * {@code Mob#doHurtTarget} 这条路径压根不调用物品命中钩子，也就有了"玩家有波、怪物没有"。</p>
 */
public final class NetherArmyFlagItem extends Item {
    public NetherArmyFlagItem(Item.Properties properties) {
        super(properties);
    }

    /**
     * 命中钩子接线：1.21.1 的 {@code Player#attack} 只有在
     * {@code ItemStack#hurtEnemy}（转发到此方法）返回 {@code true} 时才会接着调用
     * {@code postHurtEnemy}；基类 {@code Item} 默认返回 {@code false}，本物品又不是
     * {@code SwordItem} 系，若不覆写则连这一条通道都没有。返回 {@code true} 的副作用
     * 只有 {@code ITEM_USED} 统计计数，不涉及扣耐久（本物品无耐久组件）。
     */
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return true;
    }

    /**
     * 通道三：原版物品命中钩子（服务端、{@code Player#attack} 内、伤害已结算之后）。
     * 交给 {@link NetherArmyFlagWitherAoeHandler} 与另两条通道统一去重结算。
     * 基类 {@code Item#postHurtEnemy} 是空实现，先 super 保持行为链完整。
     */
    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postHurtEnemy(stack, target, attacker);
        NetherArmyFlagWitherAoeHandler.onItemMeleeHit(attacker, target);
    }

    /** 灰色说明行：与亡魂重盾同款写法（{@code translatable} + {@code GRAY}）。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.nether_army_flag.tooltip.wither")
                .withStyle(ChatFormatting.GRAY));
    }
}
