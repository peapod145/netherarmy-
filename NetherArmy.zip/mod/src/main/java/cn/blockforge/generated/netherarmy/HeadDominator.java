package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * 御首者：凋灵骷髅阵营的施法者，手托一杆悬浮杖头的法杖。
 *
 * <h3>数值</h3>
 * <p>血量 20、护甲 2、移速与凋灵骷髅一致（{@code MOVEMENT_SPEED 0.25}，直接继承
 * {@link AbstractSkeleton#createAttributes()}）、索敌 35 格；对魔法伤害
 * （{@code #minecraft:is_magic}：药水、滞留云、龙息等）有 50% 抗性，在
 * {@link #hurt} 入口统一折半，覆盖抛射物与持续伤害两条路径。经验掉落为
 * 凋灵骷髅（5 点）的 3 倍。</p>
 *
 * <h3>战斗</h3>
 * <p>与反逆者同款"风筝"逻辑（{@link MesmerizerRangedAttackGoal} 的后撤分支照搬）：
 * 目标进入 10 格以内就背离目标横移拉开，站定条件为视线 + 30 格。它不近战、不持械
 * （需求明确"没有石剑"，{@link #populateDefaultEquipmentSlots} 置空）。
 * 发现敌人后循环施法，三个技能冷却相互独立：</p>
 * <ol>
 *   <li>向目标前方扇形发射 5 发凋灵之首（黑色），冷却 6s；</li>
 *   <li>发射 1 发可追踪目标的蓝色凋灵之首（{@code dangerous}，可破坏方块），冷却 15s；</li>
 *   <li>前后左右各 1 格召唤一个无头骑士头颅（共 4 个），并在召唤处冒出少量黑烟，
 *       头颅仇恨与本尊保持一致，冷却 12s。</li>
 * </ol>
 * <p>每次施法先播 1.25s 施法动画（{@link HeadDominatorModel}），抛射物/召唤在动画
 * 顶点（第 20 tick）结算——{@code DATA_CAST_TICKS} 走实体数据同步，客户端只负责摆
 * 姿势，服务端到点才真正放出技能。任一技能结算后，御首者还会进入 2s 强制施法锁定，
 * 期间不能再次起手。</p>
 */
public class HeadDominator extends WitherSkeleton {
    /** 索敌范围 35 格（需求值；与凋灵骷髅的 20 格、反逆者的 32 格都不同）。 */
    public static final double FOLLOW_RANGE = 35.0D;
    /** 施法射程：视线可见且不超过这个距离才起手（与反逆者的光球射程对齐）。 */
    private static final float CAST_RANGE = 30.0F;
    /** 后撤距离：与反逆者一致，目标进入 10 格以内就拉开。 */
    private static final float RETREAT_DISTANCE = 10.0F;
    /** 施法动画总时长 1.25s = 25 tick（bbmodel "cast spell" 动画原长）。 */
    static final int CAST_TOTAL_TICKS = 25;
    /** 动画第 20 tick（即 castTicks 倒数到 5）结算技能效果，对应动画里法杖抬到顶点的瞬间。 */
    private static final int CAST_TRIGGER_AT = 5;
    private static final int SKULLS_COOLDOWN = 120;  // 技能 1：6s
    private static final int BLUE_COOLDOWN = 300;    // 技能 2：15s
    private static final int HEADS_COOLDOWN = 240;   // 技能 3：12s
    /** 任一技能释放后的公共施法锁定：2s 内强制无法再次起手。 */
    private static final int CAST_LOCKOUT_TICKS = 40;
    /** 扇形技能的水平总张角：5 发弹头均匀覆盖 54°，中间一发沿目标方向。 */
    private static final float SKULL_FAN_ANGLE = 54.0F;
    /** 凋灵骷髅经验 5 点的 3 倍。 */
    private static final int XP_REWARD = 15;
    /** 魔法伤害标签（本模组命名空间）：原版 1.21.1 并不存在 #minecraft:is_magic 标签，
     * 照搬会永远判空。这里按原版女巫魔抗（#minecraft:witch_resistant_to）的口径自建
     * #netherarmy:is_magic = magic（药水即时伤害）+ indirect_magic（滞留药水云），
     * 整合包想再收编龙息等类型只需往标签里追加一行。 */
    private static final TagKey<DamageType> IS_MAGIC =
            TagKey.create(Registries.DAMAGE_TYPE,
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "is_magic"));
    /** 仇恨同步的追踪半径：超出就不管了（头颅本来就飞不快，64 格留足绕路余量）。 */
    private static final double HEAD_TRACK_RANGE = 64.0D;
    private static final int HEAD_REFRESH_TICKS = 10;

    private static final EntityDataAccessor<Integer> DATA_CAST_TICKS =
            SynchedEntityData.defineId(HeadDominator.class, EntityDataSerializers.INT);

    private static final String CAST_TICKS_TAG = "generated_mod_head_dominator_cast_ticks";
    private static final String CASTING_SKILL_TAG = "generated_mod_head_dominator_casting_skill";
    private static final String SKULLS_COOLDOWN_TAG = "generated_mod_head_dominator_skulls_cooldown";
    private static final String BLUE_COOLDOWN_TAG = "generated_mod_head_dominator_blue_cooldown";
    private static final String HEADS_COOLDOWN_TAG = "generated_mod_head_dominator_heads_cooldown";
    private static final String CAST_LOCKOUT_TAG = "generated_mod_head_dominator_cast_lockout";
    private static final String SUMMONED_HEADS_TAG = "generated_mod_head_dominator_summoned_heads";

    /** 当前正在施放的技能（1~3，0=空闲）；只在服务端有权威意义。 */
    private int castingSkill;
    private int skullsCooldown;
    private int blueCooldown;
    private int headsCooldown;
    /** 技能释放后的公共锁定计时；服务端权威，不进入实体同步数据。 */
    private int castLockoutTicks;
    /** 本尊召唤过、还活着的无头骑士头颅名单（纯内存快照，服务端每 10 tick 重扫）。 */
    private final List<UUID> summonedHeadIds = new ArrayList<>();
    private final List<DullhanHead> summonedHeads = new ArrayList<>();
    private int headRefreshCountdown;

    public HeadDominator(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.xpReward = XP_REWARD;
        this.setLeftHanded(false);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_CAST_TICKS, 0);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ARMOR, 2.0D)
                .add(Attributes.FOLLOW_RANGE, FOLLOW_RANGE);
    }

    /**
     * 施法动画时间轴（秒，0~1.25），未施法返回 -1。
     *
     * <p>{@code castTicks} 由服务端逐 tick 递减并同步；两个同步 tick 之间用
     * {@code ageInTicks - tickCount} 的分数部分补间，动画才不会一格一跳。
     * {@code ageInTicks - tickCount} 即渲染帧的 partialTick。</p>
     */
    public float castAnimationTime(float ageInTicks) {
        int ticks = this.entityData.get(DATA_CAST_TICKS);
        if (ticks <= 0) {
            return -1.0F;
        }
        float partial = ageInTicks - (float) this.tickCount;
        float t = (float) (CAST_TOTAL_TICKS - ticks) + partial;
        if (t < 0.0F) {
            t = 0.0F;
        }
        return t / 20.0F;
    }

    /** 是否正处于施法动画中（服务端与客户端都会随同步数据翻转）。 */
    public boolean isCasting() {
        return this.entityData.get(DATA_CAST_TICKS) > 0;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide() || !this.isAlive()) {
            return;
        }
        if (this.skullsCooldown > 0) {
            this.skullsCooldown--;
        }
        if (this.blueCooldown > 0) {
            this.blueCooldown--;
        }
        if (this.headsCooldown > 0) {
            this.headsCooldown--;
        }
        if (this.castLockoutTicks > 0) {
            this.castLockoutTicks--;
        }
        int ticks = this.entityData.get(DATA_CAST_TICKS);
        if (ticks > 0) {
            ticks--;
            this.entityData.set(DATA_CAST_TICKS, ticks);
            if (ticks == CAST_TRIGGER_AT && this.castingSkill != 0) {
                this.executeSkill(this.castingSkill);
                this.castingSkill = 0;
            }
        }
        if (--this.headRefreshCountdown <= 0) {
            this.headRefreshCountdown = HEAD_REFRESH_TICKS;
            this.refreshSummonedHeads();
        }
        // 需求：无头骑士头颅的仇恨与御首者一致。本尊锁定目标期间，把目标持续推给
        // 还在身边的头颅；本尊没有目标时不干预（头颅保留自己的反击/索敌）。
        LivingEntity aggro = this.getTarget();
        if (aggro != null && aggro.isAlive() && isShareableAggro(aggro)) {
            for (DullhanHead head : this.summonedHeads) {
                if (head.getTarget() != aggro) {
                    head.setTarget(aggro);
                }
            }
        }
    }

    private void refreshSummonedHeads() {
        this.summonedHeads.removeIf(head -> !head.isAlive() || head.level() != this.level()
                || head.distanceToSqr(this) > HEAD_TRACK_RANGE * HEAD_TRACK_RANGE);
        if (!(this.level() instanceof ServerLevel level) || this.summonedHeadIds.isEmpty()) {
            return;
        }
        this.summonedHeadIds.removeIf(id -> {
            Entity entity = level.getEntity(id);
            if (entity instanceof DullhanHead head && head.isAlive()) {
                if (!this.summonedHeads.contains(head)) {
                    this.summonedHeads.add(head);
                }
                return false;
            }
            return true;
        });
    }

    /** 技能结算（服务端，施法动画顶点触发）；冷却和公共锁定都从技能真正放出这一刻起算。 */
    private void executeSkill(int skill) {
        this.castLockoutTicks = CAST_LOCKOUT_TICKS;
        switch (skill) {
            case 1 -> {
                this.fireSkullFan(5);
                this.skullsCooldown = SKULLS_COOLDOWN;
            }
            case 2 -> {
                this.fireTrackingBlueSkull();
                this.blueCooldown = BLUE_COOLDOWN;
            }
            case 3 -> {
                this.summonHeads();
                this.headsCooldown = HEADS_COOLDOWN;
            }
            default -> {
            }
        }
    }

    /**
     * 向目标前方扇形发射 {@code count} 发凋灵之首。扇形以瞄准方向为中心，在水平面内
     * 均匀展开 {@value #SKULL_FAN_ANGLE}°；原版凋灵之首保持直线飞行，因此这里不逐发
     * 随机散布，确保五发都落在前方而不是散成球形。count 为奇数时正中间那发的偏角恰为
     * 0°，即严格沿 {@link #aimDirection} 对准目标眼睛射出。
     */
    private void fireSkullFan(int count) {
        if (!(this.level() instanceof ServerLevel level) || count <= 0) {
            return;
        }
        Vec3 eye = this.getEyePosition();
        Vec3 base = aimDirection(eye);
        for (int i = 0; i < count; i++) {
            double fraction = count == 1 ? 0.0D : (double) i / (double) (count - 1);
            float yawOffset = (float) ((fraction - 0.5D) * SKULL_FAN_ANGLE);
            Vec3 direction = base.yRot(yawOffset * Mth0.PI_180).normalize();
            WitherSkull skull = new WitherSkull(level, this, direction.scale(1.6D));
            skull.setPos(eye.add(direction.scale(0.75D)));
            skull.setDangerous(false);
            level.addFreshEntity(skull);
        }
        this.playSound(SoundEvents.WITHER_SHOOT, 1.0F, 0.9F + this.getRandom().nextFloat() * 0.2F);
    }

    /** 技能 2：发射一枚蓝色凋灵之首；该弹头持续追踪御首者当前目标。 */
    private void fireTrackingBlueSkull() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        Vec3 eye = this.getEyePosition();
        Vec3 direction = aimDirection(eye);
        WitherSkull skull = new WitherSkull(level, this, direction.scale(1.6D));
        skull.setPos(eye.add(direction.scale(0.75D)));
        skull.setDangerous(true);
        HeadDominatorSkullHandler.markTracking(skull, this.getTarget());
        level.addFreshEntity(skull);
        this.playSound(SoundEvents.WITHER_SHOOT, 1.0F, 1.05F + this.getRandom().nextFloat() * 0.15F);
    }

    /** 取当前目标视线方向；没有目标或方向退化时回落到实体正前方。 */
    private Vec3 aimDirection(Vec3 eye) {
        LivingEntity target = this.getTarget();
        Vec3 direction = target != null ? target.getEyePosition().subtract(eye) : this.getForward();
        return direction.lengthSqr() < 1.0E-6D ? this.getForward().normalize() : direction.normalize();
    }

    /** 技能 3：前后左右各 1 格召唤一个无头骑士头颅，仇恨与本尊一致。 */
    private void summonHeads() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        Vec3 forward = this.getForward();
        forward = new Vec3(forward.x, 0.0D, forward.z);
        if (forward.lengthSqr() < 1.0E-6D) {
            forward = new Vec3(-Math.sin(this.getYRot() * Mth0.PI_180), 0.0D, Math.cos(this.getYRot() * Mth0.PI_180));
        } else {
            forward = forward.normalize();
        }
        Vec3 right = new Vec3(-forward.z, 0.0D, forward.x);
        Vec3[] offsets = {forward, forward.scale(-1.0D), right, right.scale(-1.0D)};
        LivingEntity aggro = this.getTarget();
        for (Vec3 offset : offsets) {
            DullhanHead head = GeneratedMod.DULLHAN_HEAD.get().create(level);
            if (head == null) {
                continue;
            }
            head.setPos(this.getX() + offset.x, this.getY() + 0.5D, this.getZ() + offset.z);
            head.setYRot(this.getYRot());
            head.finalizeSpawn(level, level.getCurrentDifficultyAt(head.blockPosition()),
                    MobSpawnType.MOB_SUMMONED, null);
            head.setPersistenceRequired();
            if (aggro != null && aggro.isAlive() && isShareableAggro(aggro)) {
                head.setTarget(aggro);
            }
            level.addFreshEntity(head);
            this.summonedHeadIds.add(head.getUUID());
            level.sendParticles(ParticleTypes.LARGE_SMOKE, head.getX(), head.getY() + 0.25D, head.getZ(),
                    5, 0.22D, 0.18D, 0.22D, 0.012D);
            level.sendParticles(ParticleTypes.SMOKE, head.getX(), head.getY() + 0.35D, head.getZ(),
                    3, 0.18D, 0.14D, 0.18D, 0.018D);
        }
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 0.9F, 0.8F);
    }

    /** 共享仇恨合法性判定：与运兵车乘员同一套规则（阵营成员与创造/旁观玩家除外）。 */
    private boolean isShareableAggro(LivingEntity aggro) {
        return aggro != null && aggro != this && aggro.isAlive()
                && !LegionAuraHandler.isFactionMember(aggro)
                && !(aggro instanceof Player player && (player.isCreative() || player.isSpectator()));
    }

    /** 魔法伤害 50% 抗性：所有伤害都从 hurt() 入口过一遍，在这里先折半再交给父类。 */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (amount > 0.0F && source.is(IS_MAGIC)) {
            amount *= 0.5F;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 与反逆者同款处理：不近战、不拉弓，只留施法与基础漫游/浮动。
        this.goalSelector.removeAllGoals(goal -> isGoalType(goal, MeleeAttackGoal.class)
                || isGoalType(goal, net.minecraft.world.entity.ai.goal.RangedBowAttackGoal.class));
        this.targetSelector.removeAllGoals(goal -> true);
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Piglin.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(5, new NearestAttackableTargetGoal<>(this, PiglinBrute.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.goalSelector.addGoal(2, new HeadDominatorCastGoal(this));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(CAST_TICKS_TAG, this.entityData.get(DATA_CAST_TICKS));
        tag.putInt(CASTING_SKILL_TAG, this.castingSkill);
        tag.putInt(SKULLS_COOLDOWN_TAG, this.skullsCooldown);
        tag.putInt(BLUE_COOLDOWN_TAG, this.blueCooldown);
        tag.putInt(HEADS_COOLDOWN_TAG, this.headsCooldown);
        tag.putInt(CAST_LOCKOUT_TAG, this.castLockoutTicks);
        long[] ids = new long[this.summonedHeadIds.size() * 2];
        for (int i = 0; i < this.summonedHeadIds.size(); i++) {
            UUID uuid = this.summonedHeadIds.get(i);
            ids[i * 2] = uuid.getMostSignificantBits();
            ids[i * 2 + 1] = uuid.getLeastSignificantBits();
        }
        tag.putLongArray(SUMMONED_HEADS_TAG, ids);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_CAST_TICKS,
                Math.max(0, Math.min(CAST_TOTAL_TICKS, tag.getInt(CAST_TICKS_TAG))));
        this.castingSkill = Math.max(0, Math.min(3, tag.getInt(CASTING_SKILL_TAG)));
        this.skullsCooldown = Math.max(0, tag.getInt(SKULLS_COOLDOWN_TAG));
        this.blueCooldown = Math.max(0, tag.getInt(BLUE_COOLDOWN_TAG));
        this.headsCooldown = Math.max(0, tag.getInt(HEADS_COOLDOWN_TAG));
        this.castLockoutTicks = Math.max(0, tag.getInt(CAST_LOCKOUT_TAG));
        this.summonedHeadIds.clear();
        long[] ids = tag.getLongArray(SUMMONED_HEADS_TAG);
        for (int i = 0; i + 1 < ids.length; i += 2) {
            this.summonedHeadIds.add(new UUID(ids[i], ids[i + 1]));
        }
    }

    // ---- 不持械、不捡装备：需求明确"没有石剑"，凋灵骷髅的默认装备整套关掉 ----

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                         DifficultyInstance difficulty) {
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.setLeftHanded(false);
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setCanPickUpLoot(false);
        return result;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        return false;
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return false;
    }

    @Override
    public void reassessWeaponGoal() {
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        // 施法走 HeadDominatorCastGoal，原版弓手接口保持空实现（不持弓，永远不会被调）。
    }

    /**
     * 施法 + 风筝：站定条件、后撤距离与反逆者的
     * {@link MesmerizerRangedAttackGoal} 完全对齐（需求："和反逆者一样，当敌人靠近时会后撤"）。
     * 施法动画期间钉在原地；否则目标进入 10 格就背离横移，30 格内站定起手，更远就靠近。
     */
    private static final class HeadDominatorCastGoal extends Goal {
        private static final int PATH_RECALCULATION_INTERVAL = 8;
        private final HeadDominator dominator;
        private LivingEntity target;
        private int strafingTime = -1;
        private boolean strafingClockwise;
        private int pathRecalculationCountdown;

        private HeadDominatorCastGoal(HeadDominator dominator) {
            this.dominator = dominator;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity candidate = this.dominator.getTarget();
            if (candidate == null || !candidate.isAlive()) {
                return false;
            }
            this.target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive()
                    && this.dominator.getTarget() == this.target;
        }

        @Override
        public void start() {
            this.strafingTime = -1;
            this.pathRecalculationCountdown = 0;
            this.strafingClockwise = this.dominator.getRandom().nextBoolean();
        }

        @Override
        public void stop() {
            this.target = null;
            this.strafingTime = -1;
            this.dominator.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity currentTarget = this.dominator.getTarget();
            if (currentTarget == null || !currentTarget.isAlive()) {
                return;
            }
            this.target = currentTarget;
            this.dominator.getLookControl().setLookAt(currentTarget, 30.0F, 30.0F);
            if (this.dominator.isCasting()) {
                // 施法动画期间钉在原地（动画是站桩的，走路会歪）。
                this.dominator.getNavigation().stop();
                this.dominator.stopInPlace();
                return;
            }
            double distanceSqr = this.dominator.distanceToSqr(currentTarget);
            boolean canSee = this.dominator.getSensing().hasLineOfSight(currentTarget);
            if (canSee && distanceSqr < RETREAT_DISTANCE * RETREAT_DISTANCE) {
                // 后撤时照样能起手：先照常拉开距离，同一 tick 内再尝试施法。
                // 起手成功后本方法下一 tick 会走上面的"施法钉住"分支把移动收掉，
                // 所以观感是"边退边抬手，抬到一半就站定"。
                this.strafeBackward(currentTarget);
                this.tryStartCast();
            } else if (canSee && distanceSqr <= CAST_RANGE * CAST_RANGE) {
                this.strafingTime = -1;
                this.dominator.getNavigation().stop();
                this.dominator.stopInPlace();
                this.tryStartCast();
            } else {
                this.strafingTime = -1;
                if (--this.pathRecalculationCountdown <= 0) {
                    this.pathRecalculationCountdown = PATH_RECALCULATION_INTERVAL;
                    this.dominator.getNavigation().moveTo(currentTarget, 1.0D);
                }
            }
        }

        /** 三个冷却独立：只在"已就绪"的技能里随机起手；全在冷却就不施法（继续风筝）。 */
        private void tryStartCast() {
            if (this.dominator.castingSkill != 0 || this.dominator.isCasting()
                    || this.dominator.castLockoutTicks > 0) {
                return;
            }
            int ready = 0;
            int options = 0;
            if (this.dominator.skullsCooldown <= 0) {
                ready |= 1;
                options++;
            }
            if (this.dominator.blueCooldown <= 0) {
                ready |= 2;
                options++;
            }
            if (this.dominator.headsCooldown <= 0) {
                ready |= 4;
                options++;
            }
            if (options == 0) {
                return;
            }
            int pick = this.dominator.getRandom().nextInt(options);
            int skill = 0;
            for (int candidate = 1; candidate <= 3; candidate++) {
                if ((ready & (1 << (candidate - 1))) != 0) {
                    if (pick == 0) {
                        skill = candidate;
                        break;
                    }
                    pick--;
                }
            }
            this.dominator.castingSkill = skill;
            this.dominator.entityData.set(HeadDominator.DATA_CAST_TICKS, CAST_TOTAL_TICKS);
        }

        /** 背离方向后撤 + 随机左右横移：与反逆者同款实现（不依赖实体朝向的滞后）。 */
        private void strafeBackward(LivingEntity target) {
            if (this.strafingTime-- <= 0) {
                this.strafingClockwise = this.dominator.getRandom().nextBoolean();
                this.strafingTime = 4 + this.dominator.getRandom().nextInt(7);
            }
            Vec3 away = this.dominator.position().subtract(target.position());
            away = new Vec3(away.x, 0.0D, away.z);
            if (away.lengthSqr() < 1.0E-6D) {
                away = new Vec3(0.0D, 0.0D, 1.0D);
            } else {
                away = away.normalize();
            }
            Vec3 side = new Vec3(-away.z, 0.0D, away.x);
            Vec3 retreat = away.scale(0.625D).add(side.scale(this.strafingClockwise ? 0.5D : -0.5D));
            retreat = retreat.normalize();
            this.dominator.getNavigation().stop();
            this.dominator.getMoveControl().setWantedPosition(
                    this.dominator.getX() + retreat.x,
                    this.dominator.getY(),
                    this.dominator.getZ() + retreat.z,
                    1.0D);
        }
    }

    /** 弧度换算小工具（避免为两个数拉整个 Mth 的静态导入歧义）。 */
    private static final class Mth0 {
        private static final float PI_180 = (float) (Math.PI / 180.0D);

        private Mth0() {
        }
    }

    private static boolean isGoalType(Goal goal, Class<? extends Goal> type) {
        return type.isInstance(goal)
                || goal instanceof WrappedGoal wrapped && type.isInstance(wrapped.getGoal());
    }
}
