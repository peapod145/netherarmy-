package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 御首者披风层：玩家披风式的独立单片披布，直接贴用户提供的 16x32 披风贴图
 * （head_dominator_cape.png），不再做任何 UV 烘焙。
 *
 * <p>做法：盒按贴图原尺寸建 16 宽 x 32 高 x 1 厚，正/背面 UV 恰好是整张贴图
 * （0,0)-(16,32)；再把 cape 骨自身的缩放设为 (10/16, 18/32, 1)——原版
 * {@code ModelPart.translateAndRotate} 会在旋转之后应用骨骼 scale，于是游戏里
 * 得到一块 10x18x1 的披布，且 UV 与贴图逐像素对应、无需重采样。</p>
 *
 * <p>挂点：cape 骨是 body 骨的子骨，枢轴落在颈后
 * （java 绝对坐标 (0, 0, 2.25)，躯干后面 z=2 留 0.25 防 z-fighting），
 * xRot=+15° 让下摆向 z+（背后）外摆——与作者 Blockbench 截图里披风
 * 从肩部垂下、底边离腿外摆约 15° 的姿态一致；披布从颈（y=0）垂到小腿中段
 * （y=18，腿骨占 y=12..24）。walk/cast 动画都不驱动 body 骨，因此披风
 * 与本体一样静止，只需 {@link HeadDominatorPose#apply} 复位 body 骨。</p>
 */
public class HeadDominatorCapeModel extends EntityModel<HeadDominator> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "head_dominator_cape"), "main");

    /** 披布实际尺寸：10 宽 x 18 高（贴图原尺寸 16x32 的骨骼缩放换算）。 */
    private static final float CAPE_WIDTH = 10.0F;
    private static final float CAPE_HEIGHT = 18.0F;
    /** 下摆向外（背后 +z）摆角，对齐作者 Blockbench 参考图。 */
    private static final float CAPE_TILT = 15.0F * Mth.DEG_TO_RAD;

    private final ModelPart body;
    private final ModelPart cape;

    public HeadDominatorCapeModel(ModelPart root) {
        this.body = root.getChild("body");
        this.cape = this.body.getChild("cape");
        // 盒按 16x32 原尺寸建（UV 正好铺满贴图），用骨骼缩放压回 10x18。
        this.cape.xScale = CAPE_WIDTH / 16.0F;
        this.cape.yScale = CAPE_HEIGHT / 32.0F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        body.render(poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public void setupAnim(HeadDominator entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HeadDominatorPose.apply(this.body, null, null, null, null, null, null, null,
                entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition parent = mesh.getRoot();
        PartDefinition body = parent.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0F, 12F, 0F));
        { // 披布：16x32x1 盒，正/背面各铺整幅披风贴图；侧/顶/底零 UV 不渲染。
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.SOUTH, 0F, 0F, -8F, 0F, 0F, 16F, 32F, 1F);
            face(builder, Direction.NORTH, 0F, 0F, -8F, 0F, 0F, 16F, 32F, 1F);
            // 枢轴在披布顶边（颈后），xRot>0 把 +y（下摆）扫向 +z（背后）。
            body.addOrReplaceChild("cape", builder,
                    PartPose.offsetAndRotation(0F, -12F, 2.25F, CAPE_TILT, 0F, 0F));
        }
        return LayerDefinition.create(mesh, 16, 32);
    }

    private static void face(CubeListBuilder builder, Direction dir, float u, float v,
                             float x, float y, float z, float w, float h, float d) {
        HeadDominatorPose.face(builder, dir, u, v, x, y, z, w, h, d);
    }
}
