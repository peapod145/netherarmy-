package cn.blockforge.generated.netherarmy;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;

/**
 * 符卡规则的黑白粒子。
 *
 * <p>复用原版 {@code effect_0..7} 星形帧（见 assets/netherarmy/particles/
 * spell_card_rules.json），随年龄逐帧播放；颜色每 5 刻在纯白与近黑之间翻转一次，
 * 初始相位随机——同一实体周围的粒子因此呈现黑白交错、不断闪烁的效果。
 * 粒子不落地、不衰减重力（friction 0.96 + gravity 0），沿原版效果粒子的
 * 飘散方式上浮消散。</p>
 */
public class SpellCardRulesParticle extends TextureSheetParticle {
    /** 颜色翻转周期（刻）。 */
    private static final int FLIP_PERIOD_TICKS = 5;
    private final SpriteSet sprites;
    private boolean whitePhase;

    public SpellCardRulesParticle(ClientLevel level, double x, double y, double z,
                                  double xd, double yd, double zd, SpriteSet sprites) {
        super(level, x, y, z, xd, yd, zd);
        this.sprites = sprites;
        this.pickSprite(sprites);
        this.quadSize *= this.random.nextFloat() * 0.4F + 0.6F;
        this.lifetime = (int) (16.0D / (this.random.nextFloat() * 0.8F + 0.2F));
        this.whitePhase = this.random.nextBoolean();
        this.applyPhase();
        this.friction = 0.96F;
        this.gravity = 0.0F;
        this.hasPhysics = false;
    }

    private void applyPhase() {
        if (this.whitePhase) {
            this.setColor(1.0F, 1.0F, 1.0F);
        } else {
            // 近黑而非纯黑：留约 5/255 底光，让粒子在纯黑背景（如无头骑士躯体、
            // 暗处）上也还有一圈可辨的轮廓。
            this.setColor(0.02F, 0.02F, 0.02F);
        }
    }

    /** 不受方块光照影响的满亮度透明层（传送门粒子同款），黑白天地在任何环境都清晰。 */
    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_LIT;
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(this.sprites);
        if (this.age % FLIP_PERIOD_TICKS == 0) {
            this.whitePhase = !this.whitePhase;
            this.applyPhase();
        }
    }
}
