package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.NetherCrystalArmorItem;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 炼狱晶靴：饥饿值消耗速度 -25%。
 *
 * <p>1.21.1 的 NeoForge 没有玩家疲劳度事件（{@code PlayerExhaustionEvent} 在旧版
 * Forge 才有），所有原版饥饿消耗（行走、冲刺、跳跃、破坏方块、受伤、各类伤害源的
 * food exhaustion）都汇聚到 {@code Player#causeFoodExhaustion(float)} 这一个入口，
 * 在这里把入参乘 0.75 即等价于"消耗速度 -25%"。</p>
 */
@Mixin(Player.class)
public abstract class PlayerFoodExhaustionMixin {
    @ModifyVariable(method = "causeFoodExhaustion", at = @At("HEAD"), ordinal = 0)
    private float netherarmy$crystalBootsHungerSave(float amount) {
        Player self = (Player) (Object) this;
        if (self.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof NetherCrystalArmorItem) {
            return amount * 0.75F;
        }
        return amount;
    }
}
