package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 凋灵骷髅阵营的受击联动仇恨。
 *
 * <p>同阵营实体在自己的索敌范围内看见队友受伤时，会把伤害来源锁为目标；
 * 已经有活着的攻击目标的实体不改写原有仇恨。创造与旁观玩家永远不触发这条联动。</p>
 */
public final class WitherFactionRetaliationHandler {
    /** 当前模组阵营成员的最大索敌属性为 50 格；多留余量避免查询框漏掉观察者。 */
    private static final double MAX_SEARCH_RADIUS = 64.0D;
    private static final double DEFAULT_FOLLOW_RANGE = 16.0D;

    private WitherFactionRetaliationHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled() || event.getEntity().level().isClientSide()) {
            return;
        }

        LivingEntity victim = event.getEntity();
        if (!LegionAuraHandler.isFactionMember(victim)) {
            return;
        }

        LivingEntity attacker = event.getSource().getEntity() instanceof LivingEntity living
                ? living : null;
        if (attacker == null || !attacker.isAlive()
                || WitherFactionCreativePassivityHandler.isIgnoredPlayer(attacker)
                || LegionAuraHandler.isFactionMember(attacker)) {
            return;
        }

        for (Mob observer : victim.level().getEntitiesOfClass(
                Mob.class, victim.getBoundingBox().inflate(MAX_SEARCH_RADIUS))) {
            if (!isEligibleObserver(observer, victim, attacker)) {
                continue;
            }
            observer.setTarget(attacker);
        }
    }

    private static boolean isEligibleObserver(Mob observer, LivingEntity victim, LivingEntity attacker) {
        if (!observer.isAlive() || !LegionAuraHandler.isFactionMember(observer)
                || observer == attacker || !MesmerizerControl.sameWitherSkeletonFaction(observer, victim)) {
            return false;
        }
        LivingEntity currentTarget = observer.getTarget();
        if (currentTarget != null && currentTarget.isAlive()) {
            return false;
        }

        double followRange = maxFollowRange(observer);
        if (observer.distanceToSqr(victim) > followRange * followRange
                || !observer.getSensing().hasLineOfSight(victim)) {
            return false;
        }
        return !WitherFactionCreativePassivityHandler.isIgnoredPlayer(attacker)
                && MesmerizerControl.canAttack(observer, attacker);
    }

    private static double maxFollowRange(Entity entity) {
        if (entity instanceof Mob mob && mob.getAttribute(Attributes.FOLLOW_RANGE) != null) {
            return Math.max(0.0D, mob.getAttributeValue(Attributes.FOLLOW_RANGE));
        }
        return DEFAULT_FOLLOW_RANGE;
    }
}
