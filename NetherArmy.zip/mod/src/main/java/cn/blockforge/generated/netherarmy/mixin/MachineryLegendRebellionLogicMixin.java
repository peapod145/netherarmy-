package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MachineryLegendCompat;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 可选覆盖《器械传说》的原生阵营判断。
 * 目标模组不存在时，{@link Pseudo} 让该混入被安全跳过。
 */
@Pseudo
@Mixin(targets = "cn.blockforge.generated.machinerylegend.effect.RebellionLogic")
public abstract class MachineryLegendRebellionLogicMixin {
    @Inject(method = "canMachineAttack", at = @At("HEAD"), cancellable = true, require = 0)
    private static void netherarmy$allowMachineFactionCombat(
            Entity attacker, LivingEntity target, CallbackInfoReturnable<Boolean> callback) {
        Boolean override = MachineryLegendCompat.machineAttackOverride(attacker, target);
        if (override != null) {
            callback.setReturnValue(override);
        }
    }

    @Inject(method = "canMachineProjectileHit", at = @At("HEAD"), cancellable = true, require = 0)
    private static void netherarmy$allowMachineProjectileFactionCombat(
            Entity owner, Entity target, CallbackInfoReturnable<Boolean> callback) {
        Boolean override = MachineryLegendCompat.machineProjectileOverride(owner, target);
        if (override != null) {
            callback.setReturnValue(override);
        }
    }
}
