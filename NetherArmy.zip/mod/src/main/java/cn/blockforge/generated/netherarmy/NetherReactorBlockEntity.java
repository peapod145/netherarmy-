package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedRandom;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainer;
import net.minecraft.world.level.chunk.PalettedContainerRO;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.entity.boss.wither.WitherBoss;

public final class NetherReactorBlockEntity extends BlockEntity {
    private static final int REPLACEMENT_INTERVAL = 200;
    private static final int SPAWN_INTERVAL = 200;
    private static final int NETHER_STAGE_INTERVAL = 100;
    private static final int NETHER_MOB_WAVE_INTERVAL = 10;
    private static final int MAX_REPLACEMENT_ATTEMPTS = 512;
    private static final int MAX_NETHER_SPAWN_ATTEMPTS = 24;
    private static final int SPAWN_VERTICAL_SEARCH_UP = 16;
    private static final int SPAWN_VERTICAL_SEARCH_DOWN = 160;
    private static final String TARGET_BIOME = "TargetBiome";
    private static final String NETHER_STAGE = "NetherStage";
    private static final String NETHER_STAGE_TICKS = "NetherStageTicks";
    private static final String NETHER_MOB_WAVE_TICKS = "NetherMobWaveTicks";
    private static final int NO_STRUCTURE = 0;
    private static final int NETHER_FORTRESS = 1;
    private static final int BASTION_REMNANT = 2;
    private static final List<ResourceKey<Biome>> NETHER_BIOMES = List.of(
            Biomes.NETHER_WASTES, Biomes.CRIMSON_FOREST, Biomes.WARPED_FOREST,
            Biomes.SOUL_SAND_VALLEY, Biomes.BASALT_DELTAS);

    private int spawnCooldown;
    private int netherStageTicks;
    private int netherMobWaveTicks;
    private int netherStage;
    private boolean netherDetonationPending;

    public NetherReactorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        this.netherStage = state.hasProperty(NetherReactorBlock.STAGE)
                ? state.getValue(NetherReactorBlock.STAGE) : 0;
    }

    public NetherReactorBlockEntity(BlockPos pos, BlockState state) {
        this(GeneratedMod.NETHER_REACTOR_BLOCK_ENTITY.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, BlockEntity entity) {
        if (level instanceof ServerLevel serverLevel && entity instanceof NetherReactorBlockEntity reactor) {
            reactor.tickServer(serverLevel);
        }
    }

    private void tickServer(ServerLevel level) {
        if (level.dimension().equals(Level.NETHER)) {
            tickNether(level);
            return;
        }

        ReactorChunkState state = ReactorChunkState.get(level, worldPosition);
        ResourceKey<Biome> biome = state.targetBiome(worldPosition);
        if (biome == null) {
            return;
        }
        if (isCoordinator(level)) {
            if (level.getGameTime() % REPLACEMENT_INTERVAL == 0L) {
                replaceNextBlock(level, state);
            }
            if (++spawnCooldown >= SPAWN_INTERVAL) {
                spawnCooldown = 0;
                spawnOverworldMobs(level, state);
            }
        }
    }

    /** 下界中的反应核不改群系、不替换方块，独立经历五个阶段后自毁。 */
    private void tickNether(ServerLevel level) {
        if (netherDetonationPending) {
            detonate(level);
            return;
        }
        if (level.getBlockState(worldPosition).hasProperty(NetherReactorBlock.STAGE)
                && level.getBlockState(worldPosition).getValue(NetherReactorBlock.STAGE) != netherStage) {
            updateStage(level);
        }

        // 第二至第四阶段各持续 5 秒；阶段期间每 10 tick 再发起一波，确保生成迅速且数量足够。
        if (netherStage >= 1 && netherStage <= 3) {
            if (++netherMobWaveTicks >= NETHER_MOB_WAVE_INTERVAL) {
                netherMobWaveTicks = 0;
                spawnNetherStageMobs(level, netherStage);
            }
        }

        if (netherStage >= 4) {
            return;
        }
        if (++netherStageTicks < NETHER_STAGE_INTERVAL) {
            return;
        }

        netherStageTicks = 0;
        netherMobWaveTicks = 0;
        ++netherStage;
        updateStage(level);
        spawnNetherStageMobs(level, netherStage);
        if (netherStage >= 4) {
            netherDetonationPending = true;
        }
        setChanged();
    }

    public static void activateChunk(ServerLevel level, BlockPos pos) {
        // 下界专用阶段流程不写入群系状态，也不触发方块替换。
        if (level.dimension().equals(Level.NETHER)) {
            return;
        }
        ReactorChunkState state = ReactorChunkState.get(level, pos);
        int roll = level.random.nextInt(6);
        int structureType = roll == 0 ? NETHER_FORTRESS : roll == 1 ? BASTION_REMNANT : NO_STRUCTURE;
        ResourceKey<Biome> biome = structureType == NO_STRUCTURE
                ? NETHER_BIOMES.get(level.random.nextInt(NETHER_BIOMES.size()))
                : Biomes.NETHER_WASTES;
        state.activate(pos, biome, structureType);
        applyBiome(level, pos, biome);
    }

    private void updateStage(ServerLevel level) {
        if (!level.getBlockState(worldPosition).hasProperty(NetherReactorBlock.STAGE)) {
            return;
        }
        BlockState updated = level.getBlockState(worldPosition)
                .setValue(NetherReactorBlock.STAGE, Math.min(netherStage, 4));
        level.setBlock(worldPosition, updated, Block.UPDATE_ALL);
    }

    private boolean isCoordinator(ServerLevel level) {
        LevelChunk chunk = level.getChunk(worldPosition.getX() >> 4, worldPosition.getZ() >> 4);
        BlockPos coordinator = null;
        for (BlockPos candidate : chunk.getBlockEntities().keySet()) {
            if (level.getBlockState(candidate).is(GeneratedMod.NETHER_REACTOR_BLOCK.get())
                    && (coordinator == null || candidate.compareTo(coordinator) < 0)) {
                coordinator = candidate;
            }
        }
        return worldPosition.equals(coordinator);
    }

    private static void applyBiome(ServerLevel level, BlockPos pos, ResourceKey<Biome> biomeKey) {
        Registry<Biome> registry = level.registryAccess().registryOrThrow(Registries.BIOME);
        Holder.Reference<Biome> biome = registry.getHolderOrThrow(biomeKey);
        LevelChunk chunk = level.getChunk(pos.getX() >> 4, pos.getZ() >> 4);
        for (LevelChunkSection section : chunk.getSections()) {
            PalettedContainerRO<Holder<Biome>> biomes = section.getBiomes();
            if (biomes instanceof PalettedContainer<?> palette) {
                @SuppressWarnings("unchecked")
                PalettedContainer<Holder<Biome>> typedPalette = (PalettedContainer<Holder<Biome>>) palette;
                for (int x = 0; x < 4; x++) {
                    for (int y = 0; y < 4; y++) {
                        for (int z = 0; z < 4; z++) {
                            typedPalette.set(x, y, z, biome);
                        }
                    }
                }
            }
        }
        chunk.setUnsaved(true);
    }

    private void replaceNextBlock(ServerLevel level, ReactorChunkState state) {
        int chunkX = worldPosition.getX() >> 4;
        int chunkZ = worldPosition.getZ() >> 4;
        int minY = level.dimensionType().minY();
        int height = level.dimensionType().height();
        RandomSource random = level.random;
        ResourceKey<Biome> biomeKey = state.targetBiome(worldPosition);
        int structureType = state.structureType(worldPosition);

        for (int attempt = 0; attempt < MAX_REPLACEMENT_ATTEMPTS; attempt++) {
            int x = random.nextInt(16);
            int y = minY + random.nextInt(height);
            int z = random.nextInt(16);
            BlockPos candidate = new BlockPos((chunkX << 4) + x, y, (chunkZ << 4) + z);
            BlockState current = level.getBlockState(candidate);
            FluidState fluid = level.getFluidState(candidate);
            if (!current.is(Blocks.BEDROCK) && fluid.isEmpty() && !current.isAir()
                    && !current.is(GeneratedMod.NETHER_REACTOR_BLOCK.get())) {
                BlockState replacement = replacementFor(biomeKey, structureType, random);
                if (replacement != null && !replacement.equals(current)) {
                    level.setBlock(candidate, replacement, Block.UPDATE_ALL);
                    return;
                }
            }
        }
    }

    private static BlockState replacementFor(ResourceKey<Biome> biomeKey, int structureType, RandomSource random) {
        if (structureType == NETHER_FORTRESS) {
            int roll = random.nextInt(5);
            return roll < 2 ? Blocks.NETHER_BRICKS.defaultBlockState()
                    : roll == 2 ? Blocks.NETHER_BRICK_FENCE.defaultBlockState()
                    : Blocks.NETHERRACK.defaultBlockState();
        }
        if (structureType == BASTION_REMNANT) {
            int roll = random.nextInt(7);
            return roll < 3 ? Blocks.BLACKSTONE.defaultBlockState()
                    : roll < 5 ? Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState()
                    : roll == 5 ? Blocks.GILDED_BLACKSTONE.defaultBlockState()
                    : Blocks.NETHERRACK.defaultBlockState();
        }
        if (Biomes.CRIMSON_FOREST.equals(biomeKey)) {
            return random.nextBoolean() ? Blocks.CRIMSON_NYLIUM.defaultBlockState()
                    : Blocks.NETHERRACK.defaultBlockState();
        }
        if (Biomes.WARPED_FOREST.equals(biomeKey)) {
            return random.nextBoolean() ? Blocks.WARPED_NYLIUM.defaultBlockState()
                    : Blocks.NETHERRACK.defaultBlockState();
        }
        if (Biomes.SOUL_SAND_VALLEY.equals(biomeKey)) {
            return random.nextBoolean() ? Blocks.SOUL_SAND.defaultBlockState()
                    : Blocks.SOUL_SOIL.defaultBlockState();
        }
        if (Biomes.BASALT_DELTAS.equals(biomeKey)) {
            return random.nextBoolean() ? Blocks.BASALT.defaultBlockState()
                    : Blocks.BLACKSTONE.defaultBlockState();
        }
        return Blocks.NETHERRACK.defaultBlockState();
    }

    private void spawnNetherStageMobs(ServerLevel level, int stage) {
        List<MobSpawnSettings.SpawnerData> candidates = new ArrayList<>();
        if (stage == 1) {
            addSpawner(candidates, EntityType.HOGLIN, 8, 6, 10);
            addSpawner(candidates, EntityType.PIGLIN, 8, 6, 10);
            addSpawner(candidates, EntityType.PIGLIN_BRUTE, 8, 5, 8);
        } else if (stage == 2) {
            addSpawner(candidates, EntityType.ZOMBIFIED_PIGLIN, 8, 6, 10);
            addSpawner(candidates, EntityType.MAGMA_CUBE, 8, 6, 10);
            addSpawner(candidates, EntityType.BLAZE, 8, 6, 10);
        } else if (stage == 3) {
            addSpawner(candidates, EntityType.GHAST, 8, 4, 7);
            addSpawner(candidates, EntityType.WITHER_SKELETON, 8, 6, 10);
            addSpawner(candidates, GeneratedMod.DULLHAN_BODY.get(), 8, 4, 7);
            addSpawner(candidates, GeneratedMod.BERSERKER.get(), 8, 6, 10);
            addSpawner(candidates, GeneratedMod.NETHER_HUNTER.get(), 8, 6, 10);
        } else if (stage == 4) {
            // 第五阶段只生成一只凋灵，随后在下一 tick 清除范围内方块。
            spawnWither(level);
            return;
        }
        for (MobSpawnSettings.SpawnerData data : candidates) {
            int count = data.minCount + level.random.nextInt(data.maxCount - data.minCount + 1);
            for (int i = 0; i < count; i++) {
                spawnMob(level, data.type, level.random);
            }
        }
    }

    private void spawnOverworldMobs(ServerLevel level, ReactorChunkState state) {
        int structureType = state.structureType(worldPosition);
        List<MobSpawnSettings.SpawnerData> candidates = new ArrayList<>();
        if (structureType == NETHER_FORTRESS) {
            addSpawner(candidates, EntityType.BLAZE, 15, 1, 2);
            addSpawner(candidates, EntityType.WITHER_SKELETON, 8, 1, 2);
            addSpawner(candidates, EntityType.SKELETON, 10, 1, 2);
            addSpawner(candidates, EntityType.MAGMA_CUBE, 2, 1, 2);
            addSpawner(candidates, EntityType.ZOMBIFIED_PIGLIN, 5, 1, 2);
            addSpawner(candidates, GeneratedMod.BERSERKER.get(), 8, 1, 2);
            addSpawner(candidates, GeneratedMod.NETHER_HUNTER.get(), 8, 1, 2);
            addSpawner(candidates, GeneratedMod.DULLHAN_BODY.get(), 2, 1, 1);
        } else if (structureType == BASTION_REMNANT) {
            addSpawner(candidates, EntityType.PIGLIN, 10, 1, 2);
            addSpawner(candidates, EntityType.PIGLIN_BRUTE, 8, 1, 2);
            addSpawner(candidates, EntityType.HOGLIN, 5, 1, 2);
            addSpawner(candidates, EntityType.ZOMBIFIED_PIGLIN, 1, 1, 1);
        } else {
            ResourceKey<Biome> biomeKey = state.targetBiome(worldPosition);
            if (biomeKey == null) {
                return;
            }
            Registry<Biome> registry = level.registryAccess().registryOrThrow(Registries.BIOME);
            MobSpawnSettings settings = registry.getOrThrow(biomeKey).getMobSettings();
            for (MobCategory category : MobCategory.values()) {
                if (category != MobCategory.MISC) {
                    candidates.addAll(settings.getMobs(category).unwrap());
                }
            }
        }
        spawnMobBatch(level, candidates);
    }

    private void spawnMobBatch(ServerLevel level, List<MobSpawnSettings.SpawnerData> candidates) {
        if (candidates.isEmpty()) {
            return;
        }
        RandomSource random = level.random;
        MobSpawnSettings.SpawnerData data = WeightedRandom.getRandomItem(random, candidates).orElse(null);
        if (data == null) {
            return;
        }
        int count = data.minCount + random.nextInt(data.maxCount - data.minCount + 1);
        for (int i = 0; i < count; i++) {
            spawnMob(level, data.type, random);
        }
    }

    private void spawnMob(ServerLevel level, EntityType<?> type, RandomSource random) {
        int chunkX = worldPosition.getX() >> 4;
        int chunkZ = worldPosition.getZ() >> 4;
        boolean flying = type == EntityType.GHAST || type == EntityType.BLAZE;
        int minY = level.dimensionType().minY() + 2;
        int maxY = level.dimensionType().minY() + level.dimensionType().height() - 3;
        for (int attempt = 0; attempt < MAX_NETHER_SPAWN_ATTEMPTS; attempt++) {
            int spawnX = (chunkX << 4) + random.nextInt(16);
            int spawnZ = (chunkZ << 4) + random.nextInt(16);
            Mob mob = createMob(type, level, new BlockPos(spawnX, worldPosition.getY(), spawnZ));
            if (mob == null) {
                continue;
            }

            BlockPos spawnPos = findSpawnPosition(level, mob, spawnX, spawnZ, flying, minY, maxY);
            if (spawnPos == null) {
                mob.discard();
                continue;
            }
            mob.moveTo(spawnPos, random.nextFloat() * 360.0F, 0.0F);
            // 反应核生成不受亮度、群系和原版刷怪规则限制，只要求实体处于真实可用空间。
            // 不调用 checkSpawnObstruction：它包含各实体的自然生成限制，会错误地拒绝反应核波次。
            if (level.noCollision(mob)) {
                mob.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos), MobSpawnType.TRIGGERED, null);
                if (level.noCollision(mob) && level.addFreshEntity(mob)) {
                    mob.setPersistenceRequired();
                    return;
                }
            }
            mob.discard();
        }
    }

    /**
     * 为地面生物寻找反应核附近真正可站立的位置。高度图在下界可能指向顶部基岩，
     * 因而不能直接作为生成坐标；从反应核高度向上下扫描可同时覆盖洞穴和地表。
     */
    private BlockPos findSpawnPosition(ServerLevel level, Mob mob, int x, int z, boolean flying,
                                       int minY, int maxY) {
        if (flying) {
            int y = Math.max(minY, Math.min(maxY, worldPosition.getY() + level.random.nextInt(25) - 12));
            return new BlockPos(x, y, z);
        }
        int originY = Math.max(minY, Math.min(maxY, worldPosition.getY()));
        for (int offset = 0; offset <= SPAWN_VERTICAL_SEARCH_DOWN; offset++) {
            int below = originY - offset;
            if (below >= minY) {
                BlockPos candidate = findGroundPosition(level, mob, x, below, z);
                if (candidate != null) {
                    return candidate;
                }
            }
            if (offset <= SPAWN_VERTICAL_SEARCH_UP) {
                int above = originY + offset;
                if (above <= maxY) {
                    BlockPos candidate = findGroundPosition(level, mob, x, above, z);
                    if (candidate != null) {
                        return candidate;
                    }
                }
            }
        }
        return null;
    }

    private static BlockPos findGroundPosition(ServerLevel level, Mob mob, int x, int y, int z) {
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos support = feet.below();
        if (!level.getBlockState(feet).isAir()
                || !level.getBlockState(support).isFaceSturdy(level, support, net.minecraft.core.Direction.UP)) {
            return null;
        }
        mob.moveTo(feet, mob.getYRot(), mob.getXRot());
        return mob.checkSpawnObstruction(level) && level.noCollision(mob) ? feet : null;
    }

    private void spawnWither(ServerLevel level) {
        WitherBoss wither = EntityType.WITHER.create(level);
        if (wither != null) {
            wither.moveTo(worldPosition.getX() + 0.5D, worldPosition.getY() + 1.0D,
                    worldPosition.getZ() + 0.5D, 0.0F, 0.0F);
            wither.setPersistenceRequired();
            level.addFreshEntity(wither);
        }
    }

    /** 第五阶段先生成凋灵，下一 tick 播放爆炸声并清除反应核和周围方块。 */
    private void detonate(ServerLevel level) {
        netherDetonationPending = false;
        level.playSound(null, worldPosition, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 4.0F, 0.8F);
        destroyAreaWithoutDrops(level);
        setRemoved();
    }

    /** 直接写入空气，不调用破坏掉落逻辑，因此基岩也会被清除且不会掉落物品。 */
    private void destroyAreaWithoutDrops(ServerLevel level) {
        int radius = 10;
        int minY = Math.max(level.dimensionType().minY(), worldPosition.getY() - radius);
        int maxY = Math.min(level.dimensionType().minY() + level.dimensionType().height() - 1,
                worldPosition.getY() + radius);
        for (int x = worldPosition.getX() - radius; x <= worldPosition.getX() + radius; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = worldPosition.getZ() - radius; z <= worldPosition.getZ() + radius; z++) {
                    int dx = x - worldPosition.getX();
                    int dy = y - worldPosition.getY();
                    int dz = z - worldPosition.getZ();
                    if (dx * dx + dy * dy + dz * dz <= radius * radius) {
                        BlockPos target = new BlockPos(x, y, z);
                        if (!level.getBlockState(target).isAir()) {
                            level.setBlock(target, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                        }
                    }
                }
            }
        }
    }

    private static void addSpawner(List<MobSpawnSettings.SpawnerData> candidates, EntityType<?> type,
                                   int weight, int minCount, int maxCount) {
        candidates.add(new MobSpawnSettings.SpawnerData(type, weight, minCount, maxCount));
    }

    private static Mob createMob(EntityType<?> type, ServerLevel level, BlockPos pos) {
        Entity entity = type.create(level);
        if (entity instanceof Mob mob) {
            mob.moveTo(pos, level.random.nextFloat() * 360.0F, 0.0F);
            return mob;
        }
        return null;
    }

    @Override
    protected void loadAdditional(net.minecraft.nbt.CompoundTag tag,
                                  net.minecraft.core.HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains(NETHER_STAGE)) {
            this.netherStage = Math.max(0, Math.min(4, tag.getInt(NETHER_STAGE)));
        }
        this.netherStageTicks = Math.max(0, tag.getInt(NETHER_STAGE_TICKS));
        this.netherMobWaveTicks = Math.max(0, tag.getInt(NETHER_MOB_WAVE_TICKS));
        this.netherDetonationPending = tag.getBoolean("NetherDetonationPending");
    }

    @Override
    protected void saveAdditional(net.minecraft.nbt.CompoundTag tag,
                                  net.minecraft.core.HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt(NETHER_STAGE, netherStage);
        tag.putInt(NETHER_STAGE_TICKS, netherStageTicks);
        tag.putInt(NETHER_MOB_WAVE_TICKS, netherMobWaveTicks);
        tag.putBoolean("NetherDetonationPending", netherDetonationPending);
    }
}
