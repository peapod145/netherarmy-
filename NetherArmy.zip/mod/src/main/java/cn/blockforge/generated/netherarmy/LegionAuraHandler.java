package cn.blockforge.generated.netherarmy;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * 军团光环的服务端结算中心。
 *
 * <p>规格：每个下界传令兵统计半径 30 格内的凋灵骷髅阵营生物（除凋灵 boss、
 * 其他传令兵与独来独往的黑客）作为追随者；追随者 ≥ 3 时，传令兵本人与全体追随者获得军团光环——
 * 护甲 +1、移速 +25%、攻速 +25%（攻速在 {@code MeleeAttackGoal} 的冷却注入里
 * 落地）、每 3 秒回复 1 点血量，脚下由客户端渲染光环贴图。</p>
 *
 * <p>此外，带光环的成员还有一条<b>速度下限</b>（{@link #enforceSpeedFloors}，
 * 每 tick 结算）：实际移速低于"授予其光环的传令兵"的当前移速时垫平到一致，
 * 高于传令兵的不予干预——传令兵跑得快，队伍不掉队；下限读的是传令兵的最终
 * 属性值，所以传令兵穿戴装备、喝药水、被减速导致移速变化时，成员的下限
 * 同 tick 跟着变。</p>
 *
 * <h3>为什么集中结算而不是写在传令兵的 tick 里</h3>
 * <p>两个传令兵的 30 格圈会重叠，同一个追随者可能同时属于两拨军团；如果各自
 * add/remove 修饰符与标志，收尾时序会互相踩。这里每 20 tick 把本维度所有传令兵
 * 扫一遍，取"应带光环"的并集（成员 → 授予其光环的传令兵集合），再与上一轮的
 * 名单做差分：新进的挂修饰符、出圈的摘干净，天然幂等，也不怕实体中途死亡/卸载
 * （名单只存 UUID，取不回实体就跳过）。</p>
 *
 * <h3>属性防呆</h3>
 * <p>阵营里不少生物（原版凋灵骷髅、尸鬼、衰翼……）的属性表里根本没有 ARMOR 项，
 * {@code getAttribute} 返回 null；{@link LegionFactionHandler} 会在属性事件里给
 * 它们补 0 点护甲底，这里仍对 null 做防御。移速是所有 Mob 的标配。</p>
 */
public final class LegionAuraHandler {
    /** 凋灵骷髅阵营名册（与 {@link WitherFactionInfectionHandler} 同一本账）。 */
    private static final TagKey<EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    private static final ResourceLocation AURA_ARMOR_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "legion_aura_armor");
    private static final ResourceLocation AURA_SPEED_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "legion_aura_speed");
    /** 速度下限补丁：运行时每 tick 现算现挂，进世界时由 {@link #onEntityJoin} 清残留。 */
    private static final ResourceLocation AURA_SPEED_FLOOR_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "legion_aura_speed_floor");
    private static final AttributeModifier AURA_ARMOR = new AttributeModifier(
            AURA_ARMOR_ID, 1.0D, AttributeModifier.Operation.ADD_VALUE);
    private static final AttributeModifier AURA_SPEED = new AttributeModifier(
            AURA_SPEED_ID, 0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);

    private static final double FOLLOW_RADIUS_SQR =
            NetherCourier.FOLLOW_RADIUS * NetherCourier.FOLLOW_RADIUS;
    /** 每 3 秒（60 tick）回 1 点血；结算循环是 20 tick 一轮，60 恰好整除。 */
    private static final long HEAL_INTERVAL_TICKS = 60L;
    /** 速度下限的收敛阈值（格/tick）：差距小于它就不再动属性，避免无意义抖动。 */
    private static final double SPEED_FLOOR_EPSILON = 1.0E-4D;

    /**
     * 每个维度当前带光环的实体 → 授予其光环的传令兵 UUID 集合（重叠军团取并集；
     * 传令兵自己只含自己）。上一轮名单与它做差分离圈者。
     */
    private static final Map<ServerLevel, Map<UUID, Set<UUID>>> AURA_SOURCES = new java.util.WeakHashMap<>();

    private LegionAuraHandler() {
    }

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        long gameTime = level.getGameTime();
        if (gameTime % 20L == 0L) {
            refreshAuras(level, gameTime);
        }
        enforceSpeedFloors(level);
    }

    /** 20 tick 一轮的光环名册重算：进圈挂光环、出圈摘干净、按节拍回血。 */
    private static void refreshAuras(ServerLevel level, long gameTime) {
        Map<UUID, Set<UUID>> sources = new HashMap<>();
        for (NetherCourier courier : level.getEntities(
                net.minecraft.world.level.entity.EntityTypeTest.forClass(NetherCourier.class),
                NetherCourier::isAlive)) {
            List<Mob> followers = collectFollowers(level, courier);
            if (followers.size() >= NetherCourier.MIN_FOLLOWERS_FOR_AURA) {
                link(sources, courier.getUUID(), courier.getUUID());
                for (Mob follower : followers) {
                    link(sources, follower.getUUID(), courier.getUUID());
                }
            }
        }

        Map<UUID, Set<UUID>> previous = AURA_SOURCES.getOrDefault(level, Map.of());
        for (UUID id : previous.keySet()) {
            if (!sources.containsKey(id) && level.getEntity(id) instanceof Mob mob && mob.isAlive()) {
                removeAura(mob);
            }
        }
        for (UUID id : sources.keySet()) {
            if (level.getEntity(id) instanceof Mob mob && mob.isAlive()) {
                applyAura(mob);
                if (gameTime % HEAL_INTERVAL_TICKS == 0L && mob.getHealth() < mob.getMaxHealth()) {
                    mob.heal(1.0F);
                }
            }
        }
        AURA_SOURCES.put(level, sources);
    }

    private static void link(Map<UUID, Set<UUID>> sources, UUID member, UUID courier) {
        sources.computeIfAbsent(member, id -> new LinkedHashSet<>()).add(courier);
    }

    /** 30 格内的合法追随者（不含凋灵 boss 与其他传令兵——名册本身就不含它们）。 */
    private static List<Mob> collectFollowers(ServerLevel level, NetherCourier courier) {
        AABB box = courier.getBoundingBox().inflate(NetherCourier.FOLLOW_RADIUS);
        return level.getEntitiesOfClass(Mob.class, box,
                mob -> isFollowerCandidate(mob) && mob.distanceToSqr(courier) <= FOLLOW_RADIUS_SQR);
    }

    /**
     * 可被传令兵征召的阵营生物：名册标签 + 无头骑士头颅，排除凋灵 boss、传令兵
     * 与黑客。黑客虽在凋灵骷髅名册里（友伤豁免、岩浆寻路等阵营待遇照旧），但它
     * 独来独往：不挂 {@link CourierFollowGoal}/{@link CourierProtectTargetGoal}、
     * 不计入军团光环人数，传令兵受击向 30 格内队友转移仇恨时也不算它一份。
     */
    public static boolean isFollowerCandidate(Mob mob) {
        if (!mob.isAlive() || mob instanceof NetherCourier || mob instanceof Hacker
                || mob instanceof OverlordWitherBoss) {
            return false;
        }
        return mob.getType().is(WITHER_SKELETONS) || mob instanceof DullhanHead;
    }

    /** 阵营成员（友伤判定用）：名册标签 + 头颅 + 传令兵本体。 */
    public static boolean isFactionMember(Entity entity) {
        if (entity instanceof NetherCourier) {
            return true;
        }
        if (entity instanceof DullhanHead) {
            return true;
        }
        return entity.getType().is(WITHER_SKELETONS);
    }

    /**
     * 实体进世界时清掉存进 NBT 的光环修饰符。永久属性修饰符会随生物的
     * "Attributes" 标签持久化，而 {@link #AURA_SOURCES} 是纯内存账——服务器
     * 重启后账本清空，存盘前带光环的成员若不清理，+25%/+1 护甲与速度下限
     * 就成了永久白嫖。清错也无妨：仍在传令兵 30 格内的成员，最多 1 秒后
     * （下一轮 20 tick 结算）光环原样补回。
     */
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        stripAuraModifiers(mob);
    }

    private static void applyAura(Mob mob) {
        ((ILegionAuraCarrier) mob).netherarmy$setLegionAura(true);
        addModifier(mob, Attributes.ARMOR, AURA_ARMOR);
        addModifier(mob, Attributes.MOVEMENT_SPEED, AURA_SPEED);
    }

    private static void removeAura(Mob mob) {
        ((ILegionAuraCarrier) mob).netherarmy$setLegionAura(false);
        stripAuraModifiers(mob);
    }

    /** 摘掉该生物身上全部军团光环修饰符（护甲 +1、移速 +25%、速度下限补丁）。 */
    private static void stripAuraModifiers(Mob mob) {
        removeModifier(mob, Attributes.ARMOR, AURA_ARMOR);
        removeModifier(mob, Attributes.MOVEMENT_SPEED, AURA_SPEED);
        removeModifier(mob, Attributes.MOVEMENT_SPEED, AURA_SPEED_FLOOR_ID);
    }

    // ------------------------------------------------------------------
    // 速度下限（军团光环成员 ⇔ 传令兵当前移速）
    // ------------------------------------------------------------------

    /**
     * 每 tick 结算：把带光环成员的移速垫到不低于授予其光环的传令兵的<b>当前</b>
     * 实际移速（读最终属性值，天然含传令兵自己的光环加成、装备属性与药水效果）。
     * 高于传令兵的成员一律不碰；传令兵全部死亡/卸载时下限归零并撤掉补丁。
     */
    private static void enforceSpeedFloors(ServerLevel level) {
        Map<UUID, Set<UUID>> sources = AURA_SOURCES.get(level);
        if (sources == null || sources.isEmpty()) {
            return;
        }
        for (Map.Entry<UUID, Set<UUID>> entry : sources.entrySet()) {
            if (!(level.getEntity(entry.getKey()) instanceof Mob member) || !member.isAlive()) {
                continue;
            }
            AttributeInstance speed = member.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed == null) {
                continue;
            }
            double target = courierFloorValue(level, entry.getValue());
            if (target <= SPEED_FLOOR_EPSILON) {
                if (speed.hasModifier(AURA_SPEED_FLOOR_ID)) {
                    speed.removeModifier(AURA_SPEED_FLOOR_ID);
                }
                continue;
            }
            applySpeedFloor(speed, target);
        }
    }

    /** 成员所属多支军团（圈重叠）时取最快的那名传令兵；取不到活传令兵返回 0。 */
    private static double courierFloorValue(ServerLevel level, Set<UUID> courierIds) {
        double fastest = 0.0D;
        for (UUID courierId : courierIds) {
            if (level.getEntity(courierId) instanceof NetherCourier courier && courier.isAlive()
                    && courier.getAttribute(Attributes.MOVEMENT_SPEED) instanceof AttributeInstance leaderSpeed) {
                fastest = Math.max(fastest, leaderSpeed.getValue());
            }
        }
        return fastest;
    }

    /**
     * 给属性实例垫一个专属 ADD_VALUE 修饰符，使最终值不低于 {@code target}。
     * 最终值 = (基数 + ΣADD_VALUE) × Π乘区，所以把差额除以乘区总和才是修饰符数值
     * ——成员自身若也带 +25% 之类的乘区加成，补丁量要相应放大，垫完恰好齐平。
     * 差额收敛在阈值内、或既有下限数值没变时直接不动属性，避免每 tick 广播属性包。
     */
    private static void applySpeedFloor(AttributeInstance speed, double target) {
        double multiplier = multipliedModifierSum(speed);
        AttributeModifier existing = speed.getModifier(AURA_SPEED_FLOOR_ID);
        double natural = speed.getValue() - (existing == null ? 0.0D : existing.amount() * multiplier);
        double gap = target - natural;
        if (gap <= SPEED_FLOOR_EPSILON) {
            if (existing != null) {
                speed.removeModifier(AURA_SPEED_FLOOR_ID);
            }
            return;
        }
        if (Math.abs(multiplier) <= SPEED_FLOOR_EPSILON) {
            return; // 乘区整体为 0 的畸形属性，加法修饰符垫不起来
        }
        double amount = gap / multiplier;
        if (existing != null && Math.abs(existing.amount() - amount) <= 1.0E-6D) {
            return;
        }
        speed.addOrReplacePermanentModifier(new AttributeModifier(
                AURA_SPEED_FLOOR_ID, amount, AttributeModifier.Operation.ADD_VALUE));
    }

    /** Π(1 + Σadd_multiplied_base) × Π(1 + Σadd_multiplied_total)：属性最终值的乘区因子。 */
    private static double multipliedModifierSum(AttributeInstance speed) {
        double multipliedBase = 1.0D;
        double multipliedTotal = 1.0D;
        for (AttributeModifier modifier : speed.getModifiers()) {
            if (modifier.operation() == AttributeModifier.Operation.ADD_MULTIPLIED_BASE) {
                multipliedBase += modifier.amount();
            } else if (modifier.operation() == AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL) {
                multipliedTotal += modifier.amount();
            }
        }
        return multipliedBase * multipliedTotal;
    }

    private static void addModifier(Mob mob, Holder<Attribute> attribute, AttributeModifier modifier) {
        AttributeInstance instance = mob.getAttribute(attribute);
        if (instance != null && !instance.hasModifier(modifier.id())) {
            instance.addPermanentModifier(modifier);
        }
    }

    private static void removeModifier(Mob mob, Holder<Attribute> attribute, AttributeModifier modifier) {
        removeModifier(mob, attribute, modifier.id());
    }

    private static void removeModifier(Mob mob, Holder<Attribute> attribute, ResourceLocation modifierId) {
        AttributeInstance instance = mob.getAttribute(attribute);
        if (instance != null && instance.hasModifier(modifierId)) {
            instance.removeModifier(modifierId);
        }
    }
}
