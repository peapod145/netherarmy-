package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.attachment.AttachmentHolder;

/** 灵魂火燃烧状态的统一读写入口，状态由 NeoForge 实体附件同步。 */
public final class SoulFireBurn {
    private SoulFireBurn() {
    }

    public static boolean isSoulFlame(Entity entity) {
        return entity instanceof AttachmentHolder holder
                && holder.getData(GeneratedMod.SOUL_FLAME.get());
    }

    public static void setSoulFlame(Entity entity, boolean value) {
        if (!(entity instanceof AttachmentHolder holder)
                || isSoulFlame(entity) == value) {
            return;
        }
        holder.setData(GeneratedMod.SOUL_FLAME.get(), value);
    }

    public static boolean isSelfSustained(Entity entity) {
        return entity instanceof ShadowApostle apostle && apostle.isCharging();
    }

    public static void ignite(LivingEntity entity, float seconds) {
        entity.igniteForSeconds(seconds);
        setSoulFlame(entity, true);
    }
}
