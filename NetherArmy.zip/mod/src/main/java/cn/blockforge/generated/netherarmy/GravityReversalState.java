package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.attachment.AttachmentHolder;

/**
 * "实体此刻是否处于重力反转中"的统一读写入口，状态由 NeoForge 实体附件同步。
 *
 * <p>这份状态存在的唯一理由是：客户端看不到怪身上的效果。1.21.1 的服务端不向客户端同步
 * 非玩家生物的状态效果（详见 {@link GeneratedMod#GRAVITY_REVERSED} 的说明），而
 * {@code LivingEntityRenderer#isEntityUpsideDown} 这个倒置判定是在客户端跑的，它只认客户端
 * 本地能读到的东西。服务端每 tick 用 {@link #setReversed} 把"效果在不在"写进附件，
 * 由 NeoForge 广播给正在追踪该实体的玩家，渲染半边就能读到同一份真相。</p>
 *
 * <p>读写都走 {@code getExistingDataOrNull} 而不是 {@code getData}，是为了<b>不凭空创建条目</b>：
 * {@code getData} 在缺省时会替实体建一个 false 附件并立刻同步一次，那意味着世界里每一只
 * 从未中过招的生物都要白发一个包；用"取不到就当 false"的读法，只有真正中过招的实体才会有
 * 这条同步记录。物理半边（{@code EntityGravityReversalMixin}）判据仍是服务端的真实效果，
 * 这里只负责"让客户端也能看见"。</p>
 */
public final class GravityReversalState {
    private GravityReversalState() {
    }

    /** 客户端与服务端通用：该实体当前是否应该上下颠倒。取不到附件一律按未反转处理。 */
    public static boolean isReversed(Entity entity) {
        return entity instanceof AttachmentHolder holder
                && Boolean.TRUE.equals(holder.getExistingDataOrNull(GeneratedMod.GRAVITY_REVERSED.get()));
    }

    /** 服务端写入，值没变时不发包（附件同步由 NeoForge 在 {@code setData} 里自动触发）。 */
    public static void setReversed(Entity entity, boolean value) {
        if (!(entity instanceof AttachmentHolder holder) || isReversed(entity) == value) {
            return;
        }
        holder.setData(GeneratedMod.GRAVITY_REVERSED.get(), value);
    }

    /**
     * 服务端每 tick 的维护动作：把附件对齐到实体身上真实的效果状态。
     *
     * <p>这样添加、续时长、自然到期、{@code /effect clear}、死亡清空，以及任何别的模组给生物
     * 挂上这个效果的情况，全都自动跟上——不需要逐个去挂钩"效果被加/被移"的事件，
     * 也不存在漏掉某条移除路径就让怪物永久倒立的风险。</p>
     */
    public static void syncFromEffect(LivingEntity entity) {
        setReversed(entity, entity.hasEffect(GeneratedMod.GRAVITY_REVERSAL));
    }
}
