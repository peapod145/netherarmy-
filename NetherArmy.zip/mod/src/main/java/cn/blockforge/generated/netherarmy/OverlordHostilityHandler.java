package cn.blockforge.generated.netherarmy;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 全场众生对霸主凋灵的敌意：凡是不属于凋灵骷髅阵营的生物，都把霸主当成敌人。
 *
 * <h3>补的是哪半边</h3>
 * <p>霸主凋灵自己是阵营成员（{@code extends WitherBoss}，也登记在军团亡灵名册
 * {@code #netherarmy:nether_legion_undead} 里、由阵营名册 {@code #netherarmy:wither_faction}
 * 嵌套），所以"恨整个阵营"的那批生物
 * 天生就恨它：铁傀儡／雪傀儡由 {@link WitherFactionHostilityHandler} 挂了全阵营索敌目标，
 * 成年猪灵与猪灵蛮兵由同一处理器的复仇记忆通道点名，蓝图器械按
 * {@code Enemy} 口径自取。缺的是<b>其余所有生物</b>——僵尸、骷髅、苦力怕、蜘蛛、
 * 末影人、女巫、灾厄村民、烈焰人、恶魂、狼、羊驼、熊猫，以及第三方模组的怪：
 * 它们的目标组只锁玩家／村民／傀儡这几类固定名单，霸主不在任何一份名单里，
 * 于是战场上出现"凋灵在旁边飞，一屋子怪各忙各的"的尴尬。这里把这条边补齐。</p>
 *
 * <h3>两条通道，按生物的索敌实现分流</h3>
 * <ol>
 * <li><b>目标组通道</b>（{@link EntityJoinLevelEvent}，服务端）：沿用
 * {@link MachineryHostilityHandler} 的套路，在 {@code targetSelector} 的 3 优先级挂一个
 * 只认霸主的 {@link OverlordTargetGoal}。目标不进 NBT，区块重载时事件重放，
 * 幂等检查防止重复挂载。</li>
 * <li><b>脑记忆通道</b>（{@link EntityTickEvent.Post}，每 20 tick 一次）：疣猪兽、监守者、
 * 青蛙、蝾螈这类 Brain AI 覆盖了 {@code getTarget()}，读的是脑里的 {@code ATTACK_TARGET}
 * 记忆——给它们挂目标组等于每 10 tick 白扫一次箱。凡是脑里注册了 {@code ATTACK_TARGET}
 * 的生物都改走记忆写入：补 {@code ANGRY_AT}（注册了才写）＋ {@code ATTACK_TARGET}，
 * 监守者则只喂 {@code increaseAngerAt}（它的 FIGHT 活动以愤怒值为前提，没有愤怒时写进去的
 * 攻击目标会在下一脑 tick 被原版校验行为抹掉）。写法与
 * {@code MesmerizerControlHandler#setControlledMobTarget} 同源，猪灵系不在此列——
 * 它们已由 {@link WitherFactionHostilityHandler} 用复仇记忆处理过，避免两套逻辑互相抢写。</li>
 * </ol>
 *
 * <h3>只填空位，不抢现仇</h3>
 * <p>两条通道都遵守同一条规矩：<b>该生物此刻还锁着活目标就不动手</b>。原版的
 * {@code NearestAttackableTargetGoal.canUse()} 并不检查 {@code Mob#getTarget()}，
 * 只要扫描命中就 {@code start()} 改写目标；照抄过来会让正在追玩家的怪每 10 tick
 * 被霸主拽走一次，玩家反而安全得离谱。加了这道闸门后，霸主是"闲下来就打"的敌人，
 * 而它自己那身凋灵光环与凋灵之首一视同仁地砸向四周，被砸到的怪立刻由 1 优先级的
 * 受击反击记仇——两条路合起来，场上不会出现无视霸主的怪。</p>
 *
 * <h3>不会打架的旁观者不挂目标</h3>
 * <p>牛、羊、猪、鸡、村民这类生物压根没有攻击手段。给它们塞一个目标只会让
 * {@code RandomStrollGoal}/{@code WaterAvoidingRandomStrollGoal} 因"已有目标"而停摆，
 * 结果是全场的动物杵在原地盯着霸主发呆（与"反转士面对某些生物不施法"同一类毛病）。
 * 因此先过一遍 {@link #canFight}：{@code Enemy} 标记、脑里注册了 {@code ATTACK_TARGET}、
 * 或目标组里能找到近战／远程攻击组三者之一，才算有作战能力。</p>
 *
 * <h3>军团一侧不受影响</h3>
 * <p>排除名单：阵营成员（含霸主自己、所有军团生物与无头骑士头颅）、被心控者
 * （{@code MesmerizerControl#isControlled}，它们是军团的盟军）、《机械传说》的反逆器械
 * （{@link MachineryLegendCompat#isRebelMachinery}，同理）、以及幼崽与 {@code NoAI}。
 * 这条与 {@code MesmerizerControl#canAttack} 的门禁口径完全一致，不会出现
 * "盟军转头轰炸自己人"的自相残杀。</p>
 *
 * <h3>霸主不在场时近乎零开销</h3>
 * <p>全场每个怪都多挂一个目标组、每 20 tick 都有一次脑判定，代价不能靠"反正是空扫描"
 * 糊过去。因此加了一道维度级闸门：只有最近 20 tick 内有霸主凋灵报到过（由它自己的
 * {@code EntityTickEvent.Post} 写入游戏刻），索敌扫描才会真的发生。霸主是召唤出来的
 * 稀有实体，绝大多数时间这条通道完全闭合，普通生物的行为与不装本处理器时逐 tick 一致。
 * 键用维度键、值是游戏刻，既不用弱引用表也不怕漏掉某个移除事件——霸主死亡或被区块
 * 卸载后保鲜期自然过完，闸门自动关闭。</p>
 */
public final class OverlordHostilityHandler {
    /** 索敌目标组的优先级：1 是受击反击、2 是各生物的原生目标名单，霸主排在"闲下来才打"这一档。 */
    private static final int TARGET_GOAL_PRIORITY = 3;
    /** 目标组的重扫间隔（tick），与阵营索敌、器械索敌同一档。 */
    private static final int GOAL_SCAN_INTERVAL = 10;
    /** 脑驱动生物的仇恨补写间隔（tick），避免脑 AI 出现明显锁敌空窗。 */
    private static final int BRAIN_SCAN_INTERVAL = 5;
    /** 在场判定的保鲜期（tick）：霸主死亡或被区块卸载后，最多这么久全场扫描随之闭合。 */
    private static final int PRESENCE_TTL = 20;
    /** 复仇记忆的时长（tick），与 {@code WitherFactionHostilityHandler} 的写法一致。 */
    private static final long ANGER_MEMORY_TTL = 600L;
    /** 攻击目标记忆的时长（tick）：必须明显长于补写间隔，否则两次补写之间会自行过期。 */
    private static final long ATTACK_TARGET_TTL = 200L;
    /** 每轮给监守者累加的愤怒值：阈值 80 才算"发怒"，两三轮即可进入战斗活动。 */
    private static final int WARDEN_ANGER_STEP = 30;
    /** 没有跟随距离属性的生物的兜底半径。 */
    private static final double DEFAULT_FOLLOW_RANGE = 16.0D;

    /** 维度 → 该维度内霸主凋灵最后一次报到的游戏刻。纯内存，不入存档。 */
    private static final Map<ResourceKey<Level>, Long> OVERLORD_SEEN_AT = new ConcurrentHashMap<>();

    private OverlordHostilityHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (!(event.getEntity() instanceof Mob mob)) {
            return;
        }
        // 脑驱动的怪的 getTarget() 只读 ATTACK_TARGET 记忆，挂目标组看不见，交给记忆通道。
        if (usesBrainTargeting(mob)) {
            return;
        }
        if (!resentsTheOverlord(mob) || !canFight(mob)) {
            return;
        }
        if (hasOverlordTargetGoal(mob)) {
            return;
        }
        mob.targetSelector.addGoal(TARGET_GOAL_PRIORITY, new OverlordTargetGoal(mob));
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof Mob mob)) {
            return;
        }
        Level level = mob.level();
        if (level.isClientSide()) {
            return;
        }
        if (mob instanceof OverlordWitherBoss) {
            OVERLORD_SEEN_AT.put(level.dimension(), level.getGameTime());
            return;
        }
        if (mob.tickCount % BRAIN_SCAN_INTERVAL != 0 || !isOverlordInPlay(level)) {
            return;
        }
        if (!usesBrainTargeting(mob) || !resentsTheOverlord(mob)) {
            return;
        }
        if (mob.isBaby() || mob.isNoAi() || HackerCountermeasureHandler.isSuppressed(mob)) {
            return;
        }
        LivingEntity current = mob.getTarget();
        if (current != null && current.isAlive()) {
            return;
        }
        OverlordWitherBoss overlord = nearestVisibleOverlord(mob);
        if (overlord == null) {
            return;
        }
        imposeBrainAnger(mob, overlord);
    }

    /** 该维度内此刻是否有正在活动的霸主凋灵（决定两条通道的扫描要不要真的发生）。 */
    private static boolean isOverlordInPlay(Level level) {
        Long seenAt = OVERLORD_SEEN_AT.get(level.dimension());
        return seenAt != null && level.getGameTime() - seenAt <= PRESENCE_TTL;
    }

    /**
     * 该生物是否应当把霸主视作敌人。四条排除对应军团一侧的四类盟军，
     * 口径与 {@code MesmerizerControl#canAttack} 的门禁一致。
     */
    private static boolean resentsTheOverlord(Mob mob) {
        // 霸主属于凋灵骷髅阵营：同袍互不可攻击，它自己也不必恨自己。
        if (MesmerizerControl.isWitherSkeletonFaction(mob)) {
            return false;
        }
        // 被心控的生物与反逆器械属于反逆者一侧，是军团的盟军。
        if (MesmerizerControl.isControlled(mob) || MachineryLegendCompat.isRebelMachinery(mob)) {
            return false;
        }
        // 猪灵系与两种傀儡早被 WitherFactionHostilityHandler 记成阵营公敌（霸主也在其列），
        // 再挂一份等于同一目标扫两遍，还可能与那侧的复仇记忆逻辑抢写。
        return !(mob instanceof AbstractPiglin)
                && !(mob instanceof IronGolem)
                && !(mob instanceof SnowGolem);
    }

    /** 该生物有没有作战能力：{@code Enemy} 标记、脑里有攻击目标记忆、或目标组里有攻击组。 */
    private static boolean canFight(Mob mob) {
        if (mob instanceof Enemy || usesBrainTargeting(mob)) {
            return true;
        }
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            Goal goal = wrapped.getGoal();
            if (goal instanceof MeleeAttackGoal
                    || goal instanceof RangedAttackGoal
                    || goal instanceof RangedBowAttackGoal
                    || goal instanceof RangedCrossbowAttackGoal) {
                return true;
            }
        }
        return false;
    }

    private static boolean usesBrainTargeting(Mob mob) {
        return registersMemory(mob, MemoryModuleType.ATTACK_TARGET);
    }

    /**
     * 脑记忆是否注册过该模块。原版的读写都以"已注册"为前提，未注册时
     * {@code eraseMemory} 一类接口会直接抛 {@code IllegalStateException}
     * （见 {@code HackerCountermeasureHandler#eraseRegisteredMemory} 的说明），
     * 而"这只怪用不用脑索敌"正是靠这份名册判断的。
     */
    private static boolean registersMemory(Mob mob, MemoryModuleType<?> type) {
        return mob.getBrain().getMemories().containsKey(type);
    }

    private static boolean hasOverlordTargetGoal(Mob mob) {
        return mob.targetSelector.getAvailableGoals().stream()
                .map(WrappedGoal::getGoal)
                .anyMatch(OverlordTargetGoal.class::isInstance);
    }

    /** 按生物自己的跟随距离找最近、且看得见、已进入可被打状态的霸主。 */
    private static OverlordWitherBoss nearestVisibleOverlord(Mob mob) {
        if (!(mob.level() instanceof ServerLevel level)) {
            return null;
        }
        double range = followRange(mob);
        List<OverlordWitherBoss> nearby = level.getEntitiesOfClass(OverlordWitherBoss.class,
                mob.getBoundingBox().inflate(range), OverlordHostilityHandler::isAttackableOverlord);
        OverlordWitherBoss nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (OverlordWitherBoss overlord : nearby) {
            double distance = mob.distanceToSqr(overlord);
            if (distance > range * range || distance >= nearestDistance) {
                continue;
            }
            if (!mob.getSensing().hasLineOfSight(overlord)) {
                continue;
            }
            nearestDistance = distance;
            nearest = overlord;
        }
        return nearest;
    }

    /**
     * 可以列为打击目标的霸主：活着，且已经走完召唤动画。
     *
     * <p>召唤动画那 220 tick 里它是无敌的，原版凋灵此时也打不动；提前把全场的怪
     * 放出去围一个打不动的目标，看上去只会像 AI 故障。{@code getInvulnerableTicks()}
     * 被 {@code Bedserker}／{@code HolyBomb} 这类"强行破盾"的写法清零时动画视为结束，
     * 索敌也随之放开，与模组既有的无敌期口径保持一致。</p>
     */
    private static boolean isAttackableOverlord(LivingEntity candidate) {
        return candidate instanceof OverlordWitherBoss overlord
                && overlord.isAlive()
                && overlord.getInvulnerableTicks() <= 0;
    }

    /** 把霸主写进脑驱动生物的仇恨记忆。 */
    private static void imposeBrainAnger(Mob mob, OverlordWitherBoss overlord) {
        if (mob instanceof Warden warden) {
            // 监守者只认愤怒值：FIGHT 活动里 StopAttackingIfTargetInvalid 的谓词要求
            // getAngerLevel().isAngry()，光写 ATTACK_TARGET 会在下一脑 tick 被抹掉。
            // 不直接用 setAttackTarget——它顺带把声波冷却重置成 200 tick，按 20 tick 补写
            // 就等于永远不许监守者放声波。第三参数关叫喊音效，免得每轮扫描播一次。
            warden.increaseAngerAt(overlord, WARDEN_ANGER_STEP, false);
            return;
        }
        Brain<?> brain = mob.getBrain();
        // 清掉"够不着"计时，否则走位行为会把新目标当成死路直接放弃。
        HackerCountermeasureHandler.eraseRegisteredMemory(mob, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);
        if (registersMemory(mob, MemoryModuleType.ANGRY_AT)) {
            brain.setMemoryWithExpiry(MemoryModuleType.ANGRY_AT, overlord.getUUID(), ANGER_MEMORY_TTL);
        }
        brain.setMemoryWithExpiry(MemoryModuleType.ATTACK_TARGET, overlord, ATTACK_TARGET_TTL);
        // 半脑半目标组的混合 AI（以及只看经典字段的模组怪）也一并喂到。
        mob.setTarget(overlord);
    }

    private static double followRange(Mob mob) {
        if (mob.getAttribute(Attributes.FOLLOW_RANGE) != null) {
            return Math.max(1.0D, mob.getAttributeValue(Attributes.FOLLOW_RANGE));
        }
        return DEFAULT_FOLLOW_RANGE;
    }

    /**
     * 只把霸主凋灵列进索敌名单的目标组。
     *
     * <p>目标类型直接用 {@code OverlordWitherBoss.class} 而不是宽泛的 {@code LivingEntity.class}
     * ＋谓词：原版的 {@code findTarget()} 会按这个类过滤包围盒内的实体，霸主是稀有实体，
     * 一次扫描捞上来的候选数量几乎为零，比"整盒实体再过一遍谓词"便宜得多。</p>
     */
    private static final class OverlordTargetGoal extends NearestAttackableTargetGoal<OverlordWitherBoss> {
        private OverlordTargetGoal(Mob mob) {
            super(mob, OverlordWitherBoss.class, GOAL_SCAN_INTERVAL, true, false,
                    OverlordHostilityHandler::isAttackableOverlord);
        }

        @Override
        public boolean canUse() {
            if (!isOverlordInPlay(this.mob.level())) {
                return false;
            }
            LivingEntity current = this.mob.getTarget();
            if (current != null && current.isAlive()) {
                return false;
            }
            return super.canUse();
        }
    }
}
