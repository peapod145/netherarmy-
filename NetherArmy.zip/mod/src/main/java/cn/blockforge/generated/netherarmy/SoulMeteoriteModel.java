package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 灵魂陨石落地前的立方体（16×16×16，贴图六个面都贴满）。
 */
public final class SoulMeteoriteModel extends EntityModel<SoulMeteorite> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soul_meteorite"), "main");
    private static final int TEX_WIDTH = 16;
    private static final int TEX_HEIGHT = 16;

    private final ModelPart root;

    public SoulMeteoriteModel(ModelPart root) {
        this.root = root;
    }

    @Override
    public void setupAnim(SoulMeteorite entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        HackerQuads.emit(poseStack, buffer, this.root, SoulMeteoriteQuads.QUADS,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("meteorite", CubeListBuilder.create(), PartPose.offset(0.0F, 16.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
