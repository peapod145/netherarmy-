package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;

/**
 * 灵魂土偶的弓目标：补上原版 {@code RangedBowAttackGoal} 缺失的存活判定，
 * 避免目标死后仍继续拉弓射击。
 */
final class SoulsandFigurineBowAttackGoal extends RangedBowAttackGoal<SoulsandFigurine> {
    private final SoulsandFigurine figurine;

    SoulsandFigurineBowAttackGoal(SoulsandFigurine figurine, double speedModifier, int attackInterval,
                                  float attackRadius) {
        super(figurine, speedModifier, attackInterval, attackRadius);
        this.figurine = figurine;
    }

    @Override
    public boolean canUse() {
        LivingEntity target = this.figurine.getTarget();
        return target != null && target.isAlive() && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity target = this.figurine.getTarget();
        return target != null && target.isAlive() && super.canContinueToUse();
    }
}
