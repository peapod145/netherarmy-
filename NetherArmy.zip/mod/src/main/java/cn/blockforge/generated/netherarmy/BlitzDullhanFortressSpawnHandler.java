package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent;

/** 下界要塞与小型要塞中的无头强袭骑士稀有刷新。 */
public final class BlitzDullhanFortressSpawnHandler {
    private static final float SPAWN_CHANCE = 0.0001F;

    private BlitzDullhanFortressSpawnHandler() {
    }

    @SubscribeEvent
    public static void onFinalizeSpawn(FinalizeSpawnEvent event) {
        Mob source = event.getEntity();
        MobSpawnType spawnType = event.getSpawnType();

        if (source instanceof DullhanBody
                || source instanceof DullhanHead
                || source instanceof DullhanHorse
                || (spawnType != MobSpawnType.NATURAL
                    && spawnType != MobSpawnType.CHUNK_GENERATION
                    && spawnType != MobSpawnType.STRUCTURE)) {
            return;
        }

        ServerLevelAccessor level = event.getLevel();
        if (level.getLevel().dimension() != Level.NETHER) {
            return;
        }

        BlockPos pos = BlockPos.containing(event.getX(), event.getY(), event.getZ());
        if (!FortressSpawnBlacklistHandler.insideFortress(level, pos)
                || source.getRandom().nextFloat() >= SPAWN_CHANCE) {
            return;
        }

        ServerLevel serverLevel = level.getLevel();
        BlitzDullhanBody blitz = GeneratedMod.BLITZ_DULLHAN_BODY.get().create(serverLevel);
        if (blitz == null
                || !SpawnPlacements.isSpawnPositionOk(blitz.getType(), serverLevel, pos)
                || !SpawnPlacements.checkSpawnRules(blitz.getType(), serverLevel, spawnType, pos,
                        source.getRandom())) {
            return;
        }

        blitz.moveTo(event.getX(), event.getY(), event.getZ(), source.getYRot(), 0.0F);
        DifficultyInstance difficulty = event.getDifficulty();
        blitz.finalizeSpawn(serverLevel, difficulty, spawnType, null);
        if (serverLevel.isUnobstructed(blitz)
                && serverLevel.noCollision(blitz)
                && !serverLevel.containsAnyLiquid(blitz.getBoundingBox())) {
            serverLevel.addFreshEntity(blitz);
        }
    }
}
