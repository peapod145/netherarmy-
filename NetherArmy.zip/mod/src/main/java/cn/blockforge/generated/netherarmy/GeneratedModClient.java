package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.HorseModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.PhantomRenderer;
import net.minecraft.client.renderer.entity.SkeletonRenderer;
import net.minecraft.client.renderer.entity.layers.EnergySwirlLayer;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.BossEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.CustomizeGuiOverlayEvent;
import net.minecraft.client.renderer.entity.UndeadHorseRenderer;
import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.layers.PhantomEyesLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AnimalArmorItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.ClientHooks;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.gui.ScreenUtils;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = GeneratedMod.MOD_ID, dist = Dist.CLIENT)
public final class GeneratedModClient {
    private static BerserkerHelmetArmorModel helmetArmorModel;
    private static MesmerizerCrownArmorModel mesmerizerCrownArmorModel;
    private static NetherCrystalHelmetArmorModel netherCrystalHelmetArmorModel;
    private static NetherCrystalChestplateArmorModel netherCrystalChestplateArmorModel;
    private static NetherCrystalLeggingsArmorModel netherCrystalLeggingsArmorModel;
    private static NetherCrystalBootsArmorModel netherCrystalBootsArmorModel;
    private static final ResourceLocation GEARDLE_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/misc/geardle.png");
    private static final ResourceLocation GEARDLE_BLIND_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/misc/geardle_blind.png");
    private static final ResourceLocation OVERLORD_BOSS_BAR_BACKGROUND = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/gui/overlord_wither_boss_bar_background.png");
    private static final ResourceLocation OVERLORD_BOSS_BAR_PROGRESS = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/gui/overlord_wither_boss_bar_progress.png");

    public GeneratedModClient(IEventBus modBus) {
        modBus.addListener(GeneratedModClient::registerLayerDefinitions);
        modBus.addListener(GeneratedModClient::registerRenderers);
        modBus.addListener(GeneratedModClient::registerParticleProviders);
        modBus.addListener(GeneratedModClient::addLegionAuraLayers);
        modBus.addListener(GeneratedModClient::registerClientExtensions);
        modBus.addListener(GeneratedModClient::registerScreens);
        // blocking 属性必须等注册表绑定后再注册：构造函数阶段 SOUL_SHIELD.get() 还是
        // unbound 的，直接调用会让游戏在模组加载期崩溃（NPE: Trying to access unbound value）。
        modBus.addListener(GeneratedModClient::onClientSetup);
        NeoForge.EVENT_BUS.register(GeneratedModClient.class);
        NeoForge.EVENT_BUS.register(GravityReversalClientHandler.class);
    }

    /** 自有铁砧菜单直接复用原版铁砧界面（菜单本身就是 AnvilMenu 子类）。 */
    private static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(GeneratedMod.SOUL_SHIELD_ANVIL_MENU.get(), AnvilScreen::new);
    }

    private static void onClientSetup(net.neoforged.fml.event.lifecycle.FMLClientSetupEvent event) {
        registerShieldBlockingProperty();
        StartupWatchdog.start();
        GeneratedMod.LOGGER.info("[netherarmy] client setup done");
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        int hand = GeardleHandler.CLIENT_PENDING_GEARDLE_HAND;
        if (hand >= 0 && Minecraft.getInstance().screen == null) {
            GeardleHandler.CLIENT_PENDING_GEARDLE_HAND = -1;
            GeardleConfirmationScreen.open(hand);
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null && minecraft.player.hasEffect(GeneratedMod.REBELLION)) {
            event.getGuiGraphics().fill(0, 0, event.getGuiGraphics().guiWidth(), event.getGuiGraphics().guiHeight(), 0x452C075E);
        }
        if (GeardleHandler.CLIENT_APOCALYPSE && minecraft.level != null
                && minecraft.level.dimensionType().hasSkyLight() && GeardleHandler.isNight(minecraft.level)) {
            GuiGraphics graphics = event.getGuiGraphics();
            graphics.setColor(1.0F, 1.0F, 1.0F, 0.8F);
            graphics.blit(GEARDLE_BLIND_TEXTURE, 0, 0,
                    graphics.guiWidth(), graphics.guiHeight(), 0.0F, 0.0F,
                    558, 448, 558, 448);
            graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onRenderGeardle(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES
                || !GeardleHandler.CLIENT_APOCALYPSE) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.level == null) {
            return;
        }
        // 光环贴在背后，第一人称不该看见它（低头时它原本会闯进视野）：直接不画。
        if (minecraft.options.getCameraType().isFirstPerson()) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        // 位置与角度都绑定躯干（yBodyRot），不再跟随头部视线（getLookAngle）与
        // 镜头朝向（camera.rotation 的 billboard）：转身体光环才跟着转，
        // 转头、抬头低头都不动；正面（THIRD_PERSON_FRONT）看不到背面属正常遮挡。
        float bodyYaw = Mth.lerp(partialTick, player.yBodyRotO, player.yBodyRot);
        float yawRad = bodyYaw * Mth.DEG_TO_RAD;
        Vec3 playerPosition = player.getPosition(partialTick);
        // 躯干朝向向量 (-sinθ, 0, cosθ)，光环悬在其反方向（背后）1.35 格处。
        Vec3 center = playerPosition.add(0.0D, 1.15D, 0.0D)
                .add(Mth.sin(yawRad) * 1.35D, 0.0D, -Mth.cos(yawRad) * 1.35D);
        Vec3 cameraPosition = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        poseStack.translate(center.x - cameraPosition.x, center.y - cameraPosition.y,
                center.z - cameraPosition.z);
        // 绕 Y 转 (180° - 躯干偏航)：面片法线 (0,0,1) 转到 (sinθ,0,-cosθ)，
        // 即正面朝身体正后方（第三人居后视角看得见，躯干转多少它转多少）。
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
        float halfSize = 0.8F;
        VertexConsumer consumer = minecraft.renderBuffers().bufferSource()
                .getBuffer(RenderType.entityTranslucent(GEARDLE_TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        addGeardleVertex(consumer, pose, -halfSize, -halfSize, 0.0F, 0.0F, 1.0F);
        addGeardleVertex(consumer, pose, -halfSize, halfSize, 0.0F, 0.0F, 0.0F);
        addGeardleVertex(consumer, pose, halfSize, halfSize, 0.0F, 1.0F, 0.0F);
        addGeardleVertex(consumer, pose, halfSize, -halfSize, 0.0F, 1.0F, 1.0F);
        poseStack.popPose();
    }

    private static void addGeardleVertex(VertexConsumer consumer, PoseStack.Pose pose,
                                         float x, float y, float z, float u, float v) {
        consumer.addVertex(pose, x, y, z).setColor(255, 255, 255, 255)
                .setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY).setLight(0xF000F0)
                .setNormal(pose, 0.0F, 0.0F, 1.0F);
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onBossEventProgress(CustomizeGuiOverlayEvent.BossEventProgress event) {
        BossEvent bossEvent = event.getBossEvent();
        if (!(bossEvent.getName().getContents() instanceof TranslatableContents contents)
                || !"entity.netherarmy.overlord_wither".equals(contents.getKey())) {
            return;
        }
        event.setCanceled(true);
        GuiGraphics graphics = event.getGuiGraphics();
        int x = event.getX();
        int y = event.getY();
        int progressWidth = Math.round(182.0F * Math.clamp(bossEvent.getProgress(), 0.0F, 1.0F));
        graphics.blit(OVERLORD_BOSS_BAR_BACKGROUND, x, y, 182, 29,
                0.0F, 0.0F, 182, 29, 182, 29);
        if (progressWidth > 0) {
            graphics.blit(OVERLORD_BOSS_BAR_PROGRESS, x, y, progressWidth, 29,
                    0.0F, 0.0F, progressWidth, 29, 182, 29);
        }
        graphics.blit(OVERLORD_BOSS_BAR_BACKGROUND, x + 82, y, 18, 29,
                82.0F, 0.0F, 18, 29, 182, 29);
        Font font = Minecraft.getInstance().font;
        graphics.drawString(font, bossEvent.getName(), x + 91 - font.width(bossEvent.getName()) / 2,
                y - 9, 0xFFFFFF, false);
        event.setIncrement(32);
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!event.getEntity().hasEffect(GeneratedMod.REBELLION)) {
            return;
        }

        var input = event.getInput();
        input.leftImpulse = 0.0F;
        input.forwardImpulse = 0.0F;
        input.up = false;
        input.down = false;
        input.left = false;
        input.right = false;
        input.jumping = false;
        input.shiftKeyDown = false;
    }

    /** 注册符卡规则的粒子提供者（模组总线，仅客户端）。 */
    private static void registerParticleProviders(net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent event) {
        // 符卡规则的黑白交替粒子：贴图帧由 assets/netherarmy/particles/spell_card_rules.json
        // 提供（复用原版 effect_0..7 星形帧），颜色翻转在 SpellCardRulesParticle 内部完成。
        event.registerSpriteSet(GeneratedMod.SPELL_CARD_RULES_PARTICLE.get(),
                sprites -> (options, level, x, y, z, dx, dy, dz) ->
                        new SpellCardRulesParticle(level, x, y, z, dx, dy, dz, sprites));
    }

    private static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BerserkerModel.LAYER, BerserkerModel::createBodyLayer);
        event.registerLayerDefinition(BedserkerModel.LAYER, BedserkerModel::createBodyLayer);

        event.registerLayerDefinition(DullhanBodyModel.LAYER, DullhanBodyModel::createBodyLayer);
        event.registerLayerDefinition(DullhanHeadModel.LAYER, DullhanHeadModel::createBodyLayer);
        event.registerLayerDefinition(DullhanHeadArmorModel.LAYER, DullhanHeadArmorModel::createBodyLayer);
        event.registerLayerDefinition(DullhanCrystalHelmetArmorModel.LAYER, DullhanCrystalHelmetArmorModel::createBodyLayer);
        event.registerLayerDefinition(BerserkerHelmetArmorModel.LAYER, BerserkerHelmetArmorModel::createBodyLayer);
        event.registerLayerDefinition(MesmerizerCrownArmorModel.LAYER, MesmerizerCrownArmorModel::createBodyLayer);
        event.registerLayerDefinition(NetherCrystalHelmetArmorModel.LAYER, NetherCrystalHelmetArmorModel::createBodyLayer);
        event.registerLayerDefinition(NetherCrystalChestplateArmorModel.LAYER, NetherCrystalChestplateArmorModel::createBodyLayer);
        event.registerLayerDefinition(NetherCrystalLeggingsArmorModel.LAYER, NetherCrystalLeggingsArmorModel::createBodyLayer);
        event.registerLayerDefinition(NetherCrystalBootsArmorModel.LAYER, NetherCrystalBootsArmorModel::createBodyLayer);
        event.registerLayerDefinition(WitherZombieModel.LAYER, WitherZombieModel::createBodyLayer);
        event.registerLayerDefinition(WitherServantModel.LAYER, WitherServantModel::createBodyLayer);
        event.registerLayerDefinition(WitherServantModel.INNER_ARMOR, WitherServantModel::createInnerArmorLayer);
        event.registerLayerDefinition(WitherServantModel.OUTER_ARMOR, WitherServantModel::createOuterArmorLayer);
        event.registerLayerDefinition(SuppressorModel.LAYER, SuppressorModel::createBodyLayer);
        event.registerLayerDefinition(SuppressorModel.INNER_ARMOR, SuppressorModel::createInnerArmorLayer);
        event.registerLayerDefinition(SuppressorModel.OUTER_ARMOR, SuppressorModel::createOuterArmorLayer);
        event.registerLayerDefinition(ImmortalWarriorModel.LAYER, ImmortalWarriorModel::createBodyLayer);
         event.registerLayerDefinition(NetherCourierModel.LAYER, NetherCourierModel::createBodyLayer);
        event.registerLayerDefinition(NetherCarrierModel.LAYER, NetherCarrierModel::createBodyLayer);
        event.registerLayerDefinition(NetherCourierArmorModel.LAYER, NetherCourierArmorModel::createBodyLayer);
        event.registerLayerDefinition(HeadDominatorModel.LAYER, HeadDominatorModel::createBodyLayer);
        event.registerLayerDefinition(HeadDominatorStaffModel.LAYER, HeadDominatorStaffModel::createBodyLayer);
        event.registerLayerDefinition(HeadDominatorCapeModel.LAYER, HeadDominatorCapeModel::createBodyLayer);
        event.registerLayerDefinition(HackerModel.LAYER, HackerModel::createBodyLayer);
        event.registerLayerDefinition(HackerClothesModel.LAYER, HackerClothesModel::createBodyLayer);
        event.registerLayerDefinition(WitherGhostModel.LAYER, WitherGhostModel::createBodyLayer);
         event.registerLayerDefinition(ShadowApostleModel.LAYER, ShadowApostleModel::createBodyLayer);
        event.registerLayerDefinition(OverlordWitherModel.LAYER, OverlordWitherModel::createBodyLayer);
        event.registerLayerDefinition(OverlordWitherModel.ARMOR_LAYER, OverlordWitherModel::createBodyLayer);
        event.registerLayerDefinition(OverlordWitherSkullModel.LAYER, OverlordWitherSkullModel::createBodyLayer);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
         event.registerEntityRenderer(GeneratedMod.BEDSERKER.get(), BedserkerRenderer::new);

        event.registerEntityRenderer(GeneratedMod.BERSERKER.get(), BerserkerRenderer::new);
        event.registerEntityRenderer(GeneratedMod.NETHER_HUNTER.get(), NetherHunterRenderer::new);
        event.registerEntityRenderer(GeneratedMod.DULLHAN_BODY.get(), DullhanBodyRenderer::new);
        event.registerEntityRenderer(GeneratedMod.DULLHAN_HEAD.get(), DullhanHeadRenderer::new);
        event.registerEntityRenderer(GeneratedMod.DULLHAN_HORSE.get(), DullhanHorseRenderer::new);
        event.registerEntityRenderer(GeneratedMod.BLITZ_DULLHAN_BODY.get(), BlitzDullhanBodyRenderer::new);
        event.registerEntityRenderer(GeneratedMod.BLITZ_DULLHAN_HEAD.get(), BlitzDullhanHeadRenderer::new);
        event.registerEntityRenderer(GeneratedMod.BLITZ_DULLHAN_HORSE.get(), BlitzDullhanHorseRenderer::new);
        event.registerEntityRenderer(GeneratedMod.MESMERIZER.get(), MesmerizerRenderer::new);
        event.registerEntityRenderer(GeneratedMod.MESMERIZER_ORB.get(),
                context -> new ThrownItemRenderer(context, 0.5F, true));
        event.registerEntityRenderer(GeneratedMod.WITHERPHANTOM.get(), WitherphantomRenderer::new);
        event.registerEntityRenderer(GeneratedMod.WITHER_ZOMBIE.get(), WitherZombieRenderer::new);
        event.registerEntityRenderer(GeneratedMod.WITHER_SERVANT.get(), WitherServantRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SUPPRESSOR.get(), SuppressorRenderer::new);
        event.registerEntityRenderer(GeneratedMod.IMMORTAL_WARRIOR.get(), ImmortalWarriorRenderer::new);
         event.registerEntityRenderer(GeneratedMod.IMMORTAL_WARRIOR_REMAINS.get(), ImmortalWarriorRenderer::new);
         event.registerEntityRenderer(GeneratedMod.NETHER_COURIER.get(), NetherCourierRenderer::new);
        event.registerEntityRenderer(GeneratedMod.NETHER_CARRIER.get(), NetherCarrierRenderer::new);
        event.registerEntityRenderer(GeneratedMod.HEAD_DOMINATOR.get(), HeadDominatorRenderer::new);
        event.registerEntityRenderer(GeneratedMod.HACKER.get(), HackerRenderer::new);
        event.registerEntityRenderer(GeneratedMod.WITHER_GHOST.get(), WitherGhostRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SHADOW_APOSTLE.get(), ShadowApostleRenderer::new);
        event.registerEntityRenderer(GeneratedMod.WITHER_CHARGE.get(),
                 context -> new ThrownItemRenderer(context, 0.75F, true));
        event.registerEntityRenderer(GeneratedMod.HOLY_BOMB.get(),
                 context -> new ThrownItemRenderer(context, 1.25F, true));
         event.registerEntityRenderer(GeneratedMod.OVERLORD_WITHER.get(), OverlordWitherRenderer::new);
        event.registerEntityRenderer(GeneratedMod.OVERLORD_WITHER_SKULL.get(), OverlordWitherSkullRenderer::new);
        event.registerEntityRenderer(GeneratedMod.NETHER_CARRIER_HITBOX.get(), CarrierHitboxRenderer::new);
    }

    private static final class HackerRenderer extends MobRenderer<Hacker, HackerModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/hacker.png");
        private static final ResourceLocation CLOTHES_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/hacker_clothes.png");
        private final HackerClothesModel clothesModel;

        private HackerRenderer(EntityRendererProvider.Context context) {
            // 影子半径与凋灵骷髅渲染器一致（0.5）。
            super(context, new HackerModel(context.bakeLayer(HackerModel.LAYER)), 0.5F);
            this.clothesModel = new HackerClothesModel(context.bakeLayer(HackerClothesModel.LAYER));
            this.addLayer(new RenderLayer<Hacker, HackerModel>(this) {
                @Override
                public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                   Hacker entity, float limbSwing, float limbSwingAmount,
                                   float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
                    clothesModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                    clothesModel.renderToBuffer(poseStack,
                            buffer.getBuffer(RenderType.entityCutoutNoCull(CLOTHES_TEXTURE)),
                            packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
                }
            });
        }

        @Override
        protected void scale(Hacker entity, PoseStack poseStack, float partialTick) {
            // 身高对齐凋灵骷髅：32px 人形网格 × 1.2 = 视觉 2.4 格，
            // 正好撑满 0.6×2.4 判定箱（与原版 WitherSkeletonRenderer 同款处理）。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(Hacker entity) {
            return TEXTURE;
        }
    }

    /**
     * 运兵车子判定盒的渲染侧：什么都不画。该实体只为补齐车头/车尾探出段的
     * "可命中、可瞄准、F3 判定线"而存在（见 {@link CarrierHitbox}），像素全归
     * 运兵车自己的模型。必须注册一个渲染器——F3 的判定线是跟着渲染调度器画的，
     * 没有渲染器的类型会在渲染那一帧被整个跳过，判定线也会再次缺席。
     */
    private static final class CarrierHitboxRenderer extends EntityRenderer<CarrierHitbox> {
        private CarrierHitboxRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.shadowRadius = 0.0F;
            this.shadowStrength = 0.0F;
        }

        @Override
        public void render(CarrierHitbox entity, float yaw, float partialTick, PoseStack poseStack,
                           MultiBufferSource bufferSource, int packedLight) {
            // 隐形：只有判定盒，没有像素。
        }

        @Override
        public ResourceLocation getTextureLocation(CarrierHitbox entity) {
            return ResourceLocation.withDefaultNamespace("textures/atlas/blocks.png");
        }
    }

    /**
     * 军团光环的地面贴图：给所有生物渲染器统一挂一层光环环。
     *
     * <p>带光环的实体是整个凋灵骷髅阵营（原版凋灵骷髅、狂战士、尸鬼、无头骑士
     * 三件套……），逐个渲染器加层不现实；光环本身只是"脚下画一圈贴图"，与宿主
     * 模型零耦合，于是挂在 {@link net.minecraft.client.renderer.entity.LivingEntityRenderer}
     * 的通用层上，渲染时读 {@link ILegionAuraCarrier} 的原版同步标志，
     * 没光环的实体一次 instanceof + 布尔读取即返回。</p>
     */
    private static void addLegionAuraLayers(EntityRenderersEvent.AddLayers event) {
        for (net.minecraft.world.entity.EntityType<?> type : event.getEntityTypes()) {
            if (event.getRenderer(type) instanceof net.minecraft.client.renderer.entity.LivingEntityRenderer<?, ?> renderer) {
                addAuraRingLayer(renderer);
            }
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void addAuraRingLayer(
            net.minecraft.client.renderer.entity.LivingEntityRenderer renderer) {
        renderer.addLayer(new LegionAuraRingLayer(renderer));
    }

    private static void registerClientExtensions(RegisterClientExtensionsEvent event) {
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                BerserkerHelmetArmorModel custom = getHelmetArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.BERSERKER_HELMET.get());
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                MesmerizerCrownArmorModel custom = getMesmerizerCrownArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.MESMERIZER_CROWN.get());
        // 炼狱晶套四件：几何与 UV 逐块取自用户上传的 geo.bbmodel（模型类由
        // tools/gen_crystal_armor_models.py 生成），贴图共用 64×64 的 nether_crystal_suits.png。
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                NetherCrystalHelmetArmorModel custom = getNetherCrystalHelmetArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.NETHER_CRYSTAL_HELMET.get());
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                NetherCrystalChestplateArmorModel custom = getNetherCrystalChestplateArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.NETHER_CRYSTAL_CHESTPLATE.get());
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                NetherCrystalLeggingsArmorModel custom = getNetherCrystalLeggingsArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.NETHER_CRYSTAL_LEGGINGS.get());
        event.registerItem(new IClientItemExtensions() {
            @Override
            public HumanoidModel getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                        EquipmentSlot slot, HumanoidModel original) {
                NetherCrystalBootsArmorModel custom = getNetherCrystalBootsArmorModel();
                original.copyPropertiesTo(custom);
                return custom;
            }
        }, GeneratedMod.NETHER_CRYSTAL_BOOTS.get());
        // 亡魂重盾不再自定义第一人称变换：applyForgeHandTransform 返回 true 会整段跳过
        // 原版盾牌的持握/举盾第一人称管线，正是"第一视角盾牌横过来"的根因。
        // 朝向全部交给 soul_shield.json 的 display（与原版盾牌姿态等价换算），
        // 举盾姿态通过注册 blocking 物品属性 + 模型 overrides 实现（与原版机制一致）。
        //
        // 地煞战斧反过来正是要用这个钩子：静止姿态 = 原版手部基准 +
        // disha_battle_axe.json 的 firstperson display（用户 Blockbench 定稿：
        // rot[-14.77,-1.94,-0.52] / trans[3,-2.75,0] / scale 1.5，刃面正对镜头的
        // 大双刃战斧握法）。挥击是一记带前冲的重劈，参数按新静止姿态重新扫描定稿
        // （tools/swing_scan2.py + tools/swing_tape.py 逐帧仿真）：
        // X 摆幅 -70°、Z 侧倾 -15°、挥中 Y 偏置 -20°、峰值沿视线前推 1.0 格。
        // 前推必不可少：scale 1.5 下握点下方还垂着约 0.9 格斧柄，不推离时柄尾
        // 配重会在挥击中段贴脸扫过、大半个屏幕被糊死；前推 1.0 格后全程最近顶点
        // 距相机 ≥0.44 格，斧头扫过屏幕中线、双刃轮廓始终可读。
        // swingProcess 为 0 或 1 时所有自定义项归零（f、f1 均为 sin 形、两端为 0），
        // 起手收势与静止姿态完全一致，无跳变。第三人称无需接管：手臂挥动由原版
        // setupAttackAnimation 驱动。TP display 定稿 rot[0,-90,18]：游戏第三人称链是
        // ArmPose.ITEM(手臂前摆-18°) · Rx(-90) · Ry(180) · display（ItemInHandLayer
        // 反编译确认），Ry(-90) 把刃面从朝下转到竖直朝角色外侧、双刃上下，+18° Z
        // 分量抵消手臂前摆使斧头水平前伸（tools/tp_front34_check.py 逐轴验算 +
        // 前右 3/4 机位仿真对图）。左右手同值即可，ItemTransform.apply 运行时镜像。
        event.registerItem(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack poseStack, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack itemInHand, float partialTick,
                                                   float equipProcess, float swingProcess) {
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                float f = Mth.sin(swingProcess * swingProcess * Mth.PI);
                float f1 = Mth.sin(Mth.sqrt(swingProcess) * Mth.PI);
                // 挥击位移：原版三分量 + 前冲（柄尾躲开脸部视野）
                poseStack.translate(side * -0.4F * f1,
                        0.2F * Mth.sin(Mth.sqrt(swingProcess) * Mth.PI * 2.0F),
                        -0.2F * Mth.sin(swingProcess * Mth.PI) - 1.0F * f1);
                // 手部基准位（等价原版 applyItemArmTransform，含切换下坠补偿）
                poseStack.translate(side * 0.56F, -0.52F + equipProcess * -0.6F, -0.72F);
                // 重劈旋转：Y 起收势保持原版 + 挥中 -20° 偏置（挥击面让开视线中央），
                // Z 侧倾 -15°，X 摆幅 -70°
                poseStack.mulPose(Axis.YP.rotationDegrees(side * (45.0F + f * -20.0F + f1 * -20.0F)));
                poseStack.mulPose(Axis.ZP.rotationDegrees(side * f1 * -15.0F));
                poseStack.mulPose(Axis.XP.rotationDegrees(f1 * -70.0F));
                poseStack.mulPose(Axis.YP.rotationDegrees(side * -45.0F));
                return true;
            }
        }, GeneratedMod.DISHA_BATTLE_AXE.get());
    }

    /** 原版只为 Items.SHIELD 注册 blocking 谓词；自定义 ShieldItem 需要自己补一份，
     *  否则 soul_shield.json 里的 blocking 覆盖模型（举盾 display）不会生效。 */
    private static void registerShieldBlockingProperty() {
        ItemProperties.register(GeneratedMod.SOUL_SHIELD.get(),
                ResourceLocation.withDefaultNamespace("blocking"),
                (stack, level, entity, seed) -> entity != null && entity.isUsingItem()
                        && entity.getUseItem() == stack ? 1.0F : 0.0F);
    }

    private static BerserkerHelmetArmorModel getHelmetArmorModel() {
        if (helmetArmorModel == null) {
            helmetArmorModel = new BerserkerHelmetArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(BerserkerHelmetArmorModel.LAYER));
        }
        return helmetArmorModel;
    }

    private static MesmerizerCrownArmorModel getMesmerizerCrownArmorModel() {
        if (mesmerizerCrownArmorModel == null) {
            mesmerizerCrownArmorModel = new MesmerizerCrownArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(MesmerizerCrownArmorModel.LAYER));
        }
        return mesmerizerCrownArmorModel;
    }

    private static NetherCrystalHelmetArmorModel getNetherCrystalHelmetArmorModel() {
        if (netherCrystalHelmetArmorModel == null) {
            netherCrystalHelmetArmorModel = new NetherCrystalHelmetArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(NetherCrystalHelmetArmorModel.LAYER));
        }
        return netherCrystalHelmetArmorModel;
    }

    private static NetherCrystalChestplateArmorModel getNetherCrystalChestplateArmorModel() {
        if (netherCrystalChestplateArmorModel == null) {
            netherCrystalChestplateArmorModel = new NetherCrystalChestplateArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(NetherCrystalChestplateArmorModel.LAYER));
        }
        return netherCrystalChestplateArmorModel;
    }

    private static NetherCrystalLeggingsArmorModel getNetherCrystalLeggingsArmorModel() {
        if (netherCrystalLeggingsArmorModel == null) {
            netherCrystalLeggingsArmorModel = new NetherCrystalLeggingsArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(NetherCrystalLeggingsArmorModel.LAYER));
        }
        return netherCrystalLeggingsArmorModel;
    }

    private static NetherCrystalBootsArmorModel getNetherCrystalBootsArmorModel() {
        if (netherCrystalBootsArmorModel == null) {
            netherCrystalBootsArmorModel = new NetherCrystalBootsArmorModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(NetherCrystalBootsArmorModel.LAYER));
        }
        return netherCrystalBootsArmorModel;
    }

    /**
     * 眼/嘴自发光层（末影人眼睛同款机制）：直接复用父模型——同一份几何、同一帧姿态、
     * 同一 UV，发光贴图与本体贴图共用 (8,8)-(16,16) 头部正面区域，坐标天然严格对齐；
     * 原版 eyes 管线以满亮度 15728640 绘制且深度为 LEQUAL，覆盖在本体面部之上不受光照影响。
     */
    private static final class GlowEyesLayer<T extends Entity, M extends EntityModel<T>> extends EyesLayer<T, M> {
        private final RenderType renderType;

        private GlowEyesLayer(RenderLayerParent<T, M> parent, ResourceLocation glowTexture) {
            super(parent);
            this.renderType = RenderType.eyes(glowTexture);
        }

        @Override
        public RenderType renderType() {
            return this.renderType;
        }
    }

    /**
     * 衰翼渲染器：直接使用原版幻翼模型（ModelLayers.PHANTOM），整体缩放 1.5 倍；
     * 发光眼用与本体同一份几何的 EyesLayer（满亮度自发光），贴图透明处不产生像素。
     */
    private static final class WitherphantomRenderer extends PhantomRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/witherphantom.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/witherphantom_eye.png");

        private WitherphantomRenderer(EntityRendererProvider.Context context) {
            super(context);
            // 原版 PhantomEyesLayer 无条件绘制 phantom_eyes.png，会与衰翼自己的眼贴图叠影，移除。
            this.layers.removeIf(layer -> layer instanceof PhantomEyesLayer);
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        protected void scale(net.minecraft.world.entity.monster.Phantom entity,
                             PoseStack poseStack, float partialTick) {
            // 与原版一致（幻翼 size 恒为 0，原版即 scale(1)+该平移），整体再放大 1.5 倍。
            poseStack.scale(1.5F, 1.5F, 1.5F);
            poseStack.translate(0.0F, 1.3125F, 0.1875F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.Phantom entity) {
            return TEXTURE;
        }
    }

    /**
     * 尸鬼渲染器：自有 64×64 逐面 UV 模型 + 僵尸同款内外甲层（ModelLayers 的
     * ZOMBIE_INNER/OUTER_ARMOR，护甲几何与尸鬼部件同枢轴，穿戴自动贴合）；
     * 手持武器/盔甲由 HumanoidMobRenderer 基类的 ItemInHandLayer / CustomHeadLayer 负责。
     */
    private static final class WitherZombieRenderer extends HumanoidMobRenderer<WitherZombie, WitherZombieModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/witherzombie.png");

        private WitherZombieRenderer(EntityRendererProvider.Context context) {
            super(context, new WitherZombieModel(context.bakeLayer(WitherZombieModel.LAYER)), 0.5F);
            this.addLayer(new HumanoidArmorLayer<>(this,
                    new ZombieModel<>(context.bakeLayer(ModelLayers.ZOMBIE_INNER_ARMOR)),
                    new ZombieModel<>(context.bakeLayer(ModelLayers.ZOMBIE_OUTER_ARMOR)),
                    context.getModelManager()));
        }

        @Override
        public ResourceLocation getTextureLocation(WitherZombie entity) {
            return TEXTURE;
        }
    }

    /**
     * 凋灵仆役渲染器：25px 幼年体模型按 1:1 绘制（不做凋灵骷髅式 1.2 倍放大）。
     * 穿戴护甲沿用凋灵骷髅内/外甲层几何（拾荒捡来的盔甲自动上身渲染），
     * 手持武器与副手盾牌由基类 ItemInHandLayer / 原版格挡姿势通道负责。
     */
    private static final class WitherServantRenderer extends HumanoidMobRenderer<WitherServant, WitherServantModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/wither_servant.png");

        private WitherServantRenderer(EntityRendererProvider.Context context) {
            super(context, new WitherServantModel(context.bakeLayer(WitherServantModel.LAYER)), 0.5F);
            this.addLayer(new HumanoidArmorLayer<>(this,
                    new WitherServantModel(context.bakeLayer(WitherServantModel.INNER_ARMOR)),
                    new WitherServantModel(context.bakeLayer(WitherServantModel.OUTER_ARMOR)),
                    context.getModelManager()));
        }

        @Override
        public ResourceLocation getTextureLocation(WitherServant entity) {
            return TEXTURE;
        }
    }

    /**
     * 反转士渲染器：本体（64×64 主贴图，受击照常闪红）、自发光层（同 UV 的
     * 64×64 透明底，只有双眼与双臂腕带两处像素）、穿戴护甲层（本模型自己的
     * 内/外甲几何，枢轴与本体一致）。
     *
     * <p>视觉身高与凋灵骷髅一致：32px 标准人形模型 × {@code scale(1.2)} = 2.4 格，
     * 套 0.6×2.4 判定箱。上下颠倒的翻转不在这里做——见
     * {@code mixin/LivingEntityRendererGravityMixin}，它对带重力反转效果的
     * 所有生物统一生效。</p>
     */
    private static final class SuppressorRenderer extends HumanoidMobRenderer<Suppressor, SuppressorModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/suppressor.png");
        /** 眼与腕带的自发光图（与本体同 64×64 图集，逐像素对齐）。 */
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/suppressor_glow.png");

        private SuppressorRenderer(EntityRendererProvider.Context context) {
            super(context, new SuppressorModel(context.bakeLayer(SuppressorModel.LAYER)), 0.5F);
            this.addLayer(new HumanoidArmorLayer<>(this,
                    new SuppressorModel(context.bakeLayer(SuppressorModel.INNER_ARMOR)),
                    new SuppressorModel(context.bakeLayer(SuppressorModel.OUTER_ARMOR)),
                    context.getModelManager()));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        protected void scale(Suppressor entity, PoseStack poseStack, float partialTick) {
            // 与原版 WitherSkeletonRenderer 同款 1.2×：32px 模型撑满 2.4 格判定箱。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(Suppressor entity) {
            return TEXTURE;
        }
    }

    /**
     * 下界传令兵渲染器：本体层（64×32 主贴图，受击照常闪红）与自带胸甲层
     * （32×32 甲片贴图）分两遍绘制；甲片层固定纯白着色 + NO_OVERLAY，
     * 因此"实体受击时胸甲不会变红"。
     *
     * <p>视觉身高与凋灵骷髅一致：32px 人形模型原生只有 2.0 格，原版凋灵骷髅
     * 在渲染器里 {@code scale(1.2)} 撑满 2.4 格判定箱，这里逐字同款处理。</p>
     *
     * <p>手持旗帜：不再用基类默认的 {@code ItemInHandLayer}——它在手臂姿态系
     * 里把持物点沿肩→手轴向的垂直方向外推 1px（凋灵骷髅垂手持剑时看不出来，
     * 传令兵双臂恒前平举后旗杆明显"偏外"）。本版在渲染前把持物系整体向内
     * 收回 1px，让旗杆落回前臂中线。</p>
     */
    private static final class NetherCourierRenderer extends HumanoidMobRenderer<NetherCourier, NetherCourierModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/nether_courier.png");
        private static final ResourceLocation ARMOR_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/nether_courier_armor.png");

        private final NetherCourierArmorModel armorModel;

        private NetherCourierRenderer(EntityRendererProvider.Context context) {
            super(context, new NetherCourierModel(context.bakeLayer(NetherCourierModel.LAYER)), 0.5F);
            this.armorModel = new NetherCourierArmorModel(context.bakeLayer(NetherCourierArmorModel.LAYER));
            this.addLayer(new RenderLayer<NetherCourier, NetherCourierModel>(this) {
                @Override
                public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                   NetherCourier entity, float limbSwing, float limbSwingAmount,
                                   float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
                    getParentModel().copyPropertiesTo(armorModel);
                    // 注意：armorModel 的 setupAnim 与本体模型走同一个姿态出口
                    // CourierArmAnimation#apply（常态双臂钉死前平举、攻击时右臂
                    // 叠加挥手）；attackTime 已随 copyPropertiesTo 传入，肩甲立方体
                    // 挂在手臂部件下，出手时随胳膊一起挥动，与本体同步。
                    armorModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                    armorModel.renderToBuffer(poseStack,
                            buffer.getBuffer(RenderType.armorCutoutNoCull(ARMOR_TEXTURE)),
                            packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
                }
            });
            // 穿戴装备支持：与原版凋灵骷髅同款的人形护甲层（WITHER_SKELETON 内/外甲
            // 几何，2px 细臂、±1.9 髋距与传令兵本体一致）。图层每帧把本体模型的姿态
            // copyPropertiesTo 进甲层模型、并且从不重跑甲层自身的 setupAnim，因此
            // 传令兵钉死的"双臂前平举 + 攻击挥手"会原样传导到护甲袖管上；炼狱晶套等
            // 自定义盔甲经 IClientItemExtensions 钩子换掉模型时同样带着这份拷贝姿态。
            this.addLayer(new HumanoidArmorLayer<>(this,
                    new CourierWornArmorModel(context.bakeLayer(ModelLayers.WITHER_SKELETON_INNER_ARMOR)),
                    new CourierWornArmorModel(context.bakeLayer(ModelLayers.WITHER_SKELETON_OUTER_ARMOR)),
                    context.getModelManager()));
            // 换掉基类默认持物层：向内修正旗杆偏移。
            this.layers.removeIf(layer -> layer instanceof ItemInHandLayer);
            this.addLayer(new CourierItemInHandLayer(this, context.getItemInHandRenderer()));
        }

        @Override
        protected void scale(NetherCourier entity, PoseStack poseStack, float partialTick) {
            // 与 WitherSkeletonRenderer 完全同款的 1.2× 放大：
            // 32px 模型 × 1.2 = 2.4 格，正好撑满凋灵骷髅同款判定箱。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(NetherCourier entity) {
            return TEXTURE;
        }
    }

    /**
     * 传令兵穿戴原版护甲的几何载体：与原版 SkeletonModel 同款空壳包装，立方体
     * 全部来自凋灵骷髅内/外甲层的烘焙定义。姿态由 HumanoidArmorLayer 从本体模型
     * copyPropertiesTo 同步（双臂前平举会原样传导），因此这里无需任何动画逻辑。
     */
    private static final class CourierWornArmorModel extends HumanoidModel<NetherCourier> {
        private CourierWornArmorModel(net.minecraft.client.model.geom.ModelPart root) {
            super(root);
        }
    }

    /**
     * 传令兵专用持物层：在进入手臂姿态系之前，把持物点沿模型横轴向身体中线
     * 收回 1px（原版 ItemInHandLayer 会在手臂系里外推 1px，双臂前平举时表现为
     * 旗杆偏离前臂中线挂在手臂外侧）。
     */
    private static final class CourierItemInHandLayer extends ItemInHandLayer<NetherCourier, NetherCourierModel> {
        private CourierItemInHandLayer(RenderLayerParent<NetherCourier, NetherCourierModel> parent,
                                       ItemInHandRenderer itemInHandRenderer) {
            super(parent, itemInHandRenderer);
        }

        @Override
        protected void renderArmWithItem(LivingEntity entity, ItemStack stack,
                                         ItemDisplayContext displayContext, HumanoidArm arm,
                                         PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
            if (!stack.isEmpty()) {
                // 模型空间 +x 朝向实体左侧：右手物品向内（左）收 1px，左手反之。
                poseStack.pushPose();
                poseStack.translate(arm == HumanoidArm.RIGHT ? 0.0625F : -0.0625F, 0.0F, 0.0F);
                super.renderArmWithItem(entity, stack, displayContext, arm, poseStack, buffer, packedLight);
                poseStack.popPose();
            }
        }
    }

    /**
     * 下界运兵车渲染器：模型按 bbmodel 1:1 换算（1 像素 = 1/16 格），因此不像凋灵骷髅
     * 系列那样乘 1.2——整车本来就是 9.94×3.75×4.44 格。影子给到 1.6 格半径，让
     * 9 格长的车体在地面上有相称的投影。军团光环层由基类提供；需求要求<b>受击不再闪红</b>
     * （改为服务端在车头撒黑烟，见 {@link NetherCarrier#hurt}），而 1.21.1 的红闪是
     * {@code LivingEntityRenderer#getOverlayCoords} 直接读 {@code hurtTime} 公开字段
     * 算进 overlay（绕过了 {@code isHurt()}，覆盖方法拦不住），所以这里在每帧渲染前
     * 把字段清零：受击红一帧都不出现，受击音效与击退等服务端行为不受影响
     * （死亡倒地的 {@code deathTime} 红是原版死亡动画的一部分，按需求保留）。
     */
    private static final class NetherCarrierRenderer extends MobRenderer<NetherCarrier, NetherCarrierModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/nether_carrier.png");

        private NetherCarrierRenderer(EntityRendererProvider.Context context) {
            super(context, new NetherCarrierModel(context.bakeLayer(NetherCarrierModel.LAYER)), 1.6F);
        }

        @Override
        public void render(NetherCarrier entity, float entityYaw, float partialTick,
                           PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
            entity.hurtTime = 0;
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        }

        @Override
        public ResourceLocation getTextureLocation(NetherCarrier entity) {
            return TEXTURE;
        }
    }

    /**
     * 御首者渲染器：本体（64×32 主贴图）、法杖（32×32 杖纹贴图）、披风（16×32 披风贴图）
     * 三层各用一张独立贴图。bbmodel 把这套模型拆成了三张贴图，Java 侧只能按贴图分层绘制。
     *
     * <p>三层的姿态都由 {@link HeadDominatorPose} 读同一份同步实体数据（施法进度）现算，
     * 因此抬杖、杖头旋转在三层之间逐帧一致，无需层间拷贝。披风/法杖层用
     * {@code entityCutoutNoCull}（贴图含透明像素），且不吃本体受击闪红——与传令兵胸甲同款处理。</p>
     *
     * <p>视觉身高与凋灵骷髅一致：32px 模型 × {@code scale(1.2)} = 2.4 格，套 0.72×2.4 判定箱。</p>
     */
    private static final class HeadDominatorRenderer extends MobRenderer<HeadDominator, HeadDominatorModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/head_dominator.png");
        private static final ResourceLocation STAFF_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/head_dominator_staff.png");
        private static final ResourceLocation CAPE_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/head_dominator_cape.png");
        /** 眼睛/嘴与法杖凋灵头颅的自发光图（与本体贴图同为 64x32 图集，逐像素对齐）。 */
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/head_dominator_glow.png");

        private final HeadDominatorStaffModel staffModel;
        private final HeadDominatorCapeModel capeModel;

        private HeadDominatorRenderer(EntityRendererProvider.Context context) {
            super(context, new HeadDominatorModel(context.bakeLayer(HeadDominatorModel.LAYER)), 0.5F);
            this.staffModel = new HeadDominatorStaffModel(context.bakeLayer(HeadDominatorStaffModel.LAYER));
            this.capeModel = new HeadDominatorCapeModel(context.bakeLayer(HeadDominatorCapeModel.LAYER));
            // 自发光层复用本体几何：头部五官与杖头（group2 子树在本体层里）共用这一张贴图，
            // 满亮度绘制、透明像素不出光，所以一次就能点亮三处（眼、嘴、杖上的凋灵头颅）。
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
            // 披风在下、法杖在上：先画贴身的披风，再画悬在体外的法杖，遮挡关系正确。
            this.addLayer(new RenderLayer<HeadDominator, HeadDominatorModel>(this) {
                @Override
                public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight,
                                   HeadDominator entity, float limbSwing, float limbSwingAmount, float partialTick,
                                   float ageInTicks, float netHeadYaw, float headPitch) {
                    capeModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                    capeModel.renderToBuffer(poseStack,
                            bufferSource.getBuffer(RenderType.entityCutoutNoCull(CAPE_TEXTURE)),
                            packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
                }
            });
            this.addLayer(new RenderLayer<HeadDominator, HeadDominatorModel>(this) {
                @Override
                public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight,
                                   HeadDominator entity, float limbSwing, float limbSwingAmount, float partialTick,
                                   float ageInTicks, float netHeadYaw, float headPitch) {
                    staffModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                    staffModel.renderToBuffer(poseStack,
                            bufferSource.getBuffer(RenderType.entityCutoutNoCull(STAFF_TEXTURE)),
                            packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
                }
            });
        }

        @Override
        protected void scale(HeadDominator entity, PoseStack poseStack, float partialTick) {
            // 与 WitherSkeletonRenderer 同款 1.2×：32px 模型撑满 2.4 格判定箱。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(HeadDominator entity) {
            return TEXTURE;
        }
    }

    /** 怨灵渲染器：虚化时使用半透明本体贴图，并仅显示半透明自发光层。 */
    private static final class WitherGhostRenderer extends MobRenderer<WitherGhost, WitherGhostModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/wither_ghost.png");
        private static final ResourceLocation TRANSLUCENT_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/wither_ghost_translucent.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/wither_ghost_glow.png");

        private WitherGhostRenderer(EntityRendererProvider.Context context) {
            super(context, new WitherGhostModel(context.bakeLayer(WitherGhostModel.LAYER)), 0.5F);
            this.addLayer(new WitherGhostGlowLayer(this, GLOW_TEXTURE));
        }

        @Override
        protected void scale(WitherGhost entity, PoseStack poseStack, float partialTick) {
            // 与原版 WitherSkeletonRenderer 一致，使用 1.2 倍模型倍率。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        protected RenderType getRenderType(WitherGhost entity, boolean showBody,
                                           boolean translucent, boolean showOutline) {
            if (showBody && !translucent && entity.isEthereal()) {
                return RenderType.entityTranslucent(TRANSLUCENT_TEXTURE);
            }
            return super.getRenderType(entity, showBody, translucent, showOutline);
        }

        @Override
        public ResourceLocation getTextureLocation(WitherGhost entity) {
            return TEXTURE;
        }
    }

    private static final class WitherGhostGlowLayer extends RenderLayer<WitherGhost, WitherGhostModel> {
        private final RenderType renderType;

        private WitherGhostGlowLayer(RenderLayerParent<WitherGhost, WitherGhostModel> parent,
                                     ResourceLocation glowTexture) {
            super(parent);
            this.renderType = RenderType.eyes(glowTexture);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                           WitherGhost entity, float limbSwing, float limbSwingAmount, float partialTick,
                           float ageInTicks, float netHeadYaw, float headPitch) {
            if (!entity.isEthereal()) {
                return;
            }
            getParentModel().renderToBuffer(poseStack, buffer.getBuffer(this.renderType),
                    15728640, OverlayTexture.NO_OVERLAY, 0x80FFFFFF);
        }
    }

    private static final class NetherHunterRenderer extends WitherSkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/nether_hunter.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/nether_hunter_glow.png");

        private NetherHunterRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.WitherSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class MesmerizerRenderer extends WitherSkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/mesmerizer.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/mesmerizer_glow.png");

        private MesmerizerRenderer(EntityRendererProvider.Context context) {
            super(context);
            // SkeletonRenderer 会自动添加通用护甲层；反逆者的王冠由专用层负责，避免默认层把模型部件隐藏。
            this.layers.removeIf(layer -> layer instanceof HumanoidArmorLayer);
            this.addLayer(new MesmerizerCrownLayer(this,
                    new MesmerizerCrownArmorModel(context.bakeLayer(MesmerizerCrownArmorModel.LAYER))));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.WitherSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class MesmerizerCrownLayer
            extends RenderLayer<net.minecraft.world.entity.monster.WitherSkeleton,
            net.minecraft.client.model.SkeletonModel<net.minecraft.world.entity.monster.WitherSkeleton>> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/models/entity/mesmerizer_crown.png");
        private final MesmerizerCrownArmorModel model;

        private MesmerizerCrownLayer(RenderLayerParent<net.minecraft.world.entity.monster.WitherSkeleton,
                net.minecraft.client.model.SkeletonModel<net.minecraft.world.entity.monster.WitherSkeleton>> parent,
                                     MesmerizerCrownArmorModel model) {
            super(parent);
            this.model = model;
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                           net.minecraft.world.entity.monster.WitherSkeleton entity,
                           float limbSwing, float limbSwingAmount, float partialTick,
                           float ageInTicks, float netHeadYaw, float headPitch) {
            if (!(entity instanceof Mesmerizer mesmerizer)) {
                return;
            }
            ItemStack stack = mesmerizer.getItemBySlot(EquipmentSlot.HEAD);
            if (!stack.is(GeneratedMod.MESMERIZER_CROWN.get())) {
                return;
            }

            getParentModel().copyPropertiesTo(model);
            model.setAllVisible(false);
            model.head.visible = true;
            model.setupAnim(mesmerizer, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            VertexConsumer vertices = buffer.getBuffer(RenderType.armorCutoutNoCull(TEXTURE));
            model.renderToBuffer(poseStack, vertices, packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
            if (stack.hasFoil()) {
                model.renderToBuffer(poseStack, buffer.getBuffer(RenderType.armorEntityGlint()),
                        packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
            }
        }
    }

    private static final class ImmortalWarriorRenderer extends SkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/immortal_warrior.png");

        private ImmortalWarriorRenderer(EntityRendererProvider.Context context) {
            super(context, ModelLayers.WITHER_SKELETON_INNER_ARMOR,
                    ModelLayers.WITHER_SKELETON_OUTER_ARMOR,
                    new ImmortalWarriorModel(context.bakeLayer(ImmortalWarriorModel.LAYER)));
        }

        @Override
        protected void scale(LivingEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.AbstractSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class BerserkerRenderer extends SkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/berserker.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/berserker_glow.png");

        private BerserkerRenderer(EntityRendererProvider.Context context) {
            super(context, ModelLayers.WITHER_SKELETON_INNER_ARMOR, ModelLayers.WITHER_SKELETON_OUTER_ARMOR,
                    new BerserkerModel(context.bakeLayer(BerserkerModel.LAYER)));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        protected void scale(LivingEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.AbstractSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class BedserkerRenderer extends SkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/bedserker.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/bedserker_glow.png");

        private BedserkerRenderer(EntityRendererProvider.Context context) {
            super(context, ModelLayers.WITHER_SKELETON_INNER_ARMOR, ModelLayers.WITHER_SKELETON_OUTER_ARMOR,
                    new BedserkerModel(context.bakeLayer(BedserkerModel.LAYER)));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
            this.addLayer(new BedserkerFlashLayer(this));
        }

        @Override
        protected void scale(LivingEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.AbstractSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class BedserkerFlashLayer
            extends RenderLayer<net.minecraft.world.entity.monster.WitherSkeleton,
            net.minecraft.client.model.SkeletonModel<net.minecraft.world.entity.monster.WitherSkeleton>> {
        private BedserkerFlashLayer(RenderLayerParent<net.minecraft.world.entity.monster.WitherSkeleton,
                net.minecraft.client.model.SkeletonModel<net.minecraft.world.entity.monster.WitherSkeleton>> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                           net.minecraft.world.entity.monster.WitherSkeleton entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            if (!(entity instanceof Bedserker bedserker) || !bedserker.shouldRenderRedFlash(partialTick)) {
                return;
            }
            this.getParentModel().renderToBuffer(poseStack,
                    buffer.getBuffer(RenderType.entityCutoutNoCull(
                            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                                    "textures/entity/bedserker.png"))),
                    15728640, OverlayTexture.NO_OVERLAY, 0xFFFF3030);
        }
    }

    private static final class DullhanBodyRenderer extends WitherSkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/dullhan_body.png");

        private DullhanBodyRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.model = new DullhanBodyModel(context.bakeLayer(DullhanBodyModel.LAYER));
        }

        @Override
        protected void scale(net.minecraft.world.entity.monster.WitherSkeleton entity,
                             PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.WitherSkeleton entity) {
            return TEXTURE;
        }
    }

    private static final class DullhanHorseRenderer extends UndeadHorseRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/dullhan_horse.png");

        private DullhanHorseRenderer(EntityRendererProvider.Context context) {
            super(context, ModelLayers.SKELETON_HORSE);
            this.addLayer(new DullhanHorseArmorLayer(this,
                    new HorseModel<>(context.bakeLayer(ModelLayers.HORSE_ARMOR))));
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.animal.horse.AbstractHorse entity) {
            return TEXTURE;
        }
    }

    /**
     * 原版 HorseArmorLayer 的类型参数被固定在 Horse 上，骷髅马系用不到，
     * 因此为无头骑士的马单独挂一层马铠渲染。马鞍本身由 HorseModel 依据
     * isSaddled 显示，无需额外图层。
     */
    private static final class DullhanHorseArmorLayer
            extends RenderLayer<net.minecraft.world.entity.animal.horse.AbstractHorse,
                    HorseModel<net.minecraft.world.entity.animal.horse.AbstractHorse>> {
        private final HorseModel<net.minecraft.world.entity.animal.horse.AbstractHorse> armorModel;

        private DullhanHorseArmorLayer(
                RenderLayerParent<net.minecraft.world.entity.animal.horse.AbstractHorse,
                        HorseModel<net.minecraft.world.entity.animal.horse.AbstractHorse>> parent,
                HorseModel<net.minecraft.world.entity.animal.horse.AbstractHorse> armorModel) {
            super(parent);
            this.armorModel = armorModel;
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                           net.minecraft.world.entity.animal.horse.AbstractHorse entity,
                           float limbSwing, float limbSwingAmount, float partialTick,
                           float ageInTicks, float netHeadYaw, float headPitch) {
            ItemStack stack = entity.getBodyArmorItem();
            if (!(stack.getItem() instanceof AnimalArmorItem armor)
                    || armor.getBodyType() != AnimalArmorItem.BodyType.EQUESTRIAN) {
                return;
            }
            getParentModel().copyPropertiesTo(this.armorModel);
            this.armorModel.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
            this.armorModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(armor.getTexture()));
            this.armorModel.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, -1);
        }
    }

    private static final class DullhanHeadRenderer extends MobRenderer<DullhanHead, DullhanHeadModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/dullhan_head.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/dullhan_head_glow.png");

        private DullhanHeadRenderer(EntityRendererProvider.Context context) {
            super(context, new DullhanHeadModel(context.bakeLayer(DullhanHeadModel.LAYER)), 0.25F);
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
            this.addLayer(new DullhanHeadArmorLayer(this,
                    new DullhanHeadArmorModel(context.bakeLayer(DullhanHeadArmorModel.LAYER)),
                    new BerserkerHelmetArmorModel(context.bakeLayer(BerserkerHelmetArmorModel.LAYER)),
                    new MesmerizerCrownArmorModel(context.bakeLayer(MesmerizerCrownArmorModel.LAYER)),
                    new DullhanCrystalHelmetArmorModel(context.bakeLayer(DullhanCrystalHelmetArmorModel.LAYER))));
        }

        @Override
        protected void scale(DullhanHead entity, PoseStack poseStack, float partialTick) {
            // 与用户要求一致：小型史莱姆模型整体放大 1.2 倍，实体判定仍保持原版小型史莱姆尺寸。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(DullhanHead entity) {
            return TEXTURE;
        }
    }

    /** 史莱姆模型不兼容 HumanoidArmorLayer，因此单独渲染头盔槽。 */
    private static final class DullhanHeadArmorLayer extends RenderLayer<DullhanHead, DullhanHeadModel> {
        private final DullhanHeadArmorModel armorModel;
        private final BerserkerHelmetArmorModel berserkerHelmetModel;
        private final MesmerizerCrownArmorModel mesmerizerCrownModel;
        private final DullhanCrystalHelmetArmorModel crystalHelmetModel;

        private DullhanHeadArmorLayer(RenderLayerParent<DullhanHead, DullhanHeadModel> parent,
                                      DullhanHeadArmorModel armorModel,
                                      BerserkerHelmetArmorModel berserkerHelmetModel,
                                      MesmerizerCrownArmorModel mesmerizerCrownModel,
                                      DullhanCrystalHelmetArmorModel crystalHelmetModel) {
            super(parent);
            this.armorModel = armorModel;
            this.berserkerHelmetModel = berserkerHelmetModel;
            this.mesmerizerCrownModel = mesmerizerCrownModel;
            this.crystalHelmetModel = crystalHelmetModel;
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                           DullhanHead entity, float limbSwing, float limbSwingAmount,
                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
            ItemStack stack = entity.getItemBySlot(EquipmentSlot.HEAD);
            if (!(stack.getItem() instanceof ArmorItem armor)
                    || armor.getEquipmentSlot() != EquipmentSlot.HEAD) {
                return;
            }

            // 自定义人形盔（狂战士头环 / 御首者王冠）：几何与 UV 都不是原版 64×32
            // 盔壳布局，走"HumanoidModel 头部坐标系 + 搬上头颅"分支。
            if (stack.is(GeneratedMod.BERSERKER_HELMET.get())) {
                renderHumanoidHeadArmor(poseStack, buffer, packedLight, entity, stack,
                        berserkerHelmetModel);
                return;
            }
            if (stack.is(GeneratedMod.MESMERIZER_CROWN.get())) {
                renderHumanoidHeadArmor(poseStack, buffer, packedLight, entity, stack,
                        mesmerizerCrownModel);
                return;
            }
            // 炼狱晶头盔：完全复刻原版头盔在无头骑士头颅上的做法——专用模型的立方体
            // 直接建在头颅主模型坐标系（y 16..24，外扩 1px），与下面 armorModel 分支
            // 同一条渲染路径、同轴直渲，不做任何运行时位移。此前借用玩家用的
            // HumanoidModel 盔壳再靠 translate 搬上头颅，实测在头颅上整体偏低；
            // 静态几何与原版盔壳一样天然贴合。
            if (stack.is(GeneratedMod.NETHER_CRYSTAL_HELMET.get())) {
                crystalHelmetModel.setupAnim(entity, limbSwing, limbSwingAmount,
                        ageInTicks, netHeadYaw, headPitch);
                renderArmorModel(poseStack, buffer, packedLight, entity, stack,
                        armor, crystalHelmetModel, false);
                return;
            }

            armorModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            renderArmorModel(poseStack, buffer, packedLight, entity, stack, armor, armorModel, false);
        }

        /**
         * 自定义人形盔的通用绘制：这些模型按 HumanoidModel 头部坐标系烘焙（头顶 -8），
         * 而无头骑士头颅的主立方体位于 16..24，因此沿模型局部 Y 轴上移 24 个单位。
         * 头部零旋转、与主模型完全同轴；几何/UV 按各模型自己的纹理尺寸（64×64 或
         * 32×32）采样，不再借用 64×32 的通用盔壳。
         */
        private void renderHumanoidHeadArmor(PoseStack poseStack, MultiBufferSource buffer,
                                             int packedLight, DullhanHead entity, ItemStack stack,
                                             HumanoidModel<?> model) {
            poseStack.pushPose();
            poseStack.translate(0.0D, 24.0D / 16.0D, 0.0D);
            model.head.xRot = 0.0F;
            model.head.yRot = 0.0F;
            model.head.zRot = 0.0F;
            model.head.visible = true;
            model.hat.visible = false;
            model.body.visible = false;
            model.rightArm.visible = false;
            model.leftArm.visible = false;
            model.rightLeg.visible = false;
            model.leftLeg.visible = false;
            renderArmorModel(poseStack, buffer, packedLight, entity, stack,
                    (ArmorItem) stack.getItem(), model, false);
            poseStack.popPose();
        }

        private void renderArmorModel(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                      DullhanHead entity, ItemStack stack, ArmorItem armor,
                                      net.minecraft.client.model.EntityModel<?> model,
                                      boolean secondLayer) {
            int color = IClientItemExtensions.of(stack).getDefaultDyeColor(stack);
            if (color == 0) {
                color = 0xFFFFFFFF;
            }
            for (net.minecraft.world.item.ArmorMaterial.Layer layer : armor.getMaterial().value().layers()) {
                ResourceLocation texture = ClientHooks.getArmorTexture(
                        entity, stack, layer, secondLayer, EquipmentSlot.HEAD);
                VertexConsumer vertices = buffer.getBuffer(RenderType.armorCutoutNoCull(texture));
                model.renderToBuffer(poseStack, vertices, packedLight, OverlayTexture.NO_OVERLAY, color);
            }
            if (stack.hasFoil()) {
                model.renderToBuffer(poseStack, buffer.getBuffer(RenderType.armorEntityGlint()),
                        packedLight, OverlayTexture.NO_OVERLAY, color);
            }
        }
    }

    /**
     * 无头强袭骑士躯体渲染：几何与无头骑士完全相同（其 .bbmodel 即原版凋灵骷髅
     * 几何按 1.2 倍烘进贴图坐标系），沿用 SkeletonModel 图层 + 1.2 倍渲染缩放；
     * 发光层为腕带（blitz_dullhan_body_glow.png，64×32 透明底，与本体同一套 UV）。
     */
    private static final class BlitzDullhanBodyRenderer extends WitherSkeletonRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_body.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_body_glow.png");

        private BlitzDullhanBodyRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.model = new DullhanBodyModel(context.bakeLayer(DullhanBodyModel.LAYER));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        protected void scale(net.minecraft.world.entity.monster.WitherSkeleton entity,
                             PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.WitherSkeleton entity) {
            return TEXTURE;
        }
    }

    /**
     * 无头强袭骑士头颅渲染：与无头骑士头颅同一套史莱姆立方体几何与头盔图层
     * （炼狱晶头盔走 DullhanCrystalHelmetArmorModel 分支），换强袭贴图并挂
     * 头颅发光层（blitz_dullhan_head_glow.png，24×16 透明底的眼与嘴）。
     */
    private static final class BlitzDullhanHeadRenderer extends MobRenderer<DullhanHead, DullhanHeadModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_head.png");
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_head_glow.png");

        private BlitzDullhanHeadRenderer(EntityRendererProvider.Context context) {
            super(context, new DullhanHeadModel(context.bakeLayer(DullhanHeadModel.LAYER)), 0.25F);
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
            this.addLayer(new DullhanHeadArmorLayer(this,
                    new DullhanHeadArmorModel(context.bakeLayer(DullhanHeadArmorModel.LAYER)),
                    new BerserkerHelmetArmorModel(context.bakeLayer(BerserkerHelmetArmorModel.LAYER)),
                    new MesmerizerCrownArmorModel(context.bakeLayer(MesmerizerCrownArmorModel.LAYER)),
                    new DullhanCrystalHelmetArmorModel(context.bakeLayer(DullhanCrystalHelmetArmorModel.LAYER))));
        }

        @Override
        protected void scale(DullhanHead entity, PoseStack poseStack, float partialTick) {
            // 与无头骑士头颅一致：模型 1.2 倍，判定保持 0.6 格。
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(DullhanHead entity) {
            return TEXTURE;
        }
    }

    /** 无头强袭骑士的马：原版骷髅马几何 + 强袭贴图 + 马铠图层 + 眼部发光层（与无头骑士的马同链路）。 */
    private static final class BlitzDullhanHorseRenderer extends UndeadHorseRenderer {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_horse.png");
        /**
         * 眼部发光层（blitz_dullhan_horse_glow.png，64×64 透明底，仅头部左右侧面
         * UV (3,21)/(15,21) 处两点黄色光斑，与本体贴图上的红色眼睛逐像素对齐）。
         * 已核对原版 HorseModel 全部立方体 UV 区域：光斑只落在 head 立方体左右侧面，
         * 鬃毛/颈/嘴/四肢/鞍具均不受误照；eyes 管线满亮度绘制，黑暗中双眼发光。
         */
        private static final ResourceLocation GLOW_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/blitz_dullhan_horse_glow.png");

        private BlitzDullhanHorseRenderer(EntityRendererProvider.Context context) {
            super(context, ModelLayers.SKELETON_HORSE);
            this.addLayer(new DullhanHorseArmorLayer(this,
                    new HorseModel<>(context.bakeLayer(ModelLayers.HORSE_ARMOR))));
            this.addLayer(new GlowEyesLayer<>(this, GLOW_TEXTURE));
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.animal.horse.AbstractHorse entity) {
            return TEXTURE;
        }
    }

    /**
     * 霸主凋灵渲染器：五阶段按血量切换反应核贴图，三阶段起叠加凋灵护盾能量层。
     * 缩放、满方块光与原版凋灵一致；生成阶段复刻原版凋灵的贴图交替口径
     * （{@code WitherBossRenderer#getTextureLocation}）：invul 计数 &gt; 80 恒为
     * 紫红生成贴图，最后 80 tick 按 (invul / 5) % 2 在紫红与一阶段贴图间闪烁。
     */
    private static final class OverlordWitherRenderer
            extends MobRenderer<OverlordWitherBoss, OverlordWitherModel> {
        private static final ResourceLocation[] STAGE_TEXTURES = {
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/overlord_wither_stage_1.png"),
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/overlord_wither_stage_2.png"),
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/overlord_wither_stage_3.png"),
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/overlord_wither_stage_4.png"),
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/overlord_wither_stage_5.png"),
        };
        private static final ResourceLocation INVULNERABLE_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/overlord_wither_invulnerable.png");

        private OverlordWitherRenderer(EntityRendererProvider.Context context) {
            super(context, new OverlordWitherModel(context.bakeLayer(OverlordWitherModel.LAYER), false), 1.0F);
            this.addLayer(new OverlordWitherArmorLayer(this, context));
        }

        @Override
        protected int getBlockLightLevel(OverlordWitherBoss entity, net.minecraft.core.BlockPos pos) {
            return 15;
        }

        @Override
        public ResourceLocation getTextureLocation(OverlordWitherBoss entity) {
            int invul = entity.getInvulnerableTicks();
            if (invul > 0 && (invul > 80 || (invul / 5) % 2 == 0)) {
                return INVULNERABLE_TEXTURE;
            }
            return STAGE_TEXTURES[Math.clamp(entity.getPhase() - 1, 0, STAGE_TEXTURES.length - 1)];
        }

        @Override
        protected void scale(OverlordWitherBoss entity, PoseStack poseStack, float partialTick) {
            float scale = 2.0F;
            int invulnerableTicks = entity.getInvulnerableTicks();
            if (invulnerableTicks > 0) {
                scale -= (invulnerableTicks - partialTick) / 220.0F * 0.5F;
            }
            poseStack.scale(scale, scale, scale);
        }
    }

    /** 凋灵护盾覆盖层：isPowered() 为真（三阶段起）时按原版能量漩涡方式绘制。 */
    private static final class OverlordWitherArmorLayer
            extends EnergySwirlLayer<OverlordWitherBoss, OverlordWitherModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/overlord_wither_armor.png");
        private final OverlordWitherModel armorModel;

        private OverlordWitherArmorLayer(RenderLayerParent<OverlordWitherBoss, OverlordWitherModel> parent,
                                         EntityRendererProvider.Context context) {
            super(parent);
            this.armorModel = new OverlordWitherModel(
                    context.bakeLayer(OverlordWitherModel.ARMOR_LAYER), true);
        }

        @Override
        protected float xOffset(float ageInTicks) {
            return Mth.cos(ageInTicks * 0.02F) * 3.0F;
        }

        @Override
        protected ResourceLocation getTextureLocation() {
            return TEXTURE;
        }

        @Override
        protected OverlordWitherModel model() {
            return this.armorModel;
        }
    }

    /**
     * 霸主凋灵之首：沿用原版弹头的反向缩放与 yaw/pitch 旋转口径，整体按霸主凋灵
     * 本体的 2 倍模型比例绘制，使普通与炼狱弹头都和本体左右头颅大小接近。
     */
    private static final class OverlordWitherSkullRenderer extends EntityRenderer<OverlordWitherSkull> {
        private static final ResourceLocation NORMAL_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/overlord_wither_skull.png");
        private static final ResourceLocation PURGATORY_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/overlord_wither_skull_purgatory.png");
        private final OverlordWitherSkullModel model;

        private OverlordWitherSkullRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.model = new OverlordWitherSkullModel(context.bakeLayer(OverlordWitherSkullModel.LAYER));
        }

        @Override
        protected int getBlockLightLevel(OverlordWitherSkull entity, net.minecraft.core.BlockPos pos) {
            return 15;
        }

        @Override
        public void render(OverlordWitherSkull entity, float yaw, float partialTick, PoseStack poseStack,
                           MultiBufferSource bufferSource, int packedLight) {
            poseStack.pushPose();
            poseStack.scale(-2.0F, -2.0F, 2.0F);
            this.model.rotateTo(Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot()),
                    Mth.lerp(partialTick, entity.xRotO, entity.getXRot()));
            this.model.renderToBuffer(poseStack, bufferSource.getBuffer(
                            RenderType.entityTranslucent(getTextureLocation(entity))),
                    packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
            poseStack.popPose();
            super.render(entity, yaw, partialTick, poseStack, bufferSource, packedLight);
        }

        @Override
        public ResourceLocation getTextureLocation(OverlordWitherSkull entity) {
            return entity.isPurgatory() ? PURGATORY_TEXTURE : NORMAL_TEXTURE;
        }
    }

    private static final class ShadowApostleRenderer extends MobRenderer<ShadowApostle, ShadowApostleModel> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/entity/shadow_apostle.png");

        private ShadowApostleRenderer(EntityRendererProvider.Context context) {
            super(context, new ShadowApostleModel(context.bakeLayer(ShadowApostleModel.LAYER)), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(ShadowApostle entity) {
            return TEXTURE;
        }
    }

    /**
     * 光环环：贴在生物脚下地面上的一块水平贴图四边形（军团光环.png，32×32）。
     *
     * <p>渲染层拿到的 PoseStack 是 {@code LivingEntityRenderer#render} 处理完
     * 实体位姿后的模型空间：先 {@code scale(-1,-1,1)}（模型 y 轴向下翻成向上），
     * 再 {@code translate(0,-1.501,0)}——因此局部坐标 y=1.501 才是实体脚底，
     * y=0 是模型基准面（脚底上方 1.501 格）。上一版按"原点即脚底"理解、把环画在
     * y=0.02，实际悬在胸口高度；本版按换算画在 y = 1.501 - 0.02，即脚底上方
     * 0.02 格。法线同理取 (0,-1,0)，经翻转后在世界里朝上。四边形随宿主渲染器
     * 的 scale 一起缩放（狂战士 1.2 倍体型光环也大 1.2 倍，观感自然），中心
     * 镂空由贴图的 alpha 通道负责。</p>
     */
    private static final class LegionAuraRingLayer<T extends net.minecraft.world.entity.LivingEntity,
            M extends EntityModel<T>>
            extends RenderLayer<T, M> {
        private static final ResourceLocation AURA_TEXTURE = ResourceLocation.fromNamespaceAndPath(
                GeneratedMod.MOD_ID, "textures/misc/legion_aura.png");
        private static final float RING_RADIUS = 0.9F;
        /** LivingEntityRenderer 翻转+平移后，局部 y=1.501 对应实体脚底。 */
        private static final float FEET_LOCAL_Y = 1.501F;
        private static final float RING_HEIGHT = FEET_LOCAL_Y - 0.02F;

        LegionAuraRingLayer(RenderLayerParent<T, M> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            if (!(entity instanceof ILegionAuraCarrier carrier) || !carrier.netherarmy$hasLegionAura()) {
                return;
            }
            PoseStack.Pose pose = poseStack.last();
            VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityTranslucent(AURA_TEXTURE));
            vertexConsumer.addVertex(pose, -RING_RADIUS, RING_HEIGHT, -RING_RADIUS)
                    .setColor(255, 255, 255, 255).setUv(0.0F, 0.0F)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight)
                    .setNormal(pose, 0.0F, -1.0F, 0.0F);
            vertexConsumer.addVertex(pose, -RING_RADIUS, RING_HEIGHT, RING_RADIUS)
                    .setColor(255, 255, 255, 255).setUv(0.0F, 1.0F)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight)
                    .setNormal(pose, 0.0F, -1.0F, 0.0F);
            vertexConsumer.addVertex(pose, RING_RADIUS, RING_HEIGHT, RING_RADIUS)
                    .setColor(255, 255, 255, 255).setUv(1.0F, 1.0F)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight)
                    .setNormal(pose, 0.0F, -1.0F, 0.0F);
            vertexConsumer.addVertex(pose, RING_RADIUS, RING_HEIGHT, -RING_RADIUS)
                    .setColor(255, 255, 255, 255).setUv(1.0F, 0.0F)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight)
                    .setNormal(pose, 0.0F, -1.0F, 0.0F);
        }
    }
}
