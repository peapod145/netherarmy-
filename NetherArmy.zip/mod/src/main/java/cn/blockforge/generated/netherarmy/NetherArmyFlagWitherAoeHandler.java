package cn.blockforge.generated.netherarmy;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.entity.PartEntity;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 下界军团旗帜的"范围凋零 + 黑烟"结算，服务端。
 *
 * <p>规格：命中一次攻击，即以被击中者为中心，对半径
 * {@value #WITHER_AOE_RADIUS} 格内一切非凋灵骷髅阵营的存活生物施加
 * {@value #WITHER_DURATION_TICKS} 刻（10 秒）凋零 I，并在每个被影响的生物身上
 * 冒一小团原版黑烟（{@code minecraft:large_smoke}）；命中点同时炸出一团黑烟
 * （{@code minecraft:smoke}）。</p>
 *
 * <h3>持旗者不限玩家：怪物拿着旗帜打人也出波</h3>
 * <p>本效应挂在"攻击命中"这个语义上，与出手的是谁无关。玩家与怪物走的是两套完全不同的
 * 近战结算路径，所以必须各有通道：</p>
 * <ul>
 *   <li>玩家：{@code Player#attack} → 伤害类型 {@code minecraft:player_attack}，
 *       并会调到 {@code ItemStack#hurtEnemy}/{@code Item#postHurtEnemy}；</li>
 *   <li>怪物：{@code Mob#doHurtTarget} → {@code target.hurtServer(damageSources().mobAttack(this))}
 *       → 伤害类型 {@code minecraft:mob_attack}。这条路径
 *       <b>既不发 {@code AttackEntityEvent}（那是玩家专属事件），也完全不调
 *       {@code ItemStack#hurtEnemy}/{@code postHurtEnemy}（那是 {@code Player#attack} 里的
 *       物品钩子）</b>。前几版把三条通道全部写成 {@code instanceof Player} +
 *       {@code PLAYER_ATTACK}，怪物持旗时一条都进不来，表现就是"只有玩家有波、怪物没有"。</li>
 * </ul>
 *
 * <h3>四条互补通道</h3>
 * <ol>
 *   <li>{@link AttackEntityEvent}：{@code Player#attack} 一进门就发出，早于伤害结算，
 *       玩家挥中实体即触发（打免伤目标也照发）；</li>
 *   <li>{@link LivingIncomingDamageEvent}：受害者 {@code hurtServer} 内部发出。这里认
 *       {@code player_attack}、{@code mob_attack}、{@code mob_attack_no_aggro} 三种近战伤害类型，
 *       攻击者取 {@code DamageSource#getEntity()}，因此横扫、生物近战、任何绕过
 *       {@code Player#attack} 的近战结算都能覆盖；</li>
 *   <li>{@link NetherArmyFlagItem#postHurtEnemy}：原版物品命中钩子（仅玩家路径会调到），
 *       由该物品转发进来；</li>
 *   <li>{@link #onMobMeleeSwing}：由
 *       {@link cn.blockforge.generated.netherarmy.mixin.MobMeleeSwingMixin} 在
 *       {@code Mob#doHurtTarget} 的 {@code HEAD} 转发进来。它是怪物侧与通道一对等的
 *       "挥击即触发"落点：怪物打创造模式玩家、打免伤目标，或者这一拳正好落在受害者
 *       的受击硬直窗口里（{@code hurtServer} 提前返回 {@code false}，通道二根本不发出）时，
 *       只有这一条能保证旗帜依然出波——不然就是"明明砍到了却没波"。</li>
 * </ol>
 *
 * <p>四条通道在同一次挥击中只会真正结算一次：{@link #claim} 以"攻击者 UUID + 当前游戏刻"
 * 为凭据去重（一次挥击的所有回调都落在同一刻内），所以既不重复扣效果时长，也不会叠出双份粒子。</p>
 *
 * <p>阵营名册与 {@link WitherFactionInfectionHandler} 一致：{@code #minecraft:wither_skeletons}
 * 标签内的实体（本模组已把凋灵骷髅、狂战士、下界猎手、无头骑士、衰翼、尸鬼、催眠师纳入该标签）、
 * 凋灵本体、无头骑士头颅。持旗者本人不受影响。</p>
 */
public final class NetherArmyFlagWitherAoeHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("netherarmy");

    /** 凋零 AoE 半径（格），以被击中者为中心。 */
    private static final double WITHER_AOE_RADIUS = 5.0D;
    /** 凋零持续刻数：200 刻 = 10 秒。 */
    private static final int WITHER_DURATION_TICKS = 200;
    /** 凋零等级：0 即"凋零 I"。 */
    private static final int WITHER_AMPLIFIER = 0;
    /** 去重表保留窗口（刻），超过即回收，避免生物死亡后残留。 */
    private static final long CLAIM_TTL_TICKS = 20L;

    private static final TagKey<EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    /** 攻击者 UUID -> 最近一次结算的游戏刻。仅在服务器线程读写。 */
    private static final Map<UUID, Long> LAST_IMPACT_TICK = new HashMap<>();
    /** 每条通道首次成功结算时在日志里留一行凭据，便于核对触发链是否通。 */
    private static final Set<String> ANNOUNCED_CHANNELS = new HashSet<>();

    private NetherArmyFlagWitherAoeHandler() {
    }

    /** 通道一：玩家挥击命中实体，早于伤害结算。 */
    @SubscribeEvent
    public static void onPlayerAttack(AttackEntityEvent event) {
        if (event.isCanceled()) {
            return;
        }
        Player attacker = event.getEntity();
        if (attacker.level().isClientSide()) {
            return;
        }
        // 与原版 Player#attack 一致：打中分身实体（PartEntity）时按本体算
        Entity target = event.getTarget();
        if (!(unwrap(target) instanceof LivingEntity living)) {
            return;
        }
        tryImpact(attacker, living, "AttackEntityEvent");
    }

    /**
     * 通道二：受害者进入伤害结算。覆盖玩家近战（含横扫）与<b>任何生物的近战</b>——
     * {@code Mob#doHurtTarget} 的落点就是 {@code damageSources().mobAttack(this)}，
     * 归因实体 {@code DamageSource#getEntity()} 正是出手的那只怪。
     */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled()) {
            return;
        }
        DamageSource source = event.getSource();
        if (!source.is(DamageTypes.PLAYER_ATTACK) && !source.is(DamageTypes.MOB_ATTACK)
                && !source.is(DamageTypes.MOB_ATTACK_NO_AGGRO)) {
            return;
        }
        if (!(source.getEntity() instanceof LivingEntity attacker)) {
            return;
        }
        if (attacker.level().isClientSide()) {
            return;
        }
        tryImpact(attacker, event.getEntity(), "LivingIncomingDamageEvent");
    }

    /** 通道三：由 {@link NetherArmyFlagItem#postHurtEnemy} 转发的原版物品命中钩子（仅玩家路径）。 */
    public static void onItemMeleeHit(LivingEntity attacker, LivingEntity target) {
        tryImpact(attacker, target, "Item#postHurtEnemy");
    }

    /**
     * 通道四：由 {@link cn.blockforge.generated.netherarmy.mixin.MobMeleeSwingMixin}
     * 在 {@code Mob#doHurtTarget} 的 {@code HEAD} 转发的怪物近战挥击。
     *
     * <p>这里先做最便宜的持旗判定再碰目标，避免场上所有怪每次挥击都走一遍后续逻辑。</p>
     */
    public static void onMobMeleeSwing(Mob attacker, Entity rawTarget) {
        if (attacker.level().isClientSide() || !holdsFlag(attacker)) {
            return;
        }
        if (!(unwrap(rawTarget) instanceof LivingEntity living)) {
            return;
        }
        tryImpact(attacker, living, "Mob#doHurtTarget");
    }

    /** 分身实体（{@code PartEntity}）还原成本体，打无头骑士的肢体等同打它本人。 */
    private static Entity unwrap(Entity entity) {
        if (entity instanceof PartEntity part) {
            Entity parent = part.getParent();
            if (parent != null) {
                return parent;
            }
        }
        return entity;
    }

    /** 四条通道共用的人口检查：服务端、持旗、去重，然后才结算。 */
    private static void tryImpact(LivingEntity attacker, LivingEntity center, String channel) {
        if (attacker.level().isClientSide() || !(attacker.level() instanceof ServerLevel level)) {
            return;
        }
        if (!holdsFlag(attacker)) {
            return;
        }
        if (center == attacker || center.isRemoved()) {
            return;
        }
        if (!claim(attacker, level)) {
            return;
        }
        applyImpact(level, attacker, center, channel);
    }

    /**
     * 是否持有可能出波的下界军团旗帜。
     *
     * <p>常规情况是主手持旗（旗帜的伤害与攻击距离修饰符也只挂在 {@code MAINHAND} 上）。
     * 对<b>怪物</b>额外放开一条：主手空着、旗帜在副手时也认账——{@code /summon} 直接给
     * {@code HandItems} 时两件装备可以任意落到两只手上，怪物拾取时若主手已被占也会把
     * 旗帜塞进副手；玩家不走这条，玩家主手空着挥出去的是空手，不该带武器命中效果。</p>
     */
    static boolean holdsFlag(LivingEntity attacker) {
        ItemStack main = attacker.getMainHandItem();
        if (main.is(GeneratedMod.NETHER_ARMY_FLAG.get())) {
            return true;
        }
        return main.isEmpty() && !(attacker instanceof Player)
                && attacker.getOffhandItem().is(GeneratedMod.NETHER_ARMY_FLAG.get());
    }

    /** 一次挥击只结算一次：同一攻击者在同一游戏刻内的后续通道全部作废。 */
    private static boolean claim(LivingEntity attacker, ServerLevel level) {
        long tick = level.getGameTime();
        Long previous = LAST_IMPACT_TICK.put(attacker.getUUID(), tick);
        if (previous != null && previous.longValue() == tick) {
            return false;
        }
        if (LAST_IMPACT_TICK.size() > 64) {
            LAST_IMPACT_TICK.values().removeIf(lastTick -> tick - lastTick > CLAIM_TTL_TICKS);
        }
        return true;
    }

    /** 真正的结算：命中点黑烟 + 半径内非阵营生物 10 秒凋零，各自头顶冒一小团黑烟。 */
    private static void applyImpact(ServerLevel level, LivingEntity attacker, LivingEntity center, String channel) {
        // 攻击时附带的黑烟：命中点一团
        level.sendParticles(ParticleTypes.SMOKE,
                center.getX(), center.getY() + center.getBbHeight() * 0.5D, center.getZ(),
                14, center.getBbWidth() * 0.6D, center.getBbHeight() * 0.35D, center.getBbWidth() * 0.6D,
                0.02D);

        AABB area = center.getBoundingBox().inflate(WITHER_AOE_RADIUS);
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, area);
        int affected = 0;
        for (LivingEntity entity : nearby) {
            if (entity == attacker || !entity.isAlive() || isWitherFaction(entity)) {
                continue;
            }
            entity.addEffect(new MobEffectInstance(MobEffects.WITHER, WITHER_DURATION_TICKS, WITHER_AMPLIFIER,
                    false, true), attacker);
            level.sendParticles(ParticleTypes.LARGE_SMOKE,
                    entity.getX(), entity.getY() + entity.getBbHeight() * 0.7D, entity.getZ(),
                    8, entity.getBbWidth() * 0.45D, entity.getBbHeight() * 0.3D, entity.getBbWidth() * 0.45D,
                    0.03D);
            affected++;
        }
        announceOnce(channel, attacker, affected);
    }

    /**
     * 供无头强袭骑士的坐骑复用：近战命中时打出与军团旗帜完全相同的
     * "半径 5 格凋零波 + 黑烟"，走同一套 {@link #applyImpact} 结算。
     */
    public static void triggerBlitzMountImpact(ServerLevel level, LivingEntity attacker, LivingEntity center) {
        applyImpact(level, attacker, center, "blitz_dullhan_horse");
    }

    /** 凋灵骷髅阵营判定：标签名册 + 凋灵本体 + 无头骑士头颅（独立实体、不在标签里）。 */
    static boolean isWitherFaction(LivingEntity entity) {
        return entity instanceof WitherBoss || entity instanceof DullhanHead
                || entity.getType().is(WITHER_SKELETONS);
    }

    /** 每条通道每个游戏进程只打印一行，用于在 logs/latest.log 里确认触发链是否走通。 */
    private static void announceOnce(String channel, LivingEntity attacker, int affected) {
        if (!ANNOUNCED_CHANNELS.add(channel)) {
            return;
        }
        LOGGER.info("[netherarmy] nether_army_flag wither aura fired (channel={}, attacker={}, radius={} blocks, "
                + "duration={} ticks, affected entities={})", channel,
                EntityType.getKey(attacker.getType()), WITHER_AOE_RADIUS, WITHER_DURATION_TICKS, affected);
    }
}
