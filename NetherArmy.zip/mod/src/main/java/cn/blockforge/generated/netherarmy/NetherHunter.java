package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.CrossbowAttackMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.RandomSource;

/**
 * 下界猎手：使用凋零骷髅模型和基础属性，但拥有专用的远程战斗 AI。
 */
public class NetherHunter extends WitherSkeleton implements CrossbowAttackMob {
    private static final double SKELETON_FOLLOW_RANGE = 16.0D;
    private static final double NETHER_HUNTER_FOLLOW_RANGE = SKELETON_FOLLOW_RANGE * 1.5D;
    private static final float SKELETON_BOW_RANGE = 15.0F;
    private static final float NETHER_HUNTER_BOW_RANGE = SKELETON_BOW_RANGE * 1.5F;
    private static final float RETREAT_DISTANCE = 10.0F;
    private static final double DETOUR_DISTANCE = 5.0D;
    private static final int PATH_RECALCULATION_INTERVAL = 8;

    public NetherHunter(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        this.xpReward = 8;
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractSkeleton.createAttributes()
                .add(Attributes.FOLLOW_RANGE, NETHER_HUNTER_FOLLOW_RANGE);
    }

    @Override
    protected void registerGoals() {
        // WitherSkeleton 的默认弓箭目标会在较近距离持续追击；移除它，改用明确的
        // 远距离停留、10 格后退和受抛射物威胁时横移的专用目标。
        super.registerGoals();
        this.goalSelector.removeAllGoals(goal -> isGoalType(goal, RangedBowAttackGoal.class));
        this.goalSelector.removeAllGoals(goal -> isGoalType(goal, MeleeAttackGoal.class));
        this.goalSelector.removeAllGoals(goal -> isGoalType(goal, RangedCrossbowAttackGoal.class));
        this.goalSelector.addGoal(1, new ProjectileDodgeGoal(this));
        this.goalSelector.addGoal(2, new RangedCrossbowAttackGoal(this, 1.0D, 22.0F));
        this.goalSelector.addGoal(3, new NetherHunterRangedAttackGoal(this));
        this.goalSelector.addGoal(4, new NetherHunterMeleeAttackGoal(this, 1.2D, true));
    }

    @Override
    public boolean canFireProjectileWeapon(ProjectileWeaponItem weapon) {
        return weapon instanceof BowItem || weapon instanceof CrossbowItem;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        Item item = stack.getItem();
        return item instanceof BowItem || item instanceof CrossbowItem || item instanceof TridentItem
                || !(item instanceof ProjectileWeaponItem) && super.canHoldItem(stack);
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return this.canPickUpLoot() && this.canHoldItem(stack);
    }

    @Override
    public void reassessWeaponGoal() {
        // 目标由本类按当前手持武器管理，禁止 AbstractSkeleton 恢复原版弓/近战目标。
    }

    @Override
    public void setChargingCrossbow(boolean charging) {
        // 下界猎手没有专用的弩动画数据，战斗状态由 RangedCrossbowAttackGoal 管理。
    }

    @Override
    public LivingEntity getTarget() {
        return super.getTarget();
    }

    @Override
    public void onCrossbowAttackPerformed() {
        ItemStack crossbow = this.getMainHandItem();
        if (crossbow.getItem() instanceof CrossbowItem) {
            crossbow.set(net.minecraft.core.component.DataComponents.CHARGED_PROJECTILES,
                    net.minecraft.world.item.component.ChargedProjectiles.EMPTY);
        }
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                         DifficultyInstance difficulty) {
        // 下界猎手的装备附魔由 finalizeSpawn 按指定概率和候选集合生成。
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         net.minecraft.world.entity.MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 原版 Mob 会随机设置左撇子；下界猎手的弓必须固定在右手。
        this.setLeftHanded(false);
        RandomSource random = this.getRandom();
        ServerLevel serverLevel = level.getLevel();

        // 在原版生成流程后再次设置弓，保证它不会被默认装备流程移动到左手。
        ItemStack bow = new ItemStack(Items.BOW);
        if (random.nextFloat() < 0.10F) {
            addExactlyTwoBowEnchantments(serverLevel, random, bow);
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, bow);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setCanPickUpLoot(false);

        // 四个判定相互独立，因此同一只下界猎手可以同时穿戴多件皮革装备。
        equipLeatherArmor(serverLevel, random, EquipmentSlot.HEAD, Items.LEATHER_HELMET, 0.20F);
        equipLeatherArmor(serverLevel, random, EquipmentSlot.FEET, Items.LEATHER_BOOTS, 0.20F);
        equipLeatherArmor(serverLevel, random, EquipmentSlot.CHEST, Items.LEATHER_CHESTPLATE, 0.15F);
        equipLeatherArmor(serverLevel, random, EquipmentSlot.LEGS, Items.LEATHER_LEGGINGS, 0.15F);

        if (random.nextFloat() < 0.05F) {
            spawnSkeletonHorse(serverLevel);
        }
        return result;
    }

    private void equipLeatherArmor(ServerLevel level, RandomSource random, EquipmentSlot slot,
                                   Item item, float chance) {
        if (random.nextFloat() >= chance) {
            return;
        }
        ItemStack armor = new ItemStack(item);
        if (random.nextFloat() < 0.10F) {
            addRandomCompatibleArmorEnchantments(level, random, armor, slot);
        }
        this.setItemSlot(slot, armor);
        this.setDropChance(slot, 0.0F);
    }

    private void addRandomCompatibleArmorEnchantments(ServerLevel level, RandomSource random,
                                                       ItemStack stack, EquipmentSlot slot) {
        HolderLookup.RegistryLookup<Enchantment> registry =
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (Holder.Reference<Enchantment> holder : registry.listElements().toList()) {
            Enchantment enchantment = holder.value();
            if (holder.is(net.minecraft.world.item.enchantment.Enchantments.BINDING_CURSE)
                    || holder.is(net.minecraft.world.item.enchantment.Enchantments.VANISHING_CURSE)) {
                continue;
            }
            if (enchantment.canEnchant(stack) && enchantment.matchingSlot(slot)) {
                candidates.add(holder);
            }
        }
        addCompatibleRandomEnchantments(random, stack, candidates, 3);
    }

    private void addExactlyTwoBowEnchantments(ServerLevel level, RandomSource random, ItemStack stack) {
        HolderLookup.RegistryLookup<Enchantment> registry =
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<String> ids = new ArrayList<>(List.of("power", "punch", "infinity", "unbreaking", "mending"));
        Collections.shuffle(ids, new java.util.Random(random.nextLong()));
        for (int i = 0; i < 2; i++) {
            ResourceKey<Enchantment> key = ResourceKey.create(Registries.ENCHANTMENT,
                    ResourceLocation.withDefaultNamespace(ids.get(i)));
            Holder.Reference<Enchantment> holder = registry.get(key)
                    .map(found -> (Holder.Reference<Enchantment>) found).orElse(null);
            if (holder != null) {
                stack.enchant(holder, 1 + random.nextInt(Math.min(2, holder.value().getMaxLevel())));
            }
        }
    }

    private static void addCompatibleRandomEnchantments(RandomSource random, ItemStack stack,
                                                         List<Holder.Reference<Enchantment>> candidates,
                                                         int maxCount) {
        if (candidates.isEmpty()) {
            return;
        }
        Collections.shuffle(candidates, new java.util.Random(random.nextLong()));
        int wanted = 1 + random.nextInt(Math.min(maxCount, candidates.size()));
        List<Holder.Reference<Enchantment>> selected = new ArrayList<>();
        for (Holder.Reference<Enchantment> candidate : candidates) {
            boolean compatible = true;
            for (Holder.Reference<Enchantment> existing : selected) {
                if (!Enchantment.areCompatible(candidate, existing)) {
                    compatible = false;
                    break;
                }
            }
            if (!compatible) {
                continue;
            }
            selected.add(candidate);
            int maxLevel = Math.min(3, candidate.value().getMaxLevel());
            stack.enchant(candidate, 1 + random.nextInt(maxLevel));
            if (selected.size() >= wanted) {
                break;
            }
        }
    }

    private void spawnSkeletonHorse(ServerLevel level) {
        SkeletonHorse horse = EntityType.SKELETON_HORSE.create(level);
        if (horse == null) {
            return;
        }
        horse.setPos(this.getX(), this.getY(), this.getZ());
        horse.setTamed(true);
        horse.setPersistenceRequired();
        if (level.addFreshEntity(horse)) {
            this.startRiding(horse, true);
        }
    }

    @Override
    protected int getAttackInterval() {
        // 骷髅普通难度为 40 tick；40 / 1.2 取整为 33 tick。
        return 33;
    }

    @Override
    protected int getHardAttackInterval() {
        // 骷髅困难难度为 20 tick；20 / 1.2 取整为 16 tick。
        return 16;
    }

    @Override
    protected AbstractArrow getArrow(ItemStack arrowStack, float velocity, ItemStack weaponStack) {
        AbstractArrow arrow = super.getArrow(arrowStack, velocity, weaponStack);
        // WitherSkeleton 默认会把箭点燃 100 秒，这里明确覆盖为需求中的 5 秒。
        arrow.igniteForSeconds(5.0F);
        if (arrow instanceof Arrow normalArrow) {
            normalArrow.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.WITHER, 100));
        }
        return arrow;
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        // 与凋灵仆役同一条坑：弩目标会调这里，父类/弓路径拿空副手当武器会崩。
        if (this.isHolding(stack -> stack.getItem() instanceof CrossbowItem)) {
            this.performCrossbowAttack(this, 1.6F);
            return;
        }
        InteractionHand hand = ProjectileUtil.getWeaponHoldingHand(this,
                item -> item instanceof BowItem || item instanceof TridentItem);
        ItemStack weapon = this.getItemInHand(hand);
        if (weapon.getItem() instanceof TridentItem) {
            ThrownTrident trident = new ThrownTrident(this.level(), this, weapon.copy());
            double x = target.getX() - this.getX();
            double y = target.getY(1.0D / 3.0D) - trident.getY();
            double z = target.getZ() - this.getZ();
            trident.shoot(x, y, z, 2.5F * velocity, 1.0F);
            this.playSound(SoundEvents.TRIDENT_THROW.value(), 1.0F,
                    0.8F + this.getRandom().nextFloat() * 0.4F);
            this.level().addFreshEntity(trident);
            return;
        }
        if (!(weapon.getItem() instanceof BowItem)) {
            return;
        }

        ItemStack projectileStack = this.getProjectile(weapon);
        AbstractArrow arrow = this.getArrow(projectileStack, velocity, weapon);
        if (weapon.getItem() instanceof ProjectileWeaponItem projectileWeapon) {
            arrow = projectileWeapon.customArrow(arrow, projectileStack, weapon);
        }

        double x = target.getX() - this.getX();
        double y = target.getY(1.0D / 3.0D) - arrow.getY();
        double z = target.getZ() - this.getZ();
        double horizontalDistance = Math.sqrt(x * x + z * z);
        float spread = 14 - 4 * this.level().getDifficulty().getId();
        arrow.shoot(x, y + horizontalDistance * 0.2D, z, 1.6F, spread);
        this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F,
                0.8F + this.getRandom().nextFloat() * 0.4F);
        this.level().addFreshEntity(arrow);
    }

    private static final class NetherHunterMeleeAttackGoal extends MeleeAttackGoal {
        private final NetherHunter hunter;

        private NetherHunterMeleeAttackGoal(NetherHunter hunter, double speedModifier,
                                            boolean followingTargetEvenIfNotSeen) {
            super(hunter, speedModifier, followingTargetEvenIfNotSeen);
            this.hunter = hunter;
        }

        @Override
        public boolean canUse() {
            return isMeleeWeapon(this.hunter.getMainHandItem()) && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return isMeleeWeapon(this.hunter.getMainHandItem()) && super.canContinueToUse();
        }
    }

    private static boolean isMeleeWeapon(ItemStack stack) {
        Item item = stack.getItem();
        return !(item instanceof BowItem) && !(item instanceof CrossbowItem) && !(item instanceof TridentItem);
    }

    private static final class NetherHunterRangedAttackGoal extends Goal {
        private final NetherHunter hunter;
        private LivingEntity target;
        private int attackTime;
        private int seeTime;
        private int strafingTime;
        private int pathRecalculationCooldown;
        private boolean strafingClockwise;

        private NetherHunterRangedAttackGoal(NetherHunter hunter) {
            this.hunter = hunter;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity candidate = this.hunter.getTarget();
            if (candidate == null || !candidate.isAlive() || !this.isBowOrTrident()) {
                return false;
            }
            this.target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && this.hunter.getTarget() == this.target
                    && this.isBowOrTrident();
        }

        private boolean isBowOrTrident() {
            Item item = this.hunter.getMainHandItem().getItem();
            return item instanceof BowItem || item instanceof TridentItem;
        }

        @Override
        public void start() {
            this.attackTime = 0;
            this.seeTime = 0;
            this.strafingTime = -1;
            this.pathRecalculationCooldown = 0;
            this.strafingClockwise = this.hunter.getRandom().nextBoolean();
            this.hunter.setAggressive(true);
        }

        @Override
        public void stop() {
            this.target = null;
            this.strafingTime = -1;
            this.pathRecalculationCooldown = 0;
            this.hunter.setAggressive(false);
            this.hunter.stopUsingItem();
            this.hunter.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity currentTarget = this.hunter.getTarget();
            if (currentTarget == null || !currentTarget.isAlive()) {
                return;
            }
            this.target = currentTarget;
            double distanceSqr = this.hunter.distanceToSqr(currentTarget);
            boolean canSee = this.hunter.getSensing().hasLineOfSight(currentTarget);
            if (canSee) {
                ++this.seeTime;
            } else {
                this.seeTime = 0;
            }

            this.hunter.getLookControl().setLookAt(currentTarget, 30.0F, 30.0F);
            if (distanceSqr < RETREAT_DISTANCE * RETREAT_DISTANCE) {
                // 使用原版 RangedBowAttackGoal 同款的 MoveControl 游走倒退，避免直线
                // 反向寻路造成突然转身、贴墙卡住或后退轨迹僵硬。
                this.strafeBackward(currentTarget);
            } else if (distanceSqr <= NETHER_HUNTER_BOW_RANGE * NETHER_HUNTER_BOW_RANGE && canSee) {
                // 射程内保持当前位置，不再向目标靠近。
                this.strafingTime = -1;
                this.hunter.getNavigation().stop();
                this.hunter.stopInPlace();
            } else if (!canSee || distanceSqr > NETHER_HUNTER_BOW_RANGE * NETHER_HUNTER_BOW_RANGE) {
                // 目标在射程外或被遮挡时才接近；路径失败时改走目标侧面的候选点。
                this.strafingTime = -1;
                this.moveTowardTarget(currentTarget);
            }

            if (--this.attackTime <= 0) {
                if (canSee && distanceSqr <= NETHER_HUNTER_BOW_RANGE * NETHER_HUNTER_BOW_RANGE) {
                    float power = (float) Math.sqrt(distanceSqr) / NETHER_HUNTER_BOW_RANGE;
                    this.hunter.performRangedAttack(currentTarget, power);
                    this.attackTime = this.hunter.getAttackIntervalForDifficulty();
                } else {
                    this.attackTime = 5;
                }
            }
        }

        private void strafeBackward(LivingEntity target) {
            // RangedBowAttackGoal 每 4–10 tick 随机换向一次；面向目标时，负前进量
            // 就是倒退，左右分量则形成骷髅同款的游走倒退，而不是直线反向寻路。
            if (this.strafingTime-- <= 0) {
                this.strafingClockwise = this.hunter.getRandom().nextBoolean();
                this.strafingTime = 4 + this.hunter.getRandom().nextInt(7);
            }
            this.hunter.getNavigation().stop();
            this.hunter.getMoveControl().strafe(-0.625F, this.strafingClockwise ? 0.5F : -0.5F);
            this.hunter.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }

        /** 每隔几 tick 重算路径，并在直达路径不可用时尝试目标两侧和前后方。 */
        private void moveTowardTarget(LivingEntity target) {
            if (this.pathRecalculationCooldown-- > 0
                    && this.hunter.getNavigation().isInProgress()) {
                return;
            }
            this.pathRecalculationCooldown = PATH_RECALCULATION_INTERVAL;
            PathNavigation navigation = this.hunter.getNavigation();
            Path directPath = navigation.createPath(target, 0);
            if (this.usePath(navigation, directPath)) {
                return;
            }

            Vec3 toTarget = target.position().subtract(this.hunter.position());
            Vec3 horizontal = new Vec3(toTarget.x, 0.0D, toTarget.z);
            if (horizontal.lengthSqr() < 1.0E-6D) {
                horizontal = new Vec3(0.0D, 0.0D, 1.0D);
            } else {
                horizontal = horizontal.normalize();
            }
            Vec3 side = new Vec3(-horizontal.z, 0.0D, horizontal.x);
            Vec3[] candidates = {
                    target.position().add(side.scale(DETOUR_DISTANCE)),
                    target.position().add(side.scale(-DETOUR_DISTANCE)),
                    target.position().subtract(horizontal.scale(DETOUR_DISTANCE)),
                    target.position().add(horizontal.scale(DETOUR_DISTANCE))
            };
            for (Vec3 candidate : candidates) {
                Path detourPath = navigation.createPath(candidate.x, candidate.y, candidate.z, 0);
                if (this.usePath(navigation, detourPath)) {
                    return;
                }
            }

            // 路径系统暂时没有可达节点时仍持续尝试目标位置，等待下一次重算。
            navigation.moveTo(target, 1.0D);
        }

        private boolean usePath(PathNavigation navigation, Path path) {
            if (path == null || !path.canReach() || path.isDone()) {
                return false;
            }
            return navigation.moveTo(path, 1.0D);
        }
    }

    /**
     * 抛射物闪避：16 格检测、30 tick 内会合、最近距离 ≤2.5 格才算威胁。威胁过滤在弹道判定
     * 之外追加了 {@link ProjectileFlightTracker} 的插地核验——原版落地箭的
     * {@code getDeltaMovement()} 是非零的插地偏移常量，只看速度会把钉在地上的箭误判成来袭
     * （衰翼的同款目标共用此判定器）。核验直接读原版 {@code inGround} 权威标记，当 tick
     * 判定、零识别延迟，保证来袭箭（尤其近距离直射）与旧版一样即时触发闪避。
     */
    private static final class ProjectileDodgeGoal extends Goal {
        private static final double DETECTION_RADIUS = 16.0D;
        private static final double MAX_THREAT_TIME = 30.0D;
        private static final double THREAT_DISTANCE = 2.5D;
        private static final double DODGE_DISTANCE = 4.0D;
        private final NetherHunter hunter;
        private Projectile incomingProjectile;
        private int dodgeTime;
        private double dodgeX;
        private double dodgeZ;

        private ProjectileDodgeGoal(NetherHunter hunter) {
            this.hunter = hunter;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            this.incomingProjectile = this.findIncomingProjectile();
            return this.incomingProjectile != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.dodgeTime > 0 && this.hunter.isAlive();
        }

        @Override
        public void start() {
            this.dodgeTime = 8;
            this.updateDodgeDirection();
            // 成就「箭皆虚发」：闪避真正起手时上报威胁弹，同一发抛射物由处理器按
            // 抛射物自身的 PersistentData 去重，这里只管"此刻我在躲它"。
            if (this.incomingProjectile != null) {
                HunterHuntAdvancementHandler.onProjectileDodged(this.incomingProjectile);
            }
        }

        @Override
        public void tick() {
            Projectile currentThreat = this.findIncomingProjectile();
            if (currentThreat != null) {
                // 每 tick 重新寻找威胁，避免目标快速移动或抛射物改变轨迹时反应滞后。
                this.incomingProjectile = currentThreat;
                this.dodgeTime = 8;
                this.updateDodgeDirection();
                if (this.incomingProjectile != null) {
                    HunterHuntAdvancementHandler.onProjectileDodged(this.incomingProjectile);
                }
            } else {
                --this.dodgeTime;
            }
            if (this.dodgeTime > 0) {
                this.hunter.getNavigation().moveTo(
                        this.hunter.getX() + this.dodgeX * 2.5D,
                        this.hunter.getY(),
                        this.hunter.getZ() + this.dodgeZ * 2.5D,
                        1.8D);
            }
        }

        @Override
        public void stop() {
            this.incomingProjectile = null;
            this.dodgeTime = 0;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        private void updateDodgeDirection() {
            if (this.incomingProjectile == null) {
                return;
            }
            Vec3 motion = this.incomingProjectile.getDeltaMovement();
            Vec3 away = new Vec3(
                    this.hunter.getX() - this.incomingProjectile.getX(),
                    0.0D,
                    this.hunter.getZ() - this.incomingProjectile.getZ());
            if (away.lengthSqr() < 1.0E-6D) {
                away = new Vec3(-motion.x, 0.0D, -motion.z);
            }
            away = away.normalize();

            Vec3 horizontalMotion = new Vec3(motion.x, 0.0D, motion.z);
            Vec3 lateral = horizontalMotion.lengthSqr() < 1.0E-6D
                    ? new Vec3(-away.z, 0.0D, away.x)
                    : new Vec3(-horizontalMotion.z, 0.0D, horizontalMotion.x).normalize();
            // 两个候选方向都带有明确的“远离抛射物”分量，再从左右两侧选择离轨迹更远的一侧。
            Vec3 first = away.scale(0.85D).add(lateral.scale(0.65D)).normalize();
            Vec3 second = away.scale(0.85D).add(lateral.scale(-0.65D)).normalize();
            this.dodgeX = first.x;
            this.dodgeZ = first.z;
            if (this.distanceToProjectilePath(second) > this.distanceToProjectilePath(first)) {
                this.dodgeX = second.x;
                this.dodgeZ = second.z;
            }
        }

        private double distanceToProjectilePath(Vec3 direction) {
            Vec3 motion = this.incomingProjectile.getDeltaMovement();
            Vec3 path = new Vec3(motion.x, 0.0D, motion.z);
            if (path.lengthSqr() < 1.0E-6D) {
                return 0.0D;
            }
            path = path.normalize();
            Vec3 endpoint = new Vec3(
                    this.hunter.getX() + direction.x * DODGE_DISTANCE,
                    0.0D,
                    this.hunter.getZ() + direction.z * DODGE_DISTANCE);
            Vec3 projectilePosition = new Vec3(
                    this.incomingProjectile.getX(), 0.0D, this.incomingProjectile.getZ());
            Vec3 offset = endpoint.subtract(projectilePosition);
            double along = Math.max(0.0D, offset.dot(path));
            Vec3 nearest = projectilePosition.add(path.scale(along));
            return endpoint.distanceToSqr(nearest);
        }

        private Projectile findIncomingProjectile() {
            List<Projectile> projectiles = this.hunter.level().getEntitiesOfClass(
                    Projectile.class, this.hunter.getBoundingBox().inflate(DETECTION_RADIUS), projectile -> {
                        if (!projectile.isAlive()) {
                            return false;
                        }
                        Entity owner = projectile.getOwner();
                        if (owner == this.hunter
                                || owner != null && owner.getUUID().equals(this.hunter.getUUID())) {
                            return false;
                        }
                        Vec3 motion = projectile.getDeltaMovement();
                        // 静止抛射物不是飞来的威胁，不触发躲避。
                        if (motion.lengthSqr() <= 1.0E-6D) {
                            return false;
                        }
                        Vec3 toHunter = new Vec3(
                                this.hunter.getX() - projectile.getX(),
                                this.hunter.getEyeY() - projectile.getY(),
                                this.hunter.getZ() - projectile.getZ());
                        double speedSqr = motion.lengthSqr();
                        double timeToClosest = toHunter.dot(motion) / speedSqr;
                        if (timeToClosest < 0.0D || timeToClosest > MAX_THREAT_TIME) {
                            return false;
                        }
                        Vec3 closestPoint = projectile.position().add(motion.scale(timeToClosest));
                        if (closestPoint.distanceTo(this.hunter.position()) > THREAT_DISTANCE) {
                            return false;
                        }
                        // 速度过滤拦不住落地箭：原版 AbstractArrow.onHitBlock 把
                        // getDeltaMovement() 改写成"命中点在方块内的偏移"作插地姿态提示，
                        // 是个永久非零常量，还会伪装出恰好扫过本体的弹道。用原版自己维护的
                        // inGround 标记直接剔除——当 tick 判定，飞行的箭零延迟识别。
                        return ProjectileFlightTracker.isActuallyFlying(projectile);
                    });
            Projectile closestThreat = null;
            double bestTime = Double.MAX_VALUE;
            for (Projectile projectile : projectiles) {
                Vec3 motion = projectile.getDeltaMovement();
                Vec3 toHunter = this.hunter.position().subtract(projectile.position());
                double timeToClosest = toHunter.dot(motion) / motion.lengthSqr();
                if (timeToClosest < bestTime) {
                    bestTime = timeToClosest;
                    closestThreat = projectile;
                }
            }
            return closestThreat;
        }
    }

    private int getAttackIntervalForDifficulty() {
        Difficulty difficulty = this.level().getDifficulty();
        return difficulty == Difficulty.HARD ? getHardAttackInterval() : getAttackInterval();
    }

    private static boolean isGoalType(Goal goal, Class<? extends Goal> goalType) {
        return goalType.isInstance(goal)
                || goal instanceof WrappedGoal wrapped && goalType.isInstance(wrapped.getGoal());
    }
}
