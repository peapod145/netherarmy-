package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * 炼狱晶护腿装备模型：几何逐块取自用户上传的 nether_crystal_leggings-2.geo.bbmodel（bedrock geo bbmodel）。
 * 每块按未膨胀尺寸 + texOffs 注册（UV 即 bbmodel faces 的标准 box unwrap），
 * CubeDeformation 只做几何外扩、不动 UV，与该文件的 inflate 字段
 * （belt inflate=0.51、leggings_right inflate=0.5、leggings_left inflate=0.5）语义逐项一致；左侧板的镜像对应 bbmodel 左臂/左腿的翻转 UV。
 */
public final class NetherCrystalLeggingsArmorModel extends HumanoidModel<LivingEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_crystal_leggings_armor"), "main");

    public NetherCrystalLeggingsArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(5.0F, 2.0F, 0.0F));
        root.getChild("body").addOrReplaceChild("belt", CubeListBuilder.create().texOffs(16, 46).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.51F)), PartPose.ZERO);
        root.getChild("right_leg").addOrReplaceChild("leggings_right", CubeListBuilder.create().texOffs(0, 46).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.ZERO);
        root.getChild("left_leg").addOrReplaceChild("leggings_left", CubeListBuilder.create().texOffs(0, 46).mirror().addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }
}
