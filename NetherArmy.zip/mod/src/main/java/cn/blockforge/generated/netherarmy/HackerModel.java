package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 黑客本体层。由 tools/gen_hacker_model.py 从 hacker.bbmodel 生成。
 * 每个面保存四个真实顶点、UV 矩形和法线，完整保留 element 旋转。
 */
public final class HackerModel extends EntityModel<Hacker> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "hacker"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 32;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart computer;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    private static final float[] BODY = {
        -4.0F, -12.0F, -2.0F, 4.0F, -12.0F, -2.0F, 4.0F, 0.0F, -2.0F, -4.0F,
        0.0F, -2.0F, 20.0F, 20.0F, 28.0F, 32.0F, 0.0F, 0.0F, -1.0F, 4.0F,
        -12.0F, 2.0F, -4.0F, -12.0F, 2.0F, -4.0F, 0.0F, 2.0F, 4.0F, 0.0F,
        2.0F, 32.0F, 20.0F, 40.0F, 32.0F, 0.0F, 0.0F, 1.0F, -4.0F, -12.0F,
        2.0F, -4.0F, -12.0F, -2.0F, -4.0F, 0.0F, -2.0F, -4.0F, 0.0F, 2.0F,
        16.0F, 20.0F, 20.0F, 32.0F, -1.0F, 0.0F, 0.0F, 4.0F, -12.0F, -2.0F,
        4.0F, -12.0F, 2.0F, 4.0F, 0.0F, 2.0F, 4.0F, 0.0F, -2.0F, 28.0F,
        20.0F, 32.0F, 32.0F, 1.0F, 0.0F, 0.0F, 4.0F, -12.0F, -2.0F, -4.0F,
        -12.0F, -2.0F, -4.0F, -12.0F, 2.0F, 4.0F, -12.0F, 2.0F, 20.0F, 16.0F,
        28.0F, 20.0F, 0.0F, -1.0F, 0.0F, 4.0F, 0.0F, 2.0F, -4.0F, 0.0F,
        2.0F, -4.0F, 0.0F, -2.0F, 4.0F, 0.0F, -2.0F, 28.0F, 16.0F, 36.0F,
        20.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] COMPUTER = {};
    private static final float[] HEAD = {
        -4.0F, -8.0F, -4.0F, 4.0F, -8.0F, -4.0F, 4.0F, 0.0F, -4.0F, -4.0F,
        0.0F, -4.0F, 8.0F, 8.0F, 16.0F, 16.0F, 0.0F, 0.0F, -1.0F, 4.0F,
        -8.0F, 4.0F, -4.0F, -8.0F, 4.0F, -4.0F, 0.0F, 4.0F, 4.0F, 0.0F,
        4.0F, 24.0F, 8.0F, 32.0F, 16.0F, 0.0F, 0.0F, 1.0F, -4.0F, -8.0F,
        4.0F, -4.0F, -8.0F, -4.0F, -4.0F, 0.0F, -4.0F, -4.0F, 0.0F, 4.0F,
        0.0F, 8.0F, 8.0F, 16.0F, -1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F,
        4.0F, -8.0F, 4.0F, 4.0F, 0.0F, 4.0F, 4.0F, 0.0F, -4.0F, 16.0F,
        8.0F, 24.0F, 16.0F, 1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F, -4.0F,
        -8.0F, -4.0F, -4.0F, -8.0F, 4.0F, 4.0F, -8.0F, 4.0F, 8.0F, 0.0F,
        16.0F, 8.0F, 0.0F, -1.0F, 0.0F, 4.0F, 0.0F, 4.0F, -4.0F, 0.0F,
        4.0F, -4.0F, 0.0F, -4.0F, 4.0F, 0.0F, -4.0F, 16.0F, 0.0F, 24.0F,
        8.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_ARM = {
        -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
        12.0F, -1.0F, 42.0F, 18.0F, 44.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
        1.0F, 46.0F, 18.0F, 48.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
        1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
        40.0F, 18.0F, 42.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
        1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 44.0F,
        18.0F, 46.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
        0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 42.0F, 16.0F,
        44.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
        1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 44.0F, 16.0F, 46.0F,
        18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_ARM = {
        -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
        12.0F, -1.0F, 42.0F, 18.0F, 44.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
        1.0F, 46.0F, 18.0F, 48.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
        1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
        40.0F, 18.0F, 42.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
        1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 44.0F,
        18.0F, 46.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
        0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 42.0F, 16.0F,
        44.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
        1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 44.0F, 16.0F, 46.0F,
        18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_LEG = {
        -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
        12.0F, -1.0F, 2.0F, 18.0F, 4.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
        1.0F, 6.0F, 18.0F, 8.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
        1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
        0.0F, 18.0F, 2.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
        1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 4.0F,
        18.0F, 6.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
        0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 2.0F, 16.0F,
        4.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
        1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 4.0F, 16.0F, 6.0F,
        18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_LEG = {
        -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
        12.0F, -1.0F, 2.0F, 18.0F, 4.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
        0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
        1.0F, 6.0F, 18.0F, 8.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
        1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
        0.0F, 18.0F, 2.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
        1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 4.0F,
        18.0F, 6.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
        0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 2.0F, 16.0F,
        4.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
        1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 4.0F, 16.0F, 6.0F,
        18.0F, 0.0F, 1.0F, 0.0F
    };

    public HackerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.computer = this.body.getChild("computer");
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    @Override
    public void setupAnim(Hacker entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        HackerPose.apply(this.root, entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.body, BODY, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.pushPose();
        this.body.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.computer, COMPUTER, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
        HackerQuads.emit(poseStack, buffer, this.head, HEAD, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightArm, RIGHT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftArm, LEFT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightLeg, RIGHT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftLeg, LEFT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create(),
                PartPose.offset(0.0F, 12.0F, 0.0F));
        body.addOrReplaceChild("computer", CubeListBuilder.create(),
                PartPose.offset(-7.75F, 4.5F, 7.75F));
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
