package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CarvedPumpkinBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.WitherSkullBlock;
import net.minecraft.world.level.block.entity.SkullBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;
import cn.blockforge.generated.netherarmy.GeneratedMod;
import cn.blockforge.generated.netherarmy.OverlordWitherBoss;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 霸主凋灵祭坛（与玩家约定一致，图案坐标 (i=列, j=行, 自上而下)）：
 * 第一行（顶层）：凋灵骷髅头颅 ×3；
 * 第二行（中层）：灵魂沙、下界反应核、灵魂沙；
 * 第三行（底层）：空气、灵魂沙、空气。
 * 头颅必须是最后放置的方块（与原版凋灵一致，放置头颅时触发检测）。
 */
@Mixin(WitherSkullBlock.class)
public abstract class OverlordWitherRitualMixin {
    private static BlockPattern createOverlordPattern() {
        return BlockPatternBuilder.start()
                .aisle("^^^", "###", "~#~")
                .where('#', block -> block.getState().is(BlockTags.WITHER_SUMMON_BASE_BLOCKS)
                        || block.getState().is(GeneratedMod.NETHER_REACTOR_BLOCK.get()))
                .where('^', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.WITHER_SKELETON_SKULL)
                        .or(BlockStatePredicate.forBlock(Blocks.WITHER_SKELETON_WALL_SKULL))))
                .where('~', block -> block.getState().isAir())
                .build();
    }

    @Inject(
            method = "checkSpawn(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;"
                    + "Lnet/minecraft/world/level/block/entity/SkullBlockEntity;)V",
            at = @At("HEAD"), cancellable = true)
    private static void netherarmy$checkOverlordRitual(Level level, BlockPos skullPos,
                                                        SkullBlockEntity skullEntity, CallbackInfo callback) {
        if (level.isClientSide || level.getDifficulty() == Difficulty.PEACEFUL
                || skullPos.getY() < level.getMinBuildHeight()) {
            return;
        }
        BlockState skullState = skullEntity.getBlockState();
        if (!skullState.is(Blocks.WITHER_SKELETON_SKULL)
                && !skullState.is(Blocks.WITHER_SKELETON_WALL_SKULL)) {
            return;
        }

        BlockPattern.BlockPatternMatch match = createOverlordPattern().find(level, skullPos);
        if (match == null) {
            return;
        }
        // 第二行正中（图案坐标 (1,1,0)）必须是下界反应核；其余三个沙位必须是灵魂沙/灵魂土。
        if (!match.getBlock(1, 1, 0).getState().is(GeneratedMod.NETHER_REACTOR_BLOCK.get())) {
            return;
        }
        if (!match.getBlock(0, 1, 0).getState().is(BlockTags.WITHER_SUMMON_BASE_BLOCKS)
                || !match.getBlock(2, 1, 0).getState().is(BlockTags.WITHER_SUMMON_BASE_BLOCKS)
                || !match.getBlock(1, 2, 0).getState().is(BlockTags.WITHER_SUMMON_BASE_BLOCKS)) {
            return;
        }

        OverlordWitherBoss boss = GeneratedMod.OVERLORD_WITHER.get().create(level);
        if (boss == null) {
            return;
        }
        CarvedPumpkinBlock.clearPatternBlocks(level, match);
        BlockPos spawnPos = match.getBlock(1, 2, 0).getPos();
        boss.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY() + 0.55D, spawnPos.getZ() + 0.5D,
                match.getForwards().getAxis() == Direction.Axis.X ? 0.0F : 90.0F, 0.0F);
        boss.yBodyRot = match.getForwards().getAxis() == Direction.Axis.X ? 0.0F : 90.0F;
        boss.makeInvulnerable();
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class,
                boss.getBoundingBox().inflate(50.0D))) {
            CriteriaTriggers.SUMMONED_ENTITY.trigger(player, boss);
        }
        level.addFreshEntity(boss);
        CarvedPumpkinBlock.updatePatternBlocks(level, match);
        callback.cancel();
    }
}
