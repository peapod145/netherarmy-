package cn.blockforge.generated.netherarmy;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * 衰翼（witherphantom）：凋灵骷髅阵营的亡灵生物。
 *
 * <p>直接继承 {@link Phantom}，{@link #registerGoals()} 先调用 super——绕圈→俯冲→近战
 * 这套目标链就是幻翼自己的字节码（目标类绑定到本实例上），行为与幻翼完全一致；
 * 需要翻倍的数值全部按原版常量逐行对照修改。</p>
 *
 * <p><b>注意：本类绝不能放进 {@code net.minecraft.*} 包里。</b>生产环境下模组 jar 与原版
 * 各是一个 JVM 模块，同名包会被两个模块同时导出（automatic module 自动导出所有包），
 * 启动时直接 {@code java.lang.module.ResolutionException} 崩溃。对 Phantom 包私有字段的
 * 依赖（moveTargetPoint）改用"包装原版 MoveControl"的方式绕开，见
 * {@link DoubledFlightMoveControl}。</p>
 * <ul>
 *   <li>血量 25（曾为幻翼二倍的 40，后下调）、索敌 32、攻击伤害 6、移动速度 0.5——后三项为幻翼（16/3/0.25）的二倍；</li>
 *   <li>护甲值 6；</li>
 *   <li>俯冲命中附加凋零（凋灵骷髅同款 10s）与额外 5s 失明；</li>
 *   <li>远程：目标在 5 格之外、且在索敌范围（FOLLOW_RANGE，32 格）之内时，每 5s 发射一颗
 *       凋灵之首；这个 5s 计时由本实体自己的字段维护，与幻翼俯冲近战的相位/节奏互不干涉，
 *       两套冷却各自独立（见 {@link #ticksSinceLastSkull}）；</li>
 *   <li>掉落：幻翼膜 / 煤炭 / 地狱疣，见
 *       {@code data/netherarmy/loot_table/entities/witherphantom.json}；经验 10 点（幻翼 5 点的二倍）；</li>
 *   <li>免疫火焰（EntityType 构造器）、免疫凋零（阵营底层统一判定，见
 *       {@code WitherFactionWitherImmunityMixin}）、亡灵标签（数据包嵌套阵营名册）；</li>
 *   <li>与猪灵敌对：主动索敌 AbstractPiglin（凋灵骷髅同款），猪灵侧的敌意见
 *       {@link WitherFactionHostilityHandler}；</li>
 *   <li>主动攻击铁傀儡：凋灵骷髅同款目标选择器（幻翼的俯冲/绕圈链路对目标类型没有玩家限定，
 *       所以飞行行为仍与幻翼完全一致）；</li>
 *   <li>阵营判定：实体类型登记在 {@code minecraft:wither_skeletons} 与
 *       {@code minecraft:wither_friends} 标签里，与凋灵骷髅同阵营——友军门禁
 *       （{@link MesmerizerControl#isWitherSkeletonFaction}）、反逆者精神控制豁免、
 *       凋灵 Boss 不以其为目标，都按这个标签判定；</li>
 *   <li>上升卡死规避（下界顶棚适配）：朝上飞行超过 3s 而高度毫无变化时，判定被顶
 *       住/卡住，接下来的约 2s 放弃上升、改向水平方向或下方移动，见
 *       {@link #updateClimbStuckDetection()}；</li>
 *   <li>抛射物闪避：下界猎手（{@link NetherHunter}）同款的来袭抛射物检测与侧移选向，
 *       执行方式适配飞行实体（覆写水平速度，不依赖地面寻路），见
 *       {@link WitherphantomProjectileDodgeGoal}；</li>
 *   <li>自然生成：岩浆海上空（脚下岩浆、生成格与上方一格为空），判定链细节见
 *       {@link #checkWitherphantomSpawnRules}；</li>
 *   <li>碰撞箱 1.35×0.75（幻翼 0.9×0.5 的 1.5 倍），渲染缩放见客户端渲染器。</li>
 * </ul>
 */
public class Witherphantom extends Phantom {
    /** 凋灵之首发射间隔：5 秒（远程独立冷却，与俯冲近战无关）。 */
    private static final int SKULL_INTERVAL_TICKS = 100;
    /** 5 格之内交给俯冲近战，不射凋灵之首（平方距离）。 */
    private static final double SKULL_MIN_DISTANCE_SQR = 25.0;

    /** "上升但高度不变"的判定窗口：3 秒（60 tick）。 */
    private static final int CLIMB_STUCK_WINDOW_TICKS = 60;
    /** 窗口内高度变化达到该值即视为"上升有效"，窗口重新锚定。 */
    private static final double CLIMB_PROGRESS_THRESHOLD = 0.5D;
    /**
     * 判定"正在执行上升行为"的最小仰角。稳定绕圈时俯仰在 0° 附近徘徊，取一点余量避免
     * 把"平飞维持高度"误判成"上升"；而被顶棚挡住冲向高处目标点时俯仰远大于此值。
     */
    private static final float CLIMB_MIN_PITCH_DEGREES = 5.0F;
    /** 判定卡死后放弃上升、平飞/下降的持续时长（2 秒，期满恢复原版循环）。 */
    private static final int CLIMB_SUPPRESS_TICKS = 40;
    /** 卡死规避期间的水平逃逸速度（巡航 3.6 的一半，足以脱离顶棚下方）。 */
    private static final double ESCAPE_HORIZONTAL_SPEED = 1.8D;
    /** 闪避期间接管水平速度的大小（巡航 3.6 的约一半半，横向位移明显）。 */
    private static final double DODGE_LATERAL_SPEED = 2.0D;

    /**
     * 远程独立计时器（自上一次发射凋灵之首以来的 tick 数）。
     *
     * <p>它只是本类的一个普通字段，既不读写幻翼原版的 {@code attackPhase}，也不碰任何
     * Goal 的内部计时；同理近战那套（PhantomAttackStrategyGoal 的绕圈→俯冲循环）也不会
     * 因为射过凋灵之首而延后。两条冷却各自独立：近战命中不会推迟下一次远程，远程发射
     * 也不会打断俯冲。初值取满间隔，好让目标一进入射程就能立刻射出第一发。</p>
     */
    private int ticksSinceLastSkull = SKULL_INTERVAL_TICKS;

    /** 上升窗口的锚定高度；NaN 表示当前不在持续上升状态。 */
    private double climbWindowY = Double.NaN;
    /** 本窗口内已连续"朝上飞但高度不变"的 tick 数。 */
    private int climbStuckTicks;
    /** >0 表示处于放弃上升的规避期（仅服务端递减）。 */
    private int climbSuppressTicks;
    /** 闪避目标写入的横向单位方向（stop 时清零），由移动包装器接管水平速度。 */
    private double dodgeUnitX;
    private double dodgeUnitZ;

    public Witherphantom(EntityType<? extends Witherphantom> entityType, Level level) {
        super(entityType, level);
        // Phantom 构造器里创建的原装 PhantomMoveControl 已就位；用包装器接管它，
        // 同一套算法、每 tick 位移增量二倍（巡航 1.8 -> 3.6）。
        this.moveControl = new DoubledFlightMoveControl(this, this.moveControl);
        // 伤害/经验都是幻翼二倍，经验值同样取二倍（Phantom 构造器里写死 5 点）；
        // 血量单独下调为 25，见 createAttributes。
        this.xpReward = 10;
    }

    /** 索敌/伤害/速度为幻翼（Monster 默认）属性的二倍，血量 25，另加 6 点护甲；FOLLOW_RANGE 同时也是凋灵之首的射程。 */
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH, 25.0)
            .add(Attributes.FOLLOW_RANGE, 32.0)
            .add(Attributes.MOVEMENT_SPEED, 0.5)
            .add(Attributes.ATTACK_DAMAGE, 6.0)
            .add(Attributes.ARMOR, 6.0);
    }

    @Override
    protected void registerGoals() {
        // 完全保留幻翼的目标链：PhantomAttackStrategyGoal / PhantomSweepAttackGoal /
        // PhantomCircleAroundAnchorGoal / PhantomAttackPlayerTargetGoal（绑定到本实例）。
        super.registerGoals();
        // 下界猎手同款抛射物闪避：与 PhantomAttackStrategyGoal 同槽（该目标不占 MOVE 旗，
        // 互不冲突），但优先于占 MOVE 的俯冲/绕圈——有来袭抛射物时横向侧移接管移动。
        this.goalSelector.addGoal(1, new WitherphantomProjectileDodgeGoal(this));
        // 追加一个与幻翼索敌逻辑相同、但扫描范围二倍（16,64,16 -> 32,128,32，
        // 判定距离 64 -> 128）的目标选择器，优先级排在原版索敌之后，行为互不干扰。
        this.targetSelector.addGoal(2, new WitherphantomAttackPlayerTargetGoal());
        // 凋灵骷髅同款：主动攻击猪灵系（猪灵/猪灵蛮兵/僵尸猪灵）。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractPiglin.class, true));
        // 凋灵骷髅同款：主动攻击铁傀儡（原版 WitherSkeleton 就有这条；幻翼本身只索敌玩家，
        // 而俯冲/绕圈目标链对目标类型没有玩家限定，加这条目标即可完整复用幻翼 AI）。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!super.doHurtTarget(target)) {
            return false;
        }
        if (target instanceof LivingEntity livingEntity) {
            // 凋灵骷髅近战同款凋零 10s；衰翼额外附加 5s 失明。
            livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 200), this);
            livingEntity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100), this);
        }
        return true;
    }

    // 凋灵骷髅同款的"免疫凋零效果"不再写在本地：阵营成员的效果免疫已由
    // WitherFactionWitherImmunityMixin（LivingEntity#canBeAffected）按
    // #minecraft:wither_skeletons 名册统一判定。

    /**
     * 远程攻击不占用 AI 目标链：在服务端 AI step 里独立计时。目标距本实体 5 格之外、
     * 且不超出索敌范围（FOLLOW_RANGE，32 格——即"远程射程 = 索敌范围"）时，每 5 秒发射
     * 一颗凋灵之首（凋灵骷髅阵营性质：命中自带凋零）。
     */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.updateClimbStuckDetection();
        this.ticksSinceLastSkull++;
        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive() || this.ticksSinceLastSkull < SKULL_INTERVAL_TICKS) {
            return;
        }
        double distanceSqr = this.distanceToSqr(target);
        if (distanceSqr <= SKULL_MIN_DISTANCE_SQR) {
            // 5 格之内是俯冲近战的地盘；这里不发射，也不消耗远程冷却，
            // 目标一拉开距离就能立刻补上一发（远程冷却与近战互不影响）。
            return;
        }
        double followRange = this.getAttributeValue(Attributes.FOLLOW_RANGE);
        if (distanceSqr > followRange * followRange) {
            // 超出索敌范围：与远程射程一致，不打这一发，冷却继续累计。
            return;
        }
        this.fireWitherSkull(target);
        this.ticksSinceLastSkull = 0;
    }

    /**
     * 上升卡死检测（下界顶棚适配）。
     *
     * <p>原版 PhantomMoveControl 每 tick 把机头俯仰指向 {@code moveTargetPoint}：
     * 仰角超过 {@link #CLIMB_MIN_PITCH_DEGREES} 即视为"正在执行上升行为"（阈值避开稳定
     * 绕圈时 0° 附近浮动的平飞）。被顶棚/方块挡住时碰撞会
     * 吃掉向上速度，Y 恒定不变——此时若窗口（3s = 60 tick）内高度变化不足
     * {@link #CLIMB_PROGRESS_THRESHOLD}，判定卡死：进入 {@link #CLIMB_SUPPRESS_TICKS}
     * 的规避期，期间 {@link DoubledFlightMoveControl} 不再委托原版上升转向，而是执行
     * {@link #escapeFromStalledClimb()}（水平方向或向下方移动）。规避期内主动压低俯仰，
     * 检测窗口随之复位；期满恢复原版循环后若仍被挡住，会再次触发。</p>
     *
     * <p>判定只用公开的实体状态（俯仰角、坐标），不读写 Phantom 的任何包私有字段，
     * 绕圈/俯冲/受击的目标链本身保持幻翼原样。</p>
     */
    private void updateClimbStuckDetection() {
        if (this.climbSuppressTicks > 0) {
            this.climbSuppressTicks--;
        }
        boolean attemptingClimb = this.getXRot() > CLIMB_MIN_PITCH_DEGREES;
        if (!attemptingClimb) {
            this.climbWindowY = Double.NaN;
            this.climbStuckTicks = 0;
            return;
        }
        if (Double.isNaN(this.climbWindowY)) {
            this.climbWindowY = this.getY();
            this.climbStuckTicks = 0;
        } else if (Math.abs(this.getY() - this.climbWindowY) >= CLIMB_PROGRESS_THRESHOLD) {
            // 高度确实发生了变化：窗口重新锚定，重新计时。
            this.climbWindowY = this.getY();
            this.climbStuckTicks = 0;
        } else if (this.climbStuckTicks >= CLIMB_STUCK_WINDOW_TICKS && this.climbSuppressTicks <= 0) {
            // 持续朝上飞了 3 秒而高度纹丝不动：进入放弃上升的规避期。
            this.climbSuppressTicks = CLIMB_SUPPRESS_TICKS;
            this.climbWindowY = Double.NaN;
            this.climbStuckTicks = 0;
        } else {
            this.climbStuckTicks++;
        }
    }

    /** 规避期内的替代运动：保持/补齐水平速度（闪避方向优先），缓降或平飞。 */
    private void escapeFromStalledClimb() {
        Vec3 forward = this.getForward();
        double dirX = forward.x;
        double dirZ = forward.z;
        if (this.dodgeUnitX != 0.0D || this.dodgeUnitZ != 0.0D) {
            // 一边被卡一边有来袭抛射物：水平方向让位给闪避选向量。
            dirX = this.dodgeUnitX;
            dirZ = this.dodgeUnitZ;
        }
        Vec3 motion = this.getDeltaMovement();
        double y;
        boolean blockedBelow = !this.level().isEmptyBlock(this.blockPosition().below(1))
            || !this.level().isEmptyBlock(this.blockPosition().below(2));
        if (blockedBelow) {
            // 脚下（一格内或两格内）已经有岩浆面/方块：不再下探，转为纯水平移动。
            y = Math.min(motion.y, 0.0D) * 0.5D;
        } else {
            y = Mth.clamp(motion.y - 0.04D, -0.45D, 0.0D);
        }
        this.setDeltaMovement(dirX * ESCAPE_HORIZONTAL_SPEED, y, dirZ * ESCAPE_HORIZONTAL_SPEED);
        // 机头下压；规避期结束的下一 tick 原版 move control 会按目标点重新抬起。
        this.setXRot(Mth.approach(this.getXRot(), -12.0F, 3.0F));
    }

    /** 是否处于"放弃上升"的规避期（供移动包装器查询，仅服务端会置位）。 */
    private boolean isClimbSuppressed() {
        return this.climbSuppressTicks > 0;
    }

    private void fireWitherSkull(LivingEntity target) {
        Vec3 eyePos = this.getEyePosition();
        Vec3 direction = target.getEyePosition().subtract(eyePos);
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        WitherSkull skull = new WitherSkull(this.level(), this, direction);
        skull.setPos(eyePos.x + direction.x * 0.5D, eyePos.y + direction.y * 0.5D, eyePos.z + direction.z * 0.5D);
        skull.setDangerous(false);
        this.level().addFreshEntity(skull);
        this.playSound(SoundEvents.WITHER_SHOOT, 2.0F, 1.0F / (this.getRandom().nextFloat() * 0.4F + 0.8F));
    }

    /**
     * 刷新规则：与恶魂同款的和平判定与 1/20 频率闸门（配合二倍的刷怪权重即为恶魂的
     * 两倍刷新概率），并额外要求脚下是岩浆——只在岩浆海上刷新。
     *
     * <p><b>为什么不能用原版的地板校验：</b>1.21.1 里 {@code Mob.checkMobSpawnRules} 与
     * {@code SpawnPlacementTypes.ON_GROUND} 都要求 {@code pos.below()} 通过
     * {@code BlockState#isValidSpawn}——默认谓词是"顶面承重 且 发光亮度 &lt; 14"。
     * 岩浆光源恒为 15（且流体无实体支撑面），该判定对岩浆地板永远失败：先前
     * "ON_GROUND + 脚下岩浆"的组合下衰翼在任何位置都刷不出来。因此注册处改用
     * {@code NO_RESTRICTIONS}，这里自行完成等价校验：岩浆地板 + 生成格与上方一格
     * 均为可用空位（{@link NaturalSpawner#isValidEmptySpawnBlock}，防在岩浆层内部
     * 嵌入式出生）；主刷怪循环原有的 noCollision 终检保持不变。</p>
     */
    public static boolean checkWitherphantomSpawnRules(EntityType<Witherphantom> entityType,
                                                       ServerLevelAccessor level, MobSpawnType spawnType,
                                                       BlockPos pos, RandomSource random) {
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        boolean natural = spawnType == MobSpawnType.NATURAL || spawnType == MobSpawnType.CHUNK_GENERATION;
        if (!natural) {
            // 刷怪笼/刷怪蛋/增援等非自然路径与旧行为一样直接放行（恶魂式闸门只作用于自然刷新）。
            return true;
        }
        return random.nextInt(20) == 0
            && level.getBlockState(pos.below()).is(Blocks.LAVA)
            && isFreeSpawnCell(entityType, level, pos)
            && isFreeSpawnCell(entityType, level, pos.above());
    }

    /** 该格能否作为飞行实体身体所占的空位（无完整碰撞、无流体、无危险方块）。 */
    private static boolean isFreeSpawnCell(EntityType<Witherphantom> entityType, BlockGetter level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return NaturalSpawner.isValidEmptySpawnBlock(level, pos, state, state.getFluidState(), entityType);
    }

    /**
     * 幻翼飞行速度的二倍包装器。
     *
     * <p>{@code Phantom.PhantomMoveControl} 是包私有内部类且读写包私有字段
     * {@code moveTargetPoint}，模组侧无法（也不该靠越界包名）复制它的实现。
     * 这里改为持有 Phantom 构造器创建的原装实例并委托 tick()：原版控制器每 tick
     * 把位移朝巡航向量（speed 收敛到 1.8）逼近 20%，包装器把这段增量放大为 40%，
     * 即巡航速度 1.8→3.6、每 tick 加速度与转向回正全部二倍，算法结构逐行一致。
     * 原版 tick 未改变位移时（目标点水平距离过小）增量恒为 0，无副作用。</p>
     *
     * <p>两处覆写：上升卡死规避期内不委托原版转向，改走 {@link #escapeFromStalledClimb()}
     * （见 {@link #isClimbSuppressed()}）；闪避期内水平速度整体换成闪避侧移向量
     * （垂直分量不动，俯冲/凋灵之首节奏不受影响）。</p>
     */
    private static final class DoubledFlightMoveControl extends MoveControl {
        private final Witherphantom witherphantom;
        private final MoveControl delegate;

        DoubledFlightMoveControl(Witherphantom witherphantom, MoveControl delegate) {
            super(witherphantom);
            this.witherphantom = witherphantom;
            this.delegate = delegate;
        }

        @Override
        public void tick() {
            if (this.witherphantom.isClimbSuppressed()) {
                this.witherphantom.escapeFromStalledClimb();
                return;
            }
            Vec3 before = this.mob.getDeltaMovement();
            this.delegate.tick();
            Vec3 after = this.mob.getDeltaMovement();
            Vec3 doubled = before.add(after.subtract(before).scale(2.0));
            if (this.witherphantom.dodgeUnitX != 0.0D || this.witherphantom.dodgeUnitZ != 0.0D) {
                doubled = new Vec3(this.witherphantom.dodgeUnitX * DODGE_LATERAL_SPEED,
                    doubled.y(), this.witherphantom.dodgeUnitZ * DODGE_LATERAL_SPEED);
            }
            this.mob.setDeltaMovement(doubled);
        }
    }

    /**
     * 与幻翼索敌目标逐行一致，仅扫描框与判定距离二倍（16,64,16→32,128,32；64→128）。 */
    private final class WitherphantomAttackPlayerTargetGoal extends Goal {
        private final TargetingConditions attackTargeting = TargetingConditions.forCombat().range(128.0);
        private int nextScanTick = this.reducedTickDelay(20);

        @Override
        public boolean canUse() {
            if (this.nextScanTick > 0) {
                this.nextScanTick--;
                return false;
            } else {
                this.nextScanTick = this.reducedTickDelay(60);
                List<Player> list = Witherphantom.this.level()
                    .getNearbyPlayers(this.attackTargeting, Witherphantom.this,
                        Witherphantom.this.getBoundingBox().inflate(32.0, 128.0, 32.0));
                if (!list.isEmpty()) {
                    list.sort(Comparator.<Player, Double>comparing(Entity::getY).reversed());

                    for (Player player : list) {
                        if (Witherphantom.this.canAttack(player, TargetingConditions.DEFAULT)) {
                            Witherphantom.this.setTarget(player);
                            return true;
                        }
                    }
                }

                return false;
            }
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity livingEntity = Witherphantom.this.getTarget();
            return livingEntity != null ? Witherphantom.this.canAttack(livingEntity, TargetingConditions.DEFAULT) : false;
        }
    }

    /**
     * 下界猎手同款抛射物闪避（检测与选向算法逐参数对照 {@code NetherHunter.ProjectileDodgeGoal}）：
     * 16 格检测半径、预计 30 tick 内飞抵、最近会合距离 ≤2.5 格才构成威胁；多颗来袭时优先
     * 处理最先到达的一颗；规避方向取"远离抛射物 + 垂直于其水平航向"两侧中离弹道更远的一边，
     * 参考规避半径 4 格；每次窗口 8 tick，期间每 tick 重新评估威胁以跟住轨迹变化。
     * 落地插地的箭矢不算威胁：原版插地后 {@code getDeltaMovement()} 仍是非零的插地偏移
     * 常量，速度过滤拦不住，统一由 {@link ProjectileFlightTracker} 读原版 {@code inGround}
     * 权威标记当 tick 剔除——飞行的箭零延迟识别，不做任何跨观测核验。
     *
     * <p>执行方式适配飞行实体：猎手版用 {@code navigation.moveTo} 走地面寻路，衰翼不调
     * 导航（幻翼的移动完全由 moveTargetPoint + PhantomMoveControl 驱动），改为把横向单位
     * 方向写入实体字段，由 {@link DoubledFlightMoveControl} 在闪避窗口内接管水平速度；
     * 垂直分量保持原样，俯冲近战与凋灵之首的循环节奏不受闪避影响。目标（Goal）本身与
     * 猎手版一致占用 MOVE/LOOK 旗并声明每 tick 更新。</p>
     */
    private static final class WitherphantomProjectileDodgeGoal extends Goal {
        private static final double DETECTION_RADIUS = 16.0D;
        private static final double MAX_THREAT_TIME = 30.0D;
        private static final double THREAT_DISTANCE = 2.5D;
        private static final double DODGE_DISTANCE = 4.0D;
        private final Witherphantom phantom;
        private Projectile incomingProjectile;
        private int dodgeTime;
        private double dodgeX;
        private double dodgeZ;

        private WitherphantomProjectileDodgeGoal(Witherphantom phantom) {
            this.phantom = phantom;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            this.incomingProjectile = this.findIncomingProjectile();
            return this.incomingProjectile != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.dodgeTime > 0 && this.phantom.isAlive();
        }

        @Override
        public void start() {
            this.dodgeTime = 8;
            this.updateDodgeDirection();
        }

        @Override
        public void tick() {
            Projectile currentThreat = this.findIncomingProjectile();
            if (currentThreat != null) {
                // 每 tick 重新寻找威胁，避免目标快速移动或抛射物改变轨迹时反应滞后。
                this.incomingProjectile = currentThreat;
                this.dodgeTime = 8;
                this.updateDodgeDirection();
            } else {
                --this.dodgeTime;
            }
            if (this.dodgeTime > 0) {
                this.phantom.dodgeUnitX = this.dodgeX;
                this.phantom.dodgeUnitZ = this.dodgeZ;
            }
        }

        @Override
        public void stop() {
            this.incomingProjectile = null;
            this.dodgeTime = 0;
            this.phantom.dodgeUnitX = 0.0D;
            this.phantom.dodgeUnitZ = 0.0D;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        private void updateDodgeDirection() {
            if (this.incomingProjectile == null) {
                return;
            }
            Vec3 motion = this.incomingProjectile.getDeltaMovement();
            Vec3 away = new Vec3(
                    this.phantom.getX() - this.incomingProjectile.getX(),
                    0.0D,
                    this.phantom.getZ() - this.incomingProjectile.getZ());
            if (away.lengthSqr() < 1.0E-6D) {
                away = new Vec3(-motion.x, 0.0D, -motion.z);
            }
            away = away.normalize();

            Vec3 horizontalMotion = new Vec3(motion.x, 0.0D, motion.z);
            Vec3 lateral = horizontalMotion.lengthSqr() < 1.0E-6D
                    ? new Vec3(-away.z, 0.0D, away.x)
                    : new Vec3(-horizontalMotion.z, 0.0D, horizontalMotion.x).normalize();
            // 两个候选方向都带有明确的"远离抛射物"分量，再从左右两侧选择离轨迹更远的一侧。
            Vec3 first = away.scale(0.85D).add(lateral.scale(0.65D)).normalize();
            Vec3 second = away.scale(0.85D).add(lateral.scale(-0.65D)).normalize();
            this.dodgeX = first.x;
            this.dodgeZ = first.z;
            if (this.distanceToProjectilePath(second) > this.distanceToProjectilePath(first)) {
                this.dodgeX = second.x;
                this.dodgeZ = second.z;
            }
        }

        private double distanceToProjectilePath(Vec3 direction) {
            Vec3 motion = this.incomingProjectile.getDeltaMovement();
            Vec3 path = new Vec3(motion.x, 0.0D, motion.z);
            if (path.lengthSqr() < 1.0E-6D) {
                return 0.0D;
            }
            path = path.normalize();
            Vec3 endpoint = new Vec3(
                    this.phantom.getX() + direction.x * DODGE_DISTANCE,
                    0.0D,
                    this.phantom.getZ() + direction.z * DODGE_DISTANCE);
            Vec3 projectilePosition = new Vec3(
                    this.incomingProjectile.getX(), 0.0D, this.incomingProjectile.getZ());
            Vec3 offset = endpoint.subtract(projectilePosition);
            double along = Math.max(0.0D, offset.dot(path));
            Vec3 nearest = projectilePosition.add(path.scale(along));
            return endpoint.distanceToSqr(nearest);
        }

        private Projectile findIncomingProjectile() {
            List<Projectile> projectiles = this.phantom.level().getEntitiesOfClass(
                    Projectile.class, this.phantom.getBoundingBox().inflate(DETECTION_RADIUS), projectile -> {
                        if (!projectile.isAlive()) {
                            return false;
                        }
                        Entity owner = projectile.getOwner();
                        if (owner == this.phantom
                                || owner != null && owner.getUUID().equals(this.phantom.getUUID())) {
                            return false;
                        }
                        Vec3 motion = projectile.getDeltaMovement();
                        // 静止抛射物不是飞来的威胁，不触发躲避。
                        if (motion.lengthSqr() <= 1.0E-6D) {
                            return false;
                        }
                        Vec3 toHunter = new Vec3(
                                this.phantom.getX() - projectile.getX(),
                                this.phantom.getEyeY() - projectile.getY(),
                                this.phantom.getZ() - projectile.getZ());
                        double speedSqr = motion.lengthSqr();
                        double timeToClosest = toHunter.dot(motion) / speedSqr;
                        if (timeToClosest < 0.0D || timeToClosest > MAX_THREAT_TIME) {
                            return false;
                        }
                        Vec3 closestPoint = projectile.position().add(motion.scale(timeToClosest));
                        if (closestPoint.distanceTo(this.phantom.position()) > THREAT_DISTANCE) {
                            return false;
                        }
                        // 与下界猎手同款落地判定：插地箭的 getDeltaMovement() 是非零的
                        // 插地偏移常量，用原版 inGround 标记当 tick 剔除，飞行的箭零延迟识别。
                        return ProjectileFlightTracker.isActuallyFlying(projectile);
                    });
            Projectile closestThreat = null;
            double bestTime = Double.MAX_VALUE;
            for (Projectile projectile : projectiles) {
                Vec3 motion = projectile.getDeltaMovement();
                Vec3 toHunter = this.phantom.position().subtract(projectile.position());
                double timeToClosest = toHunter.dot(motion) / motion.lengthSqr();
                if (timeToClosest < bestTime) {
                    bestTime = timeToClosest;
                    closestThreat = projectile;
                }
            }
            return closestThreat;
        }
    }
}
