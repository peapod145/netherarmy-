package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 霸主凋灵之首弹头模型。由 tools/gen_overlord_models.py 从
 * overlord_wither_skull.bbmodel 生成；贴图是声明分辨率的 2 倍，UV ×2。
 * 几何与原版凋灵之首头颅同构（方块占 y -8..0，渲染端 scale(-1,-1,1) 翻正）。
 */
public final class OverlordWitherSkullModel extends EntityModel<OverlordWitherSkull> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "overlord_wither_skull"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 64;

    private final ModelPart root;

    private static final float[] HEAD = {
        -4.0F, -8.0F, -4.0F, 4.0F, -8.0F, -4.0F, 4.0F, 0.0F, -4.0F, -4.0F,
        0.0F, -4.0F, 16.0F, 16.0F, 32.0F, 32.0F, 0.0F, 0.0F, -1.0F, 4.0F,
        -8.0F, 4.0F, -4.0F, -8.0F, 4.0F, -4.0F, 0.0F, 4.0F, 4.0F, 0.0F,
        4.0F, 48.0F, 16.0F, 64.0F, 32.0F, 0.0F, 0.0F, 1.0F, -4.0F, -8.0F,
        4.0F, -4.0F, -8.0F, -4.0F, -4.0F, 0.0F, -4.0F, -4.0F, 0.0F, 4.0F,
        0.0F, 16.0F, 16.0F, 32.0F, -1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F,
        4.0F, -8.0F, 4.0F, 4.0F, 0.0F, 4.0F, 4.0F, 0.0F, -4.0F, 32.0F,
        16.0F, 48.0F, 32.0F, 1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F, -4.0F,
        -8.0F, -4.0F, -4.0F, -8.0F, 4.0F, 4.0F, -8.0F, 4.0F, 32.0F, 16.0F,
        16.0F, 0.0F, 0.0F, -1.0F, 0.0F, 4.0F, 0.0F, 4.0F, -4.0F, 0.0F,
        4.0F, -4.0F, 0.0F, -4.0F, 4.0F, 0.0F, -4.0F, 48.0F, 0.0F, 32.0F,
        16.0F, 0.0F, 1.0F, 0.0F
    };

    public OverlordWitherSkullModel(ModelPart root) {
        this.root = root;
    }

    /** 与原版 SkullModel#setupAnim 同口径：yRot=yaw，xRot=pitch（角度制入参）。 */
    public void rotateTo(float yawDegrees, float pitchDegrees) {
        this.root.yRot = yawDegrees * (float) (Math.PI / 180.0);
        this.root.xRot = pitchDegrees * (float) (Math.PI / 180.0);
    }

    @Override
    public void setupAnim(OverlordWitherSkull entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        HackerQuads.emit(poseStack, buffer, this.root, HEAD, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
