package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Drowned;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 溺尸的"受击必还手"：原版 {@code Drowned#okTarget} 是白天闸门——
 * {@code !level.isDay() || target.isInWater()}，白天的溺尸只肯打泡在水里的对象。
 * 它同时被用在两处：索敌（{@code NearestAttackableTargetGoal(Player.class, ..., this::okTarget)}）
 * 与出手的近战目标（{@code Drowned#DrownedAttackGoal#canUse/canContinueToUse}）。
 *
 * <p>后果就是溺尸跟别的僵尸系不一样：僵尸/尸壳/僵尸村民挨了打会立刻还手
 * （{@code HurtByTargetGoal} 给的仇恨不受任何时间闸门约束），溺尸在白天被尸鬼（或玩家）
 * 打了，仇恨虽然照样挂上，但近战目标选择器一句 {@code okTarget} 就把它按回去——
 * 于是"挨打不反击"。而尸鬼本身不下水（它游岩浆），溺尸被追到岸上或站在船边时，
 * 这条闸门必然命中，看起来就像完全没了反击 AI。</p>
 *
 * <p>这里只在"正在记恨"的这一种情况下把闸门抬掉：候选对象既是打自己的那个
 * （{@code getLastHurtByMob()}）又是当前仇恨目标（{@code getTarget()}）。这两个条件都由
 * 原版 {@code HurtByTargetGoal} 维护，它自带 300 刻的失忆回收，所以抬闸的窗口与别的僵尸系
 * 反击的窗口天然等长，不会让溺尸白天变成主动索敌的疯子；三叉戟远程那条目标链本来就没有
 * 这个闸门（{@code DrownedTridentAttackGoal} 只多查一手是否拿着三叉戟），不受影响。</p>
 */
@Mixin(Drowned.class)
public abstract class DrownedRevengeTargetMixin {

    @Inject(method = "okTarget", at = @At("HEAD"), cancellable = true)
    private void netherarmy$alwaysRetaliateAgainstAttacker(LivingEntity candidate,
                                                            CallbackInfoReturnable<Boolean> callback) {
        Drowned self = (Drowned) (Object) this;
        if (candidate != null && candidate == self.getLastHurtByMob() && candidate == self.getTarget()) {
            callback.setReturnValue(true);
        }
    }
}
