package cn.blockforge.generated.netherarmy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 怪物投出的三叉戟：去掉忠诚附魔，并让它在 {@value #LIFETIME_TICKS} 刻（10 秒）后消失。
 *
 * <p>问题出在原版 1.21.1 的 {@code ThrownTrident#tick}：忠诚附魔在构造时被折算成
 * {@code ID_LOYALTY}（{@code EnchantmentHelper#getTridentReturnToOwnerAcceleration} 读投掷
 * 时那件物品栈），只要它 {@code > 0} 且已经命中过实体或进入 {@code noPhysics}，三叉戟就
 * 每刻把自己朝主人的眼睛位置拽过去（{@code setPosRaw} + 朝主人的加速度）。而"收进手里"
 * 只有 {@code playerTouch} 一条路——主人是凋灵仆役／灵魂土偶这种怪物时永远走不到，
 * 于是三叉戟贴在主人身上左右抽搐，永远不会落地、也永远不会消失。</p>
 *
 * <p><b>修法两层：</b></p>
 * <ol>
 *   <li>投掷时去掉副本上的忠诚附魔（投掷者手里那件原封不动）。{@code ID_LOYALTY} 因此是 0，
 *       投出去就是一条普通弹道：命中后插地上，也不再往主人身上贴；</li>
 *   <li>给这枚三叉戟打上标记，逐刻数到 {@value #LIFETIME_TICKS} 刻就 {@code discard()}，
 *       不管它插在地上、卡在空中还是仍在飞——需求要的就是"10 秒后消失"。</li>
 * </ol>
 *
 * <p>另外把 {@code pickup} 设成 {@code DISALLOWED}：投出去的本就是一份副本，投掷者手上那件
 * 还在，若还能被玩家捡走就等于凭空多出一件（原版带忠诚的三叉戟也捡不到）。</p>
 *
 * <p>年龄存在 NeoForge 的持久化数据里，随实体一起存档，区块重载后继续往下数。</p>
 */
public final class MobThrownTridentHandler {
    /** 投出的三叉戟存在时长：200 刻 = 10 秒。 */
    public static final int LIFETIME_TICKS = 200;
    /** 标记：这枚三叉戟是本模组怪物投的，到期要消失。 */
    private static final String TRACKED_TAG = "NetherArmyMobTrident";
    /** 已存在刻数。 */
    private static final String AGE_TAG = "NetherArmyMobTridentAge";

    private MobThrownTridentHandler() {
    }

    /**
     * 造一枚"怪物投掷专用"的三叉戟：忠诚已被剥掉、不可拾取、带到期标记。
     *
     * @param held 投掷者手上那件三叉戟（这里只取副本，原物品栈不会被改动）
     */
    public static ThrownTrident create(Level level, LivingEntity thrower, ItemStack held) {
        ThrownTrident trident = new ThrownTrident(level, thrower, withoutLoyalty(held));
        trident.pickup = AbstractArrow.Pickup.DISALLOWED;
        CompoundTag data = trident.getPersistentData();
        data.putBoolean(TRACKED_TAG, true);
        data.putInt(AGE_TAG, 0);
        return trident;
    }

    /** 副本上摘掉忠诚：其余附魔（穿刺、力量之类）原样保留。 */
    private static ItemStack withoutLoyalty(ItemStack held) {
        ItemStack stack = held.copy();
        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(stack.getEnchantments());
        mutable.removeIf(holder -> holder.is(Enchantments.LOYALTY));
        EnchantmentHelper.setEnchantments(stack, mutable.toImmutable());
        return stack;
    }

    /** 逐刻数年龄，到点让三叉戟消失。 */
    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        if (!(event.getEntity() instanceof ThrownTrident trident) || trident.level().isClientSide()) {
            return;
        }
        CompoundTag data = trident.getPersistentData();
        if (!data.getBoolean(TRACKED_TAG)) {
            return;
        }
        int age = data.getInt(AGE_TAG) + 1;
        if (age >= LIFETIME_TICKS) {
            trident.discard();
            return;
        }
        data.putInt(AGE_TAG, age);
    }
}
