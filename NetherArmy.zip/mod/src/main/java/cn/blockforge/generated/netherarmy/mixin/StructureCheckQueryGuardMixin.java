package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.StructureLocateGuard;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureCheck;
import net.minecraft.world.level.levelgen.structure.StructureCheckResult;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 给 {@code /locate} 的候选预判计时，并在预算用完后直接判"不存在"。
 *
 * <p>{@code StructureCheck#checkStart} 只被 {@code ChunkGenerator#getStructureGeneratingAt}
 * 调用，而后者只服务于 {@code findNearestMapStructure}（{@code /locate structure}、
 * 探险家地图等）——区块生成阶段从不经过这里。所以在这一个方法上计时，
 * 就能精确区分"查询路径"与"真正生成结构"：预算只作用在查询上，世界里照旧按原规则
 * 生成结构，一个都不会少。</p>
 *
 * <p>三件事：</p>
 * <ol>
 *   <li>HEAD：属于本模组"容易扫满 4 万候选"的那几个结构（{@link StructureLocateGuard#budgeted}）
 *       且本批查询预算已用完时，直接返回 {@code START_NOT_PRESENT}——不解析区域文件、
 *       也不触发同步区块生成；</li>
 *   <li>HEAD：否则记一次查询开始（见 {@link StructureLocateGuard#enterQuery}）；</li>
 *   <li>RETURN：记时并把耗时记进预算。</li>
 * </ol>
 *
 * <p>除预算用完那一种情况外，方法本身的行为、返回值、异常路径都不改变。</p>
 */
@Mixin(StructureCheck.class)
public abstract class StructureCheckQueryGuardMixin {

    @Inject(method = "checkStart", at = @At("HEAD"), cancellable = true)
    private void netherarmy$capLocateScan(ChunkPos pos,
                                          Structure structure,
                                          StructurePlacement placement,
                                          boolean skipGenerated,
                                          CallbackInfoReturnable<StructureCheckResult> callback) {
        if (StructureLocateGuard.budgeted(structure) && StructureLocateGuard.budgetExhausted()) {
            callback.setReturnValue(StructureCheckResult.START_NOT_PRESENT);
            return;
        }
        StructureLocateGuard.enterQuery(structure);
    }

    @Inject(method = "checkStart", at = @At("RETURN"))
    private void netherarmy$recordLocateScan(ChunkPos pos,
                                             Structure structure,
                                             StructurePlacement placement,
                                             boolean skipGenerated,
                                             CallbackInfoReturnable<StructureCheckResult> callback) {
        StructureLocateGuard.exitQuery(structure);
    }
}
