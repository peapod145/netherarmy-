package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * 炼狱晶胸甲装备模型：几何逐块取自用户上传的 nether_crystal_chestplate-2.geo.bbmodel（bedrock geo bbmodel）。
 * 每块按未膨胀尺寸 + texOffs 注册（UV 即 bbmodel faces 的标准 box unwrap），
 * CubeDeformation 只做几何外扩、不动 UV，与该文件的 inflate 字段
 * （chestplate inflate=1.01、arm_plate_right inflate=1、arm_plate_left inflate=1）语义逐项一致；左侧板的镜像对应 bbmodel 左臂/左腿的翻转 UV。
 */
public final class NetherCrystalChestplateArmorModel extends HumanoidModel<LivingEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_crystal_chestplate_armor"), "main");

    public NetherCrystalChestplateArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(1.9F, 12.0F, 0.0F));
        root.getChild("body").addOrReplaceChild("chestplate", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(1.01F)), PartPose.ZERO);
        root.getChild("right_arm").addOrReplaceChild("arm_plate_right", CubeListBuilder.create().texOffs(40, 16).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(1.0F)), PartPose.ZERO);
        root.getChild("left_arm").addOrReplaceChild("arm_plate_left", CubeListBuilder.create().texOffs(40, 16).mirror().addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(1.0F)), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }
}
