package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 下界运兵车模型：几何与 UV 逐立方体复刻用户上传的 {@code Nethercarrier.bbmodel}
 * （800×800 贴图、99 个立方体、61 个骨骼），由 tools/carrier/gen_model.py 生成。
 *
 * <h3>坐标换算</h3>
 * <p>{@code X = -x + 50.5F}、{@code Y = 24 - y}、{@code Z = z}。x/y 同时取反就是绕 z 轴
 * 180° 的真旋转，既把编辑器里向上的 y 轴换成 Java 向下的 y 轴，又正好补偿原版
 * {@code ModelPart.Cube} 与 Blockbench 自动展开之间 east/west、up/down 的槽位互换
 * （north/south 两侧本就一致），所以每个盒子只需原样搬 {@code texOffs(u,v)}，不必镜像
 * 即可逐面还原作者贴图。判据是车头那块写着 “HELL ARM” 的铭牌：它画在 bbmodel 的
 * east(+x) 面，映射后落在 Java 的 -x 面（= 车头面）；若改用恒等映射，铭牌会跑到车尾
 * 并且左右翻转。</p>
 * <p>骨骼旋转按共轭换算 {@code (rx,ry,rz) → (-rx,-ry,+rz)}；Blockbench 的 Java 导出器与
 * {@code ModelPart#translateAndRotate} 用同一个 {@code rotationZYX} 复合顺序，三轴旋转的
 * 骑兵腿部（39.03°/9.58°/-11.6°）因此同样是精确还原。带自身旋转的立方体（车头顶板、
 * 铭牌、8 块撞角板、骑兵手臂与腿）各自单独成部件，枢轴取该盒的 rotationOrigin——
 * {@code CubeListBuilder} 不支持逐盒旋转。</p>
 * <p>车头经上面映射后朝 Java -x，根部件 {@code frame} 再叠加 {@code yRot = -90°} 把它转到
 * Java -z（实体正前方）。{@code frame} 的枢轴取 {@code (0,0,-32)}（模型单位，= 2 格）：
 * 整车沿车头方向相对实体锚点<b>前移 2 格</b>——判定箱跟着锚点走，于是正方形判定箱
 * 罩住的是车体后 3/4（后舱、后轮组、车尾只剩约 1.1 格探出），探出的那截让给
 * 车头撞击盒（{@link NetherCarrier#NOSE_REACH}）。取舍缘由见下面的"尺寸与判定箱"。</p>
 *
 * <h3>尺寸与判定箱</h3>
 * <p>含车轮与撞角长 159.0 px（9.94 格）、宽 60.0 px（3.75 格）、高 71.0 px（4.44 格）。Java 实体
 * 判定箱只能是正方形，这里取 3.7×4.4（车宽×车高），并把模型整体前移 2 格：判定箱
 * 中心落在车中点偏后 2 格处，车尾仅 1.12 格探出（原为 3.12 格——"后半部分大片没有
 * 碰撞"的来源），车头探出 5.12 格、由 {@link NetherCarrier} 的鼻尖盒负责撞击与破方块。
 * 宽度维持 3.7 不动：判定箱宽超过 4.1 就挤不进下界要塞 4 格宽的走廊，游走寻路会
 * 大面积失败，不值得为 0.25 格的侧向贴边冒这个险。</p>
 *
 * <h3>只有移动时才播放动画</h3>
 * <p>用户的 {@code animation.netherarmy.carrier.wheel_roll}（2s 一轮、循环）里只有 9 个车轮
 * 绕局部 z 轴 0→-360°，以及两根活塞杆 {@code stick}/{@code stick2} 的平移关键帧。本类不读
 * 时间而读 {@link NetherCarrier#getRollProgress()}：按实际走过的地面距离对车轮周长取模，
 * 于是静止时相位不推进（动画自然停），车速越快轮子转得越快，也不会出现“轮子不转车在飘”。
 * 车轮取 -360°：局部 -x 是车头，接触点向 +x 滑 = 向前滚，与矿车/车辆的滚动方向一致。</p>
 *
 * <h3>活塞杆运动坐标（“静止正常、一运动就错位”的根因）</h3>
 * <p>作者的动画轨里 {@code stick} 的 t=0 关键帧在 bb 编辑器是 {@code [-16,0,0]}（Bedrock
 * 导出 {@code [16,0,0]}——Bedrock 导出器相对编辑器已经翻过一次 x）而不是 {@code [0,0,0]}：
 * 静止车辆的相位恒为 0，若照抄轨道，一根连杆会永远偏离模型位一整格、另一根却在模型位上，
 * 两根杆互相对不齐——这正是“实际游戏中某些部件有错位”的来源（静态预览不经过
 * {@code setupAnim}，照不出来）。三点校正：</p>
 * <ul>
 *   <li>{@code stick} 轨改为与 {@code stick2} 相差半周期的循环曲线（保留作者的 ±16 行程与
 *       ±6/8 摆幅，t=0 仍落在作者的行程端点 Java {@code [16,0,0]}）：两杆交替泵动，且
 *       首尾闭合，不再在相位回绕时跳 16px。</li>
 *   <li>活塞位移乘一个 {@code pump} 闸门（在实体侧累计，见
 *       {@link NetherCarrier#getPumpBlend()}）：移动时 0.1/tick 升满，静止时 0.08/tick
 *       回落，约半秒内两根连杆平滑收回绑定姿态（bind pose）——静止观感与模型文件严格
 *       一致，停车后也不会把连杆冻在行程中间。</li>
 *   <li>关键帧位移的轴向换算必须与静态枢轴同一映射。上一版把 Bedrock 导出原值连同 x/y
 *       一起取反，而 Bedrock 的 position.x 相对编辑器本就翻过一次，再翻等于没翻：y 分量
 *       恰好只翻一次是对的，x 分量却停在编辑器符号上，整条轨的滑移方向与作者设计相反。
 *       静止时闸门为 0、位移全部清零，所以静止观感正常；一动起来连杆就与车轮滚动反相，
 *       行程端点相差 2×16px（2 格）——即“静止位置正常、一旦运动就错位”。正确做法是
 *       对 Bedrock 原值只翻 y、x 照抄（等价于对 bb 编辑器原值翻 x/y），下表已按 Java
 *       模型空间列出。</li>
 * </ul>
 */
public final class NetherCarrierModel extends EntityModel<NetherCarrier> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_carrier"), "main");
    /** 一轮完整滚动对应的地面行程（格）= 后轮直径 25px 的周长。 */
    public static final double ROLL_CYCLE_BLOCKS = 4.908739D;

    /**
     * 活塞杆平移关键帧（Java 模型空间，单位 = 1/16 格）：bb 编辑器原值翻 x/y；
     * 等价的 Bedrock 导出原值只需翻 y、x 照抄（导出器已相对编辑器翻过一次 x）。
     *
     * <p>{@code stick2} 保留作者原始轨（0→6/8→16→6/-6→0，首尾闭合）。
     * {@code stick} 的原始轨起点在行程端点 16、终点回到 0 且 t=1 没有关键帧，
     * 循环回绕时会跳 16px；这里改成与 {@code stick2} 相差半周期（+1.0s）的等价闭合轨，
     * 既让两杆交替泵动（作者本意：一杆推到最外时另一杆在中间），又首尾相接不跳。</p>
     */
    private static final float[] STICK_TIME = {0.0F, 0.5F, 1.0F, 1.5F, 2.0F};
    private static final double[][] STICK_POS = {{16.0, 0.0, 0.0}, {6.0, -6.0, 0.0},
            {0.0, 1.0, 0.0}, {6.0, 8.0, 0.0}, {16.0, 0.0, 0.0}};
    private static final float[] STICK2_TIME = {0.0F, 0.5F, 1.0F, 1.5F, 2.0F};
    private static final double[][] STICK2_POS = {{0.0, 0.0, 0.0}, {6.0, 8.0, 0.0},
            {16.0, 0.0, 0.0}, {6.0, -6.0, 0.0}, {0.0, 1.0, 0.0}};

    private final ModelPart frame;
    private final ModelPart wheel_front;
    private final ModelPart wheel_back;
    private final ModelPart stick;
    private final ModelPart wheel_back4;
    private final ModelPart wheel_back2;
    private final ModelPart wheel_back3;
    private final ModelPart wheel_back5;
    private final ModelPart wheel_back6;
    private final ModelPart wheel_back7;
    private final ModelPart wheel_back8;
    private final ModelPart stick2;

    public NetherCarrierModel(ModelPart root) {
        this.frame = root.getChild("frame");
        this.wheel_front = this.frame.getChild("wheel_front");
        this.wheel_back = this.frame.getChild("wheel_back");
        this.stick = this.frame.getChild("stick");
        this.wheel_back4 = this.frame.getChild("wheel_back4");
        this.wheel_back2 = this.frame.getChild("wheel_back2");
        this.wheel_back3 = this.frame.getChild("wheel_back3");
        this.wheel_back5 = this.frame.getChild("wheel_back5");
        this.wheel_back6 = this.frame.getChild("wheel_back6");
        this.wheel_back7 = this.frame.getChild("wheel_back7");
        this.wheel_back8 = this.frame.getChild("wheel_back8");
        this.stick2 = this.frame.getChild("stick2");
    }

    @Override
    public void setupAnim(NetherCarrier entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.frame.getAllParts().forEach(ModelPart::resetPose);
        // 相位只在移动时推进（实体侧累计），静止时所有部件都停在初始姿态 = 不播放动画。
        float roll = (float) (entity.getRollProgress() % 1.0D);
        if (roll < 0.0F) {
            roll += 1.0F;
        }
        // 活塞闸门由实体侧累计（见 NetherCarrier#getPumpBlend）：静止时约半秒内平滑回落，
        // 于是停车时两根连杆都严丝合缝地对齐模型文件，不会冻在行程中间或偏出一整格。
        float pump = entity.getPumpBlend();
        float wheel = roll * Mth.TWO_PI;
        this.wheel_front.zRot = -wheel;
        this.wheel_back.zRot = -wheel;
        this.wheel_back4.zRot = -wheel;
        this.wheel_back2.zRot = -wheel;
        this.wheel_back3.zRot = -wheel;
        this.wheel_back5.zRot = -wheel;
        this.wheel_back6.zRot = -wheel;
        this.wheel_back7.zRot = -wheel;
        this.wheel_back8.zRot = -wheel;
        double cycle = roll * 2.0D;   // 动画原长 2s，一轮滚动走完整条关键帧
        applyKeys(this.stick, STICK_TIME, STICK_POS, cycle, pump);
        applyKeys(this.stick2, STICK2_TIME, STICK2_POS, cycle, pump);
    }

    /**
     * 关键帧线性插值，位移叠加在部件初始枢轴上（与 Bedrock position 的语义一致）。
     * {@code amplitude} 为 {@link #pump} 闸门：0 时位移归零（收回绑定姿态），1 时走完整条轨。
     */
    private static void applyKeys(ModelPart part, float[] times, double[][] pos, double t, float amplitude) {
        PartPose base = part.getInitialPose();
        int i = 0;
        while (i + 2 < times.length && t > times[i + 1]) {
            i++;
        }
        double span = times[i + 1] - times[i];
        double k = span <= 0.0D ? 0.0D : (t - times[i]) / span;
        k = Mth.clamp(k, 0.0D, 1.0D);
        part.setPos((float) (base.x + lerp(pos[i][0], pos[i + 1][0], k) * amplitude),
                (float) (base.y + lerp(pos[i][1], pos[i + 1][1], k) * amplitude),
                (float) (base.z + lerp(pos[i][2], pos[i + 1][2], k) * amplitude));
    }

    private static double lerp(double a, double b, double k) {
        return a + (b - a) * k;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int colour) {
        this.frame.render(poseStack, buffer, packedLight, packedOverlay, colour);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // frame：整车骨架。yRot=-90° 把映射后朝 -x 的车头转到实体正前方 -z；
        // 枢轴 z=-32（模型单位）= 整车沿车头方向前移 2 格，让 3.7×4.4 的正方形判定箱
        // 罩住车体后 3/4（车尾仅探出 1.12 格），前移的分量由鼻尖撞击盒接管。
        PartDefinition frame = root.addOrReplaceChild("frame", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0.0F, 0.0F, -32.0F, 0.0F, -1.5708F, 0.0F));
        // bone "Vehiclebody" origin=[-24, 19, -23] rotation=[0, 0, 0] → 盒 25 个（其中带自身旋转 6 个）
        PartDefinition body = frame.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(119, 98).addBox(-108F, -54F, -1F, 109F, 54F, 47F, new CubeDeformation(-2F))
                .texOffs(118, 240).addBox(-107F, -3F, -1F, 107F, 14F, 47F)
                .texOffs(324, 333).addBox(-122F, -6F, -1F, 16F, 17F, 47F, new CubeDeformation(-1F))
                .texOffs(324, 335).addBox(-137F, -5F, 0F, 18F, 17F, 45F, new CubeDeformation(-2F))
                .texOffs(324, 333).addBox(-120F, -11F, -1F, 16F, 17F, 47F, new CubeDeformation(-1F))
                .texOffs(332, 341).addBox(-134F, -12F, 3F, 16F, 17F, 39F, new CubeDeformation(-2F))
                .texOffs(133, 310).addBox(-132F, -35F, -4F, 30F, 30F, 30F, new CubeDeformation(-4F))
                .texOffs(94, 30).addBox(-154F, -30F, 38F, 28F, 17F, 0F)
                .texOffs(94, 30).addBox(-154F, -30F, 30F, 28F, 17F, 0F)
                .texOffs(94, 30).addBox(-154F, -30F, 8F, 28F, 17F, 0F)
                .texOffs(94, 30).addBox(-154F, -30F, 16F, 28F, 17F, 0F)
                .texOffs(371, 372).addBox(-122F, -8F, -4F, 8F, 8F, 8F)
                .texOffs(357, 366).addBox(-122F, -1F, -7F, 16F, 8F, 14F, new CubeDeformation(-2F))
                .texOffs(371, 372).addBox(-114F, -8F, -4F, 8F, 8F, 8F)
                .texOffs(363, 367).addBox(-120F, -8F, -7F, 11F, 8F, 13F)
                .texOffs(363, 367).addBox(-120F, -8F, 38F, 11F, 8F, 13F)
                .texOffs(371, 372).addBox(-122F, -8F, 41F, 8F, 8F, 8F)
                .texOffs(371, 372).addBox(-114F, -8F, 41F, 8F, 8F, 8F)
                .texOffs(357, 366).addBox(-122F, -1F, 38F, 16F, 8F, 14F, new CubeDeformation(-2F)),
                PartPose.offsetAndRotation(74.5F, 5F, -23F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[0, 90, 0] origin=[93, 39, 10]
        PartDefinition body_c0 = body.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(133, 378).addBox(-15F, -15F, -15F, 30F, 30F, 30F, new CubeDeformation(-4F)),
                PartPose.offsetAndRotation(-117F, -20F, 33F, 0F, -1.5708F, 0F));
        // 带自身旋转的盒 rot=[-90, 0, 0] origin=[103, 46, 19]
        PartDefinition body_c1 = body.addOrReplaceChild("c1", CubeListBuilder.create()
                .texOffs(94, 30).addBox(-27F, -17F, -1F, 28F, 17F, 0F),
                PartPose.offsetAndRotation(-127F, -27F, 42F, 1.5708F, 0F, 0F));
        // 带自身旋转的盒 rot=[-90, 0, 0] origin=[103, 38, 19]
        PartDefinition body_c2 = body.addOrReplaceChild("c2", CubeListBuilder.create()
                .texOffs(94, 30).addBox(-27F, -17F, -1F, 28F, 17F, 0F),
                PartPose.offsetAndRotation(-127F, -19F, 42F, 1.5708F, 0F, 0F));
        // 带自身旋转的盒 rot=[-90, 0, 0] origin=[103, 38, -3]
        PartDefinition body_c3 = body.addOrReplaceChild("c3", CubeListBuilder.create()
                .texOffs(94, 30).addBox(-27F, -17F, -1F, 28F, 17F, 0F),
                PartPose.offsetAndRotation(-127F, -19F, 20F, 1.5708F, 0F, 0F));
        // 带自身旋转的盒 rot=[-90, 0, 0] origin=[103, 46, -3]
        PartDefinition body_c4 = body.addOrReplaceChild("c4", CubeListBuilder.create()
                .texOffs(94, 30).addBox(-27F, -17F, -1F, 28F, 17F, 0F),
                PartPose.offsetAndRotation(-127F, -27F, 20F, 1.5708F, 0F, 0F));
        // 带自身旋转的盒 rot=[0, 0, 15] origin=[110, 23, -1]
        PartDefinition body_c5 = body.addOrReplaceChild("c5", CubeListBuilder.create()
                .texOffs(534, 9).addBox(-1F, -13F, -20F, 2F, 26F, 40F, new CubeDeformation(-1F)),
                PartPose.offsetAndRotation(-134F, -4F, 22F, 0F, 0F, 0.2618F));
        // bone "wheel front" origin=[103.5, 9.5, -1.5] rotation=[0, 0, 0] → 盒 6 个（其中带自身旋转 0 个）
        PartDefinition wheel_front = frame.addOrReplaceChild("wheel_front", CubeListBuilder.create()
                .texOffs(482, 190).addBox(-9.5F, -9.5F, -20.5F, 19F, 19F, 0F)
                .texOffs(482, 190).addBox(-9.5F, -9.5F, -21.5F, 19F, 19F, 0F)
                .texOffs(482, 190).addBox(-9.5F, -9.5F, -22.5F, 19F, 19F, 0F)
                .texOffs(482, 190).addBox(-9.5F, -9.5F, 22.5F, 19F, 19F, 0F)
                .texOffs(482, 190).addBox(-9.5F, -9.5F, 21.5F, 19F, 19F, 0F)
                .texOffs(482, 190).addBox(-9.5F, -9.5F, 20.5F, 19F, 19F, 0F),
                PartPose.offsetAndRotation(-53F, 14.5F, -1.5F, 0F, 0F, 0F));
        // bone "wheel back" origin=[73.5, 12.5, 26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back = frame.addOrReplaceChild("wheel_back", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(-23F, 11.5F, 26F, 0F, 0F, 0F));
        // bone "stick" origin=[36, 13.5, 29] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition stick = frame.addOrReplaceChild("stick", CubeListBuilder.create()
                .texOffs(490, 155).addBox(-45F, -1.5F, -1F, 90F, 3F, 2F),
                PartPose.offsetAndRotation(14.5F, 10.5F, 29F, 0F, 0F, 0F));
        // bone "wheel_back4" origin=[42.5, 12.5, 26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back4 = frame.addOrReplaceChild("wheel_back4", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(8F, 11.5F, 26F, 0F, 0F, 0F));
        // bone "wheel_back2" origin=[-16.5, 12.5, 26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back2 = frame.addOrReplaceChild("wheel_back2", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(67F, 11.5F, 26F, 0F, 0F, 0F));
        // bone "wheel_back3" origin=[13.5, 12.5, 26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back3 = frame.addOrReplaceChild("wheel_back3", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(37F, 11.5F, 26F, 0F, 0F, 0F));
        // bone "wheel_back5" origin=[13.5, 12.5, -26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back5 = frame.addOrReplaceChild("wheel_back5", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(37F, 11.5F, -26F, 0F, 0F, 0F));
        // bone "wheel_back6" origin=[-16.5, 12.5, -26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back6 = frame.addOrReplaceChild("wheel_back6", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(67F, 11.5F, -26F, 0F, 0F, 0F));
        // bone "wheel_back7" origin=[42.5, 12.5, -26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back7 = frame.addOrReplaceChild("wheel_back7", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(8F, 11.5F, -26F, 0F, 0F, 0F));
        // bone "wheel_back8" origin=[73.5, 12.5, -26] rotation=[0, 0, 0] → 盒 3 个（其中带自身旋转 0 个）
        PartDefinition wheel_back8 = frame.addOrReplaceChild("wheel_back8", CubeListBuilder.create()
                .texOffs(565, 188).addBox(-12.5F, -12.5F, -2F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 0F, 25F, 25F, 0F)
                .texOffs(565, 188).addBox(-12.5F, -12.5F, 2F, 25F, 25F, 0F),
                PartPose.offsetAndRotation(-23F, 11.5F, -26F, 0F, 0F, 0F));
        // bone "stick2" origin=[36, 13.5, -29] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition stick2 = frame.addOrReplaceChild("stick2", CubeListBuilder.create()
                .texOffs(490, 155).addBox(-45F, -1.5F, -1F, 90F, 3F, 2F),
                PartPose.offsetAndRotation(14.5F, 10.5F, -29F, 0F, 0F, 0F));
        // bone "group" origin=[-8, 33, 16] rotation=[0, 0, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider1 = frame.addOrReplaceChild("rider1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(58.5F, -9F, 16F, 0F, 0F, 0F));
        // bone "body" origin=[-8, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_1 = rider1.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(172, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head" origin=[-8, 45, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head = rider1.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(156, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm" origin=[-13, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm = rider1.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[-8, 39, 13]
        PartDefinition right_arm_c0 = right_arm.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm" origin=[-3, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm = rider1.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[-8, 39, 13]
        PartDefinition left_arm_c0 = left_arm.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg" origin=[-9.9, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg = rider1.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[-8, 27, 12]
        PartDefinition right_leg_c0 = right_leg.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg" origin=[-6.1, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg = rider1.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[-8, 27, 12]
        PartDefinition left_leg_c0 = left_leg.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group2" origin=[-8, 33, -16] rotation=[0, -180, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider2 = frame.addOrReplaceChild("rider2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(58.5F, -9F, -16F, 0F, 3.1416F, 0F));
        // bone "body2" origin=[-8, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_2 = rider2.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(172, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head2" origin=[-8, 45, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_1 = rider2.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(156, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm2" origin=[-13, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_1 = rider2.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[-8, 39, -19]
        PartDefinition right_arm_1_c0 = right_arm_1.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm2" origin=[-3, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_1 = rider2.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[-8, 39, -19]
        PartDefinition left_arm_1_c0 = left_arm_1.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg2" origin=[-9.9, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_1 = rider2.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[-8, 27, -20]
        PartDefinition right_leg_1_c0 = right_leg_1.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg2" origin=[-6.1, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_1 = rider2.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[-8, 27, -20]
        PartDefinition left_leg_1_c0 = left_leg_1.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group3" origin=[11, 33, -16] rotation=[0, -180, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider3 = frame.addOrReplaceChild("rider3", CubeListBuilder.create(),
                PartPose.offsetAndRotation(39.5F, -9F, -16F, 0F, 3.1416F, 0F));
        // bone "body3" origin=[11, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_3 = rider3.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(238, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head3" origin=[11, 45, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_2 = rider3.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(222, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm3" origin=[6, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_2 = rider3.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[11, 39, -19]
        PartDefinition right_arm_2_c0 = right_arm_2.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm3" origin=[16, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_2 = rider3.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[11, 39, -19]
        PartDefinition left_arm_2_c0 = left_arm_2.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg3" origin=[9.1, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_2 = rider3.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[11, 27, -20]
        PartDefinition right_leg_2_c0 = right_leg_2.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg3" origin=[12.9, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_2 = rider3.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[11, 27, -20]
        PartDefinition left_leg_2_c0 = left_leg_2.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group4" origin=[30, 33, -16] rotation=[0, -180, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider4 = frame.addOrReplaceChild("rider4", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20.5F, -9F, -16F, 0F, 3.1416F, 0F));
        // bone "body4" origin=[30, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_4 = rider4.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(238, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head4" origin=[30, 45, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_3 = rider4.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(222, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm4" origin=[25, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_3 = rider4.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[30, 39, -19]
        PartDefinition right_arm_3_c0 = right_arm_3.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm4" origin=[35, 43, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_3 = rider4.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[30, 39, -19]
        PartDefinition left_arm_3_c0 = left_arm_3.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg4" origin=[28.1, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_3 = rider4.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[30, 27, -20]
        PartDefinition right_leg_3_c0 = right_leg_3.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg4" origin=[31.9, 33, -16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_3 = rider4.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[30, 27, -20]
        PartDefinition left_leg_3_c0 = left_leg_3.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group5" origin=[12, 33, 16] rotation=[0, 0, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider5 = frame.addOrReplaceChild("rider5", CubeListBuilder.create(),
                PartPose.offsetAndRotation(38.5F, -9F, 16F, 0F, 0F, 0F));
        // bone "body5" origin=[12, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_5 = rider5.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(294, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head5" origin=[12, 45, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_4 = rider5.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(278, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm5" origin=[7, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_4 = rider5.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[12, 39, 13]
        PartDefinition right_arm_4_c0 = right_arm_4.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(318, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm5" origin=[17, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_4 = rider5.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[12, 39, 13]
        PartDefinition left_arm_4_c0 = left_arm_4.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(318, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg5" origin=[10.1, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_4 = rider5.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[12, 27, 12]
        PartDefinition right_leg_4_c0 = right_leg_4.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(278, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg5" origin=[13.9, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_4 = rider5.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[12, 27, 12]
        PartDefinition left_leg_4_c0 = left_leg_4.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(278, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group6" origin=[34, 33, 16] rotation=[0, 0, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider6 = frame.addOrReplaceChild("rider6", CubeListBuilder.create(),
                PartPose.offsetAndRotation(16.5F, -9F, 16F, 0F, 0F, 0F));
        // bone "body6" origin=[34, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_6 = rider6.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(172, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head6" origin=[34, 45, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_5 = rider6.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(156, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm6" origin=[29, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_5 = rider6.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[34, 39, 13]
        PartDefinition right_arm_5_c0 = right_arm_5.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm6" origin=[39, 43, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_5 = rider6.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[34, 39, 13]
        PartDefinition left_arm_5_c0 = left_arm_5.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(196, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg6" origin=[32.1, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_5 = rider6.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[34, 27, 12]
        PartDefinition right_leg_5_c0 = right_leg_5.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg6" origin=[35.9, 33, 16] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_5 = rider6.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[34, 27, 12]
        PartDefinition left_leg_5_c0 = left_leg_5.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(156, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        // bone "group7" origin=[71, 43, -1] rotation=[0, -90, 0] → 盒 0 个（其中带自身旋转 0 个）
        PartDefinition rider7 = frame.addOrReplaceChild("rider7", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20.5F, -19F, -1F, 0F, 1.5708F, 0F));
        // bone "body7" origin=[71, 43, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition body_7 = rider7.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(238, 484).addBox(-4F, -12F, -2F, 8F, 12F, 4F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        // bone "head7" origin=[71, 55, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 0 个）
        PartDefinition head_6 = rider7.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(222, 468).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(0F, -12F, 0F, 0F, 0F, 0F));
        // bone "right_arm7" origin=[66, 53, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_arm_6 = rider7.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[71, 49, -4]
        PartDefinition right_arm_6_c0 = right_arm_6.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(4F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "left_arm7" origin=[76, 53, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_arm_6 = rider7.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-5F, -10F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[45, 0, 0] origin=[71, 49, -4]
        PartDefinition left_arm_6_c0 = left_arm_6.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(262, 484).addBox(-6F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(5F, 4F, -3F, -0.7854F, 0F, 0F));
        // bone "right_leg7" origin=[69.1, 43, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition right_leg_6 = rider7.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, 9.58, -11.6] origin=[71, 37, -5]
        PartDefinition right_leg_6_c0 = right_leg_6.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(2.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(-1.9F, 6F, -4F, -0.6811F, -0.1671F, -0.2024F));
        // bone "left_leg7" origin=[72.9, 43, -1] rotation=[0, 0, 0] → 盒 1 个（其中带自身旋转 1 个）
        PartDefinition left_leg_6 = rider7.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.9F, 0F, 0F, 0F, 0F, 0F));
        // 带自身旋转的盒 rot=[39.03, -9.58, 11.6] origin=[71, 37, -5]
        PartDefinition left_leg_6_c0 = left_leg_6.addOrReplaceChild("c0", CubeListBuilder.create()
                .texOffs(222, 484).addBox(-4.9F, -6F, -1F, 2F, 12F, 2F, new CubeDeformation(0.2F)),
                PartPose.offsetAndRotation(1.9F, 6F, -4F, -0.6811F, 0.1671F, 0.2024F));
        return LayerDefinition.create(mesh, 800, 800);
    }
}
