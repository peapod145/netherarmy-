package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * 神·附魔金苹果。
 * <ul>
 *   <li>【金色字体】：覆盖 {@link #getName(ItemStack)}，在原版翻译键外包一层
 *       {@code ChatFormatting.GOLD}。物品栏 / 手持 / 成就图标等所有悬停标题
 *       都经 {@code ItemStack#getHoverName()} 走到这里，一处覆盖全局生效；</li>
 *   <li>【附魔金苹果同款动态紫色光效】：覆盖 {@link #isFoil(ItemStack)} 恒为
 *       {@code true}。{@code ItemStack#hasFoil()} 在没有 ENCHANTMENT_GLINT_OVERRIDE
 *       组件时回落到 {@code Item#isFoil}，因此背包、手上、掉落物、展示框里
 *       都会渲染原版附魔光泽（流动紫色高光）贴图，而不是靠假附魔——
 *       悬浮提示里不会出现"附魔"列表，与原版附魔金苹果观感一致。</li>
 * </ul>
 * 饥饿 / 饱和度与七种食用效果都写在注册处的 FOOD 组件里，本类不碰。
 */
public final class GodGoldenAppleItem extends Item {
    public GodGoldenAppleItem(Properties properties) {
        super(properties);
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable(this.getDescriptionId(stack)).withStyle(ChatFormatting.GOLD);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
