package cn.blockforge.generated.netherarmy;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 服务端 → 客户端的"打开 BAD APPLE 视频"通知。载荷本身不携带数据，
 * 收到即触发 {@link BadAppleUrlSync#CLIENT_HANDLER}。
 */
public record BadAppleUrlPayload() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<BadAppleUrlPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(
                    GeneratedMod.MOD_ID, "bad_apple_url"));
    public static final StreamCodec<ByteBuf, BadAppleUrlPayload> STREAM_CODEC =
            StreamCodec.unit(new BadAppleUrlPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
