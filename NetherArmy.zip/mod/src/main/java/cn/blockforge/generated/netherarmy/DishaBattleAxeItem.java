package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.ItemAbility;

/**
 * 地煞战斧：伤害 18、攻击冷却 1.2 秒、耐久 5000、主手攻击距离比铁剑远 25%（3.0 格 → 3.75 格）
 * 的斧类武器。
 *
 * <p>攻击距离来自 {@link GeneratedMod#DISHA_BATTLE_AXE} 上挂在
 * {@code Attributes.ENTITY_INTERACTION_RANGE} 的主手修饰符：斧身模型比一般武器大，
 * 所以够得更远；收进背包或换到副手会自动失效。</p>
 *
 * <p>斧类的固有行为（能敲落盾牌、能去氧化/去皮、按 {@code #minecraft:axes} 参与附魔）
 * 由父类 {@link AxeItem} 与本模组的物品标签提供：原版缴械走
 * {@code IItemExtension#canDisableShield} 的 {@code this instanceof AxeItem} 判定，
 * 只要继承 AxeItem 就自动生效。</p>
 *
 * <p>缴械盾牌比一般斧头更狠（结算在 {@link ShieldEnchantmentHandler}，因为原版
 * {@code Player#disableShield()} 的 100 刻冷却是写死的、没有可改的事件）：
 * <ul>
 *   <li>缴械时间 ×2：普通盾牌 100 刻 → 200 刻（10 秒），亡魂重盾 50 → 100 刻，
 *       钝击缓冲仍按等级再减免；</li>
 *   <li>盾牌耐久损耗 = 这一击的斧伤害 ×2（满蓄力 18 点 → 扣 36 点），
 *       替换掉原版格挡本身那条 {@code 1 + floor(格挡伤害)} 的损耗，
 *       盾牌因此被打穿时同样按重塑／护主的既有规则降级或碎裂。</li>
 * </ul></p>
 *
 * <p>横扫之刃：原版只在主手物品 {@code canPerformAction(SWORD_SWEEP)} 为真时才结算横扫，
 * 这里让本斧"带横扫之刃附魔"时放行该能力——所以裸斧打不出横扫，附魔后立刻可以。</p>
 *
 * <p>掉落物免疫火烧与爆炸：火烧由 {@link Item.Properties#fireResistant()} 负责
 * （{@code ItemEntity} 对 {@code IS_FIRE} 伤害直接免疫），爆炸由
 * {@link #canBeHurtBy(ItemStack, DamageSource)} 拦下 {@code IS_EXPLOSION}。</p>
 */
public final class DishaBattleAxeItem extends AxeItem {
    /** 命中附加的虚弱等级：1 即"虚弱 II"。 */
    private static final int WEAKNESS_AMPLIFIER = 1;
    /** 命中附加的虚弱时长：200 刻 = 10 秒。 */
    private static final int WEAKNESS_DURATION_TICKS = 200;

    public DishaBattleAxeItem(Tier tier, Item.Properties properties) {
        super(tier, properties);
    }

    /**
     * 命中后附加 10 秒虚弱 II。
     * {@code postHurtEnemy} 由 {@code Player#attack} 在伤害结算成功、且服务端一侧调用，
     * 父类实现里它同时负责扣 2 点耐久，因此必须先 super。
     */
    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postHurtEnemy(stack, target, attacker);
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,
                WEAKNESS_DURATION_TICKS, WEAKNESS_AMPLIFIER, false, true));
    }

    /** 只有带着横扫之刃才允许触发横扫结算（裸斧不能横扫）。 */
    @Override
    public boolean canPerformAction(ItemStack stack, ItemAbility ability) {
        if (ability == ItemAbilities.SWORD_SWEEP) {
            return hasSweepingEdge(stack);
        }
        return super.canPerformAction(stack, ability);
    }

    /** 掉落物不吃爆炸伤害（火烧由 fireResistant 组件负责）。 */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }

    private static boolean hasSweepingEdge(ItemStack stack) {
        for (Holder<Enchantment> enchantment : stack.getEnchantments().keySet()) {
            if (enchantment.is(Enchantments.SWEEPING_EDGE)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 地煞战斧的工具等级。
     *
     * <p>耐久 5000（{@code TieredItem} 构造器会把它写进物品属性）；木质方块的挖掘速度
     * 18.0 = 下界合金斧（9.0）的两倍，速度通过 {@code Tier#createToolProperties} 生成的
     * {@code minecraft:tool} 组件作用在斧头的生效方块集（{@code #minecraft:mineable/axe}）上；
     * 附魔能力与下界合金同级（15）。攻击力/攻速不经过这里，见
     * {@link GeneratedMod#DISHA_BATTLE_AXE}。</p>
     */
    public static final class DishaTier implements Tier {
        /** 下界合金斧的挖掘速度。 */
        private static final float NETHERITE_SPEED = 9.0F;

        @Override
        public int getUses() {
            return 5000;
        }

        @Override
        public float getSpeed() {
            return NETHERITE_SPEED * 2.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 4.0F;
        }

        @Override
        public net.minecraft.tags.TagKey<Block> getIncorrectBlocksForDrops() {
            return BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
        }

        @Override
        public int getEnchantmentValue() {
            return 15;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(GeneratedMod.NETHER_CRYSTAL_SHARD.get());
        }
    }
}
