package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherZombie;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.sensing.VillagerHostilesSensor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 村民侧的"看见尸鬼即恐慌"：原版 {@link VillagerHostilesSensor} 的敌对名册
 * {@code ACCEPTABLE_DISTANCE_FROM_HOSTILES} 是一张按 EntityType 精确查表的
 * ImmutableMap，尸鬼是本模组注册的实体类型、不在表内，因此村民不会像躲僵尸那样
 * 躲尸鬼。这里在 {@code isMatchingEntity} 头部插入尸鬼分支：8.0 格内（与表内
 * 僵尸/溺尸/尸壳/僵尸村民同标定）命中即写入 {@code NEAREST_HOSTILE} 记忆。
 *
 * <p>命中之后走的全是原版管线：{@code VillagerPanicTrigger}（CORE 活动）把活动切到
 * PANIC，PANIC 包里的 {@code SetWalkTargetAwayFrom.entity(NEAREST_HOSTILE, 1.5x, 6)}
 * 让村民朝远离尸鬼的方向逃跑，威胁消失后 {@code VillagerCalmDown} 自动恢复日常——
 * 与村民见到普通僵尸的反应一字不差，正是"苦力怕遇到猫"式的主动逃跑在 Brain 生物
 * 上的等价实现。</p>
 *
 * <p>视线判定不需要自己做：{@code NearestVisibleLivingEntitySensor} 只从
 * {@code NEAREST_VISIBLE_LIVING_ENTITIES}（由原版 Sensor 按视野与遮挡过滤）里挑目标，
 * 隔墙看见不算"发现"。</p>
 */
@Mixin(VillagerHostilesSensor.class)
public abstract class VillagerHostilesSensorGhoulMixin {
    /** 与名册里 EntityType.ZOMBIE 的 8.0F 同标定（平方距离）。 */
    private static final double GHOUL_HOSTILE_DISTANCE_SQR = 64.0D;

    @Inject(method = "isMatchingEntity", at = @At("HEAD"), cancellable = true)
    private void netherarmy$ghoulCountsAsHostile(LivingEntity observer, LivingEntity lookedAt,
                                                 CallbackInfoReturnable<Boolean> callback) {
        if (lookedAt instanceof WitherZombie) {
            callback.setReturnValue(observer.distanceToSqr(lookedAt) <= GHOUL_HOSTILE_DISTANCE_SQR);
        }
    }
}
