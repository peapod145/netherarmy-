package cn.blockforge.generated.netherarmy;

import java.util.function.Supplier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

/**
 * 按贴图原样渲染的刷怪蛋。
 *
 * NeoForge 会为每一个 {@link DeferredSpawnEggItem} 注册双色着色器
 * （DeferredSpawnEggItem$ColorRegisterHandler：每个渲染层乘以 getColor(层号)），
 * 而本模组的刷怪蛋贴图已经把最终颜色画全，再乘一次构造器里的底色只会把整张
 * 贴图压到接近黑色。这里把 getColor 固定为不透明白，着色乘法变成恒等操作，
 * 物品栏与手持渲染即与贴图逐像素一致。
 *
 * 刷怪、发射器行为、实体类型延迟解析等全部沿用 DeferredSpawnEggItem，未改动。
 */
public class PlainSpawnEggItem extends DeferredSpawnEggItem {
    public PlainSpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, int backgroundColor,
                             int highlightColor, Item.Properties props) {
        super(type, backgroundColor, highlightColor, props);
    }

    @Override
    public int getColor(int index) {
        return 0xFFFFFFFF;
    }
}
