package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShieldItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 原版盾牌没有重写 {@code getEnchantmentValue()}，继承 {@link Item} 的默认实现 0，
 * 导致附魔台算出的附魔成本恒为 0、槽位全部不可用。这里把所有盾牌类物品的附魔能力
 * 提到 1，让原版盾牌也能在附魔台附魔（耐久、经验修补、护主、重塑、立体防御）。
 */
@Mixin(Item.class)
public abstract class ItemEnchantmentValueMixin {
    @Inject(method = "getEnchantmentValue", at = @At("HEAD"), cancellable = true)
    private void netherarmy$shieldEnchantability(CallbackInfoReturnable<Integer> callback) {
        if ((Object) this instanceof ShieldItem) {
            callback.setReturnValue(1);
        }
    }
}
