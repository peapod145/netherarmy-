package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 狂战士头盔的装备模型：围住头顶的石质环带 + 三根向上收尖的阶梯尖刺。
 *
 * <p>几何逐块取自用户上传的 berserker_helmet.bbmodel（32×32 贴图）。
 * 该模型里 Y 轴向上，而 HumanoidModel 头部坐标里 -Y 才是向上，
 * 因此每块按 java_y = 10.8F - bb_y 换算；尖刺从环带上沿长出，
 * 每根尖刺由 base→mid→upper→upper2→tip 五级收窄，tip 与上一级的中心对齐。
 */
public final class BerserkerHelmetArmorModel extends HumanoidModel<net.minecraft.world.entity.LivingEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "berserker_helmet_armor"), "main");

    public BerserkerHelmetArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(
                net.minecraft.client.model.geom.builders.CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        // 显式清空 HumanoidModel.createMesh() 自带的头壳与 hat 外壳；
        // 否则原版 8×8 头盔会套在环带里面挡住脸。
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition head = root.getChild("head");

        head.addOrReplaceChild("band_back", CubeListBuilder.create().texOffs(0, 4)
                .addBox(-5.2F, -7.7F, 4.15F, 10.4F, 2.3F, 1.05F), PartPose.ZERO);
        head.addOrReplaceChild("band_front", CubeListBuilder.create().texOffs(0, 8)
                .addBox(-5.2F, -7.7F, -5.2F, 10.4F, 2.3F, 1.05F), PartPose.ZERO);
        head.addOrReplaceChild("band_left", CubeListBuilder.create().texOffs(12, 0)
                .addBox(-5.2F, -7.7F, -4.15F, 1.05F, 2.3F, 8.3F), PartPose.ZERO);
        head.addOrReplaceChild("band_right", CubeListBuilder.create().texOffs(16, 0)
                .addBox(4.15F, -7.7F, -4.15F, 1.05F, 2.3F, 8.3F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_base", CubeListBuilder.create().texOffs(0, 12)
                .addBox(-1.35F, -8.6F, -5.4F, 2.7F, 1.9F, 1.25F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_mid", CubeListBuilder.create().texOffs(4, 12)
                .addBox(-1.05F, -10.1F, -5.75F, 2.1F, 1.9F, 1.2F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_upper", CubeListBuilder.create().texOffs(7, 12)
                .addBox(-0.75F, -11.4F, -6.05F, 1.5F, 1.7F, 1.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_upper2", CubeListBuilder.create().texOffs(7, 12)
                .addBox(-0.75F, -12.4F, -5.5F, 1.5F, 1.7F, 1.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_tip", CubeListBuilder.create().texOffs(10, 12)
                .addBox(-0.42F, -13.1F, -5.3F, 0.84F, 1.4F, 0.8F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_base", CubeListBuilder.create().texOffs(0, 20)
                .addBox(-6F, -8.6F, -1.35F, 1.25F, 1.9F, 2.7F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_mid", CubeListBuilder.create().texOffs(4, 20)
                .addBox(-6.35F, -10.1F, -1.05F, 1.2F, 1.9F, 2.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_upper", CubeListBuilder.create().texOffs(7, 20)
                .addBox(-6.65F, -11.4F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_upper2", CubeListBuilder.create().texOffs(7, 20)
                .addBox(-6.1F, -12.4F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_tip", CubeListBuilder.create().texOffs(10, 20)
                .addBox(-5.9F, -13.1F, -0.42F, 0.8F, 1.4F, 0.84F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_base", CubeListBuilder.create().texOffs(12, 12)
                .addBox(4.5F, -8.6F, -1.35F, 1.25F, 1.9F, 2.7F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_mid", CubeListBuilder.create().texOffs(16, 12)
                .addBox(4.9F, -10.1F, -1.05F, 1.2F, 1.9F, 2.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_upper", CubeListBuilder.create().texOffs(19, 12)
                .addBox(5.3F, -11.4F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_upper2", CubeListBuilder.create().texOffs(19, 12)
                .addBox(4.85F, -12.4F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_tip", CubeListBuilder.create().texOffs(22, 12)
                .addBox(4.85F, -13.1F, -0.42F, 0.8F, 1.4F, 0.84F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 32, 32);
    }
}
