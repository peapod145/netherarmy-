package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 狂战士头盔的装备模型。
 * 几何与 assets/netherarmy/models/entity/berserker_helmet.bbmodel 中的上传模型一致。
 */
public final class BerserkerHelmetArmorModel extends HumanoidModel<net.minecraft.world.entity.LivingEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "berserker_helmet_armor"), "main");

    public BerserkerHelmetArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(
                net.minecraft.client.model.geom.builders.CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        // 显式清空 HumanoidModel.createMesh() 自带的 hat 外壳；否则它会覆盖头部前后左右。
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition head = root.getChild("head");

        // 四段首尾相接的闭合环带；环带内沿在头颅外侧，正面段不会陷进脸部。
        head.addOrReplaceChild("band_back", CubeListBuilder.create().texOffs(0, 4)
                .addBox(-5.2F, -7.8F, 4.15F, 10.4F, 2.3F, 1.05F), PartPose.ZERO);
        head.addOrReplaceChild("band_front", CubeListBuilder.create().texOffs(0, 8)
                .addBox(-5.2F, -7.8F, -5.2F, 10.4F, 2.3F, 1.05F), PartPose.ZERO);
        head.addOrReplaceChild("band_left", CubeListBuilder.create().texOffs(12, 0)
                .addBox(-5.2F, -7.8F, -4.15F, 1.05F, 2.3F, 8.3F), PartPose.ZERO);
        head.addOrReplaceChild("band_right", CubeListBuilder.create().texOffs(16, 0)
                .addBox(4.15F, -7.8F, -4.15F, 1.05F, 2.3F, 8.3F), PartPose.ZERO);

        // 三根较短的阶梯式尖刺；Minecraft 头部局部坐标中 Y 越小越靠上。
        head.addOrReplaceChild("spike_front_base", CubeListBuilder.create().texOffs(0, 12)
                .addBox(-1.35F, -8.5F, -6.4F, 2.7F, 1.9F, 1.25F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_mid", CubeListBuilder.create().texOffs(4, 12)
                .addBox(-1.05F, -10.0F, -6.75F, 2.1F, 1.9F, 1.2F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_upper", CubeListBuilder.create().texOffs(7, 12)
                .addBox(-0.75F, -11.5F, -7.05F, 1.5F, 1.7F, 1.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_front_tip", CubeListBuilder.create().texOffs(10, 12)
                .addBox(-0.42F, -12.9F, -7.3F, 0.84F, 1.4F, 0.8F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_base", CubeListBuilder.create().texOffs(0, 20)
                .addBox(-6.4F, -8.5F, -1.35F, 1.25F, 1.9F, 2.7F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_mid", CubeListBuilder.create().texOffs(4, 20)
                .addBox(-6.75F, -10.0F, -1.05F, 1.2F, 1.9F, 2.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_upper", CubeListBuilder.create().texOffs(7, 20)
                .addBox(-7.05F, -11.5F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_left_tip", CubeListBuilder.create().texOffs(10, 20)
                .addBox(-7.3F, -12.9F, -0.42F, 0.8F, 1.4F, 0.84F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_base", CubeListBuilder.create().texOffs(12, 12)
                .addBox(5.15F, -8.5F, -1.35F, 1.25F, 1.9F, 2.7F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_mid", CubeListBuilder.create().texOffs(16, 12)
                .addBox(5.55F, -10.0F, -1.05F, 1.2F, 1.9F, 2.1F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_upper", CubeListBuilder.create().texOffs(19, 12)
                .addBox(5.95F, -11.5F, -0.75F, 1.1F, 1.7F, 1.5F), PartPose.ZERO);
        head.addOrReplaceChild("spike_right_tip", CubeListBuilder.create().texOffs(22, 12)
                .addBox(6.5F, -12.9F, -0.42F, 0.8F, 1.4F, 0.84F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 32, 32);
    }
}
