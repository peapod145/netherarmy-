package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireBurn;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.SoulFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 进入灵魂火方块的实体使用灵魂火燃烧覆盖层，并沿用原版燃烧时长与伤害。 */
@Mixin(BaseFireBlock.class)
public abstract class SoulFireBlockMixin {
    @Inject(method = "entityInside", at = @At("TAIL"))
    private void netherarmy$markSoulFire(BlockState state, Level level, BlockPos pos,
                                         Entity entity, CallbackInfo callback) {
        if ((Object) this instanceof SoulFireBlock && !entity.fireImmune()
                && entity.getRemainingFireTicks() > 0) {
            SoulFireBurn.setSoulFlame(entity, true);
        }
    }
}
