package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireBurn;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.SoulFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 火焰方块接触：灵魂火方块给生物挂上灵魂火燃烧标记，普通火方块则把这枚标记摘掉。
 *
 * <p>为什么要管普通火：标记只在"整段燃烧结束"时才清（见 {@code SoulFireEntityMixin}），
 * 而普通火方块每 tick 都会给站在里面的实体续燃。于是"先被灵魂火烧着、随后跳进普通火 /
 * 岩浆"时，燃烧一直不断，标记也就一直挂着——玩家看到的仍是灵魂火。普通火源属于新的
 * 燃烧来源，接触时把标记清掉，火焰覆盖层立刻回到原版橙焰。</p>
 *
 * <p>写标记只在服务端做：客户端本地写一份会和同步值分叉，一旦两端条件判定不同（走位、
 * 延迟、火刻差异），客户端会留下一个服务端根本不知道、也就永远不会被清掉的假标记。
 * 服务端改完由 NeoForge 附件同步下发。</p>
 */
@Mixin(BaseFireBlock.class)
public abstract class SoulFireBlockMixin {
    @Inject(method = "entityInside", at = @At("TAIL"))
    private void netherarmy$markSoulFire(BlockState state, Level level, BlockPos pos,
                                         Entity entity, CallbackInfo callback) {
        if (level.isClientSide() || entity.fireImmune() || entity.getRemainingFireTicks() <= 0) {
            return;
        }
        if ((Object) this instanceof SoulFireBlock) {
            SoulFireBurn.setSoulFlame(entity, true);
        } else if (entity instanceof LivingEntity) {
            // 箭矢上的灵魂火标记是"灵魂火矢"的判定依据，不跟着普通火方块一起清。
            SoulFireBurn.setSoulFlame(entity, false);
        }
    }
}
