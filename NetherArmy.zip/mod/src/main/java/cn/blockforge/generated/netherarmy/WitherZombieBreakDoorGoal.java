package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.DoorInteractGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.GoalUtils;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.PathNavigationRegion;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.pathfinder.Node;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.level.pathfinder.PathFinder;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.CommonHooks;

/**
 * 尸鬼的破门目标：在原版 {@code BreakDoorGoal} 的骨架上重做，并把"砸门"从被动
 * 撞见升级成主动破拆。差异点有四处——
 *
 * <ul>
 *   <li><b>无条件发动</b>：原版僵尸要过两道门槛才砸门——生成期只有
 *       {@code 区域难度加成 × 10%} 的概率挂上破门 Goal，运行期又只认 HARD 难度；
 *       尸鬼的破门是固有能力，和平以外的任何难度都发动（和平下与原版口径一致，
 *       生物不破坏方块）；</li>
 *   <li><b>木门三倍速</b>：原版破门耗时 240 tick（12 秒），尸鬼打木门用
 *       240/3 = 80 tick（4 秒）；</li>
 *   <li><b>能破铁门</b>：原版寻路根本不让路径穿过闭合铁门（
 *       {@code DOOR_IRON_CLOSED} 对任何导航都不可通行），所以原版的节点扫描永远
 *       发现不了铁门；铁门用原版僵尸的 240 tick 匀速敲碎；</li>
 *   <li><b>主动破拆 AI</b>：原版 Goal 的发动条件写着
 *       {@code mob.horizontalCollision}，而闭合铁门对寻路不可通行——路径最多铺到
 *       门前一格就算走完（{@code Path#isDone()}），导航随即不再输出位移，尸鬼站在
 *       门前不动，{@code horizontalCollision} 为假，于是这个目标永远起不来，表现出来
 *       就是"明明有砸铁门的能力却从不砸铁门"。这里补上一条主动链路：检测到敌人隔着
 *       闭合门、自己的追击路线又被这扇门堵死时，先<b>认门</b>（寻路终点邻域 → 尸鬼
 *       身边 → 尸鬼与目标的直线走廊），再<b>走到门前</b>（自己接管 MOVE/LOOK 旗标，
 *       把导航从近战目标手里抢过来），最后<b>顶着门砸</b>。门型判定、破坏权限、
 *       砸门表现全部沿用原口径。</li>
 * </ul>
 *
 * <p>门的认定沿用原版口径：{@code DoorBlock.isWoodenDoor}（可由手打开的门，覆盖
 * 全部木门）走 80 tick；其余门方块（铁门及同规格的不可手开门）走 240 tick。
 * 破坏权限走 NeoForge 的 {@code CommonHooks.canEntityDestroy}，与原版破门 Goal
 * 完全同源——{@code mobGriefing} 关闭时不破门。</p>
 *
 * <p>只有确实在"追击路线上"的门才会被砸：目标必须活着且在
 * {@link #MAX_BREACH_DISTANCE} 格内、尸鬼与目标被门所在墙面分隔在两侧、尸鬼看不见
 * 目标，并且一次独立寻路探测证明"绕不过去"（有开着的门或别的通路时尸鬼照常绕行，
 * 不会乱砸门）。门会被归一到下半格，站位取门格朝尸鬼这一侧的相邻格。走不到/砸不到的
 * 门被拉黑 {@link #DOOR_ABANDON_TICKS} tick，避免贴着围栏反复起手。</p>
 *
 * <p>砸门的表现（每约 20 tick 一次 levelEvent 1019 敲门音 + 挥臂、破坏进度粒子
 * 0..10、碎门时 1021/2001 事件）逐行复刻原版 {@code BreakDoorGoal#tick}。</p>
 */
public class WitherZombieBreakDoorGoal extends DoorInteractGoal {
    /** 原版僵尸破木门的耗时（240 tick = 12 秒），作为本目标的速度基准。 */
    private static final int ZOMBIE_DOOR_BREAK_TIME = 240;
    /** 尸鬼破木门：僵尸速度的 3 倍（80 tick = 4 秒）。 */
    private static final int WOODEN_DOOR_BREAK_TIME = ZOMBIE_DOOR_BREAK_TIME / 3;
    /** 尸鬼破铁门：与僵尸破木门同速（240 tick = 12 秒）。 */
    private static final int IRON_DOOR_BREAK_TIME = ZOMBIE_DOOR_BREAK_TIME;

    /** 尸鬼最多愿意为哪扇门跑多远（水平格）。 */
    private static final double MAX_BREACH_DISTANCE = 24.0;
    /** 离门格中心多近就可以开始砸（不用再走）。 */
    private static final double KNOCK_DISTANCE = 1.7;
    /** 砸门期间离开门格超过这个距离就收手（被人推开、被矿车带走等）。 */
    private static final double KEEP_DISTANCE = 2.5;
    /** 走向门前的超时（tick），超时即拉黑这扇门。 */
    private static final int APPROACH_TIMEOUT = 200;
    /** 拉黑一扇砸不到的门的时长（tick）。 */
    private static final int DOOR_ABANDON_TICKS = 200;
    /** 主动破拆评估的节流间隔（tick）：认门要扫格子，不必每 tick 都扫。 */
    private static final int BREACH_CHECK_INTERVAL = 8;
    /** 可达性探测结论的缓存时长（tick）。 */
    private static final int REACH_PROBE_CACHE_TICKS = 20;
    /** 直线走廊扫门的采样步长（格）。 */
    private static final double CORRIDOR_STEP = 0.5;
    /** 直线走廊扫门的采样上限（格）：门离得远就先走过去再认，别一次扫满。 */
    private static final double CORRIDOR_RANGE = 10.0;
    /** 直线走廊的横向容差（格）。 */
    private static final int CORRIDOR_LATERAL_TOLERANCE = 1;
    /** 寻路终点邻域扫门的半径（格）。 */
    private static final int PATH_END_SCAN_RADIUS = 2;
    /** 独立寻路探测的节点预算下限。 */
    private static final int PROBE_NODE_BUDGET = 256;

    /** 本目标的两个阶段：走到门前 / 站在门前砸。 */
    private enum Phase {
        /** 已经在门边，直接砸。 */
        SMASH,
        /** 先接管导航走到门前那格，再转入 {@link Phase#SMASH}。 */
        APPROACH
    }

    /** 本次砸门的累计 tick 数（原版 BreakDoorGoal 同名计时器）。 */
    private int breakTime;
    /** 上一次广播给客户端的破坏进度（0..10），变化时才发包。 */
    private int lastBreakProgress = -1;
    /** 当前目标的破门耗时，锁定于 {@link #acceptDoor} 认定门型的一刻。 */
    private int breakDuration = WOODEN_DOOR_BREAK_TIME;

    private Phase phase = Phase.SMASH;
    /** 门前站位：门格沿墙面法线朝尸鬼这一侧的相邻格。 */
    private BlockPos knockPos = BlockPos.ZERO;
    /** 主动破拆锁定的追击目标；被动撞见门（老路子）时为 null。 */
    @Nullable
    private LivingEntity routeTarget;
    private int approachTicks;
    private long nextBreachCheckTime;
    @Nullable
    private BlockPos abandonedDoor;
    private long abandonUntilGameTime;
    /** 可达性探测缓存：生效到哪一 tick / 结论 / 结论对应哪个目标。 */
    private long reachProbeCacheUntil = Long.MIN_VALUE;
    private boolean reachProbeCachedResult;
    @Nullable
    private LivingEntity reachProbeTarget;
    /** 独立寻路探测器：借用导航的 NodeEvaluator，但不碰导航自己的路径状态。 */
    @Nullable
    private PathFinder probeFinder;

    public WitherZombieBreakDoorGoal(Mob mob) {
        super(mob);
        // 抢下 MOVE/LOOK：主动破门要自己把尸鬼牵到门前，不能让近战目标每 tick 再把
        // 导航指回敌人（原版 BreakDoorGoal 不占旗标，只能被动靠位移撞门，这正是
        // 它对铁门完全失效的原因）。本目标注册在优先级 1，高于僵尸的
        // ZombieAttackGoal(2)，GoalSelector 会把 MOVE/LOOK 从它手里夺走，
        // 并在它下次 canUse 时拦住它，直到这扇门倒下。
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    // ---------------------------------------------------------------- 起手判定

    @Override
    public boolean canUse() {
        Level level = this.mob.level();
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        if (!GoalUtils.hasGroundPathNavigation(this.mob)) {
            return false;
        }
        // A) 原版口径：位移正被挡住时（horizontalCollision），先扫当前路径上的门，
        //    再扫视线前方 / 自身格 / 头顶 / 水平四邻。木门靠这条支路就够用——寻路把
        //    闭合木门当可通行（DOOR_WOOD_CLOSED → WALKABLE_DOOR），尸鬼会一路顶到门前。
        if (this.mob.horizontalCollision && findDoorOnRouteOrAdjacent()) {
            beginSmash();
            return true;
        }
        // B) 主动破拆：目标在闭合门另一侧、追击路线又被这扇门堵死时，认门并走过去。
        return findBlockingDoorAhead(level);
    }

    /** 原版式认门：路径节点两格内 → 视线前方 → 头顶 → 自身 → 水平四邻。 */
    private boolean findDoorOnRouteOrAdjacent() {
        GroundPathNavigation navigation = (GroundPathNavigation)this.mob.getNavigation();
        Path path = navigation.getPath();
        if (path != null && !path.isDone() && navigation.canOpenDoors()) {
            for (int i = 0; i < Math.min(path.getNextNodeIndex() + 2, path.getNodeCount()); i++) {
                Node node = path.getNode(i);
                BlockPos candidate = new BlockPos(node.x, node.y + 1, node.z);
                if (this.mob.distanceToSqr((double)candidate.getX(), this.mob.getY(), (double)candidate.getZ()) <= 2.25
                        && acceptDoor(candidate)) {
                    return true;
                }
            }
        }
        if (acceptDoor(forwardCell())
                || acceptDoor(this.mob.blockPosition().above())
                || acceptDoor(this.mob.blockPosition())) {
            return true;
        }
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (acceptDoor(this.mob.blockPosition().relative(direction))) {
                return true;
            }
        }
        this.hasDoor = false;
        return false;
    }

    /** 主动破拆起手：查目标 → 认门 → 验破坏权限 → 确认绕不过去 → 决定阶段。 */
    private boolean findBlockingDoorAhead(Level level) {
        long gameTime = level.getGameTime();
        if (gameTime < this.nextBreachCheckTime) {
            return false;
        }
        this.nextBreachCheckTime = gameTime + BREACH_CHECK_INTERVAL;

        LivingEntity target = this.mob.getTarget();
        if (target == null || !target.isAlive() || target == this.mob) {
            return false;
        }
        double planar = horizontalDistanceTo(target.getX(), target.getZ());
        if (planar < 1.0 || planar > MAX_BREACH_DISTANCE) {
            return false;
        }
        if (Math.abs(target.getY() - this.mob.getY()) > 3.0) {
            return false;
        }
        // 看得见目标就没什么好砸的：要么直接上手打，要么本来就没东西挡路。
        if (this.mob.hasLineOfSight(target)) {
            return false;
        }
        BlockPos door = locateBlockingDoor(target);
        if (door == null) {
            return false;
        }
        // acceptDoor 顺带把 doorPos / breakDuration / knockPos 锁好。
        if (!acceptDoor(door)) {
            return false;
        }
        // 绕得过去（有开着的门、有别的通路）就别砸这一扇。
        if (canReachTarget(target)) {
            this.hasDoor = false;
            return false;
        }
        this.routeTarget = target;
        if (isAtDoor()) {
            beginSmash();
        } else {
            this.phase = Phase.APPROACH;
            this.approachTicks = 0;
            this.knockPos = knockCellFor(this.doorPos, level.getBlockState(this.doorPos), this.mob.position());
        }
        return true;
    }

    /**
     * 找出挡在追击路线上的门。三处来源按代价从低到高合并成两步：寻路终点邻域
     * （导航就是在那儿放弃的，门几乎必然贴着它，顺带覆盖"尸鬼自己就卡在门边"）
     * → 尸鬼与目标的直线走廊（±1 格横向容差）。候选都必须把二者分隔在墙面两侧。
     */
    @Nullable
    private BlockPos locateBlockingDoor(LivingEntity target) {
        BlockPos door = scanDoorAround(pathEndCell(), target, PATH_END_SCAN_RADIUS);
        if (door == null) {
            door = scanDoorAround(this.mob.blockPosition(), target, PATH_END_SCAN_RADIUS);
        }
        return door != null ? door : scanDoorOnCorridor(target);
    }

    /** 导航当前路径的终点格；没有路径时返回 null。 */
    @Nullable
    private BlockPos pathEndCell() {
        Path path = this.mob.getNavigation().getPath();
        if (path == null || path.getNodeCount() == 0) {
            return null;
        }
        Node end = path.getEndNode();
        return new BlockPos(Mth.floor(end.x), Mth.floor(end.y), Mth.floor(end.z));
    }

    /** 以 center 为心扫一个盒子，取离尸鬼最近、且确实分隔二者的闭合门（下半格）。 */
    @Nullable
    private BlockPos scanDoorAround(@Nullable BlockPos center, LivingEntity target, int radius) {
        if (center == null) {
            return null;
        }
        Level level = this.mob.level();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockPos bottom = bottomDoorCell(level, cursor);
                    if (bottom == null || !doorSeparates(bottom, level, target)) {
                        continue;
                    }
                    double distance = horizontalDistanceTo(bottom.getX() + 0.5, bottom.getZ() + 0.5);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        best = bottom.immutable();
                    }
                }
            }
        }
        return best;
    }

    /** 沿"尸鬼→目标"直线带形扫门：0.5 格步进、横向 ±1 格、最多扫 {@link #CORRIDOR_RANGE} 格。 */
    @Nullable
    private BlockPos scanDoorOnCorridor(LivingEntity target) {
        Vec3 from = this.mob.position();
        Vec3 to = target.position();
        double deltaX = to.x - from.x;
        double deltaZ = to.z - from.z;
        double planar = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        if (planar < 1.0) {
            return null;
        }
        double stepX = deltaX / planar;
        double stepZ = deltaZ / planar;
        // 走廊带形的左右两翼方向（水平面内垂直于连线）。
        double perpX = -stepZ;
        double perpZ = stepX;
        Level level = this.mob.level();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        double limit = Math.min(planar, CORRIDOR_RANGE);
        for (double travelled = 0.5; travelled <= limit; travelled += CORRIDOR_STEP) {
            double baseX = from.x + stepX * travelled;
            double baseZ = from.z + stepZ * travelled;
            int lineY = Mth.floor(Mth.lerp(travelled / planar, from.y + 0.5, to.y + 0.5));
            for (int lateral = 0; lateral <= CORRIDOR_LATERAL_TOLERANCE; lateral++) {
                for (int sign : lateralOffsets(lateral)) {
                    double x = baseX + perpX * (double)lateral * (double)sign;
                    double z = baseZ + perpZ * (double)lateral * (double)sign;
                    for (int y = lineY - 1; y <= lineY + 2; y++) {
                        cursor.set(Mth.floor(x), y, Mth.floor(z));
                        BlockPos bottom = bottomDoorCell(level, cursor);
                        if (bottom != null && doorSeparates(bottom, level, target)) {
                            return bottom.immutable();
                        }
                    }
                }
            }
        }
        return null;
    }

    /** 带形扫门的采样次序：先正中，再左右各一格（0 → {-1,1} → {-2,2}）。 */
    private static int[] lateralOffsets(int lateral) {
        if (lateral == 0) {
            return new int[]{0};
        }
        if (lateral == 1) {
            return new int[]{-1, 1};
        }
        return new int[]{-2, 2};
    }

    /** 门所在的墙面是否真的把尸鬼与目标分隔在两侧（门必须是闭合的）。 */
    private boolean doorSeparates(BlockPos door, Level level, LivingEntity target) {
        BlockState state = level.getBlockState(door);
        if (!(state.getBlock() instanceof DoorBlock)) {
            return false;
        }
        if (state.getValue(DoorBlock.OPEN)) {
            return false;
        }
        Direction facing = state.getValue(DoorBlock.FACING);
        double mobSide = sideOffset(this.mob.position(), door, facing);
        double targetSide = sideOffset(target.position(), door, facing);
        // 尸鬼已经贴在门面（或站在门框里）时符号可能为 0，这种情况同样算挡路。
        return Math.abs(mobSide) < 0.5 || mobSide * targetSide < 0.0;
    }

    /** 该格是不是"还能砸、且没被拉黑"的门：是则锁定 doorPos / breakDuration / knockPos。 */
    private boolean acceptDoor(BlockPos pos) {
        Level level = this.mob.level();
        BlockPos bottom = bottomDoorCell(level, pos);
        if (bottom == null) {
            return false;
        }
        if (isAbandoned(bottom)) {
            return false;
        }
        BlockState state = level.getBlockState(bottom);
        if (state.getValue(DoorBlock.OPEN)) {
            return false;
        }
        if (!CommonHooks.canEntityDestroy(level, bottom, this.mob)) {
            return false;
        }
        this.doorPos = bottom.immutable();
        this.hasDoor = true;
        this.breakDuration = DoorBlock.isWoodenDoor(state) ? WOODEN_DOOR_BREAK_TIME : IRON_DOOR_BREAK_TIME;
        this.knockPos = knockCellFor(this.doorPos, state, this.mob.position());
        return true;
    }

    /** 双格门的下半格；给定格不是门（或上半格下面没有同种门）时返回 null。 */
    @Nullable
    private static BlockPos bottomDoorCell(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof DoorBlock)) {
            return null;
        }
        if (state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
            return pos;
        }
        BlockPos below = pos.below();
        return level.getBlockState(below).is(state.getBlock()) ? below : null;
    }

    /** 门前站位：门格沿墙面法线朝给定位置这一侧的相邻格。 */
    private static BlockPos knockCellFor(BlockPos door, BlockState state, Vec3 from) {
        Direction facing = state.getValue(DoorBlock.FACING);
        return door.relative(sideOffset(from, door, facing) >= 0.0 ? facing : facing.getOpposite());
    }

    /** 位置相对门所在墙面的带符号偏移：正负代表在哪一侧，绝对值是离墙面的距离。 */
    private static double sideOffset(Vec3 position, BlockPos door, Direction facing) {
        Vec3 center = Vec3.atCenterOf(door);
        Vec3 axis = new Vec3((double)facing.getStepX(), 0.0, (double)facing.getStepZ());
        return position.subtract(center).dot(axis);
    }

    /** 实体视线方向前移一格对应的脚层格子（铁门大多正对着它）。 */
    private BlockPos forwardCell() {
        Vec3 look = this.mob.getLookAngle();
        return BlockPos.containing(this.mob.getX() + look.x, this.mob.getY(), this.mob.getZ() + look.z);
    }

    // ---------------------------------------------------------------- 生命周期

    @Override
    public void start() {
        super.start();
        this.breakTime = 0;
        this.lastBreakProgress = -1;
        this.approachTicks = 0;
        this.mob.setAggressive(true);
        if (this.phase == Phase.APPROACH) {
            this.mob.getNavigation()
                    .moveTo((double)this.knockPos.getX() + 0.5, (double)this.knockPos.getY(), (double)this.knockPos.getZ() + 0.5, 1.0);
        } else {
            // 原地开砸：清掉导航手里的路径，免得它每 tick 把位移目标改回别处。
            this.mob.getNavigation().stop();
        }
    }

    @Override
    public boolean canContinueToUse() {
        Level level = this.mob.level();
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        if (!this.hasDoor || this.isOpen()) {
            return false;
        }
        if (!(level.getBlockState(this.doorPos).getBlock() instanceof DoorBlock)) {
            return false;
        }
        if (!CommonHooks.canEntityDestroy(level, this.doorPos, this.mob)) {
            return false;
        }
        if (this.phase == Phase.APPROACH) {
            if (this.approachTicks > APPROACH_TIMEOUT) {
                abandonCurrentDoor();
                return false;
            }
            // 目标换了 / 没了 / 已经看得见（有人开了门、或者绕到了窗口）就别砸。
            LivingEntity target = this.routeTarget;
            if (target == null || !target.isAlive() || this.mob.getTarget() != target) {
                return false;
            }
            return !this.mob.hasLineOfSight(target);
        }
        return this.breakTime <= this.breakDuration
                && this.doorPos.closerToCenterThan(this.mob.position(), KEEP_DISTANCE);
    }

    @Override
    public void stop() {
        super.stop();
        this.mob.level().destroyBlockProgress(this.mob.getId(), this.doorPos, -1);
        this.mob.setAggressive(false);
        this.phase = Phase.SMASH;
        this.routeTarget = null;
        this.breakTime = 0;
        this.lastBreakProgress = -1;
        this.approachTicks = 0;
        // 让近战目标下一 tick 自己重新规划追击路径。
        this.mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        super.tick();
        Vec3 doorCenter = Vec3.atCenterOf(this.doorPos);
        if (this.phase == Phase.APPROACH) {
            this.approachTicks++;
            if (isAtDoor()) {
                this.phase = Phase.SMASH;
                this.breakTime = 0;
                this.lastBreakProgress = -1;
                this.mob.getNavigation().stop();
                return;
            }
            this.mob.getLookControl().setLookAt(doorCenter.x, doorCenter.y, doorCenter.z, 30.0F, 30.0F);
            double knockX = (double)this.knockPos.getX() + 0.5;
            double knockZ = (double)this.knockPos.getZ() + 0.5;
            // 每 10 tick（或导航已经走完当前路径）重新往站位格铺一次路径。
            if (this.approachTicks % 10 == 0 || this.mob.getNavigation().isDone()) {
                if (!this.mob.getNavigation().moveTo(knockX, (double)this.knockPos.getY(), knockZ, 1.0)) {
                    // 站位格给不出路径（被别的东西占着、或者导航自认为已经走到了）：
                    // 直接用移动控制往那里顶，兜不住就交给超时时限拉黑这扇门。
                    this.mob.getMoveControl().setWantedPosition(knockX, this.mob.getY(), knockZ, 1.0);
                }
            }
            return;
        }

        // ---- SMASH：一边往门上顶（保住贴脸距离和原版那种推门姿态），一边计时砸门。
        this.mob.getMoveControl().setWantedPosition(doorCenter.x, this.mob.getY(), doorCenter.z, 1.0);
        this.mob.getLookControl().setLookAt(doorCenter.x, doorCenter.y, doorCenter.z, 30.0F, 30.0F);
        if (this.mob.getRandom().nextInt(20) == 0) {
            this.mob.level().levelEvent(1019, this.doorPos, 0);
            if (!this.mob.swinging) {
                this.mob.swing(this.mob.getUsedItemHand());
            }
        }
        this.breakTime++;
        int progress = (int)((float)this.breakTime / (float)this.breakDuration * 10.0F);
        if (progress != this.lastBreakProgress) {
            this.mob.level().destroyBlockProgress(this.mob.getId(), this.doorPos, progress);
            this.lastBreakProgress = progress;
        }
        if (this.breakTime == this.breakDuration && this.mob.level().getDifficulty() != Difficulty.PEACEFUL) {
            Level level = this.mob.level();
            level.removeBlock(this.doorPos, false);
            level.levelEvent(1021, this.doorPos, 0);
            level.levelEvent(2001, this.doorPos, Block.getId(level.getBlockState(this.doorPos)));
        }
    }

    // ---------------------------------------------------------------- 可达性探测

    /**
     * 尸鬼能不能靠正常寻路走到目标（有别的路绕过去，或者那扇门开着/是能走的木门）。
     * 能走到就不砸门。结论缓存 {@link #REACH_PROBE_CACHE_TICKS} tick。
     */
    private boolean canReachTarget(LivingEntity target) {
        long gameTime = this.mob.level().getGameTime();
        if (gameTime < this.reachProbeCacheUntil && this.reachProbeTarget == target) {
            return this.reachProbeCachedResult;
        }
        boolean reachable = probeReachable(target);
        this.reachProbeTarget = target;
        this.reachProbeCacheUntil = gameTime + REACH_PROBE_CACHE_TICKS;
        this.reachProbeCachedResult = reachable;
        return reachable;
    }

    /**
     * 用导航自己的 NodeEvaluator 单独跑一次寻路（不走 {@link PathNavigation}，
     * 免得污染它缓存的目标格与当前路径）。搜索到上限、区域外、无路径都按
     * "到不了"处理——此时砸门才是符合直觉的行为。
     */
    private boolean probeReachable(LivingEntity target) {
        PathNavigation navigation = this.mob.getNavigation();
        if (!(navigation instanceof GroundPathNavigation groundNavigation) || groundNavigation.getNodeEvaluator() == null) {
            return false;
        }
        Level level = this.mob.level();
        double followRange = this.mob.getAttributeValue(Attributes.FOLLOW_RANGE);
        if (this.probeFinder == null) {
            int budget = Math.max(PROBE_NODE_BUDGET, Mth.floor(followRange * 16.0));
            this.probeFinder = new PathFinder(groundNavigation.getNodeEvaluator(), budget);
        }
        BlockPos from = this.mob.blockPosition();
        BlockPos to = target.blockPosition();
        int radius = Mth.ceil(Math.max(Math.abs(to.getX() - from.getX()), Math.abs(to.getZ() - from.getZ()))) + 8;
        radius = Math.min(radius, Mth.ceil(followRange) + 16);
        PathNavigationRegion region = new PathNavigationRegion(
                level, from.offset(-radius, -radius, -radius), from.offset(radius, radius, radius));
        Path path = this.probeFinder.findPath(region, this.mob, Set.of(to), (float)followRange, 2, 1.0F);
        return path != null && path.canReach();
    }

    // ---------------------------------------------------------------- 小工具

    private void beginSmash() {
        this.phase = Phase.SMASH;
        this.routeTarget = null;
        this.breakTime = 0;
        this.approachTicks = 0;
    }

    /** 尸鬼是否已经站到能砸这扇门的位置上了。 */
    private boolean isAtDoor() {
        Vec3 center = Vec3.atCenterOf(this.doorPos);
        return horizontalDistanceTo(center.x, center.z) <= KNOCK_DISTANCE
                && Math.abs(this.mob.getY() - (double)this.doorPos.getY()) <= 1.5;
    }

    private double horizontalDistanceTo(double x, double z) {
        double deltaX = this.mob.getX() - x;
        double deltaZ = this.mob.getZ() - z;
        return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
    }

    /** 这扇门是否刚被拉黑（走不到 / 砸不到，短时间别再起手）。 */
    private boolean isAbandoned(BlockPos door) {
        BlockPos abandoned = this.abandonedDoor;
        return abandoned != null
                && abandoned.equals(door)
                && this.mob.level().getGameTime() < this.abandonUntilGameTime;
    }

    /** 拉黑当前这扇门：主动破拆走到超时也用不到它。 */
    private void abandonCurrentDoor() {
        this.abandonedDoor = this.doorPos.immutable();
        this.abandonUntilGameTime = this.mob.level().getGameTime() + DOOR_ABANDON_TICKS;
    }
}
