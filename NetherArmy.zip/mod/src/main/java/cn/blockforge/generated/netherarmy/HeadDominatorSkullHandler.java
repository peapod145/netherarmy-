package cn.blockforge.generated.netherarmy;

import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 御首者追踪蓝色凋灵之首的目标记忆处理器。
 *
 * <p>弹头的实际运动不在这里另写一套制导算法，而是交给
 * {@link WitherEnhancementHandler#tickTrackingBlueSkull}，与凋灵发射的蓝色凋灵之首共用
 * 速度记忆、平滑转向、限步命中扫描和穿墙命中处理。此类只负责保存御首者施法时锁定的
 * 目标 UUID，并在目标失效后回退到御首者当前仇恨。</p>
 */
public final class HeadDominatorSkullHandler {
    /** 追踪标记：存在即视为御首者的追踪弹头。 */
    private static final String TRACK_TAG = "generated_mod_head_dominator_tracking";
    /** 首发目标 UUID（拆成两个 long 存进 PersistentData）。 */
    private static final String TRACK_TARGET_TAG = "generated_mod_head_dominator_tracking_target";

    private HeadDominatorSkullHandler() {
    }

    /** 在弹头加入世界前打上追踪印记；{@code target} 可为空（此时按发射者当前仇恨追踪）。 */
    public static void markTracking(WitherSkull skull, LivingEntity target) {
        CompoundTag data = skull.getPersistentData();
        data.putBoolean(TRACK_TAG, true);
        if (target != null) {
            UUID id = target.getUUID();
            data.putLongArray(TRACK_TARGET_TAG,
                    new long[] {id.getMostSignificantBits(), id.getLeastSignificantBits()});
        } else {
            data.remove(TRACK_TARGET_TAG);
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof WitherSkull skull)
                || !(skull.level() instanceof ServerLevel level)
                || !skull.getPersistentData().getBoolean(TRACK_TAG)
                || !(skull.getOwner() instanceof LivingEntity owner)) {
            return;
        }
        LivingEntity target = resolveTarget(level, skull);
        WitherEnhancementHandler.tickTrackingBlueSkull(skull, owner, target);
    }

    /** 追踪目标解析：优先施法时锁定的目标，失效后回退到发射者当前仇恨目标。 */
    private static LivingEntity resolveTarget(ServerLevel level, WitherSkull skull) {
        CompoundTag data = skull.getPersistentData();
        long[] pair = data.getLongArray(TRACK_TARGET_TAG);
        if (pair.length == 2) {
            Entity stored = level.getEntity(new UUID(pair[0], pair[1]));
            if (stored instanceof LivingEntity living && living.isAlive() && living != skull.getOwner()) {
                return living;
            }
        }
        if (skull.getOwner() instanceof Mob owner) {
            LivingEntity aggro = owner.getTarget();
            if (aggro != null && aggro.isAlive()) {
                return aggro;
            }
        }
        return null;
    }
}
