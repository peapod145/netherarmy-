package cn.blockforge.generated.netherarmy;

import java.util.List;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 让主人的"远程命中"和"近战命中"对灵魂土偶一视同仁。
 *
 * <p>原版只有两处会更新攻击者自己的 {@code lastHurtMob}：{@code Player#attack}
 * （玩家近战）和 {@code LivingEntity#doHurtTarget}（生物近战）。箭、弩箭、三叉戟、
 * 烟花火箭这类投射物命中时，原版只写受害者一侧的 {@code lastHurtByMob}，射手那一侧
 * 不更新。而灵魂土偶判断"主人攻击过的目标"用的正是 {@code owner.getLastHurtMob()}
 * （{@code OwnerHurtTargetGoal}，以及 {@code isHostileTarget} 里的同一条判据），
 * 于是主人拿弓弩射谁，土偶都当没看见——保镖模式不上去帮忙，侍从模式也不还手。</p>
 *
 * <p>这里在投射物造成伤害时替主人把这一步补上，后续仍然完全复用原来的判定链：
 * {@code OwnerHurtTargetGoal} 读 {@code getLastHurtMobTimestamp} 决定是否挂目标，
 * {@code isHostileTarget} 决定目标能不能打，所以近战与远程走的是同一条路，
 * 模式差异（侍从模式只打主人招惹过的目标）也自动保持一致。</p>
 *
 * <p>只在该玩家身边确有属于他的土偶时才补记：没养土偶的玩家完全不受影响，
 * 原版给狼等其他随从用的 {@code OwnerHurtTargetGoal} 行为也不会被顺手改掉。</p>
 */
public final class SoulsandFigurineRangedAggroHandler {

    /**
     * 土偶要么跟在主人身边，要么停在驻守点（警戒模式可能离主人一二百格，取一半留余量）；
     * 出了这个范围就算挂上目标也追不回来，没必要为此每次命中都全维度翻实体。
     */
    private static final double FIGURINE_SEARCH_RADIUS = 128.0D;

    private SoulsandFigurineRangedAggroHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) {
            return;
        }
        DamageSource source = event.getSource();
        // 只看"玩家射出的抛射物"：直接来源必须是弹丸本身，真正的动手人则是 getEntity()。
        // 这样箭、三叉戟、烟花火箭、投掷药水都算，而 TNT 之类间接爆炸（直接来源不是
        // Projectile）不会误判。
        if (!(source.getDirectEntity() instanceof Projectile)
                || !(source.getEntity() instanceof Player player)
                || victim == player
                || victim.isSpectator()) {
            return;
        }
        List<SoulsandFigurine> figurines = player.level().getEntitiesOfClass(
                SoulsandFigurine.class,
                player.getBoundingBox().inflate(FIGURINE_SEARCH_RADIUS),
                figurine -> figurine.isOwnedBy(player));
        if (figurines.isEmpty()) {
            return;
        }
        player.setLastHurtMob(victim);
    }
}
