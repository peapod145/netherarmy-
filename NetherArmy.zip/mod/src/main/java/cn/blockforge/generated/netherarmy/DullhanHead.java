package cn.blockforge.generated.netherarmy;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** 无头骑士的悬浮头颅：使用独立的高速飞行控制，允许头颅装备。 */
public class DullhanHead extends Slime {
    // 直接飞行的速度上限约为每 tick 0.35 格，确保头颅不会像普通史莱姆一样缓慢跳跃。
    private static final double HEAD_FLIGHT_SPEED = 0.35D;
    // 头颅固定 20 点生命；Slime.setSize 会按体型改写属性，必须逐项钉回。
    private static final double HEAD_MAX_HEALTH = 20.0D;
    private static final double HEAD_ATTACK_DAMAGE = 3.0D;
    private static final double ATTACK_RANGE_SQR = 4.0D;
    private static final int ATTACK_COOLDOWN_TICKS = 20;

    public DullhanHead(EntityType<? extends Slime> type, Level level) {
        super(type, level);
        this.moveControl = new HeadMoveControl(this);
        this.setNoGravity(true);
        this.xpReward = 5;
        // 直接复用原版小型史莱姆的同步尺寸数据，避免尺寸不同步。
        this.setSize(1, false);
    }

    @Override
    public void setSize(int size, boolean resetHealth) {
        // 无头骑士头颅始终使用小型史莱姆尺寸；Slime.setSize 会按体型数值无条件
        // 覆盖 MAX_HEALTH / MOVEMENT_SPEED / ATTACK_DAMAGE 并改写经验掉落，
        // 因此调用完父类后必须把头颅自己的属性钉回设定值。
        super.setSize(1, false);
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(HEAD_MAX_HEALTH);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(HEAD_ATTACK_DAMAGE);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(HEAD_FLIGHT_SPEED);
        this.getAttribute(Attributes.FLYING_SPEED).setBaseValue(HEAD_FLIGHT_SPEED);
        this.xpReward = 5;
        if (resetHealth) {
            this.setHealth(this.getMaxHealth());
        }
    }

    @Override
    public boolean isTiny() {
        return true;
    }

    @Override
    public EntityDimensions getDefaultDimensions(net.minecraft.world.entity.Pose pose) {
        return EntityDimensions.fixed(0.6F, 0.6F).withEyeHeight(0.3F);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanPassDoors(false);
        navigation.setCanFloat(true);
        return navigation;
    }

    @Override
    protected void registerGoals() {
        // 不注册 Slime 的跳跃目标；头颅使用直接飞行控制追击目标。
        this.goalSelector.addGoal(1, new FloatingMeleeAttackGoal(this));
        this.targetSelector.addGoal(1, new RetaliateGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /**
     * 落地时彻底去掉史莱姆同款特效与音效。
     *
     * <p>注意 {@code Slime#tick()} 里这段判定的方向：落地瞬间
     * （{@code onGround()} 由 false 翻 true）若 {@code spawnCustomParticles()}
     * 返回 {@code false}，原版会自己铺一轮 {@code ITEM_SLIME} 绿色粒子——
     * 返回 {@code true} 才表示"自定义粒子自理"并跳过整个循环。旧实现返回
     * {@code false} 恰与默认值相同，等于没改，落地照样冒史莱姆粒子。
     * 这里返回 {@code true} 且不铺任何粒子；同分支的史莱姆噗叽声由下面的
     * {@link #playSound} 拦掉（挤压动画走 {@code SlimeRenderer}，头颅用的是
     * 自定义 {@code DullhanHeadModel}，本就不吃 squash 值，无需处理）。</p>
     */
    @Override
    protected boolean spawnCustomParticles() {
        return true;
    }

    /** 只屏蔽史莱姆落地/挤压那声噗叽，其它音效（凋灵骷髅受伤、死亡声等）原样播放。 */
    @Override
    public void playSound(SoundEvent sound, float volume, float pitch) {
        if (sound != null && sound == this.getSquishSound()) {
            return;
        }
        super.playSound(sound, volume, pitch);
    }

    @Override
    public void aiStep() {
        this.setNoGravity(true);
        super.aiStep();
    }

    @Override
    protected void customServerAiStep() {
        // 目标同步由三个部件各自的 tick 完成；这里保留 Mob 的常规服务端 AI 更新。
        super.customServerAiStep();
    }

    private void driveToward(LivingEntity target) {
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        this.getMoveControl().setWantedPosition(target.getX(), target.getEyeY() - 0.3D, target.getZ(), 1.0D);
    }

    /** 不依赖寻路节点，直接朝目标飞行，避免空中目标经常丢失或移动缓慢。 */
    private static final class HeadMoveControl extends MoveControl {
        private final DullhanHead head;

        private HeadMoveControl(DullhanHead head) {
            super(head);
            this.head = head;
        }

        @Override
        public void tick() {
            if (this.operation != Operation.MOVE_TO || this.head.getVehicle() != null) {
                this.operation = Operation.WAIT;
                this.head.setDeltaMovement(this.head.getDeltaMovement().scale(0.82D));
                return;
            }
            Vec3 offset = new Vec3(this.wantedX - this.head.getX(),
                    this.wantedY - this.head.getY(), this.wantedZ - this.head.getZ());
            double distance = offset.length();
            if (distance < 0.08D) {
                this.operation = Operation.WAIT;
                this.head.setDeltaMovement(this.head.getDeltaMovement().scale(0.65D));
                return;
            }
            double speed = Math.min(HEAD_FLIGHT_SPEED,
                    Math.max(0.08D, this.speedModifier * this.head.getAttributeValue(Attributes.FLYING_SPEED)));
            Vec3 desired = offset.scale(speed / distance);
            Vec3 velocity = this.head.getDeltaMovement().scale(0.55D).add(desired.scale(0.45D));
            if (velocity.lengthSqr() > HEAD_FLIGHT_SPEED * HEAD_FLIGHT_SPEED) {
                velocity = velocity.normalize().scale(HEAD_FLIGHT_SPEED);
            }
            this.head.setDeltaMovement(velocity);
            this.head.hasImpulse = true;
            if (velocity.horizontalDistanceSqr() > 1.0E-5D) {
                this.head.setYRot((float) (Math.toDegrees(Math.atan2(-velocity.x, velocity.z))));
            }
            this.operation = Operation.WAIT;
        }
    }

    private static final class RetaliateGoal extends Goal {
        private final DullhanHead head;
        private int lastHurtTimestamp;

        private RetaliateGoal(DullhanHead head) {
            this.head = head;
        }

        @Override
        public boolean canUse() {
            LivingEntity attacker = this.head.getLastHurtByMob();
            return attacker != null && attacker.isAlive()
                    && !DullhanBody.isIgnoredTarget(attacker)
                    // 友军误伤不记仇：御首者等凋灵骷髅阵营生物的溅射/爆炸打到头颅时，
                    // 不能把头颅的反击目标钉在阵营同袍身上（门禁二在 setTarget 与
                    // LivingChangeTargetEvent 两层，这里是第一层，省掉整轮空转的起手套路）。
                    && !MesmerizerControl.sameWitherSkeletonFaction(this.head, attacker)
                    && this.head.getLastHurtByMobTimestamp() != this.lastHurtTimestamp;
        }

        @Override
        public void start() {
            LivingEntity attacker = this.head.getLastHurtByMob();
            if (attacker != null && attacker.isAlive()) {
                this.head.setTarget(attacker);
            }
            this.lastHurtTimestamp = this.head.getLastHurtByMobTimestamp();
        }
    }

    private static final class FloatingMeleeAttackGoal extends Goal {
        private final DullhanHead head;
        private int attackTime;

        private FloatingMeleeAttackGoal(DullhanHead head) {
            this.head = head;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = head.getTarget();
            return head.getVehicle() == null && target != null && target.isAlive()
                    && head.canAttack(target);
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            this.attackTime = 0;
        }

        @Override
        public void stop() {
            head.getNavigation().stop();
            head.setDeltaMovement(Vec3.ZERO);
        }

        @Override
        public void tick() {
            this.attackTime--;
            LivingEntity target = head.getTarget();
            if (target == null || !target.isAlive()) {
                return;
            }
            double distanceSqr = head.distanceToSqr(target);
            if (distanceSqr <= ATTACK_RANGE_SQR) {
                // 空中目标不再额外依赖视线判定，避免头颅贴近目标时经常无法攻击。
                if (this.attackTime <= 0) {
                    head.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                    head.doHurtTarget(target);
                    this.attackTime = ATTACK_COOLDOWN_TICKS;
                }
            } else {
                head.driveToward(target);
            }
            head.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HEAD_MAX_HEALTH)
                .add(Attributes.ATTACK_DAMAGE, HEAD_ATTACK_DAMAGE)
                .add(Attributes.MOVEMENT_SPEED, HEAD_FLIGHT_SPEED)
                .add(Attributes.FLYING_SPEED, HEAD_FLIGHT_SPEED)
                .add(Attributes.FOLLOW_RANGE, 35.0D);
    }

    /** 拦截对创造/旁观玩家的仇恨：受击反击与编组同步都不能锁定他们。 */
    @Override
    public void setTarget(LivingEntity target) {
        if (DullhanBody.isIgnoredTarget(target)) {
            return;
        }
        super.setTarget(target);
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_SKELETON_DEATH;
    }

    @Override
    public boolean canUseSlot(EquipmentSlot slot) {
        return slot == EquipmentSlot.HEAD;
    }

    @Override
    public boolean canHoldItem(net.minecraft.world.item.ItemStack stack) {
        return stack.getItem() instanceof net.minecraft.world.item.ArmorItem armor
                && armor.getType() == net.minecraft.world.item.ArmorItem.Type.HELMET;
    }

    @Override
    public boolean wantsToPickUp(net.minecraft.world.item.ItemStack stack) {
        return this.canPickUpLoot() && this.canHoldItem(stack);
    }

    @Override
    public void tick() {
        this.setNoGravity(true);
        super.tick();
        if (!this.level().isClientSide()) {
            if (this.getVehicle() instanceof DullhanBody body) {
                DullhanBody.setGroupId(this, DullhanBody.ensureGroupId(body));
                if (body.getTarget() != null) {
                    this.setTarget(body.getTarget());
                }
            }
            DullhanBody.synchronizeTargets(this);
        }
    }

    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(
            net.minecraft.world.level.ServerLevelAccessor level,
            net.minecraft.world.DifficultyInstance difficulty,
            net.minecraft.world.entity.MobSpawnType spawnType,
            net.minecraft.world.entity.SpawnGroupData groupData) {
        net.minecraft.world.entity.SpawnGroupData result =
                super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 史莱姆一系不会在 finalizeSpawn 里自动调用 populateDefaultEquipmentSlots
        // （原版只有部分怪物种接线），生成新个体时手动执行一次头盔概率。
        if (groupData == null) {
            this.populateDefaultEquipmentSlots(this.random, difficulty);
        }
        return result;
    }

    @Override
    protected void populateDefaultEquipmentSlots(net.minecraft.util.RandomSource random,
                                                  net.minecraft.world.DifficultyInstance difficulty) {
        // 生成时 10% 概率携带金头盔，10% 概率携带铁头盔（互斥）。
        float roll = random.nextFloat();
        if (roll < 0.10F) {
            this.setItemSlot(EquipmentSlot.HEAD,
                    new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GOLDEN_HELMET));
            this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        } else if (roll < 0.20F) {
            this.setItemSlot(EquipmentSlot.HEAD,
                    new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.IRON_HELMET));
            this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100), this);
        }
        return hurt;
    }
}
