package cn.blockforge.generated.netherarmy;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileItem;
import net.minecraft.world.level.Level;

/** 可像风弹一样快速投掷的凋零飞弹物品。 */
public final class WitherChargeItem extends Item implements ProjectileItem {
    private static final int COOLDOWN_TICKS = 10;

    public WitherChargeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide()) {
            WitherCharge charge = new WitherCharge(player, level, player.getViewVector(1.0F));
            charge.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.5F, 1.0F);
            level.addFreshEntity(charge);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.WIND_CHARGE_THROW, SoundSource.NEUTRAL, 0.5F,
                0.4F / (level.getRandom().nextFloat() * 0.4F + 0.8F));
        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        player.awardStat(Stats.ITEM_USED.get(this));
        stack.consume(1, player);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public Projectile asProjectile(Level level, net.minecraft.core.Position position,
                                   ItemStack stack, net.minecraft.core.Direction direction) {
        WitherCharge charge = new WitherCharge(level, position.x(), position.y(), position.z());
        charge.setItem(stack);
        charge.setDeltaMovement(direction.getStepX(), direction.getStepY(), direction.getStepZ());
        return charge;
    }
}
