package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherFactionRoster;
import cn.blockforge.generated.netherarmy.WitherFactionSupremeHostility;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 军团仇恨总闸（二）：{@code Mob#canAttackType}。
 *
 * <p>这是 {@code TargetingConditions} 在 {@code canAttack} 之后问的第二道"类型级"闸门，
 * 也是第三方模组最常覆写的一处——"同族不相残""亡灵是一家"这类设定都写在这里。军团成员
 * 的答案只有一条：名册内的类型不能打，其余全部能打。</p>
 *
 * <p>只在阵营成员作为攻击方时生效，且不做任何字段影子化。</p>
 */
@Mixin(Mob.class)
public abstract class LegionSupremeCanAttackTypeMixin {

    @Inject(method = "canAttackType(Lnet/minecraft/world/entity/EntityType;)Z", at = @At("HEAD"), cancellable = true)
    private void netherarmy$legionDecidesType(EntityType<?> type, CallbackInfoReturnable<Boolean> callback) {
        Mob self = (Mob) (Object) this;
        if (!(self instanceof LivingEntity attacker) || !WitherFactionRoster.isMember(self)) {
            return;
        }
        callback.setReturnValue(WitherFactionSupremeHostility.canLegionAttackType(attacker, type));
    }
}
