package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.ILegionAuraCarrier;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 给一切 {@link Mob} 挂上"军团光环"同步标志。
 *
 * <p>追随下界传令兵的是整个凋灵骷髅阵营——原版凋灵骷髅、狂战士、下界猎手、
 * 无头骑士三件套、反逆者、衰翼、尸鬼，类各不相同，逐个加实体数据不现实；
 * 光环又是纯状态标志（服务端集中结算、客户端只读着画贴图），用原版同步数据
 * 通道最合适，于是混入公共父类 {@code Mob} 一处搞定。</p>
 *
 * <p>注入点 {@code defineSynchedData(SynchedEntityData.Builder)} 是 1.20.5+ 的
 * Builder 形态签名；在 TAIL 处补一条布尔项，默认 false，实体死亡/重载后由
 * {@code LegionAuraHandler} 每 20 tick 重算，无需持久化。</p>
 */
@Mixin(Mob.class)
public abstract class LegionAuraMobMixin implements ILegionAuraCarrier {

    @Unique
    private static final EntityDataAccessor<Boolean> netherarmy$LEGION_AURA =
            SynchedEntityData.defineId(Mob.class, EntityDataSerializers.BOOLEAN);

    @Inject(method = "defineSynchedData", at = @At("TAIL"))
    private void netherarmy$defineLegionAura(SynchedEntityData.Builder builder, CallbackInfo callback) {
        builder.define(netherarmy$LEGION_AURA, false);
    }

    @Override
    public boolean netherarmy$hasLegionAura() {
        return ((Mob) (Object) this).getEntityData().get(netherarmy$LEGION_AURA);
    }

    @Override
    public void netherarmy$setLegionAura(boolean value) {
        ((Mob) (Object) this).getEntityData().set(netherarmy$LEGION_AURA, value);
    }
}
