package cn.blockforge.generated.netherarmy;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.furnace.FurnaceFuelBurnTimeEvent;

/**
 * 炼狱晶碎片的熔炉燃料注册：燃烧时间 30 秒（600 tick）。原版每个物品要烧 200 tick，
 * 单看燃烧时长是"一枚碎片 ≈ 3 个物品"；但配方烧炼速度另有 3 倍加成
 * （见 {@link cn.blockforge.generated.netherarmy.mixin.CrystalShardSmeltingSpeedMixin}），
 * 所以实际一枚碎片能在 30 秒里烧出 9 个物品，相当于 66~67 tick 一个。
 * 对比：煤炭 1600 tick / 80 秒、正常速度 8 个物品。
 *
 * 实现说明：1.21.1 的燃烧时长查询链路是
 * {@code ItemStack#getBurnTime} → {@code Item#getBurnTime}（读 neoforge:fuel 数据映射）
 * → 再统一后置 {@link FurnaceFuelBurnTimeEvent}。事件在每次查询时都会投递，
 * 因此这里改写事件值即可同时覆盖燃料槽的可放入判定与熔炉实际燃烧，
 * 与煤炭一样在所有查询熔炉燃烧时间的场合（熔炉/高炉/烟熏炉/营火）生效。
 */
public final class CrystalShardFuelHandler {
    /** 30 秒 × 20 tick/秒。 */
    private static final int BURN_TIME_TICKS = 600;

    private CrystalShardFuelHandler() {}

    @SubscribeEvent
    public static void onFuelBurnTime(FurnaceFuelBurnTimeEvent event) {
        if (event.getItemStack().is(GeneratedMod.NETHER_CRYSTAL_SHARD.get())) {
            event.setBurnTime(BURN_TIME_TICKS);
        }
    }
}
