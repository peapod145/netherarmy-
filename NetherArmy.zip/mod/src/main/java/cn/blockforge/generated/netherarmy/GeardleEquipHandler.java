package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 世界天数驱动的凋灵骷髅阵营装备进阶。 */
public final class GeardleEquipHandler {
    private static final long DAY = 24000L;
    private static final String STAGE_EQUIPPED_TAG = "netherarmy_geardle_stage_equipped";

    private GeardleEquipHandler() {
    }

    private enum Tier {
        NONE, IRON_PLAIN, IRON_ENCHANTED, NETHERITE_ENCHANTED, CRYSTAL_MEDIUM, CRYSTAL_MAX
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (mob instanceof BlitzDullhanBody || mob instanceof BlitzDullhanHead
                || mob instanceof BlitzDullhanHorse) {
            return;
        }

        ServerLevel level = (ServerLevel) event.getLevel();
        long time = level.getDayTime();
        if (mob instanceof DullhanHorse horse) {
            if (time > 20L * DAY && horse.getItemBySlot(EquipmentSlot.BODY).isEmpty()) {
                horse.setItemSlot(EquipmentSlot.BODY,
                        new ItemStack(GeneratedMod.NETHER_CRYSTAL_HORSE_ARMOR.get()));
                horse.setDropChance(EquipmentSlot.BODY, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
            }
            return;
        }
        if (time <= 5L * DAY || !isEquipmentTarget(mob)
                || mob.getPersistentData().getBoolean(STAGE_EQUIPPED_TAG)) {
            return;
        }
        mob.getPersistentData().putBoolean(STAGE_EQUIPPED_TAG, true);

        RandomSource random = mob.getRandom();
        Tier tier = chooseTier(time, random);
        if (tier == Tier.NONE) {
            return;
        }
        equipArmor(level, mob, random, tier);
        equipWeapon(level, mob, random, tier);
    }

    private static boolean isEquipmentTarget(Mob mob) {
        if (mob.getType() == EntityType.WITHER_SKELETON) {
            return true;
        }
        return mob instanceof Berserker && !(mob instanceof Bedserker)
                || mob instanceof NetherHunter
                || mob instanceof DullhanBody || mob instanceof DullhanHead
                || mob instanceof Mesmerizer || mob instanceof HeadDominator
                || mob instanceof NetherCourier || mob instanceof WitherGhost
                || mob instanceof WitherZombie || mob instanceof Hacker;
    }

    private static Tier chooseTier(long time, RandomSource random) {
        if (time > 30L * DAY) {
            return Tier.CRYSTAL_MAX;
        }
        if (time > 20L * DAY) {
            return random.nextFloat() < 0.50F ? Tier.CRYSTAL_MEDIUM : chooseTenDayTier(random);
        }
        if (time > 10L * DAY) {
            return chooseTenDayTier(random);
        }
        return random.nextFloat() < 0.50F ? Tier.IRON_PLAIN : Tier.NONE;
    }

    private static Tier chooseTenDayTier(RandomSource random) {
        return random.nextFloat() < 0.20F ? Tier.IRON_ENCHANTED : Tier.NETHERITE_ENCHANTED;
    }

    private static void equipArmor(ServerLevel level, Mob mob, RandomSource random, Tier tier) {
        if (mob instanceof DullhanHead) {
            if (!isProtectedHelmet(mob.getItemBySlot(EquipmentSlot.HEAD))) {
                ItemStack helmet = new ItemStack(helmetFor(tier));
                enchantForTier(level, random, helmet, EquipmentSlot.HEAD, tier);
                mob.setItemSlot(EquipmentSlot.HEAD, helmet);
                mob.setDropChance(EquipmentSlot.HEAD, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
            }
            return;
        }
        if (!(mob instanceof DullhanBody) && !isProtectedHelmet(mob.getItemBySlot(EquipmentSlot.HEAD))) {
            ItemStack helmet = new ItemStack(helmetFor(tier));
            enchantForTier(level, random, helmet, EquipmentSlot.HEAD, tier);
            mob.setItemSlot(EquipmentSlot.HEAD, helmet);
            mob.setDropChance(EquipmentSlot.HEAD, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
        }
        ItemStack chest = new ItemStack(chestplateFor(tier));
        ItemStack legs = new ItemStack(leggingsFor(tier));
        ItemStack boots = new ItemStack(bootsFor(tier));
        enchantForTier(level, random, chest, EquipmentSlot.CHEST, tier);
        enchantForTier(level, random, legs, EquipmentSlot.LEGS, tier);
        enchantForTier(level, random, boots, EquipmentSlot.FEET, tier);
        mob.setItemSlot(EquipmentSlot.CHEST, chest);
        mob.setItemSlot(EquipmentSlot.LEGS, legs);
        mob.setItemSlot(EquipmentSlot.FEET, boots);
        mob.setDropChance(EquipmentSlot.CHEST, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
        mob.setDropChance(EquipmentSlot.LEGS, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
        mob.setDropChance(EquipmentSlot.FEET, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
    }

    private static boolean isProtectedHelmet(ItemStack stack) {
        return stack.is(GeneratedMod.BERSERKER_HELMET.get())
                || stack.is(GeneratedMod.MESMERIZER_CROWN.get());
    }

    private static Item helmetFor(Tier tier) {
        return switch (tier) {
            case IRON_PLAIN, IRON_ENCHANTED -> Items.IRON_HELMET;
            case NETHERITE_ENCHANTED -> Items.NETHERITE_HELMET;
            case CRYSTAL_MEDIUM, CRYSTAL_MAX -> GeneratedMod.NETHER_CRYSTAL_HELMET.get();
            default -> Items.IRON_HELMET;
        };
    }

    private static Item chestplateFor(Tier tier) {
        return switch (tier) {
            case IRON_PLAIN, IRON_ENCHANTED -> Items.IRON_CHESTPLATE;
            case NETHERITE_ENCHANTED -> Items.NETHERITE_CHESTPLATE;
            case CRYSTAL_MEDIUM, CRYSTAL_MAX -> GeneratedMod.NETHER_CRYSTAL_CHESTPLATE.get();
            default -> Items.IRON_CHESTPLATE;
        };
    }

    private static Item leggingsFor(Tier tier) {
        return switch (tier) {
            case IRON_PLAIN, IRON_ENCHANTED -> Items.IRON_LEGGINGS;
            case NETHERITE_ENCHANTED -> Items.NETHERITE_LEGGINGS;
            case CRYSTAL_MEDIUM, CRYSTAL_MAX -> GeneratedMod.NETHER_CRYSTAL_LEGGINGS.get();
            default -> Items.IRON_LEGGINGS;
        };
    }

    private static Item bootsFor(Tier tier) {
        return switch (tier) {
            case IRON_PLAIN, IRON_ENCHANTED -> Items.IRON_BOOTS;
            case NETHERITE_ENCHANTED -> Items.NETHERITE_BOOTS;
            case CRYSTAL_MEDIUM, CRYSTAL_MAX -> GeneratedMod.NETHER_CRYSTAL_BOOTS.get();
            default -> Items.IRON_BOOTS;
        };
    }

    private static void equipWeapon(ServerLevel level, Mob mob, RandomSource random, Tier tier) {
        ItemStack current = mob.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!isReplaceableMelee(current)) {
            return;
        }
        boolean berserker = mob instanceof Berserker;
        Item weapon = switch (tier) {
            case IRON_PLAIN, IRON_ENCHANTED -> berserker ? Items.IRON_AXE : Items.IRON_SWORD;
            case NETHERITE_ENCHANTED -> berserker ? Items.NETHERITE_AXE : Items.NETHERITE_SWORD;
            case CRYSTAL_MEDIUM, CRYSTAL_MAX -> GeneratedMod.DISHA_BATTLE_AXE.get();
            default -> current.getItem();
        };
        ItemStack replacement = new ItemStack(weapon);
        enchantForTier(level, random, replacement, EquipmentSlot.MAINHAND, tier);
        mob.setItemSlot(EquipmentSlot.MAINHAND, replacement);
        mob.setDropChance(EquipmentSlot.MAINHAND, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
    }

    private static boolean isReplaceableMelee(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.WOODEN_SWORD || item == Items.STONE_SWORD || item == Items.GOLDEN_SWORD
                || item == Items.IRON_SWORD || item == Items.WOODEN_AXE || item == Items.STONE_AXE
                || item == Items.GOLDEN_AXE || item == Items.IRON_AXE;
    }

    private static void enchantForTier(ServerLevel level, RandomSource random, ItemStack stack,
                                       EquipmentSlot slot, Tier tier) {
        if (tier == Tier.IRON_PLAIN || tier == Tier.NONE) {
            return;
        }
        HolderLookup.RegistryLookup<Enchantment> registry =
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (Holder.Reference<Enchantment> holder : registry.listElements().toList()) {
            Enchantment enchantment = holder.value();
            if (holder.is(Enchantments.BINDING_CURSE) || holder.is(Enchantments.VANISHING_CURSE)
                    || !enchantment.canEnchant(stack) || !enchantment.matchingSlot(slot)) {
                continue;
            }
            candidates.add(holder);
        }
        for (int i = candidates.size() - 1; i > 0; i--) {
            int swap = random.nextInt(i + 1);
            Holder.Reference<Enchantment> value = candidates.get(i);
            candidates.set(i, candidates.get(swap));
            candidates.set(swap, value);
        }
        List<Holder<Enchantment>> applied = new ArrayList<>();
        int count = 1 + random.nextInt(3);
        for (Holder.Reference<Enchantment> holder : candidates) {
            if (applied.size() >= count) {
                break;
            }
            if (applied.stream().anyMatch(existing -> !Enchantment.areCompatible(existing, holder))) {
                continue;
            }
            Enchantment enchantment = holder.value();
            int max = enchantment.getMaxLevel();
            int levelValue;
            if (tier == Tier.CRYSTAL_MAX) {
                levelValue = max;
            } else if (tier == Tier.CRYSTAL_MEDIUM) {
                levelValue = max <= 2 ? max : 2 + random.nextInt(max - 1);
            } else {
                levelValue = Math.min(max, 1 + random.nextInt(2));
            }
            stack.enchant(holder, Math.max(enchantment.getMinLevel(), levelValue));
            applied.add(holder);
        }
    }
}
