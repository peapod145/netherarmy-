package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulsandFigurineSummon;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.CarvedPumpkinBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** 南瓜头叠两块灵魂土时召唤灵魂土偶，检测口径与雪傀儡相同。 */
@Mixin(CarvedPumpkinBlock.class)
public abstract class CarvedPumpkinSoulFigurineMixin {
    @Inject(method = "trySpawnGolem", at = @At("HEAD"))
    private void netherarmy$trySpawnSoulFigurine(Level level, BlockPos pos, CallbackInfo callback) {
        SoulsandFigurineSummon.trySpawn(level, pos);
    }

    @Inject(method = "canSpawnGolem", at = @At("RETURN"), cancellable = true)
    private void netherarmy$canSpawnSoulFigurine(LevelReader level, BlockPos pos,
                                                CallbackInfoReturnable<Boolean> callback) {
        if (!callback.getReturnValueZ() && SoulsandFigurineSummon.canSpawn(level, pos)) {
            callback.setReturnValue(true);
        }
    }
}
