package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** 灵魂土偶界面里切换行为模式的网络处理。 */
public final class SoulsandFigurineModeSync {
    private SoulsandFigurineModeSync() {
    }

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(SoulsandFigurineModePayload.TYPE, SoulsandFigurineModePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> {
                    if (!(context.player() instanceof ServerPlayer player)) {
                        return;
                    }
                    if (!(player.level().getEntity(payload.entityId()) instanceof SoulsandFigurine figurine)) {
                        return;
                    }
                    // 只有能配置这只土偶的玩家（召唤者本人，无主土偶不设限）才允许换模式。
                    if (!figurine.canConfigure(player)
                            || !player.canInteractWithEntity(figurine, 8.0D)) {
                        return;
                    }
                    figurine.setMode(figurine.getMode().next());
                }));
    }
}
