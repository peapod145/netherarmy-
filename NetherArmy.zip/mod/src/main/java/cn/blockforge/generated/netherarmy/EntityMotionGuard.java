package cn.blockforge.generated.netherarmy;

import java.util.concurrent.atomic.AtomicInteger;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 速度兜底：把外部模组灌进实体身上的"天文数字速度"收回到可结算范围。
 *
 * <p><b>为什么需要这道护栏：</b>1.21.1 的 {@code Entity#move} 会把
 * {@code getBoundingBox().expandTowards(位移)} 当成碰撞搜索盒交给
 * {@code EntitySectionStorage#forEachAccessibleNonEmptySection}，而这个方法把盒子的
 * min/max 用 {@code SectionPos.asLong} 打包成 long 再取 {@code subSet}。打包只留了
 * 每轴 22 位（section 坐标），也就是大约 ±6700 万格。一旦某个实体的
 * {@code deltaMovement} 到了 10<sup>12</sup> 这一档（本模组遇到过的实例：
 * {@code spore:inf_human} 的 Momentum 是 1.98e12 / -2.47e12 / -4.71e12），
 * 打包结果就会回绕成 start &gt; end，直接抛
 * {@code IllegalArgumentException: Start element (...) is larger than end element (...)}
 * 并把整局游戏崩掉。抛出点在原版/Lithium 的公共路径上，谁写坏了速度都不会幸免。</p>
 *
 * <p><b>为什么放在本模组里：</b>那种速度不是原版物理能产生的（原版最快也就自由落体的
 * 3.92 格/tick、鞘翅大约 4 格/tick），只能是某个模组把速度算爆了。本模组既不能替别人
 * 修它，也没法保证玩家不装那样的模组，所以只做"收拾结果"这一层：每 tick 在实体
 * tick 之前把速度收进 {@link #MAX_SPEED_PER_TICK}，让碰撞盒永远是小盒子，
 * 崩服那一处就不可能被触发。</p>
 *
 * <p><b>两层：</b></p>
 * <ol>
 *   <li>{@link #onEntityTick}（{@link EntityTickEvent.Pre}，服务端与客户端都跑）：
 *       把<b>存着的</b> {@code deltaMovement} 归一，顺带让这种脏速度不再被写进存档
 *       （实体的 Motion 是存盘的，脏速度会被带进下一局）。</li>
 *   <li>{@link cn.blockforge.generated.netherarmy.mixin.EntityMoveSpeedGuardMixin}：
 *       在 {@code Entity#move} 入口再卡一次<b>这一 tick 的位移实参</b>。有些模组是在
 *       自己的 {@code travel}/{@code tick} 里当场把速度写爆、紧接着就 {@code move}
 *       的，只靠上一层的"上一 tick 状态"挡不住，必须在调用点兜住。</li>
 * </ol>
 *
 * <p><b>阈值取多松：</b>{@value #MAX_SPEED_PER_TICK} 格/tick 是原版最快速度的十几倍，
 * 正常玩法、击退、爆炸、本模组自己的冲锋（下界载体撞击最高 0.4 格/tick）都远远够用；
 * 超过它的值无一例外是"算错了"，压回去不会误伤正经机制。方向保持不变（按向量长度等比
 * 缩小），所以被压过的实体仍然朝原方向飞，只是不再超速。非有限值（NaN/Infinity）直接
 * 归零——它们在任何物理公式里都已经没有意义了。</p>
 */
public final class EntityMotionGuard {

    /**
     * 单 tick 速度上限（格/tick）。原版自由落体约 3.92、鞘翅约 4、击退不到 1，
     * 这里给到十几倍余量，只为拦住"模组算爆了"的那一档。
     */
    public static final double MAX_SPEED_PER_TICK = 64.0D;

    /** 同样的消息只打前若干条，避免每 tick 刷屏把日志撑爆。 */
    private static final int MAX_WARNINGS = 8;
    private static final AtomicInteger WARNINGS = new AtomicInteger();

    private EntityMotionGuard() {
    }

    /**
     * 把速度向量收进"长度 ≤ {@link #MAX_SPEED_PER_TICK}、每个分量都是有限值"的范围。
     *
     * <p>没有问题时<b>原样返回同一个对象</b>（不分配），调用方因此可以用引用比较判断
     * "到底改没改"，逐实体逐 tick 的常规路径上零开销。</p>
     */
    public static Vec3 clamp(Vec3 motion) {
        double x = finite(motion.x);
        double y = finite(motion.y);
        double z = finite(motion.z);
        double lengthSqr = x * x + y * y + z * z;
        double maxSqr = MAX_SPEED_PER_TICK * MAX_SPEED_PER_TICK;
        if (lengthSqr <= maxSqr) {
            return x == motion.x && y == motion.y && z == motion.z ? motion : new Vec3(x, y, z);
        }
        // lengthSqr 即便溢出成 Infinity，scale 也会落到 0，结果同样是"停住"，不会变成 NaN。
        double scale = MAX_SPEED_PER_TICK / Math.sqrt(lengthSqr);
        return new Vec3(x * scale, y * scale, z * scale);
    }

    private static double finite(double value) {
        return Double.isFinite(value) ? value : 0.0D;
    }

    /** 第二层：{@code Entity#move} 入口处对"这一 tick 的位移"再卡一次。 */
    public static Vec3 guardMovementStep(Entity entity, Vec3 movement) {
        Vec3 clamped = clamp(movement);
        if (clamped != movement) {
            warn(entity, movement, clamped, "单 tick 位移");
        }
        return clamped;
    }

    /** 第一层：每个实体 tick 之前归一它身上存着的速度。 */
    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        Entity entity = event.getEntity();
        Vec3 motion = entity.getDeltaMovement();
        Vec3 clamped = clamp(motion);
        if (clamped == motion) {
            return;
        }
        entity.setDeltaMovement(clamped);
        warn(entity, motion, clamped, "速度");
    }

    /**
     * 打一条限幅日志（有上限）。日志里带上实体类型、id 与位置，方便玩家把这条贴给
     * 真正写坏速度的那个模组——本模组只是兜底，根因不在这一侧。
     */
    public static void warn(Entity entity, Vec3 before, Vec3 after, String what) {
        int count = WARNINGS.incrementAndGet();
        if (count > MAX_WARNINGS) {
            return;
        }
        GeneratedMod.LOGGER.warn("[netherarmy] 实体 {}（id={}）的{}超出安全范围，已限幅：{} → {}，"
                        + "位置 ({}, {}, {})（第 {} 条，超出后不再打印）。这类速度通常来自外部模组"
                        + "把速度算爆，本模组在此兜底，避免 move() 的碰撞盒溢出把游戏崩掉。",
                BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()), entity.getId(), what,
                before, after, entity.getX(), entity.getY(), entity.getZ(), count);
    }
}
