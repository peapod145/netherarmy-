package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireBurn;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 只挂接到已有的 Entity 生命周期方法，避免注入 1.21.1 的抽象 defineSynchedData。 */
@Mixin(Entity.class)
public abstract class SoulFireEntityMixin {
    /** 灵魂火状态随实际燃烧结束清理；客户端火焰改由渲染器替换为灵魂火覆盖层。 */
    @Inject(method = "baseTick", at = @At("TAIL"))
    private void netherarmy$clearExpiredSoulFlame(CallbackInfo callback) {
        Entity self = (Entity) (Object) this;
        if (self.level().isClientSide()) {
            return;
        }
        if (SoulFireBurn.isSoulFlame(self)
                && self.getRemainingFireTicks() <= 0
                && !SoulFireBurn.isSelfSustained(self)) {
            SoulFireBurn.setSoulFlame(self, false);
        }
    }
}
