package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireBurn;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 只挂接到已有的 Entity 生命周期方法，避免注入 1.21.1 的抽象 defineSynchedData。 */
@Mixin(Entity.class)
public abstract class SoulFireEntityMixin {
    /**
     * 灵魂火状态随实际燃烧结束清理；客户端火焰改由渲染器替换为灵魂火覆盖层。
     *
     * <p>注意这里用的是 {@code getRemainingFireTicks()} 而不是 {@code isOnFire()}：
     * 免疫火焰的实体（例如本模组的熔髓）被灵魂火打中时不会显示火焰，但标记还带着
     * "我被灵魂火打过"的含义，{@code Emberbone#touchesSoulFire} 靠它切形态，所以要让
     * 它跟着燃烧刻数自然耗尽，不能立刻清掉。</p>
     */
    @Inject(method = "baseTick", at = @At("TAIL"))
    private void netherarmy$clearExpiredSoulFlame(CallbackInfo callback) {
        Entity self = (Entity) (Object) this;
        if (self.level().isClientSide()) {
            return;
        }
        if (SoulFireBurn.isSoulFlame(self)
                && self.getRemainingFireTicks() <= 0
                && !SoulFireBurn.isSelfSustained(self)) {
            SoulFireBurn.setSoulFlame(self, false);
        }
    }

    /**
     * 普通火源（火焰弹、火矢、火矢附魔、岩浆、闪电……）真正接管燃烧时，把上一次灵魂火
     * 留下的标记摘掉，火焰覆盖层回到原版橙焰。
     *
     * <p>判定放在 {@code igniteForTicks} 的 HEAD、并且只在"这次点燃确实会延长燃烧"时
     * 才清：</p>
     * <ul>
     *   <li>{@code igniteForTicks} 本身只在 {@code remainingFireTicks < ticks} 时才生效，
     *       不生效说明燃烧仍是原来的那一段，标记也该保持原样；</li>
     *   <li>灵魂火矢命中时，{@link SoulFireBurn#ignite} 已经在 {@code ProjectileImpactEvent}
     *       里把目标点着并挂上标记，随后原版 {@code AbstractArrow} 又会给目标来一次
     *       5 秒的普通点燃——那一次因为目标已经烧得更久而不会生效，于是不会误清标记。</li>
     * </ul>
     *
     * <p>只处理生物：箭矢身上的标记是"灵魂火矢"的判定依据，不能被普通点燃顺手抹掉。</p>
     */
    @Inject(method = "igniteForTicks", at = @At("HEAD"))
    private void netherarmy$clearSoulFlameOnNormalIgnite(int ticks, CallbackInfo callback) {
        Entity self = (Entity) (Object) this;
        if (self.level().isClientSide() || !(self instanceof LivingEntity)) {
            return;
        }
        if (self.getRemainingFireTicks() >= ticks) {
            return;
        }
        SoulFireBurn.setSoulFlame(self, false);
    }
}
