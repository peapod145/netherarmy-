package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 被尸鬼吓跑的实体会主动远离尸鬼（苦力怕躲猫式的"发现即逃"）。
 *
 * <p>本类是原版 {@code AvoidEntityGoal} 的等价替身，存在的唯一理由是把导航器改成
 * <b>每刻现取</b>：原版在构造时就把 {@code mob.getNavigation()} 存进 final 字段
 * {@code pathNav}，之后建路（{@code canUse}）、走路（{@code start}）、判"走完了没有"
 * （{@code canContinueToUse = !pathNav.isDone()}）全用它。这对普通怪没问题——僵尸、尸壳、
 * 僵尸村民一辈子只有一个导航器。但溺尸不是：{@code Mob} 构造器先建了一个
 * {@code GroundPathNavigation}，{@code Drowned} 构造器又另建 {@code waterNavigation} 与
 * {@code groundNavigation} 两套，之后每刻由 {@code Drowned#updateSwimming()}（在
 * {@code Entity#baseTick} 里）按"在水里且目标也在水里"把 {@code this.navigation} 在两套之间
 * 来回换，那个最初的实例永远不再被换回来、也永远不再被 {@code Mob#aiStep} 调 {@code tick()}。
 * 于是在实体入世界的瞬间构造的 {@code AvoidEntityGoal} 攥着的正是一个没人驱动的导航器：
 * 路建在它身上、移动指令下给它，溺尸本体一步不动；更要命的是它的 {@code isDone()} 永远为假
 * （路径从不推进），{@code canContinueToUse} 就永远为真——这条优先级 1、占着
 * {@code Flag.MOVE} 的目标一旦启动就再也不撒手，把溺尸优先级 2 的近战（{@code DrownedAttackGoal}）
 * 与三叉戟远程（{@code DrownedTridentAttackGoal}）一并锁死。这正是"溺尸既不逃、挨打也不反击"
 * 的来源：不是没挂 AI，而是挂上去的 AI 卡住后把整个移动/攻击管线全堵死了。</p>
 *
 * <p>本类所有导航操作都走 {@code mob.getNavigation()}，导航器被换掉的下一刻
 * {@code isDone()} 自然为真，{@link #tick()} 就在新的导航器上重铺一条逃逸路线，
 * 溺水态（{@code WaterBoundPathNavigation}，只能在水格中建路）与陆地态
 * （{@code GroundPathNavigation}）都能真的跑起来。</p>
 *
 * <p>与原版 {@code AvoidEntityGoal} 的其余语义保持一致：8 格内"看见"尸鬼
 * （{@link TargetingConditions#forCombat()}，带视线校验，隔墙不算发现）即朝反方向重新寻路，
 * 7 格内提速到 1.2 倍。差别只有四处：一是摆脱半径放到发现半径的 1.5 倍（12 格）再收手，
 * 免得在原地反复起停；二是逃逸点按水陆分开挑（见 {@link #escapeCandidates}）；三是
 * {@link #isFightBackAgainstGhoul()} 为真（它已经把打自己的那只尸鬼记成仇恨目标）时主动让位，
 * 不抢移动控制权，否则"逃跑"会把"反击"整条吃掉；四是 {@code canContinueToUse} 不再挂靠在
 * "路走完了没"上，而是距离 + 连续铺不出路 {@value #MAX_FAILED_REPATHS} 次即撒手——
 * 无论地形多别扭，这条目标都不可能再把实体永久钉在原地。</p>
 */
public final class WitherZombiePreyFleeGoal extends Goal {
    /** 近身（<7 格）奔逃阈值（平方距离，苦力怕躲猫同款 49.0）。 */
    private static final double SPRINT_DISTANCE_SQR = 49.0D;
    /** 未运行时多久扫一次周围（刻）：一次扫描最坏要拿几个候选点各跑一遍寻路。 */
    private static final int SCAN_INTERVAL_TICKS = 5;
    /** 路线走完/导航器换掉之后，多久允许重铺一次（刻）。 */
    private static final int REPATH_INTERVAL_TICKS = 10;
    /** 一次铺路最多试几个候选点（寻路是按跟随距离开大方块的，不能无限试）。 */
    private static final int MAX_ESCAPE_ATTEMPTS = 3;
    /** 连续铺不出路线的容忍次数，超过就撒手让出移动控制权。 */
    private static final int MAX_FAILED_REPATHS = 3;
    /** 水中逃逸点探测的水平距离（由远及近，取第一个还在水里的）。 */
    private static final double[] WATER_PROBE_DISTANCES = {6.0D, 4.0D, 3.0D, 2.0D};
    /** 水中逃逸点探测的上下偏移（贴着当前深度 → 往水面 → 往水底）。 */
    private static final double[] WATER_PROBE_HEIGHT_OFFSETS = {0.0D, 0.7D, -0.7D};
    /** 岸上随机逃逸点参数，与原版 {@code AvoidEntityGoal} 逐字相同。 */
    private static final int LAND_PROBE_RADIUS = 16;
    private static final int LAND_PROBE_HEIGHT = 7;

    private final PathfinderMob mob;
    private final float maxDist;
    /** 摆脱半径：发现半径的 1.5 倍，留出滞回区间，逃到位才让位给别的目标。 */
    private final double stopDist;
    private final double walkSpeedModifier;
    private final double sprintSpeedModifier;
    private final TargetingConditions avoidTargeting;
    private LivingEntity danger;
    private Path path;
    private int repathCooldown;
    /** 未运行时的扫描节流：扫一次周围要连带好几次寻路，不能每刻都来。 */
    private int scanCooldown;
    /**
     * 连着铺不出逃逸路线的次数。原版 {@code AvoidEntityGoal} 卡死溺尸就是这么来的：
     * 路建不成还赖着不走，把移动控制权一直占住。这里给它一个上限，到点就主动撒手，
     * 让溺尸该干嘛干嘛（下一次扫描再来试），绝不把整条 goalSelector 堵死。
     */
    private int failedRepathStrikes;

    /**
     * @param mob                 会逃跑的实体
     * @param radius              发现半径（格）
     * @param walkSpeedModifier   常态移速系数
     * @param sprintSpeedModifier 近身奔逃移速系数
     */
    public WitherZombiePreyFleeGoal(PathfinderMob mob, float radius,
                                    double walkSpeedModifier, double sprintSpeedModifier) {
        this.mob = mob;
        this.maxDist = radius;
        this.stopDist = radius * 1.5D;
        this.walkSpeedModifier = walkSpeedModifier;
        this.sprintSpeedModifier = sprintSpeedModifier;
        // TargetingConditions.range 存的是"线性距离"（test 里再平方比较），与原版传 maxDist 一致。
        this.avoidTargeting = TargetingConditions.forCombat()
                .range(radius)
                .selector(EntitySelector.NO_CREATIVE_OR_SPECTATOR::test);
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        // 导航器被溺尸每刻换，重铺路线必须逐刻判定，不能被隔刻节流拖慢半拍。
        return true;
    }

    @Override
    public boolean canUse() {
        if (this.isFightBackAgainstGhoul()) {
            return false;
        }
        if (this.scanCooldown > 0) {
            this.scanCooldown--;
            return false;
        }
        this.scanCooldown = SCAN_INTERVAL_TICKS;
        LivingEntity ghoul = this.findNearestGhoul();
        if (ghoul == null) {
            return false;
        }
        Path path = this.createEscapePath(ghoul);
        if (path == null) {
            return false;
        }
        this.danger = ghoul;
        this.path = path;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return this.danger != null
                && this.danger.isAlive()
                && !this.isFightBackAgainstGhoul()
                && this.failedRepathStrikes < MAX_FAILED_REPATHS
                && this.mob.distanceToSqr(this.danger) <= this.stopDist * this.stopDist;
    }

    @Override
    public void start() {
        this.repathCooldown = REPATH_INTERVAL_TICKS;
        this.failedRepathStrikes = 0;
        if (this.path != null && this.danger != null) {
            this.mob.getNavigation().moveTo(this.path, this.speedFor(this.danger));
        }
    }

    @Override
    public void stop() {
        this.danger = null;
        this.path = null;
        this.repathCooldown = 0;
        this.failedRepathStrikes = 0;
    }

    @Override
    public void tick() {
        LivingEntity ghoul = this.danger;
        if (ghoul == null) {
            return;
        }
        PathNavigation navigation = this.mob.getNavigation();
        double speed = this.speedFor(ghoul);
        navigation.setSpeedModifier(speed);
        if (this.repathCooldown > 0) {
            this.repathCooldown--;
            return;
        }
        this.repathCooldown = REPATH_INTERVAL_TICKS;
        // 只在"没有路线在推进"时重铺：换导航器（溺尸入水/出水、仇恨目标变化）后 isDone 必为真，
        // 正好在这一刻把逃逸路线重建到当前真正被驱动的那套导航器上。
        if (!navigation.isDone()) {
            this.failedRepathStrikes = 0;
            return;
        }
        Path next = this.createEscapePath(ghoul);
        if (next == null) {
            this.failedRepathStrikes++;
            return;
        }
        this.failedRepathStrikes = 0;
        this.path = next;
        navigation.moveTo(next, speed);
    }

    /**
     * 它正在跟打自己的那只尸鬼对上了——此时"反击"优先，逃跑不抢移动控制权。
     *
     * <p>原版僵尸系的仇恨名册里根本没有尸鬼（僵尸只索敌玩家/村民/铁傀儡/海龟），能把它
     * 指向尸鬼的只有 {@code HurtByTargetGoal}——也就是"谁打了我"。所以这个条件就是
     * "正在反击"的准确定义，不会让它平白放弃逃跑去追一只没招惹它的尸鬼。</p>
     */
    private boolean isFightBackAgainstGhoul() {
        LivingEntity target = this.mob.getTarget();
        return target instanceof WitherZombie && target == this.mob.getLastHurtByMob();
    }

    /** 视野内最近的一只尸鬼（隔墙不算看见），没有则返回 {@code null}。 */
    private LivingEntity findNearestGhoul() {
        Level level = this.mob.level();
        AABB scan = this.mob.getBoundingBox().inflate(this.maxDist, 3.0D, this.maxDist);
        List<WitherZombie> nearby = level.getEntitiesOfClass(WitherZombie.class, scan, entity -> true);
        return level.getNearestEntity(nearby, this.avoidTargeting, this.mob,
                this.mob.getX(), this.mob.getY(), this.mob.getZ());
    }

    private double speedFor(LivingEntity ghoul) {
        return ghoul != null && this.mob.distanceToSqr(ghoul) < SPRINT_DISTANCE_SQR
                ? this.sprintSpeedModifier : this.walkSpeedModifier;
    }

    /** 拿候选逃逸点依次到<b>当前</b>导航器上建路，第一个成功的就是路线。 */
    private Path createEscapePath(LivingEntity ghoul) {
        PathNavigation navigation = this.mob.getNavigation();
        List<Vec3> candidates = this.escapeCandidates(ghoul);
        int attempts = Math.min(candidates.size(), MAX_ESCAPE_ATTEMPTS);
        for (int i = 0; i < attempts; i++) {
            Vec3 candidate = candidates.get(i);
            Path path = navigation.createPath(candidate.x, candidate.y, candidate.z, 0);
            if (path != null) {
                return path;
            }
        }
        return null;
    }

    /**
     * 候选逃逸点，按"越远越优先、越可能建出路优先"排。
     *
     * <p>水里不能照抄原版的 {@code DefaultRandomPos.getPosAway}：那个取点器只挑"上方是空气、
     * 脚下能站"的岸上格，对泡在水里的溺尸几乎必然返回 {@code null}；而
     * {@code WaterBoundPathNavigation} 用的 {@code SwimNodeEvaluator} 只在水格里建节点，
     * 拿一个空气格去建路只会拿到空路径。所以水中分支沿"威胁→自己"的反方向，按 6/4/3/2 格
     * 与"同深度/偏上/偏下"逐档探测，只要那一格还是水就留下——这种格子对水下
     * （{@code SwimNodeEvaluator}）与河床行走（{@code WalkNodeEvaluator}，溺尸把
     * {@code PathType.WATER} 的代价设成 0，见其构造器）两套导航器都可用。</p>
     *
     * <p>岸上仍走原版那条随机逃逸点：同一个取点器、同一条"落点必须比自身离威胁更远"的校验
     * （这条校验两个分支都上，防止选出"绕到尸鬼身后去"的点）。</p>
     */
    private List<Vec3> escapeCandidates(LivingEntity ghoul) {
        List<Vec3> candidates = new ArrayList<>();
        Vec3 self = this.mob.position();
        double dangerDistance = ghoul.distanceToSqr(self.x, self.y, self.z);
        if (this.mob.isInWater()) {
            Vec3 away = this.awayDirection(ghoul);
            for (double distance : WATER_PROBE_DISTANCES) {
                for (double heightOffset : WATER_PROBE_HEIGHT_OFFSETS) {
                    Vec3 candidate = self.add(away.x * distance, heightOffset, away.z * distance);
                    if (this.isWaterAt(candidate)
                            && ghoul.distanceToSqr(candidate.x, candidate.y, candidate.z) >= dangerDistance) {
                        candidates.add(candidate);
                    }
                }
            }
            // 四周没有可用的水格（卡在一个孤立水洼/无水方格里）：再交给下面那条岸上取点器碰运气。
        }
        Vec3 land = DefaultRandomPos.getPosAway(this.mob, LAND_PROBE_RADIUS, LAND_PROBE_HEIGHT, ghoul.position());
        if (land != null && ghoul.distanceToSqr(land.x, land.y, land.z) >= dangerDistance) {
            candidates.add(land);
        }
        return candidates;
    }

    /** 水平方向上"从威胁指向自己"的单位向量（重合时给个稳定方向，避免退化）。 */
    private Vec3 awayDirection(LivingEntity ghoul) {
        double dx = this.mob.getX() - ghoul.getX();
        double dz = this.mob.getZ() - ghoul.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-4D) {
            double angle = this.mob.getRandom().nextFloat() * (float) Math.PI * 2.0D;
            return new Vec3(Math.cos(angle), 0.0D, Math.sin(angle));
        }
        return new Vec3(dx / length, 0.0D, dz / length);
    }

    private boolean isWaterAt(Vec3 pos) {
        return this.mob.level().getFluidState(BlockPos.containing(pos)).is(FluidTags.WATER);
    }
}
