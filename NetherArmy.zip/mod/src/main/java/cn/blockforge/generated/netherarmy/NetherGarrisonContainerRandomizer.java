package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.PiecesContainer;

/**
 * 下界戍城容器随机化。
 *
 * <p>模板 {@code nether_garrison.nbt} 的 5 个箱子和 5 个木桶存的也是固定
 * {@code Items} 列表（没有 LootTable）。本类在结构放置完成后按 chunk 就地改写：
 * <ul>
 *   <li>箱子与木桶：物品堆的槽位顺序随机打乱；</li>
 *   <li>每堆数量随机增加或减少 1~3 个（也可以不变），结果夹在
 *       {@code [1, 最大堆叠数]} 之间——所以单件物品（马铠、附魔书等）数量不变；</li>
 *   <li>木桶里的附魔书原本写死 {@code minecraft:feather_falling}，现在每条都按
 *       原版附魔台规则重新随机（1~3 条互不冲突的附魔，等级随“附魔等级”浮动）；</li>
 *   <li>木桶另有 0.1% 概率刷出一件炼狱晶马铠（优先放空槽，满了就顶掉随机一格）。</li>
 * </ul>
 *
 * <p>扫描与洗牌细节见 {@link StructureContainers}。
 */
public final class NetherGarrisonContainerRandomizer {

    /** 木桶里刷出炼狱晶马铠的概率：0.1%。 */
    private static final float HORSE_ARMOR_CHANCE = 0.001F;
    /** 单堆物品数量的最大波动幅度。 */
    private static final int MAX_COUNT_DELTA = 3;
    /** 附魔书重掷时随机取的“附魔等级”范围（相当于附魔台书架数换算后的等级）。 */
    private static final int MIN_ENCHANT_POWER = 5;
    private static final int MAX_ENCHANT_POWER = 30;

    private NetherGarrisonContainerRandomizer() {
    }

    /** 扫描本次放置落在当前可写区域内的容器并随机化内容。 */
    public static void randomizePieces(WorldGenLevel level, BoundingBox writableArea,
                                       PiecesContainer pieces, RandomSource random) {
        StructureContainers.forEachFixedContainer(level, writableArea, pieces, (container, barrel) -> {
            List<ItemStack> stacks = StructureContainers.collect(container);
            if (!stacks.isEmpty()) {
                for (ItemStack stack : stacks) {
                    adjustCount(stack, random);
                    if (barrel && stack.is(Items.ENCHANTED_BOOK)) {
                        rerollBookEnchantments(stack, level, random);
                    }
                }
                StructureContainers.fisherYates(stacks, random);
                StructureContainers.placeInto(container, stacks, random);
            }
            if (barrel && random.nextFloat() < HORSE_ARMOR_CHANCE) {
                insertHorseArmor(container, random);
            }
            container.setChanged();
        });
    }

    /** 单堆数量随机 ±1~3（也可能不变），并夹在 1 与最大堆叠数之间。 */
    private static void adjustCount(ItemStack stack, RandomSource random) {
        int delta = random.nextInt(MAX_COUNT_DELTA * 2 + 1) - MAX_COUNT_DELTA;
        if (delta == 0) {
            return;
        }
        int count = Mth.clamp(stack.getCount() + delta, 1, stack.getMaxStackSize());
        stack.setCount(count);
    }

    /**
     * 重掷附魔书的附魔：借用原版附魔台的选附魔逻辑（{@code EnchantmentHelper#enchantItem}），
     * 因此得到的条目天然互不冲突、等级也符合各附魔的等级成本曲线，并且会把模组附魔一起纳入抽取池。
     * 书本身的堆叠数与其它组件保持不变，只替换 {@code stored_enchantments}。
     */
    private static void rerollBookEnchantments(ItemStack stack, WorldGenLevel level, RandomSource random) {
        int power = Mth.nextInt(random, MIN_ENCHANT_POWER, MAX_ENCHANT_POWER);
        for (int attempt = 0; attempt < 3; attempt++) {
            ItemStack rolled = EnchantmentHelper.enchantItem(random, new ItemStack(Items.BOOK),
                    power, bookEnchantmentPool(level));
            ItemEnchantments enchantments = rolled.get(DataComponents.STORED_ENCHANTMENTS);
            if (enchantments != null && !enchantments.isEmpty()) {
                stack.set(DataComponents.STORED_ENCHANTMENTS, enchantments);
                return;
            }
            // 低等级抽不到任何附魔时拉满等级再试一次，仍失败就保留模板原样。
            power = MAX_ENCHANT_POWER;
        }
    }

    /** 附魔书的抽取池：当前全部附魔（含模组附魔、稀有附魔），只把诅咒剔除掉。 */
    private static Stream<Holder<Enchantment>> bookEnchantmentPool(WorldGenLevel level) {
        return level.registryAccess().registryOrThrow(Registries.ENCHANTMENT).holders()
                .<Holder<Enchantment>>map(holder -> holder)
                .filter(holder -> !holder.is(EnchantmentTags.CURSE));
    }

    /** 往木桶里塞一件炼狱晶马铠：优先用空槽，没有空槽就顶掉随机一格。 */
    private static void insertHorseArmor(RandomizableContainer container, RandomSource random) {
        int capacity = container.getContainerSize();
        if (capacity <= 0) {
            return;
        }
        List<Integer> emptySlots = new ArrayList<>();
        for (int i = 0; i < capacity; i++) {
            if (container.getItem(i).isEmpty()) {
                emptySlots.add(i);
            }
        }
        int slot = emptySlots.isEmpty()
                ? random.nextInt(capacity)
                : emptySlots.get(random.nextInt(emptySlots.size()));
        container.setItem(slot, new ItemStack(GeneratedMod.NETHER_CRYSTAL_HORSE_ARMOR.get()));
    }
}
