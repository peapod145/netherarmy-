package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;

/**
 * 下界要塞及小型要塞的刷怪黑名单。
 *
 * <p>结构的 {@code spawn_overrides} 只覆盖结构部件包围盒，部件外的庭院和缝隙仍会
 * 使用群系刷怪表。因此这里在最终的刷怪位置检查处统一拦截僵尸猪灵和尸鬼，确保
 * 两种要塞的整个结构包围盒内都不会通过自然刷怪或刷怪笼生成它们。</p>
 *
 * <p>判定全部走 {@code #netherarmy:counts_as_nether_fortress} 标签；该标签以可选条目
 * 收录 YUNG's Better Nether Fortresses 的 {@code betterfortresses:fortress}
 * （{@code required: false}，没装该模组时自动忽略），因此该模组的要塞同样继承本模组的
 * 要塞刷怪规则。</p>
 */
public final class FortressSpawnBlacklistHandler {
    public static final TagKey<Structure> FORTRESS_STRUCTURES = TagKey.create(
            Registries.STRUCTURE,
            ResourceLocation.fromNamespaceAndPath("netherarmy", "counts_as_nether_fortress"));

    private FortressSpawnBlacklistHandler() {
    }

    /**
     * 判断位置是否在标签所列出的任一下界要塞的整体包围盒内。
     * 标签同时覆盖原版要塞、{@code netherarmy:fortress}、
     * {@code netherarmy:small_fortress}，以及装了 YUNG's Better Nether Fortresses
     * 时一并覆盖的 {@code betterfortresses:fortress}（出怪与本模组要塞同套规则）。
     */
    public static boolean insideFortress(ServerLevelAccessor level, BlockPos pos) {
        if (level.getLevel().dimension() != Level.NETHER) {
            return false;
        }

        Registry<Structure> structures = level.registryAccess()
                .registryOrThrow(Registries.STRUCTURE);
        for (Holder<Structure> holder : structures.getOrCreateTag(FORTRESS_STRUCTURES)) {
            if (level.getLevel().structureManager()
                    .getStructureAt(pos, holder.value()).isValid()) {
                return true;
            }
        }
        return false;
    }

    @SubscribeEvent
    public static void onSpawnPlacementCheck(MobSpawnEvent.SpawnPlacementCheck event) {
        EntityType<?> type = event.getEntityType();
        MobSpawnType spawnType = event.getSpawnType();

        // 原版下界群系没有僵尸刷怪项，但其他刷怪表、结构或增援可能仍把它送进
        // SpawnPlacements。仅拦截非玩家主动生成路径，保留刷怪蛋、命令和创造模式操作。
        if (type == EntityType.ZOMBIE
                && event.getLevel().getLevel().dimension() == Level.NETHER
                && (spawnType == MobSpawnType.NATURAL
                    || spawnType == MobSpawnType.CHUNK_GENERATION
                    || spawnType == MobSpawnType.STRUCTURE
                    || spawnType == MobSpawnType.REINFORCEMENT)) {
            event.setResult(MobSpawnEvent.SpawnPlacementCheck.Result.FAIL);
            return;
        }

        if (type != EntityType.ZOMBIFIED_PIGLIN
                && type != GeneratedMod.WITHER_ZOMBIE.get()) {
            return;
        }
        if (insideFortress(event.getLevel(), event.getPos())) {
            event.setResult(MobSpawnEvent.SpawnPlacementCheck.Result.FAIL);
        }
    }
}
