package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * 可被尸鬼感染的实体会在发现尸鬼时主动逃跑（苦力怕躲猫同款管线）。
 *
 * <p>本类负责其中走"目标选择器"的僵尸系（僵尸/溺尸/尸壳/僵尸村民）：实体进入世界时
 * （仅服务端）往它的 goalSelector 挂一条 {@link WitherZombiePreyFleeGoal}——8 格内"看见"
 * 尸鬼（走 {@code TargetingConditions.forCombat()}，带视线校验，隔墙不算发现）就朝远离它的
 * 方向重新寻路，距离近于 7 格时提速到 1.2 倍，拉到 12 格外才收手。</p>
 *
 * <p>为什么不用现成的原版 {@code AvoidEntityGoal}（这条 AI 前两版就是用它，溺尸一直不生效）：
 * 它在构造时就把 {@code mob.getNavigation()} 缓存进 final 字段，而溺尸每刻都会在
 * {@code Drowned#updateSwimming()} 里把导航器在水/陆两套之间换掉，入世界那一刻拿到的
 * 实例之后再也不被驱动。结果逃跑目标建了一条没人走的路、{@code isDone()} 永远为真、
 * {@code canContinueToUse} 永远为真——优先级 1 且占着 {@code Flag.MOVE} 的它一旦启动就再也不
 * 撒手，顺带把溺尸优先级 2 的近战与三叉戟远程全部锁死。所以溺尸的表现是"既不逃、挨打也不
 * 反击"，其它僵尸系则一切正常。 {@link WitherZombiePreyFleeGoal} 改为每刻现取导航器，并对
 * 水中/陆地把逃逸点分开取，两套导航都能真正建出路来。</p>
 *
 * <p>优先级 1：只让位于 FloatGoal(0)，压过僵尸近战(2)、啄龟蛋(4)、穿村(6)、
 * 闲逛(7)，因此"发现即逃"，正在打玩家也会立刻转身。与僵尸破门(1)/溺尸入水(1)
 * 同优先级时按原版规则互不打断，行为与两只苦力怕躲猫躲水一样温和。</p>
 *
 * <p>反击与逃跑的取舍写在目标内部：一旦它把"打自己的那只尸鬼"记成仇恨目标
 * （{@code HurtByTargetGoal}，原版僵尸系唯一的对尸鬼仇恨来源），逃跑就主动让出移动控制权，
 * 让它照原版打法还手；白天溺尸还手不了的那道闸见 {@code DrownedRevengeTargetMixin}。
 * 尸鬼不在溺尸视野里时，本目标完全不介入。</p>
 *
 * <p>不在此处理的分支：村民（{@code Villager}）走 Brain 活动系统，goalSelector 对其无效——
 * 由 {@code VillagerHostilesSensorGhoulMixin} 把尸鬼注册进村民的"敌对生物"感知，触发原版
 * 恐慌活动（{@code SetWalkTargetAwayFrom}，远离威胁、1.5 倍速）；流浪商人在原版
 * {@code registerGoals} 里本就带 {@code AvoidEntityGoal(Zombie.class, 8.0F, 0.5, 0.5)}，
 * 尸鬼是 Zombie 子类天然被它覆盖，无需也不应重复添加。</p>
 */
public final class WitherZombiePreyFleeHandler {
    /** 逃跑目标优先级：仅次于 FloatGoal，压过一切攻击/移动类目标。 */
    private static final int FLEE_GOAL_PRIORITY = 1;
    /** 发现半径（格）。取 8.0 与原版村民/流浪商人恐惧僵尸的距离标定一致（苦力怕躲猫为 6.0）。 */
    private static final float FLEE_RADIUS = 8.0F;
    /** 行走速度系数（苦力怕躲猫同款 1.0）。 */
    private static final double FLEE_WALK_SPEED = 1.0D;
    /** 近身（<7 格）奔逃速度系数（苦力怕躲猫同款 1.2）。 */
    private static final double FLEE_SPRINT_SPEED = 1.2D;

    private WitherZombiePreyFleeHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof PathfinderMob mob)) {
            return;
        }
        // 村民系走 Brain（见类注释），流浪商人已被原版对 Zombie 的躲避目标覆盖。
        if (mob instanceof AbstractVillager) {
            return;
        }
        // 与感染共用同一名册判定（僵尸/溺尸/尸壳/僵尸村民/村民，排除尸鬼同类）。
        if (!WitherZombie.isInfectable(mob)) {
            return;
        }
        // 入世界事件对同一实体可能重复触发（换维度、僵尸转化而来的溺尸等），挂重了会白跑寻路。
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            if (wrapped.getGoal() instanceof WitherZombiePreyFleeGoal) {
                return;
            }
        }
        mob.goalSelector.addGoal(
                FLEE_GOAL_PRIORITY,
                new WitherZombiePreyFleeGoal(mob, FLEE_RADIUS, FLEE_WALK_SPEED, FLEE_SPRINT_SPEED));
    }
}
