package cn.blockforge.generated.netherarmy;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** 圣光炸弹：用爆炸清除硬度为 0 的方块，并让范围内生物显形。 */
public final class HolyBomb extends ThrowableItemProjectile {
    private static final float EXPLOSION_RADIUS = 3.0F;
    private static final double EFFECT_RADIUS = 3.0D;
    private static final int CENTER_GLOWING_TICKS = 30 * 20;
    private static final int EDGE_GLOWING_TICKS = 10 * 20;

    private static final ExplosionDamageCalculator DAMAGE_CALCULATOR = new ExplosionDamageCalculator() {
        @Override
        public Optional<Float> getBlockExplosionResistance(Explosion explosion,
                                                              net.minecraft.world.level.BlockGetter level,
                                                              BlockPos pos, BlockState state, FluidState fluid) {
            if (state.isAir()) {
                return Optional.empty();
            }
            return state.getDestroySpeed(level, pos) == 0.0F
                    ? super.getBlockExplosionResistance(explosion, level, pos, state, fluid)
                    : Optional.of(Float.MAX_VALUE);
        }

        @Override
        public boolean shouldBlockExplode(Explosion explosion, net.minecraft.world.level.BlockGetter level,
                                          BlockPos pos, BlockState state, float power) {
            return state.getDestroySpeed(level, pos) == 0.0F;
        }

        @Override
        public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
            // 圣光炸弹的生物效果由下方的距离渐变发光与亡灵魔法伤害单独结算。
            return false;
        }
    };

    public HolyBomb(EntityType<? extends HolyBomb> type, Level level) {
        super(type, level);
    }

    public HolyBomb(LivingEntity owner, Level level, Vec3 direction) {
        super(GeneratedMod.HOLY_BOMB.get(), owner, level);
    }

    public HolyBomb(Level level, double x, double y, double z) {
        super(GeneratedMod.HOLY_BOMB.get(), x, y, z, level);
    }

    @Override
    protected Item getDefaultItem() {
        return GeneratedMod.HOLY_BOMB_ITEM.get();
    }

    /** 与雪球使用相同的默认重力。 */
    @Override
    protected double getDefaultGravity() {
        return 0.03D;
    }

    @Override
    protected void onHit(HitResult result) {
        if (this.level().isClientSide()) {
            return;
        }
        this.explode(result);
        this.discard();
    }

    /**
     * 起爆。爆炸中心与发光、伤害的距离判定都取<b>命中点的真实坐标</b>
     * {@link HitResult#getLocation()}，不再用弹体位置。
     *
     * <p>{@code Projectile#tick} 的顺序是"先用当前坐标按本 tick 的位移扫命中、再把自己挪过去"，
     * 所以命中回调触发时弹体还停在上一刻坐标，1.5 格/tick 的初速下最多落后命中点约 1.5 格。
     * 旧实现拿这个落后坐标当球心，半径 3 的圣光判定整球朝发射者偏了 1.5 格：命中点前方
     * 约 1.5 格外的那半边目标会超出判定半径而漏掉，身后的目标反而被多算一次；爆炸清草的
     * 覆盖范围同样整体偏移，看起来就像"炸弹打中了却没什么反应"。
     * 这与凋零飞弹此前修掉的是同一个成因，判定方式也对齐过去：中心用命中点、搜索盒以命中点
     * 为中心、被直接命中的生物无条件进名单。</p>
     */
    private void explode(HitResult result) {
        Entity owner = this.getOwner();
        Vec3 center = result.getLocation();
        // 必须走 Level.explode 的服务端分发路径：直接 new Explosion 后调用 finalizeExplosion
        // 只在服务端本地计算，客户端收不到爆炸包，所以声音和爆炸粒子都会消失。
        // 该重载会把自定义粒子与声音一并发送给附近客户端，同时保留硬度过滤器。
        this.level().explode(this, null, DAMAGE_CALCULATOR,
                center.x(), center.y(), center.z(), EXPLOSION_RADIUS, false,
                Level.ExplosionInteraction.BLOCK, ParticleTypes.EXPLOSION,
                ParticleTypes.EXPLOSION_EMITTER, SoundEvents.GENERIC_EXPLODE);

        Set<LivingEntity> victims = new LinkedHashSet<>();
        // 被直接命中的那个生物无条件进名单：它的碰撞箱上就含着 getLocation()，
        // 距离判定本来也必然通过，显式补一条只是保证"命中 ⇒ 必有结算"这条硬约束。
        if (result instanceof EntityHitResult entityHit
                && entityHit.getEntity() instanceof LivingEntity direct) {
            victims.add(direct);
        }
        AABB search = new AABB(center, center).inflate(EFFECT_RADIUS + 1.0D);
        for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class, search,
                Entity::isAlive)) {
            // 用实体碰撞箱到爆炸中心的最近距离，而不是实体原点；凋灵的头部/侧身
            // 命中点可能远离实体原点，否则会出现“明明命中却没有效果”。
            if (living.getBoundingBox().distanceToSqr(center) <= EFFECT_RADIUS * EFFECT_RADIUS) {
                victims.add(living);
            }
        }

        DamageSource magicDamage = this.level().damageSources().magic();
        for (LivingEntity living : victims) {
            if (!living.isAlive()) {
                continue;
            }
            double distance = Math.sqrt(living.getBoundingBox().distanceToSqr(center));
            int duration = (int) Math.round(CENTER_GLOWING_TICKS
                    - (CENTER_GLOWING_TICKS - EDGE_GLOWING_TICKS) * (distance / EFFECT_RADIUS));
            duration = Math.max(EDGE_GLOWING_TICKS, Math.min(CENTER_GLOWING_TICKS, duration));
            MobEffectInstance glowing = new MobEffectInstance(MobEffects.GLOWING, duration);
            if (living instanceof WitherBoss wither) {
                // 凋灵及霸主凋灵的圣光效果不能被其自身的效果门禁拒绝。
                living.forceAddEffect(glowing, owner);
                hurtWitherIgnoringShield(wither, magicDamage, 20.0F);
            } else {
                living.addEffect(glowing, owner);
                if (living.getType().is(EntityTypeTags.UNDEAD)) {
                    living.hurt(magicDamage, 20.0F);
                }
            }
        }

        // 爆炸粒子由 Explosion.finalizeExplosion 统一在客户端播放。
    }

    /**
     * 圣光炸弹对凋灵类目标的专用伤害通道：护盾阶段与普通受击无敌帧都不能拦截这一下。
     * {@link OverlordWitherBoss#hurt} 还会额外拦截三阶段起的普通抛射物，因此这里用
     * 服务端的实体伤害入口并临时清除护盾/无敌帧；事件中的攻击者仍是圣光炸弹本身。
     */
    private static void hurtWitherIgnoringShield(WitherBoss wither, DamageSource source, float amount) {
        int invulnerableTicks = wither.getInvulnerableTicks();
        wither.setInvulnerableTicks(0);
        wither.invulnerableTime = 0;
        try {
            wither.hurt(source, amount);
        } finally {
            wither.invulnerableTime = 0;
            if (wither.isAlive()) {
                wither.setInvulnerableTicks(invulnerableTicks);
            }
        }
    }
}
