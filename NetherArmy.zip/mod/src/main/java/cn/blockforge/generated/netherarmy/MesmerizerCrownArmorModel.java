package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.WitherSkeleton;

/**
 * 反逆者王冠：方形底座、四根外倾立柱、四道向中央收拢的斜梁、
 * 顶上盖上方形顶板与十字冠饰，正中一颗紫色宝石。
 *
 * <p>几何逐块取自用户上传的 mesmerizer_crown.bbmodel（64×64 贴图）。
 * 把模型从 Blockbench 口径搬到 HumanoidModel 头部坐标：X/Z 不变、Y 取反
 * （java_y = -bb_y），整体再上移 8 落到头顶。Y 轴镜像是反射，旋转角按
 * M·R·M⁻¹ 换算——X/Z 分量取反、Y 分量不变，轴心同样 (ox,-oy,oz)。
 */
public final class MesmerizerCrownArmorModel extends HumanoidModel<WitherSkeleton> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "mesmerizer_crown_armor"), "main");

    public MesmerizerCrownArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(
                net.minecraft.client.model.geom.builders.CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.ZERO);

        PartDefinition head = root.getChild("head");
        // 模型的底框下沿 bb_y=0 就是头顶，因此挂点整体上移 8。
        PartDefinition crown = head.addOrReplaceChild("crown", CubeListBuilder.create(),
                PartPose.offset(0.0F, -8F, 0.0F));

        crown.addOrReplaceChild("base_front", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-4.6F, -1.5F, -4.6F, 9.2F, 1.5F, 1.35F), PartPose.ZERO);
        crown.addOrReplaceChild("base_back", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.6F, -1.5F, 3.25F, 7.2F, 1.5F, 1.35F), PartPose.ZERO);
        crown.addOrReplaceChild("base_left", CubeListBuilder.create().texOffs(16, 0)
                .addBox(-4.6F, -1.5F, -4.25F, 1.35F, 1.5F, 9F), PartPose.ZERO);
        crown.addOrReplaceChild("base_right", CubeListBuilder.create().texOffs(16, 0)
                .addBox(3.25F, -1.5F, -4.25F, 1.35F, 1.5F, 8.5F), PartPose.ZERO);
        crown.addOrReplaceChild("front_left", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.625F, -3F, -0.625F, 1.25F, 4.5F, 1.25F),
                PartPose.offsetAndRotation(-4.975F, -2.9F, -4.975F, (float) Math.toRadians(30F), (float) Math.toRadians(45F), 0.0F));
        crown.addOrReplaceChild("front_right", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.625F, -3F, -0.625F, 1.25F, 4.5F, 1.25F),
                PartPose.offsetAndRotation(4.975F, -2.9F, -4.975F, (float) Math.toRadians(30F), (float) Math.toRadians(-45F), 0.0F));
        crown.addOrReplaceChild("back_left", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-0.625F, -3F, -0.625F, 1.25F, 4.5F, 1.25F),
                PartPose.offsetAndRotation(-4.975F, -2.9F, 4.975F, (float) Math.toRadians(-30F), (float) Math.toRadians(-45F), 0.0F));
        crown.addOrReplaceChild("back_right", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-0.625F, -3F, -0.625F, 1.25F, 4.5F, 1.25F),
                PartPose.offsetAndRotation(4.975F, -2.9F, 4.975F, (float) Math.toRadians(-30F), (float) Math.toRadians(45F), 0.0F));
        crown.addOrReplaceChild("front_left_beam", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.68F, -4.10002F, -0.68F, 1.36F, 8.20004F, 1.36F),
                PartPose.offsetAndRotation(-4.49F, -8.1F, -4.49F, (float) Math.toRadians(-30F), 0.0F, (float) Math.toRadians(30F)));
        crown.addOrReplaceChild("front_right_beam", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.68F, -4.10002F, -0.68F, 1.36F, 8.20004F, 1.36F),
                PartPose.offsetAndRotation(4.49F, -8.1F, -4.49F, (float) Math.toRadians(-30F), 0.0F, (float) Math.toRadians(-30F)));
        crown.addOrReplaceChild("back_left_beam", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-0.68F, -4.10002F, -0.68F, 1.36F, 8.20004F, 1.36F),
                PartPose.offsetAndRotation(-4.49F, -8.1F, 4.49F, (float) Math.toRadians(30F), 0.0F, (float) Math.toRadians(30F)));
        crown.addOrReplaceChild("back_right_beam", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-0.68F, -4.10002F, -0.68F, 1.36F, 8.20005F, 1.36F),
                PartPose.offsetAndRotation(4.71429F, -7.91084F, 4.05001F, (float) Math.toRadians(30F), 0.0F, (float) Math.toRadians(-30F)));
        crown.addOrReplaceChild("apex_mount", CubeListBuilder.create().texOffs(16, 0)
                .addBox(-1.05F, -11.9F, -1.05F, 2.1F, 0.9F, 2.1F), PartPose.ZERO);
        crown.addOrReplaceChild("crest_stem", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.25F, -14.75F, -0.35F, 0.5F, 3F, 0.5F), PartPose.ZERO);
        crown.addOrReplaceChild("crest_left_lower", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-0.5F, 0.4F, -0.42F, 0.5F, 3F, 0.5F),
                PartPose.offsetAndRotation(0F, -14.9F, 0F, 0.0F, 0.0F, (float) Math.toRadians(90F)));
        crown.addOrReplaceChild("crest_right_upper", CubeListBuilder.create().texOffs(16, 0)
                .addBox(-0.5F, 0.4F, -0.42F, 0.5F, 3F, 0.5F),
                PartPose.offsetAndRotation(0F, -15.4F, 0F, 0.0F, 0.0F, (float) Math.toRadians(-90F)));
        crown.addOrReplaceChild("crest_bottom_right", CubeListBuilder.create().texOffs(16, 0)
                .addBox(-0.5F, 0F, -0.42F, 0.5F, 3.4F, 0.5F),
                PartPose.offsetAndRotation(-0.25F, -15.1F, 0F, 0.0F, 0.0F, (float) Math.toRadians(180F)));
        crown.addOrReplaceChild("apex_mount_wide", CubeListBuilder.create().texOffs(16, 0)
                .addBox(-2.05F, -11.5F, -2.05F, 4.1F, 0.5F, 4.1F), PartPose.ZERO);

        // 宝石：侧面用紫色区、北面用亮紫，与模型文件里的两面分配一致。
        crown.addOrReplaceChild("jewel", CubeListBuilder.create()
                .texOffs(48, 0)
                .addBox(-0.5F, -15.5F, -0.82F, 1.0F, 1.0F, 1.0F)
                .texOffs(56, 0)
                .addBox(-0.5F, -15.5F, -0.83F, 1.0F, 1.0F, 0.01F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }
}
