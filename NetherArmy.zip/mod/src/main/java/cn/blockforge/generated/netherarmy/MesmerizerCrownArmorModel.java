package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.WitherSkeleton;

/** 反逆者王冠：方形底座、四角立柱、向中央收拢的四棱锥框架和紫色顶宝石。 */
public final class MesmerizerCrownArmorModel extends HumanoidModel<WitherSkeleton> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "mesmerizer_crown_armor"), "main");

    public MesmerizerCrownArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(
                net.minecraft.client.model.geom.builders.CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.ZERO);

        PartDefinition head = root.getChild("head");
        // 源模型的底框下沿为 Y=0；head 的顶部为 Y=-8，因此只在挂点处平移一次。
        PartDefinition crown = head.addOrReplaceChild("crown", CubeListBuilder.create(),
                PartPose.offset(0.0F, -8.0F, 0.0F));
        int goldDark = 0;
        int gold = 16;
        int goldHighlight = 32;
        int purple = 48;
        int gemHighlight = 56;

        // Exact source geometry: x/z stay unchanged, while source Y is mapped to -Y.
        // The crown group offset above is the only attachment translation.
        box(crown, "base_front", goldHighlight, -4.6F, -1.5F, -4.6F, 9.2F, 1.5F, 1.35F);
        box(crown, "base_back", goldDark, -3.6F, -1.5F, 3.25F, 7.2F, 1.5F, 1.35F);
        box(crown, "base_left", gold, -4.6F, -1.5F, -4.25F, 1.35F, 1.5F, 9.0F);
        box(crown, "base_right", gold, 3.25F, -1.5F, -4.25F, 1.35F, 1.5F, 8.5F);

        box(crown, "front_left", goldHighlight, -4.6F, -3.15F, -4.6F, 1.25F, 1.75F, 1.25F);
        box(crown, "front_right", goldHighlight, 3.35F, -3.15F, -4.6F, 1.25F, 1.75F, 1.25F);
        box(crown, "back_left", goldDark, -4.6F, -3.15F, 3.35F, 1.25F, 1.75F, 1.25F);
        box(crown, "back_right", goldDark, 3.35F, -3.15F, 3.35F, 1.25F, 1.75F, 1.25F);

        float apexY = -7.2F;
        float beamLength = 8.20005F;
        // Source beam boxes run from apexY-length to apexY. After Y reflection,
        // the equivalent Java box runs from apexY to apexY+length.
        rotatedBeam(crown, "front_left_beam", goldHighlight, apexY, beamLength, -37.3955F, 49.8566F);
        rotatedBeam(crown, "front_right_beam", goldHighlight, apexY, beamLength, -37.3955F, -49.8566F);
        rotatedBeam(crown, "back_left_beam", goldDark, apexY, beamLength, 37.3955F, 49.8566F);
        rotatedBeam(crown, "back_right_beam", goldDark, apexY, beamLength, 37.3955F, -49.8566F);

        box(crown, "apex_mount", gold, -1.05F, -7.9F, -1.05F, 2.1F, 0.9F, 2.1F);
        box(crown, "crest_stem", goldHighlight, -0.35F, -10.8F, -0.35F, 0.7F, 3.05F, 0.7F);
        rotatedCrestBeam(crown, "crest_left_lower", goldHighlight, -11.1F, 3.4F, 90.0F);
        rotatedCrestBeam(crown, "crest_right_upper", gold, -11.1F, 3.4F, -90.0F);
        rotatedCrestBeam(crown, "crest_bottom_right", gold, -11.1F, 3.4F, 180.0F);

        // The supplied model maps purple to the jewel sides and a bright variant to its north face.
        crown.addOrReplaceChild("jewel", CubeListBuilder.create()
                .texOffs(purple, 0)
                .addBox(-0.82F, -11.85F, -0.82F, 1.64F, 1.5F, 1.64F)
                .texOffs(gemHighlight, 0)
                .addBox(-0.82F, -11.85F, -0.83F, 1.64F, 1.5F, 0.01F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void rotatedBeam(PartDefinition head, String name, int textureOffset,
                                    float apexY, float length, float xRotation, float zRotation) {
        head.addOrReplaceChild(name, CubeListBuilder.create().texOffs(textureOffset, 0)
                .addBox(-0.68F, 0.0F, -0.68F, 1.36F, length, 1.36F),
                PartPose.offsetAndRotation(0.0F, apexY, 0.0F,
                        (float) Math.toRadians(xRotation), 0.0F, (float) Math.toRadians(zRotation)));
    }

    private static void rotatedCrestBeam(PartDefinition head, String name, int textureOffset,
                                         float originY, float length, float zRotation) {
        head.addOrReplaceChild(name, CubeListBuilder.create().texOffs(textureOffset, 0)
                .addBox(-0.5F, 0.0F, -0.45F, 1.0F, length, 0.9F),
                PartPose.offsetAndRotation(0.0F, originY, 0.0F,
                        0.0F, 0.0F, (float) Math.toRadians(zRotation)));
    }

    private static void box(PartDefinition parent, String name, int textureOffset,
                            float x, float y, float z, float width, float height, float depth) {
        parent.addOrReplaceChild(name, CubeListBuilder.create().texOffs(textureOffset, 0)
                .addBox(x, y, z, width, height, depth), PartPose.ZERO);
    }
}
