package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * 下界运兵车的冲锋：发现敌人后唯一的行为就是<b>一直朝着敌人的方向移动</b>。
 *
 * <p>按需求不做任何额外判定：没有卡死计数、没有翻台阶抬脚、没有追击距离余量、
 * 没有"卡住后切换兜底通道"的状态机——只要仇恨表里有活着的敌人，这一 tick 就
 * 继续朝它走。撞击与破方块在 {@link NetherCarrier} 的 {@code tickRam}/{@code smashBlocks}
 * 里按鼻尖盒结算，与本目标的移动通道无关，贴到脸上自然生效。</p>
 *
 * <h2>为什么弃用"每 tick 重发 navigation.moveTo(敌人)"（上一版摇摆的根因）</h2>
 * <p>对着 1.21.1 的字节码逐分支核过，这条链路每 tick 都在抖：</p>
 * <ol>
 *   <li>{@code PathNavigation#moveTo(Entity,double)} 每次调用都<b>全量重算</b>
 *       一条以"敌人所在格"为终点、{@code accuracy=1} 的路径；敌人每挪一点、
 *       {@code sameAs} 一比不通过，{@code moveTo(Path,speed)} 就整条换掉
 *       {@code this.path}，节点进度同时归零。</li>
 *   <li>运兵车判定箱宽 3.7 格，敌人站的那一格对车宽永远"放不下"，终点节点只能
 *       落在相邻格上；具体落哪一格由车与敌人的相对亚格位置决定，两边一挪动，
 *       终点就在左右相邻格之间<b>逐 tick 翻转</b>。</li>
 *   <li>{@code PathNavigation#tick} 尾段把"下一个节点中心"（整数格 +0.5）写进
 *       {@code MoveControl#setWantedPosition}，而原版 {@code MoveControl} 的 MOVE_TO 分支
 *       每 tick 允许硬拧 90°——信箱指向哪，9.94 格长的车身就朝哪拧。终点格
 *       左右翻转 ⇒ 前进方向左右翻转 ⇒ 车体摇摆。（转角帽现已由
 *       {@link CarrierSteeringControl} 接管成船式的 15°/tick 上限 + 渐变，见
 *       {@link NetherCarrier#steerTowards}；但帽子只是削弱症状，摇摆的原料仍是
 *       "逐 tick 翻转的节点中心"，所以这条通道本身仍要换成实时坐标。）</li>
 *   <li>外加 {@code doStuckDetection}/{@code timeoutPath} 会在换路径时清掉旧路径，
 *       走走停停再叠一层抖动。</li>
 * </ol>
 *
 * <h2>现在的通道：MoveControl 直接指向敌人实时坐标</h2>
 * <p>{@code MoveControl#setWantedPosition} 本身就是原版寻路在跟随阶段每 tick
 * 使用的同一个信箱，差别只在写入的目标点：现在是<b>敌人脚下的真实坐标</b>，
 * 不再是路径节点中心。MOVE_TO 分支（字节码核实）的动作序列：</p>
 * <ul>
 *   <li>用 {@code atan2(敌人−车)} 直接算期望朝向，再经
 *       {@link NetherCarrier#steerTowards} 把转角请求当成<b>打舵</b>而不是瞬拧：
 *       静止禁转、运动中每 tick 最多左右 15°、转向率每 tick ×0.9 衰减（原版船
 *       {@code Boat#deltaRotation} 同款）。目标在正前方时转角恒为 0，没有任何可以
 *       左右翻的中间量；目标在侧面时车身按 15°/tick 的帽划出弧线，不会一拍拧 90°；</li>
 *   <li>{@code Mob#setSpeed} 同步把 {@code zza} 钉成 {@code speedModifier ×
 *       MOVEMENT_SPEED}，走的仍是 {@code LivingEntity#travel} 那条实测有效的推进
 *       链路，加速手感由 {@link NetherCarrier#travel} 的 2 秒线性系数负责；</li>
 *   <li>正前方有台阶/门/栅栏、或高度差超过 {@code maxUpStep} 时分支自己会踩
 *       {@code JumpControl#jump}，翻障碍仍由原版接管；</li>
 *   <li>只有车与目标点距离平方小于 2.5E-7（约 0.0005 格）才收一脚——事实上
 *       永不为真，"一直朝敌人移动"因此是硬保证；贴脸后撞击判定照常生效。</li>
 * </ul>
 * <p>{@code setWantedPosition} 还有个特性：操作位是 JUMPING 时不会把它打回
 * MOVE_TO，腾空期间照样续上目标点，起跳落地不会断。</p>
 *
 * <p>摇摆还要求"每 tick 只有一个写信箱的声音"：{@link #start()} 里补一发
 * {@code navigation.stop()}，把游走残留的路径清掉——否则
 * {@code PathNavigation#tick} 会每 tick 用节点中心覆盖我们的写入（它只在
 * {@code path==null} 时才闭嘴）。冲锋目标持有 {@code Flag.MOVE}，运行期间
 * 游走目标无法启动，也没有人再把路径装回来。{@code MoveControl} 与 STRAFE
 * 一样是单发信箱，但本目标的 {@code tick()} 每 tick 重写一次 MOVE_TO，
 * 不存在上一代 strafe 通道"换仇恨抖动一次就定住"的问题。</p>
 *
 * <h2>为什么必须 {@code requiresUpdateEveryTick()=true}（"锁敌后不动"的根因）</h2>
 * <p>{@code tick()} 想真正<b>每</b> tick 跑一次，得先活过 {@code Mob#serverAiStep}
 * 的奇偶门：它按 {@code (tickCount + 实体 id) % 2} 分节拍——奇拍只调
 * {@code GoalSelector#tickRunningGoals(false)}，而该方法只把 {@code tick()}
 * 递给 {@code requiresUpdateEveryTick()} 为 true 的目标，默认 false 的目标整拍空转。
 * 另一边 {@code MoveControl#tick} 每 tick 都跑，MOVE_TO 消费一次就把
 * {@code operation} 写回 {@code WAIT}，WAIT 分支无条件 {@code setZza(0)}。
 * 于是半拍节律下前进输入只有一半的 tick 存活；{@link NetherCarrier#travel} 的
 * 减速闸门（无输入 −0.1/tick）比加速闸门（有输入 +0.025/tick）大 4 倍，一来一回
 * 净扣 0.075，{@code speedRamp} 秒崩到 0，仅有的"有效 tick"里信箱又被乘成零——
 * 整车贴着敌人在原地定住。游走走 {@code PathNavigation}（在奇偶门外，每 tick
 * 都写信箱）所以没这问题，正是"没敌人能动、有敌人不动"的来源。原版
 * {@code MeleeAttackGoal} 用完全相同的通道（每 tick {@code setWantedPosition}），
 * 它也精确覆盖了同一个方法返回 true——这不是保险，是这条通道的开工条件。</p>
 *
 * <p>仇恨本身的合法性（阵营成员、创造/旁观玩家永不入表）收口在
 * {@link NetherCarrier#setTarget}，本目标只认 {@code getTarget()}。</p>
 */
public class CarrierChargeGoal extends Goal {

    private final NetherCarrier carrier;

    public CarrierChargeGoal(NetherCarrier carrier) {
        this.carrier = carrier;
        // MOVE：压掉游走/其他移动目标，锁敌期间移动信箱只归本目标一个声音；
        // LOOK：不让 LookAtPlayer/RandomLookAround 在冲锋中掰头。
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return validTarget(this.carrier.getTarget());
    }

    @Override
    public boolean canContinueToUse() {
        // 唯一的退出条件：仇恨空了/目标死了/目标成了阵营成员。没有距离、没有卡死判定。
        return validTarget(this.carrier.getTarget());
    }

    /**
     * 每 tick 都要被 {@code tick()} 一次：{@code Mob#serverAiStep} 的奇偶节拍会把
     * 未覆盖本方法的目标隔拍跳过，而 {@code MoveControl} 的 MOVE_TO 是一次性信箱，
     * 漏一拍就被 WAIT 分支 {@code setZza(0)} 清零，配合 {@link NetherCarrier#travel}
     * 的减速闸门会把加速系数直接抽干（锁敌定住的根因，详见类注释）。
     * 原版 {@code MeleeAttackGoal} 同款覆盖。
     */
    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    /** 仇恨总闸之外的最后一道廉价校验：活着，且不是打不动的自己人。 */
    private boolean validTarget(LivingEntity candidate) {
        return candidate != null && candidate.isAlive()
                && !LegionAuraHandler.isFactionMember(candidate);
    }

    @Override
    public void start() {
        this.carrier.setAggressive(true);
        // 清掉游走残留的路径：PathNavigation#tick 只在 path==null 时才不每 tick
        // 往移动信箱里写节点中心，不清就等于两个声音抢转向。
        this.carrier.getNavigation().stop();
    }

    @Override
    public void stop() {
        this.carrier.setAggressive(false);
        // 交还控制权给游走目标：清掉旧路径，也保证停追这一 tick 信箱指向脚下。
        this.carrier.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity target = this.carrier.getTarget();
        if (target != null) {
            // 一直朝着敌人的方向移动：信箱每 tick 钉在敌人的实时坐标上。
            // 不经过寻路——没有节点中心、没有逐 tick 换路径，也就没有摇摆的原料。
            this.carrier.getMoveControl().setWantedPosition(
                    target.getX(), target.getY(), target.getZ(), 1.0D);
        }
    }
}
