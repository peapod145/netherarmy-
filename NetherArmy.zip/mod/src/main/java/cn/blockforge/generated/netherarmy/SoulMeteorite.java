package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 灵魂陨石：凋灵魔导师技能 1 从天而降的弹体，落地即"等同于 TNT 的爆炸"。
 *
 * <p>飞行是自管的直线匀速运动（不走 {@code Entity#move} 的碰撞体推挤）：每刻用手工
 * {@code level.clip} 检测下一段位移是否撞到方块，撞到或飞过瞄准点就结算。这样既能
 * 保证 3 颗陨石各自走自己的直线，也不会像普通实体那样被台阶、栏杆之类挤偏。</p>
 *
 * <p>结算四件事：</p>
 * <ol>
 *   <li>以落点为中心威力 {@value #EXPLOSION_POWER} 的爆炸，伤害类型走
 *       {@code damageSources().indirectMagic(this, 施法者)}——呈报给玩家的死因是魔法
 *       伤害（无视护甲），同时把击杀记在凋灵魔导师头上；</li>
 *   <li>半径 {@value #VULNERABLE_RADIUS} 格内所有活物获得易伤 I，时长取魔导师的
 *       {@link WitherArchmage#VULNERABLE_TICKS}（已按施法倍率翻倍，20 秒），可叠加升级；</li>
 *   <li>落点放置一块 {@link SoulMeteoriteBlock}（黑曜石数值，钻石镐可挖）；</li>
 *   <li>方块正上方点燃 {@code minecraft:soul_fire}——灵魂陨石飞行途中本身就是灵魂火
 *       焰（见 {@link SoulFireFlareRenderer#usesSoulFlame}），落地后这簇火留在原地，
 *       且永不自然熄灭（见 {@link #placeSoulFireAbove}）。</li>
 * </ol>
 */
public class SoulMeteorite extends Entity {
    /** 爆炸威力：与原版 TNT 同值。 */
    public static final float EXPLOSION_POWER = 4.0F;
    /** 飞行速度：格/刻。 */
    public static final double SPEED = 1.2D;
    /** 施加易伤的半径：8 格。 */
    private static final double VULNERABLE_RADIUS = 8.0D;
    /** 最长存活：100 刻（5 秒），超时自爆，避免卡在天花板下无限飞。 */
    private static final int MAX_LIFE_TICKS = 100;

    /** 施法者：爆炸的间接来源，用于伤害归属。 */
    private LivingEntity owner;
    /** 瞄准点（服务端自用，不参与同步）。 */
    private Vec3 aim = Vec3.ZERO;

    public SoulMeteorite(EntityType<? extends SoulMeteorite> type, Level level) {
        super(type, level);
        // 自行判定碰撞，不让原版碰撞体推挤改变航线。
        this.noPhysics = true;
        this.noCulling = true;
    }

    public void setOwner(LivingEntity owner) {
        this.owner = owner;
    }

    public void setAim(Vec3 aim) {
        this.aim = aim;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.spawnTrailParticles();
            return;
        }
        if (this.tickCount >= MAX_LIFE_TICKS) {
            this.impact(this.position());
            return;
        }
        Vec3 from = this.position();
        Vec3 next = from.add(this.getDeltaMovement());
        BlockHitResult hit = this.level().clip(new ClipContext(from, next,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (hit.getType() != HitResult.Type.MISS) {
            this.impact(hit.getLocation());
            return;
        }
        if (this.aim != Vec3.ZERO
                && (this.aim.subtract(from).dot(this.getDeltaMovement()) <= 0.0D
                || from.distanceToSqr(this.aim) <= SPEED * SPEED)) {
            this.impact(next);
            return;
        }
        this.setPos(next.x, next.y, next.z);
    }

    /** 命中：爆炸 + 易伤 + 落地成方块，然后销毁自身。 */
    private void impact(Vec3 at) {
        if (this.level() instanceof ServerLevel serverLevel) {
            DamageSource source = serverLevel.damageSources().indirectMagic(this, this.owner);
            serverLevel.explode(this, source, new ExplosionDamageCalculator(),
                    at.x, at.y, at.z, EXPLOSION_POWER, false, Level.ExplosionInteraction.TNT);
            AABB area = new AABB(at, at).inflate(VULNERABLE_RADIUS);
            for (LivingEntity victim : serverLevel.getEntitiesOfClass(LivingEntity.class, area,
                    LivingEntity::isAlive)) {
                WitherArchmage.applyVulnerability(victim, WitherArchmage.VULNERABLE_TICKS);
                WitherArchmage.spawnVulnerabilityParticles(serverLevel, victim);
            }
            this.placeLandedBlock(serverLevel, at);
        }
        this.discard();
    }

    /**
     * 落点放置灵魂陨石方块，并在方块正上方点燃灵魂火；若落点位置被占用则退而求其次
     * 放到上方一格（此时火跟着挪到那一格上面）。
     */
    private void placeLandedBlock(ServerLevel level, Vec3 at) {
        BlockPos pos = BlockPos.containing(at.x, at.y, at.z);
        if (!level.getBlockState(pos).canBeReplaced()) {
            pos = pos.above();
        }
        if (!level.getBlockState(pos).canBeReplaced()) {
            return;
        }
        level.setBlockAndUpdate(pos, GeneratedMod.SOUL_METEORITE_BLOCK.get().defaultBlockState());
        placeSoulFireAbove(level, pos.above());
    }

    /**
     * 在方块正上方点燃灵魂火，即"陨石自带的那簇火落地后留在原地"。
     *
     * <p>这里写死 {@code Blocks.SOUL_FIRE} 而不是让 {@code BaseFireBlock.getState}
     * 按地面选：要求的正是灵魂火，不是普通火。</p>
     *
     * <p><b>为什么不用管熄灭</b>：原版普通火的燃烧寿命和雨水熄灭都写在 {@code FireBlock}
     * 的 {@code tick} / {@code scheduledTick} 里，{@code SoulFireBlock} 没有这两个钩子，
     * 也就从不自己消退——"不能自然熄灭"是原版灵魂火本身就有的性质，前提只是地面
     * 属于 {@code minecraft:soul_fire_base_blocks}。本模组已把
     * {@code netherarmy:soul_meteorite} 加进那个方块标签（见数据包
     * {@code data/minecraft/tags/block/soul_fire_base_blocks.json}），所以
     * {@code SoulFireBlock.canSurvive} 成立，火会一直烧到方块被挖走为止。</p>
     */
    private static void placeSoulFireAbove(ServerLevel level, BlockPos pos) {
        if (!level.getBlockState(pos).canBeReplaced()) {
            return;
        }
        level.setBlockAndUpdate(pos, Blocks.SOUL_FIRE.defaultBlockState());
    }

    /** 拖尾：灵魂火苗 + 黑烟，让下落的陨石在夜间也看得见。 */
    private void spawnTrailParticles() {
        for (int i = 0; i < 3; i++) {
            double x = this.getX() + (this.random.nextDouble() - 0.5D) * 0.9D;
            double y = this.getY() + 0.5D + (this.random.nextDouble() - 0.5D) * 0.9D;
            double z = this.getZ() + (this.random.nextDouble() - 0.5D) * 0.9D;
            this.level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 0.0D, 0.0D, 0.0D);
            if (i == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, x, y, z, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        // 陨石没有需要同步的额外字段：航线由服务端算、客户端只跟着位置包走。
    }

    /**
     * 恒开着火标记，让客户端走 {@code EntityRenderDispatcher#renderFlame} 的全身火焰
     * 覆盖层。原版 {@code Entity#displayFireAnimation} 读的是 {@code isOnFire()} 那个
     * 会自己烧完的标记，这里直接返回 {@code true}，火焰就永不熄灭；颜色由
     * {@link SoulFireFlareRenderer#usesSoulFlame} 判成灵魂火（蓝焰）。
     */
    @Override
    public boolean displayFireAnimation() {
        return true;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Aim")) {
            this.aim = new Vec3(tag.getDouble("AimX"), tag.getDouble("AimY"), tag.getDouble("AimZ"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (this.aim != Vec3.ZERO) {
            tag.putDouble("AimX", this.aim.x);
            tag.putDouble("AimY", this.aim.y);
            tag.putDouble("AimZ", this.aim.z);
        }
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
