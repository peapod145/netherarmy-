package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.pathfinder.PathType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * 阵营编入：把"追随/护卫传令兵"的 AI 与光环所需的属性底，补齐到每个阵营生物身上。
 *
 * <h3>目标注入</h3>
 * <p>追随者是整个凋灵骷髅阵营（原版凋灵骷髅 + 本模组狂战士/猎手/无头骑士/
 * 反逆者/衰翼/尸鬼 + 无头骑士头颅），类各不相同、注册点太多，统一在
 * {@link EntityJoinLevelEvent}（服务端）里注入：goalSelector 4 挂
 * {@link CourierFollowGoal}，targetSelector 0 挂 {@link CourierProtectTargetGoal}。
 * 传令兵保护使用最高目标优先级，在普通索敌和自卫目标之前执行；目标不进 NBT，
 * 重载后事件重放，天然幂等。</p>
 *
 * <h3>护甲属性底</h3>
 * <p>1.21.1 里绝大多数怪物的属性表根本没有 ARMOR 项（原版凋灵骷髅、尸鬼、
 * 衰翼、无头骑士的马……{@code getAttribute} 直接返回 null），光环的"护甲 +1"
 * 对它们会无声落空。借 {@link EntityAttributeModificationEvent} 给名册里的
 * 类型补一个 0 点护甲底：平时数值分毫不动（0 点护甲本就等价于没有该属性），
 * 光环一来 +1 就真实生效。</p>
 */
public final class LegionFactionHandler {

    private LegionFactionHandler() {
    }

    /** 实体进世界（服务端侧）：给合法追随者挂上追随与护卫目标。 */
    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (!LegionAuraHandler.isFollowerCandidate(mob)) {
            return;
        }
        mob.goalSelector.addGoal(4, new CourierFollowGoal(mob));
        // 传令兵保护是最高优先级：传令兵受击时，保护目标必须先于普通索敌和自卫目标接管。
        mob.targetSelector.addGoal(0, new CourierProtectTargetGoal(mob));
    }

    /**
     * 岩浆块通行：把阵营成员的火焰系寻路惩罚清零。
     *
     * <h3>为什么免疫火焰却不肯踩岩浆</h3>
     * <p>伤害与寻路是两套互不相干的判定。岩浆块掉血走
     * {@code MagmaBlock#stepOn → DamageSources#hotFloor}（{@code minecraft:hot_floor}，
     * 归在 {@code #minecraft:is_fire} 标签里），{@code EntityType.Builder#fireImmune()}
     * 能把这份伤害整个抹掉；而"能不能走过去"由 {@code WalkNodeEvaluator} 按
     * {@code PathType} 查 {@code Mob#getPathfindingMalus} 决定，压根不看
     * {@code fireImmune()}。岩浆块本身的节点是 {@code PathType.DAMAGE_FIRE}
     * （枚举自带 malus 16.0F），它上方那一格则被 {@code checkNeighbourBlocks} 折成
     * {@code PathType.DANGER_FIRE}（malus 8.0F）。代价按节点累加（{@code PathFinder}
     * 里 {@code g = 父节点 g + 位移 + costMalus}），普通一格才 1 点、踩一格岩浆要 16 点
     * ——任何绕行都比它便宜，视野里整片岩浆地板就等于一堵墙。原版凋灵骷髅同样带着
     * {@code fireImmune()}，却从没改过这两项惩罚，所以下界堡垒的岩浆地面在整个
     * 凋灵骷髅阵营眼里全程是禁区。</p>
     *
     * <h3>注入点</h3>
     * <p>与 AI 目标同一处理：{@link EntityJoinLevelEvent}（服务端）里按名册注入。
     * 惩罚表是 {@code Mob} 实例上的纯内存 map，不入 NBT，区块重载后事件重放，
     * 天然幂等；一个钩子同时覆盖原版凋灵骷髅与本模组全部成员（狂战士、下界猎手、
     * 无头骑士躯体与马、反逆者、衰翼、尸鬼、传令兵、运兵车），不必挨个子类去改
     * {@code registerGoals}。</p>
     *
     * <h3>两条闸门</h3>
     * <p>先 {@code fireImmune()} 再认阵营：踩岩浆的前提是踩了不掉血，万一哪天名册里
     * 塞进一个怕火的类型，宁可它继续绕路，也别放它进岩浆里泡着。
     * {@code PathType.LAVA}（岩浆本身，枚举 malus -1.0F，在 {@code findAcceptedNode}
     * 里属于硬否决）保持原样不动——免疫火焰不等于能在岩浆里游动，尸鬼那种
     * "炽足兽同款"的例外由它自己的构造器单独声明。</p>
     */
    @SubscribeEvent
    public static void onEntityJoinLevelAllowMagma(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (!mob.fireImmune() || !LegionAuraHandler.isFactionMember(mob)) {
            return;
        }
        mob.setPathfindingMalus(PathType.DAMAGE_FIRE, 0.0F);
        mob.setPathfindingMalus(PathType.DANGER_FIRE, 0.0F);
    }

    /** 模组总线事件：给名册类型补 ARMOR 属性底（已有则跳过）。 */
    public static void addArmorAttributeFloors(EntityAttributeModificationEvent event) {
        Holder<Attribute> armor = Attributes.ARMOR;
        addIfAbsent(event, EntityType.WITHER_SKELETON, armor);
        addIfAbsent(event, GeneratedMod.BERSERKER.get(), armor);
        addIfAbsent(event, GeneratedMod.NETHER_HUNTER.get(), armor);
        addIfAbsent(event, GeneratedMod.BEDSERKER.get(), armor);

        addIfAbsent(event, GeneratedMod.DULLHAN_BODY.get(), armor);
        addIfAbsent(event, GeneratedMod.DULLHAN_HEAD.get(), armor);
        addIfAbsent(event, GeneratedMod.DULLHAN_HORSE.get(), armor);
        addIfAbsent(event, GeneratedMod.MESMERIZER.get(), armor);
        addIfAbsent(event, GeneratedMod.WITHERPHANTOM.get(), armor);
        addIfAbsent(event, GeneratedMod.WITHER_ZOMBIE.get(), armor);
        addIfAbsent(event, GeneratedMod.NETHER_COURIER.get(), armor);
    }

    private static void addIfAbsent(EntityAttributeModificationEvent event,
                                    EntityType<? extends net.minecraft.world.entity.LivingEntity> type,
                                    Holder<Attribute> armor) {
        if (!event.has(type, armor)) {
            event.add(type, armor, 0.0D);
        }
    }
}
