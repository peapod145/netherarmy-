package cn.blockforge.generated.netherarmy.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * {@code MobEffectInstance#duration} 是私有字段且没有任何 setter；
 * buff 时长缩放（炼狱晶胸甲 +25% / 护腿 -25%）需要在
 * {@code MobEffectEvent.Applicable}（合并入库之前）直接改写即将生效实例的时长，
 * 所以开一个 Accessor。事件拿到的就是即将放入 {@code activeEffects} 的同一个对象，
 * 改它对新施加与刷新叠加两条路径都有效。
 */
@Mixin(net.minecraft.world.effect.MobEffectInstance.class)
public interface MobEffectInstanceDurationAccess {
    @Accessor("duration")
    void netherarmy$setDuration(int duration);

    @Accessor("duration")
    int netherarmy$getDuration();
}
