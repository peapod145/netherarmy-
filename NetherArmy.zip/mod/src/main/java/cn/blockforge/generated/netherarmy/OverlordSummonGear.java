package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;

/**
 * 霸主凋灵各阶段召唤物的装备规格（见需求逐阶段条款）。
 *
 * <ul>
 * <li>一阶段：至少一件金质装备，附魔数量与等级随机。</li>
 * <li>二阶段：全套满级附魔金质装备（附魔类型、数量随机）；10% 概率其中至少一件
 * 换成下界合金装备（随机数量、随机等级附魔）。</li>
 * <li>三阶段：至少 3 件附魔下界合金装备，类型、数量、等级均随机。</li>
 * <li>四阶段：全套满级附魔下界合金装备，类型、数量随机。</li>
 * <li>五阶段：全套满级附魔下界合金装备（无头强袭骑士除外）；25% 概率改穿炼狱晶
 * 装备，附魔等级与数量随机。</li>
 * </ul>
 *
 * <p>附魔从注册表里"该装备可承受"的附魔中随机抽取（{@code isSupportedItem}），
 * 等级在 1..上限 之间随机（满级模式取上限）。数量随机指每件装备 1~3 条。</p>
 */
final class OverlordSummonGear {
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
    };
    private static final ItemStack[] GOLD_SET = {
            new ItemStack(Items.GOLDEN_HELMET), new ItemStack(Items.GOLDEN_CHESTPLATE),
            new ItemStack(Items.GOLDEN_LEGGINGS), new ItemStack(Items.GOLDEN_BOOTS),
    };
    private static final ItemStack[] NETHERITE_SET = {
            new ItemStack(Items.NETHERITE_HELMET), new ItemStack(Items.NETHERITE_CHESTPLATE),
            new ItemStack(Items.NETHERITE_LEGGINGS), new ItemStack(Items.NETHERITE_BOOTS),
    };
    private static final ItemStack[] PURGATORY_CRYSTAL_SET = {
            new ItemStack(GeneratedMod.NETHER_CRYSTAL_HELMET.get()),
            new ItemStack(GeneratedMod.NETHER_CRYSTAL_CHESTPLATE.get()),
            new ItemStack(GeneratedMod.NETHER_CRYSTAL_LEGGINGS.get()),
            new ItemStack(GeneratedMod.NETHER_CRYSTAL_BOOTS.get()),
    };

    private OverlordSummonGear() {
    }

    /** 按阶段给召唤物穿戴装备。{@code blitzDullhan} 走五阶段的"无头强袭骑士除外"分支。 */
    static void equip(Mob mob, int phase, boolean blitzDullhan, RandomSource random) {
        RegistryAccess registryAccess = mob.level().registryAccess();
        switch (phase) {
            case 1 -> {
                List<Integer> picked = pickSubset(1 + random.nextInt(4), random);
                for (int slotIndex : picked) {
                    ItemStack stack = GOLD_SET[slotIndex].copy();
                    enchant(stack, random, false, registryAccess);
                    mob.setItemSlot(ARMOR_SLOTS[slotIndex], stack);
                }
            }
            case 2 -> {
                boolean netheriteSwap = random.nextFloat() < 0.10F;
                int swappedSlot = netheriteSwap ? random.nextInt(4) : -1;
                for (int slotIndex = 0; slotIndex < 4; slotIndex++) {
                    ItemStack stack = (netheriteSwap && slotIndex == swappedSlot)
                            ? NETHERITE_SET[slotIndex].copy()
                            : GOLD_SET[slotIndex].copy();
                    // 换上的下界合金件按"随机数量随机等级"，其余金件保持满级口径。
                    enchant(stack, random, !(netheriteSwap && slotIndex == swappedSlot), registryAccess);
                    mob.setItemSlot(ARMOR_SLOTS[slotIndex], stack);
                }
            }
            case 3 -> {
                for (int slotIndex : pickSubset(3 + random.nextInt(2), random)) {
                    ItemStack stack = NETHERITE_SET[slotIndex].copy();
                    enchant(stack, random, false, registryAccess);
                    mob.setItemSlot(ARMOR_SLOTS[slotIndex], stack);
                }
            }
            case 4 -> {
                for (int slotIndex = 0; slotIndex < 4; slotIndex++) {
                    ItemStack stack = NETHERITE_SET[slotIndex].copy();
                    enchant(stack, random, true, registryAccess);
                    mob.setItemSlot(ARMOR_SLOTS[slotIndex], stack);
                }
            }
            default -> {
                boolean crystal = random.nextFloat() < 0.25F;
                ItemStack[] set = crystal ? PURGATORY_CRYSTAL_SET : NETHERITE_SET;
                for (int slotIndex = 0; slotIndex < 4; slotIndex++) {
                    if (!crystal && blitzDullhan) {
                        // 五阶段"必定携带满级附魔下界合金装备（无头强袭骑士除外）"：
                        // 强袭骑士不穿下界合金，只有抽中炼狱晶时才穿装备。
                        break;
                    }
                    ItemStack stack = set[slotIndex].copy();
                    enchant(stack, random, !crystal, registryAccess);
                    mob.setItemSlot(ARMOR_SLOTS[slotIndex], stack);
                }
            }
        }
    }

    /** 从 0..3 里不重复抽 {@code count} 个槽位下标。 */
    private static List<Integer> pickSubset(int count, RandomSource random) {
        List<Integer> pool = new ArrayList<>(List.of(0, 1, 2, 3));
        List<Integer> picked = new ArrayList<>();
        for (int i = 0; i < count && !pool.isEmpty(); i++) {
            picked.add(pool.remove(random.nextInt(pool.size())));
        }
        return picked;
    }

    /**
     * 给一件装备随机附加 1~3 条附魔。
     *
     * @param maxLevel true=全部取附魔等级上限（"满级附魔"口径），false=等级在 1..上限随机。
     */
    private static void enchant(ItemStack stack, RandomSource random, boolean maxLevel, RegistryAccess registryAccess) {
        List<Holder<Enchantment>> supported = new ArrayList<>();
        HolderLookup.RegistryLookup<Enchantment> enchantments =
                registryAccess.lookupOrThrow(Registries.ENCHANTMENT);
        enchantments.listElements().forEach(holder -> {
            if (holder.value().isSupportedItem(stack)) {
                supported.add(holder);
            }
        });
        if (supported.isEmpty()) {
            return;
        }
        int count = 1 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            Holder<Enchantment> holder = supported.get(random.nextInt(supported.size()));
            int ceiling = Math.max(1, holder.value().getMaxLevel());
            int level = maxLevel ? ceiling : 1 + random.nextInt(ceiling);
            stack.enchant(holder, level);
        }
    }
}
