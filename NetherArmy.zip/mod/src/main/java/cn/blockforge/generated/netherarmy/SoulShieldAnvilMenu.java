package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;

/**
 * 铁砧菜单的自有子类，唯一改动是放行"cost==0"的输出拿取：
 * 原版 {@link AnvilMenu#mayPickup} 写死了 cost>0，否则 0 经验消耗的产物
 * （见 {@link SoulShieldAnvilRepair}）会被永远锁在输出槽里。
 * cost>0 的一切操作（原版材料修复、附魔、改名、狂战士头盔配方）仍走原版判定。
 */
public final class SoulShieldAnvilMenu extends AnvilMenu {
    /** 客户端构造：MenuType 工厂只带 (id, inventory)，与原版 ANVIL 完全一致。 */
    public SoulShieldAnvilMenu(int containerId, Inventory inventory) {
        this(containerId, inventory, ContainerLevelAccess.NULL);
    }

    public SoulShieldAnvilMenu(int containerId, Inventory inventory, ContainerLevelAccess access) {
        super(containerId, inventory, access);
    }

    @Override
    protected boolean mayPickup(Player player, boolean hasItem) {
        if (getCost() <= 0) {
            // cost<=0 且输出槽有物品的状态只可能来自免经验修复配方（原版无产出必清零槽位）。
            return hasItem;
        }
        return super.mayPickup(player, hasItem);
    }
}
