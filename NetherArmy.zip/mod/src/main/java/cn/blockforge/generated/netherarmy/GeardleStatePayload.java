package cn.blockforge.generated.netherarmy;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 服务端 → 客户端的格尔多末日状态同步：登录、重生、右键激活时各推一次。
 * 客户端据此渲染玩家背后的格尔多贴图与夜晚的致盲遮罩。
 */
public record GeardleStatePayload(boolean active) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GeardleStatePayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(
                    GeneratedMod.MOD_ID, "geardle_state"));
    public static final StreamCodec<ByteBuf, GeardleStatePayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, GeardleStatePayload::active, GeardleStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
