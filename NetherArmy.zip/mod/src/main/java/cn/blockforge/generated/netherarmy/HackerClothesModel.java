package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 黑客衣服层。由 tools/gen_hacker_model.py 从 hacker.bbmodel 生成。
 * 每个面保存四个真实顶点、UV 矩形和法线，完整保留 element 旋转。
 */
public final class HackerClothesModel extends EntityModel<Hacker> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "hacker_clothes"), "main");
    private static final int TEX_WIDTH = 160;
    private static final int TEX_HEIGHT = 160;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart computer;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    private static final float[] BODY = {
        -4.25F, -12.0F, -2.25F, 4.25F, -12.0F, -2.25F, 4.25F, 0.5F, -2.25F, -4.25F,
        0.5F, -2.25F, 10.0F, 50.0F, 20.0F, 64.0F, 0.0F, 0.0F, -1.0F, 4.25F,
        -12.0F, 2.25F, -4.25F, -12.0F, 2.25F, -4.25F, 0.5F, 2.25F, 4.25F, 0.5F,
        2.25F, 25.0F, 50.0F, 32.0F, 64.0F, 0.0F, 0.0F, 1.0F, -4.25F, -12.0F,
        2.25F, -4.25F, -12.0F, -2.25F, -4.25F, 0.5F, -2.25F, -4.25F, 0.5F, 2.25F,
        6.0F, 50.0F, 10.0F, 64.0F, -1.0F, 0.0F, 0.0F, 4.25F, -12.0F, -2.25F,
        4.25F, -12.0F, 2.25F, 4.25F, 0.5F, 2.25F, 4.25F, 0.5F, -2.25F, 20.0F,
        50.0F, 25.0F, 64.0F, 1.0F, 0.0F, 0.0F, 4.25F, -12.0F, -2.25F, -4.25F,
        -12.0F, -2.25F, -4.25F, -12.0F, 2.25F, 4.25F, -12.0F, 2.25F, 10.0F, 46.0F,
        18.0F, 50.0F, 0.0F, -1.0F, 0.0F, 4.25F, 0.5F, 2.25F, -4.25F, 0.5F,
        2.25F, -4.25F, 0.5F, -2.25F, 4.25F, 0.5F, -2.25F, 17.0F, 45.0F, 27.0F,
        48.0F, 0.0F, 1.0F, 0.0F, -3.75F, -11.5F, 0.75F, 3.25F, -11.5F, 0.75F,
        3.25F, -8.5F, 0.75F, -3.75F, -8.5F, 0.75F, 127.0F, 4.0F, 137.0F, 18.0F,
        0.0F, 0.0F, -1.0F, 3.25F, -11.5F, 4.25F, -3.75F, -11.5F, 4.25F, -3.75F,
        -8.5F, 4.25F, 3.25F, -8.5F, 4.25F, 106.0F, 14.0F, 115.0F, 21.0F, 0.0F,
        0.0F, 1.0F, -3.75F, -11.5F, 4.25F, -3.75F, -11.5F, 0.75F, -3.75F, -8.5F,
        0.75F, -3.75F, -8.5F, 4.25F, 115.0F, 14.0F, 118.0F, 21.0F, -1.0F, 0.0F,
        0.0F, 3.25F, -11.5F, 0.75F, 3.25F, -11.5F, 4.25F, 3.25F, -8.5F, 4.25F,
        3.25F, -8.5F, 0.75F, 103.0F, 14.0F, 106.0F, 21.0F, 1.0F, 0.0F, 0.0F,
        3.25F, -11.5F, 0.75F, -3.75F, -11.5F, 0.75F, -3.75F, -11.5F, 4.25F, 3.25F,
        -11.5F, 4.25F, 93.0F, 8.0F, 101.0F, 12.0F, 0.0F, -1.0F, 0.0F, 3.25F,
        -8.5F, 4.25F, -3.75F, -8.5F, 4.25F, -3.75F, -8.5F, 0.75F, 3.25F, -8.5F,
        0.75F, 106.0F, 20.0F, 115.0F, 23.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] COMPUTER = {
        3.5F, -15.0F, -18.0F, 12.0F, -15.0F, -18.0F, 12.0F, -4.0F, -18.0F, 3.5F,
        -4.0F, -18.0F, 117.0F, 76.0F, 127.0F, 89.0F, 0.0F, 0.0F, -1.0F, 12.0F,
        -15.0F, -7.0F, 3.5F, -15.0F, -7.0F, 3.5F, -4.0F, -7.0F, 12.0F, -4.0F,
        -7.0F, 132.0F, 76.0F, 139.0F, 89.0F, 0.0F, 0.0F, 1.0F, 3.5F, -15.0F,
        -7.0F, 3.5F, -15.0F, -18.0F, 3.5F, -4.0F, -18.0F, 3.5F, -4.0F, -7.0F,
        92.0F, 34.0F, 124.0F, 69.0F, -1.0F, 0.0F, 0.0F, 12.0F, -15.0F, -18.0F,
        12.0F, -15.0F, -7.0F, 12.0F, -4.0F, -7.0F, 12.0F, -4.0F, -18.0F, 124.0F,
        34.0F, 154.0F, 69.0F, 1.0F, 0.0F, 0.0F, 12.0F, -15.0F, -18.0F, 3.5F,
        -15.0F, -18.0F, 3.5F, -15.0F, -7.0F, 12.0F, -15.0F, -7.0F, 117.0F, 72.0F,
        125.0F, 75.0F, 0.0F, -1.0F, 0.0F, 12.0F, -4.0F, -7.0F, 3.5F, -4.0F,
        -7.0F, 3.5F, -4.0F, -18.0F, 12.0F, -4.0F, -18.0F, 124.0F, 71.0F, 134.0F,
        73.0F, 0.0F, 1.0F, 0.0F, 3.25F, -8.1F, -19.75F, 12.25F, -8.1F, -19.75F,
        12.25F, -7.5F, -19.75F, 3.25F, -7.5F, -19.75F, 69.0F, 104.0F, 98.0F, 112.0F,
        0.0F, 0.0F, -1.0F, 12.25F, -8.1F, -12.75F, 3.25F, -8.1F, -12.75F, 3.25F,
        -7.5F, -12.75F, 12.25F, -7.5F, -12.75F, 129.0F, 104.0F, 160.0F, 112.0F, 0.0F,
        0.0F, 1.0F, 3.25F, -8.1F, -12.75F, 3.25F, -8.1F, -19.75F, 3.25F, -7.5F,
        -19.75F, 3.25F, -7.5F, -12.75F, 38.0F, 104.0F, 69.0F, 112.0F, -1.0F, 0.0F,
        0.0F, 12.25F, -8.1F, -19.75F, 12.25F, -8.1F, -12.75F, 12.25F, -7.5F, -12.75F,
        12.25F, -7.5F, -19.75F, 98.0F, 104.0F, 129.0F, 112.0F, 1.0F, 0.0F, 0.0F,
        12.25F, -8.1F, -19.75F, 3.25F, -8.1F, -19.75F, 3.25F, -8.1F, -12.75F, 12.25F,
        -8.1F, -12.75F, 69.0F, 89.0F, 98.0F, 104.0F, 0.0F, -1.0F, 0.0F, 12.25F,
        -7.5F, -12.75F, 3.25F, -7.5F, -12.75F, 3.25F, -7.5F, -19.75F, 12.25F, -7.5F,
        -19.75F, 98.0F, 89.0F, 129.0F, 104.0F, 0.0F, 1.0F, 0.0F, 12.25F, -14.66396F,
        -21.19221F, 3.25F, -14.66396F, -21.19221F, 3.25F, -14.79382F, -20.60643F, 12.25F, -14.79382F, -20.60643F,
        69.0F, 140.0F, 98.0F, 148.0F, 0.0F, 0.0F, -1.0F, 3.25F, -7.82988F, -19.67713F,
        12.25F, -7.82988F, -19.67713F, 12.25F, -7.95975F, -19.09135F, 3.25F, -7.95975F, -19.09135F, 129.0F,
        140.0F, 160.0F, 148.0F, 0.0F, 0.0F, 1.0F, 12.25F, -7.82988F, -19.67713F, 12.25F,
        -14.66396F, -21.19221F, 12.25F, -14.79382F, -20.60643F, 12.25F, -7.95975F, -19.09135F, 38.0F, 140.0F,
        69.0F, 148.0F, -1.0F, 0.0F, 0.0F, 3.25F, -14.66396F, -21.19221F, 3.25F, -7.82988F,
        -19.67713F, 3.25F, -7.95975F, -19.09135F, 3.25F, -14.79382F, -20.60643F, 98.0F, 140.0F, 129.0F,
        148.0F, 1.0F, 0.0F, 0.0F, 3.25F, -14.66396F, -21.19221F, 12.25F, -14.66396F, -21.19221F,
        12.25F, -7.82988F, -19.67713F, 3.25F, -7.82988F, -19.67713F, 69.0F, 125.0F, 98.0F, 140.0F,
        0.0F, -1.0F, 0.0F, 3.25F, -7.95975F, -19.09135F, 12.25F, -7.95975F, -19.09135F, 12.25F,
        -14.79382F, -20.60643F, 3.25F, -14.79382F, -20.60643F, 98.0F, 125.0F, 129.0F, 140.0F, 0.0F,
        1.0F, 0.0F
    };
    private static final float[] HEAD = {
        0.1F, -4.9F, -4.1F, 4.1F, -4.9F, -4.1F, 4.1F, -2.4F, -4.1F, 0.1F,
        -2.4F, -4.1F, 20.0F, 9.0F, 29.0F, 14.0F, 0.0F, 0.0F, -1.0F, 4.1F,
        -4.9F, -0.1F, 0.1F, -4.9F, -0.1F, 0.1F, -2.4F, -0.1F, 4.1F, -2.4F,
        -0.1F, 36.0F, 9.0F, 44.0F, 14.0F, 0.0F, 0.0F, 1.0F, 0.1F, -4.9F,
        -0.1F, 0.1F, -4.9F, -4.1F, 0.1F, -2.4F, -4.1F, 0.1F, -2.4F, -0.1F,
        12.0F, 9.0F, 20.0F, 14.0F, -1.0F, 0.0F, 0.0F, 4.1F, -4.9F, -4.1F,
        4.1F, -4.9F, -0.1F, 4.1F, -2.4F, -0.1F, 4.1F, -2.4F, -4.1F, 29.0F,
        9.0F, 36.0F, 14.0F, 1.0F, 0.0F, 0.0F, 4.1F, -4.9F, -4.1F, 0.1F,
        -4.9F, -4.1F, 0.1F, -4.9F, -0.1F, 4.1F, -4.9F, -0.1F, 20.0F, 1.0F,
        28.0F, 9.0F, 0.0F, -1.0F, 0.0F, 4.1F, -2.4F, -0.1F, 0.1F, -2.4F,
        -0.1F, 0.1F, -2.4F, -4.1F, 4.1F, -2.4F, -4.1F, 28.0F, 1.0F, 36.0F,
        9.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_ARM = {
        -1.25F, -0.25F, -1.25F, 1.25F, -0.25F, -1.25F, 1.25F, 9.75F, -1.25F, -1.25F,
        9.75F, -1.25F, 73.0F, 40.0F, 77.0F, 66.0F, 0.0F, 0.0F, -1.0F, 1.25F,
        -0.25F, 1.25F, -1.25F, -0.25F, 1.25F, -1.25F, 9.75F, 1.25F, 1.25F, 9.75F,
        1.25F, 81.0F, 40.0F, 85.0F, 66.0F, 0.0F, 0.0F, 1.0F, -1.25F, -0.25F,
        1.25F, -1.25F, -0.25F, -1.25F, -1.25F, 9.75F, -1.25F, -1.25F, 9.75F, 1.25F,
        68.9F, 40.0F, 72.9F, 66.0F, -1.0F, 0.0F, 0.0F, 1.25F, -0.25F, -1.25F,
        1.25F, -0.25F, 1.25F, 1.25F, 9.75F, 1.25F, 1.25F, 9.75F, -1.25F, 76.9F,
        40.0F, 80.9F, 66.0F, 1.0F, 0.0F, 0.0F, 1.25F, -0.25F, -1.25F, -1.25F,
        -0.25F, -1.25F, -1.25F, -0.25F, 1.25F, 1.25F, -0.25F, 1.25F, 73.0F, 36.0F,
        77.0F, 40.0F, 0.0F, -1.0F, 0.0F, 1.25F, 9.75F, 1.25F, -1.25F, 9.75F,
        1.25F, -1.25F, 9.75F, -1.25F, 1.25F, 9.75F, -1.25F, 77.0F, 36.0F, 81.0F,
        40.0F, 0.0F, 1.0F, 0.0F, -1.1F, 9.8F, -1.1F, 1.1F, 9.8F, -1.1F,
        1.1F, 12.0F, -1.1F, -1.1F, 12.0F, -1.1F, 38.0F, 30.0F, 42.0F, 34.0F,
        0.0F, 0.0F, -1.0F, 1.1F, 9.8F, 1.1F, -1.1F, 9.8F, 1.1F, -1.1F,
        12.0F, 1.1F, 1.1F, 12.0F, 1.1F, 46.0F, 30.0F, 50.0F, 34.0F, 0.0F,
        0.0F, 1.0F, -1.1F, 9.8F, 1.1F, -1.1F, 9.8F, -1.1F, -1.1F, 12.0F,
        -1.1F, -1.1F, 12.0F, 1.1F, 33.9F, 30.0F, 37.9F, 34.0F, -1.0F, 0.0F,
        0.0F, 1.1F, 9.8F, -1.1F, 1.1F, 9.8F, 1.1F, 1.1F, 12.0F, 1.1F,
        1.1F, 12.0F, -1.1F, 41.9F, 30.0F, 45.9F, 34.0F, 1.0F, 0.0F, 0.0F,
        1.1F, 9.8F, -1.1F, -1.1F, 9.8F, -1.1F, -1.1F, 9.8F, 1.1F, 1.1F,
        9.8F, 1.1F, 38.0F, 26.0F, 42.0F, 30.0F, 0.0F, -1.0F, 0.0F, 1.1F,
        12.0F, 1.1F, -1.1F, 12.0F, 1.1F, -1.1F, 12.0F, -1.1F, 1.1F, 12.0F,
        -1.1F, 42.0F, 26.0F, 46.0F, 30.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_ARM = {
        -1.25F, -0.25F, -1.25F, 1.25F, -0.25F, -1.25F, 1.25F, 9.75F, -1.25F, -1.25F,
        9.75F, -1.25F, 73.0F, 40.0F, 77.0F, 66.0F, 0.0F, 0.0F, -1.0F, 1.25F,
        -0.25F, 1.25F, -1.25F, -0.25F, 1.25F, -1.25F, 9.75F, 1.25F, 1.25F, 9.75F,
        1.25F, 81.0F, 40.0F, 85.0F, 66.0F, 0.0F, 0.0F, 1.0F, -1.25F, -0.25F,
        1.25F, -1.25F, -0.25F, -1.25F, -1.25F, 9.75F, -1.25F, -1.25F, 9.75F, 1.25F,
        68.9F, 40.0F, 72.9F, 66.0F, -1.0F, 0.0F, 0.0F, 1.25F, -0.25F, -1.25F,
        1.25F, -0.25F, 1.25F, 1.25F, 9.75F, 1.25F, 1.25F, 9.75F, -1.25F, 76.9F,
        40.0F, 80.9F, 66.0F, 1.0F, 0.0F, 0.0F, 1.25F, -0.25F, -1.25F, -1.25F,
        -0.25F, -1.25F, -1.25F, -0.25F, 1.25F, 1.25F, -0.25F, 1.25F, 73.0F, 36.0F,
        77.0F, 40.0F, 0.0F, -1.0F, 0.0F, 1.25F, 9.75F, 1.25F, -1.25F, 9.75F,
        1.25F, -1.25F, 9.75F, -1.25F, 1.25F, 9.75F, -1.25F, 77.0F, 36.0F, 81.0F,
        40.0F, 0.0F, 1.0F, 0.0F, -1.1F, 9.8F, -1.1F, 1.1F, 9.8F, -1.1F,
        1.1F, 12.0F, -1.1F, -1.1F, 12.0F, -1.1F, 38.0F, 30.0F, 42.0F, 34.0F,
        0.0F, 0.0F, -1.0F, 1.1F, 9.8F, 1.1F, -1.1F, 9.8F, 1.1F, -1.1F,
        12.0F, 1.1F, 1.1F, 12.0F, 1.1F, 46.0F, 30.0F, 50.0F, 34.0F, 0.0F,
        0.0F, 1.0F, -1.1F, 9.8F, 1.1F, -1.1F, 9.8F, -1.1F, -1.1F, 12.0F,
        -1.1F, -1.1F, 12.0F, 1.1F, 33.9F, 30.0F, 37.9F, 34.0F, -1.0F, 0.0F,
        0.0F, 1.1F, 9.8F, -1.1F, 1.1F, 9.8F, 1.1F, 1.1F, 12.0F, 1.1F,
        1.1F, 12.0F, -1.1F, 41.9F, 30.0F, 45.9F, 34.0F, 1.0F, 0.0F, 0.0F,
        1.1F, 9.8F, -1.1F, -1.1F, 9.8F, -1.1F, -1.1F, 9.8F, 1.1F, 1.1F,
        9.8F, 1.1F, 38.0F, 26.0F, 42.0F, 30.0F, 0.0F, -1.0F, 0.0F, 1.1F,
        12.0F, 1.1F, -1.1F, 12.0F, 1.1F, -1.1F, 12.0F, -1.1F, 1.1F, 12.0F,
        -1.1F, 42.0F, 26.0F, 46.0F, 30.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_LEG = {
        -1.5F, 0.0F, -1.5F, 1.5F, 0.0F, -1.5F, 1.5F, 6.0F, -1.5F, -1.5F,
        6.0F, -1.5F, 44.0F, 49.0F, 47.0F, 64.0F, 0.0F, 0.0F, -1.0F, 1.5F,
        0.0F, 1.5F, -1.5F, 0.0F, 1.5F, -1.5F, 6.0F, 1.5F, 1.5F, 6.0F,
        1.5F, 50.0F, 49.0F, 53.0F, 64.0F, 0.0F, 0.0F, 1.0F, -1.5F, 0.0F,
        1.5F, -1.5F, 0.0F, -1.5F, -1.5F, 6.0F, -1.5F, -1.5F, 6.0F, 1.5F,
        41.0F, 49.0F, 44.0F, 64.0F, -1.0F, 0.0F, 0.0F, 1.5F, 0.0F, -1.5F,
        1.5F, 0.0F, 1.5F, 1.5F, 6.0F, 1.5F, 1.5F, 6.0F, -1.5F, 47.0F,
        49.0F, 50.0F, 64.0F, 1.0F, 0.0F, 0.0F, 1.5F, 0.0F, -1.5F, -1.5F,
        0.0F, -1.5F, -1.5F, 0.0F, 1.5F, 1.5F, 0.0F, 1.5F, 44.0F, 46.0F,
        47.0F, 49.0F, 0.0F, -1.0F, 0.0F, 1.5F, 6.0F, 1.5F, -1.5F, 6.0F,
        1.5F, -1.5F, 6.0F, -1.5F, 1.5F, 6.0F, -1.5F, 47.0F, 46.0F, 50.0F,
        49.0F, 0.0F, 1.0F, 0.0F, -1.5F, 9.0F, -1.5F, 1.5F, 9.0F, -1.5F,
        1.5F, 12.0F, -1.5F, -1.5F, 12.0F, -1.5F, 68.0F, 24.0F, 72.0F, 29.0F,
        0.0F, 0.0F, -1.0F, 1.5F, 9.0F, 1.5F, -1.5F, 9.0F, 1.5F, -1.5F,
        12.0F, 1.5F, 1.5F, 12.0F, 1.5F, 76.0F, 24.0F, 80.0F, 29.0F, 0.0F,
        0.0F, 1.0F, -1.5F, 9.0F, 1.5F, -1.5F, 9.0F, -1.5F, -1.5F, 12.0F,
        -1.5F, -1.5F, 12.0F, 1.5F, 64.0F, 24.0F, 68.0F, 29.0F, -1.0F, 0.0F,
        0.0F, 1.5F, 9.0F, -1.5F, 1.5F, 9.0F, 1.5F, 1.5F, 12.0F, 1.5F,
        1.5F, 12.0F, -1.5F, 72.0F, 24.0F, 76.0F, 29.0F, 1.0F, 0.0F, 0.0F,
        1.5F, 9.0F, -1.5F, -1.5F, 9.0F, -1.5F, -1.5F, 9.0F, 1.5F, 1.5F,
        9.0F, 1.5F, 68.0F, 20.0F, 72.0F, 24.0F, 0.0F, -1.0F, 0.0F, 1.5F,
        12.0F, 1.5F, -1.5F, 12.0F, 1.5F, -1.5F, 12.0F, -1.5F, 1.5F, 12.0F,
        -1.5F, 72.0F, 20.0F, 76.0F, 24.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_LEG = {
        -1.7F, 0.0F, -1.5F, 1.3F, 0.0F, -1.5F, 1.3F, 6.0F, -1.5F, -1.7F,
        6.0F, -1.5F, 44.0F, 49.0F, 47.0F, 64.0F, 0.0F, 0.0F, -1.0F, 1.3F,
        0.0F, 1.5F, -1.7F, 0.0F, 1.5F, -1.7F, 6.0F, 1.5F, 1.3F, 6.0F,
        1.5F, 50.0F, 49.0F, 53.0F, 64.0F, 0.0F, 0.0F, 1.0F, -1.7F, 0.0F,
        1.5F, -1.7F, 0.0F, -1.5F, -1.7F, 6.0F, -1.5F, -1.7F, 6.0F, 1.5F,
        41.0F, 49.0F, 44.0F, 64.0F, -1.0F, 0.0F, 0.0F, 1.3F, 0.0F, -1.5F,
        1.3F, 0.0F, 1.5F, 1.3F, 6.0F, 1.5F, 1.3F, 6.0F, -1.5F, 47.0F,
        49.0F, 50.0F, 64.0F, 1.0F, 0.0F, 0.0F, 1.3F, 0.0F, -1.5F, -1.7F,
        0.0F, -1.5F, -1.7F, 0.0F, 1.5F, 1.3F, 0.0F, 1.5F, 44.0F, 46.0F,
        47.0F, 49.0F, 0.0F, -1.0F, 0.0F, 1.3F, 6.0F, 1.5F, -1.7F, 6.0F,
        1.5F, -1.7F, 6.0F, -1.5F, 1.3F, 6.0F, -1.5F, 47.0F, 46.0F, 50.0F,
        49.0F, 0.0F, 1.0F, 0.0F, -1.7F, 9.0F, -1.5F, 1.3F, 9.0F, -1.5F,
        1.3F, 12.0F, -1.5F, -1.7F, 12.0F, -1.5F, 68.0F, 24.0F, 72.0F, 29.0F,
        0.0F, 0.0F, -1.0F, 1.3F, 9.0F, 1.5F, -1.7F, 9.0F, 1.5F, -1.7F,
        12.0F, 1.5F, 1.3F, 12.0F, 1.5F, 76.0F, 24.0F, 80.0F, 29.0F, 0.0F,
        0.0F, 1.0F, -1.7F, 9.0F, 1.5F, -1.7F, 9.0F, -1.5F, -1.7F, 12.0F,
        -1.5F, -1.7F, 12.0F, 1.5F, 64.0F, 24.0F, 68.0F, 29.0F, -1.0F, 0.0F,
        0.0F, 1.3F, 9.0F, -1.5F, 1.3F, 9.0F, 1.5F, 1.3F, 12.0F, 1.5F,
        1.3F, 12.0F, -1.5F, 72.0F, 24.0F, 76.0F, 29.0F, 1.0F, 0.0F, 0.0F,
        1.3F, 9.0F, -1.5F, -1.7F, 9.0F, -1.5F, -1.7F, 9.0F, 1.5F, 1.3F,
        9.0F, 1.5F, 68.0F, 20.0F, 72.0F, 24.0F, 0.0F, -1.0F, 0.0F, 1.3F,
        12.0F, 1.5F, -1.7F, 12.0F, 1.5F, -1.7F, 12.0F, -1.5F, 1.3F, 12.0F,
        -1.5F, 72.0F, 20.0F, 76.0F, 24.0F, 0.0F, 1.0F, 0.0F
    };

    public HackerClothesModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.computer = this.body.getChild("computer");
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    @Override
    public void setupAnim(Hacker entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        HackerPose.apply(this.root, entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.body, BODY, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.pushPose();
        this.body.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.computer, COMPUTER, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
        HackerQuads.emit(poseStack, buffer, this.head, HEAD, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightArm, RIGHT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftArm, LEFT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightLeg, RIGHT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftLeg, LEFT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create(),
                PartPose.offset(0.0F, 12.0F, 0.0F));
        body.addOrReplaceChild("computer", CubeListBuilder.create(),
                PartPose.offset(-7.75F, 4.5F, 7.75F));
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
