package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

import java.util.List;
import java.util.UUID;

/** 无头骑士的躯体：凋灵骷髅系近战实体，负责创建头颅与坐骑。 */
public class DullhanBody extends WitherSkeleton {
    private static final String GROUP_ID_TAG = "DullhanGroupId";
    private static final double TARGET_SYNC_RADIUS = 48.0D;
    private static final double HEAD_SIDE_OFFSET = 0.28D;
    private static final double HEAD_FRONT_OFFSET = 0.30D;
    private static final double HEAD_VERTICAL_OFFSET = 1.0D;
    private boolean companionsInitialized;

    /**
     * 仇恨过滤：创造/旁观模式的玩家不作为任何部件的攻击目标。
     * 三个部件的 setTarget 覆写统一走这里，反击目标与编组内目标同步均被拦截。
     */
    public static boolean isIgnoredTarget(LivingEntity target) {
        return target instanceof net.minecraft.world.entity.player.Player player
                && (player.isCreative() || player.isSpectator());
    }

    /** 获取或创建贯穿躯干、头颅和马的持久化编组 ID。 */
    public static UUID ensureGroupId(Entity entity) {
        CompoundTag data = entity.getPersistentData();
        if (!data.hasUUID(GROUP_ID_TAG)) {
            data.putUUID(GROUP_ID_TAG, entity.getUUID());
        }
        return data.getUUID(GROUP_ID_TAG);
    }

    public static void setGroupId(Entity entity, UUID groupId) {
        entity.getPersistentData().putUUID(GROUP_ID_TAG, groupId);
    }

    /** 将任一部件当前的目标同步给同一无头骑士的其它部件。 */
    public static void synchronizeTargets(Entity source) {
        if (source.level().isClientSide() || !(source instanceof net.minecraft.world.entity.Mob sourceMob)) {
            return;
        }
        LivingEntity target = sourceMob.getTarget();
        if (target == null || !target.isAlive()) {
            return;
        }
        UUID groupId = ensureGroupId(source);
        for (Entity nearby : source.level().getEntitiesOfClass(Entity.class,
                source.getBoundingBox().inflate(TARGET_SYNC_RADIUS), entity -> entity != source)) {
            if (!(nearby instanceof DullhanBody || nearby instanceof DullhanHead || nearby instanceof DullhanHorse)
                    || !nearby.getPersistentData().hasUUID(GROUP_ID_TAG)
                    || !groupId.equals(nearby.getPersistentData().getUUID(GROUP_ID_TAG))) {
                continue;
            }
            if (nearby instanceof net.minecraft.world.entity.Mob companion
                    && companion.getTarget() != target) {
                companion.setTarget(target);
            }
        }
    }

    public DullhanBody(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        // 与凋灵骷髅一致：基础经验为 5 点。
        this.xpReward = 5;
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    protected EntityDimensions getDefaultDimensions(Pose pose) {
        // 身体模型从脚底到肩部为 24 像素；头部以下的模型和判定均不再保留。
        return EntityDimensions.fixed(0.7F, 1.8F).withEyeHeight(1.5F);
    }

    @Override
    public boolean canUseSlot(EquipmentSlot slot) {
        return slot != EquipmentSlot.HEAD && super.canUseSlot(slot);
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_SKELETON_DEATH;
    }

    @Override
    protected SoundEvent getStepSound() {
        return SoundEvents.WITHER_SKELETON_STEP;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction moveFunction) {
        if (passenger instanceof DullhanHead) {
            // 把头颅放在躯干左臂（模型左侧）的怀中，而不是骑乘点正上方。
            double yaw = Math.toRadians(this.getYRot());
            double sideX = Math.cos(yaw) * HEAD_SIDE_OFFSET;
            double sideZ = Math.sin(yaw) * HEAD_SIDE_OFFSET;
            // Minecraft 的实体正面是 -Z；该向量把头颅放到左臂怀中的前侧。
            double frontX = Math.sin(yaw) * HEAD_FRONT_OFFSET;
            double frontZ = -Math.cos(yaw) * HEAD_FRONT_OFFSET;
            // 头颅实体原点就是 0.5 格碰撞箱的底面，模型与判定箱完全同轴。
            moveFunction.accept(passenger, this.getX() + sideX + frontX,
                    this.getY() + HEAD_VERTICAL_OFFSET, this.getZ() + sideZ + frontZ);
            passenger.setYRot(this.getYRot());
            passenger.setYHeadRot(this.getYRot());
            return;
        }
        super.positionRider(passenger, moveFunction);
    }

    /** 拦截对创造/旁观玩家的仇恨：受击反击与部件同步都不能锁定他们。 */
    @Override
    public void setTarget(LivingEntity target) {
        if (isIgnoredTarget(target)) {
            return;
        }
        super.setTarget(target);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.FOLLOW_RANGE, 35.0D);
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         net.minecraft.world.entity.MobSpawnType spawnType,
                                         SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.setLeftHanded(false);
        this.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        RandomSource random = this.getRandom();
        equipPiece(random, EquipmentSlot.CHEST, Items.GOLDEN_CHESTPLATE, Items.IRON_CHESTPLATE);
        equipPiece(random, EquipmentSlot.LEGS, Items.GOLDEN_LEGGINGS, Items.IRON_LEGGINGS);
        equipPiece(random, EquipmentSlot.FEET, Items.GOLDEN_BOOTS, Items.IRON_BOOTS);
        // 伴侣实体不能在这里创建：刷怪蛋此时尚未把躯体加入世界。
        // 首个服务端 tick 会在实体正式加入世界后补齐马和头颅。
        return result;
    }

    private void equipPiece(RandomSource random, EquipmentSlot slot,
                            net.minecraft.world.item.Item gold, net.minecraft.world.item.Item iron) {
        if (random.nextFloat() < 0.30F) {
            this.setItemSlot(slot, new ItemStack(random.nextBoolean() ? gold : iron));
            this.setDropChance(slot, 0.0F);
        }
    }

    /** 坐骑工厂：无头骑士本体在此挂原版骷髅马；强袭骑士子类覆写为强袭坐骑。 */
    protected DullhanHorse createMount(ServerLevel level) {
        return GeneratedMod.DULLHAN_HORSE.get().create(level);
    }

    /** 头颅工厂：同上，子类覆写为强袭头颅。 */
    protected DullhanHead createHead(ServerLevel level) {
        return GeneratedMod.DULLHAN_HEAD.get().create(level);
    }

    private boolean createCompanions(ServerLevel level, DifficultyInstance difficulty,
                                  net.minecraft.world.entity.MobSpawnType spawnType) {
        if (!this.getPassengers().isEmpty() || this.isRemoved()) {
            return true;
        }
        DullhanHorse horse = createMount(level);
        DullhanHead head = createHead(level);
        if (horse == null || head == null) {
            return false;
        }
        UUID groupId = ensureGroupId(this);
        setGroupId(horse, groupId);
        setGroupId(head, groupId);
        horse.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), 0.0F);
        horse.setPersistenceRequired();
        horse.finalizeSpawn(level, difficulty, spawnType, null);
        // 先放在与实体脚点一致的低空高度，正式乘骑后由 positionRider 统一定位。
        head.moveTo(this.getX(), this.getY() + HEAD_VERTICAL_OFFSET, this.getZ(), this.getYRot(), 0.0F);
        head.setPersistenceRequired();
        head.finalizeSpawn(level, difficulty, spawnType, null);
        boolean horseAdded = level.addFreshEntity(horse);
        boolean headAdded = horseAdded && level.addFreshEntity(head);
        boolean mounted = horseAdded && headAdded
                && this.startRiding(horse, true)
                && head.startRiding(this, true);
        if (mounted) {
            return true;
        }
        horse.discard();
        head.discard();
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("DullhanCompanionsInitialized", this.companionsInitialized);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.companionsInitialized = tag.getBoolean("DullhanCompanionsInitialized");
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            return;
        }
        ensureGroupId(this);
        if (!this.companionsInitialized) {
            if (!this.getPassengers().isEmpty()) {
                // 存档载入时乘客已经恢复，不再重复创建伴侣。
                this.companionsInitialized = true;
            } else {
                DifficultyInstance difficulty = this.level().getCurrentDifficultyAt(this.blockPosition());
                this.companionsInitialized = createCompanions((ServerLevel) this.level(), difficulty,
                        this.getSpawnType());
            }
        }
        if (this.getVehicle() instanceof DullhanHorse horse) {
            if (this.getTarget() != null) {
                horse.setTarget(this.getTarget());
            } else if (horse.getTarget() != null) {
                this.setTarget(horse.getTarget());
            }
        }
        // setTarget 可能会让头颅主动拆乘，不能在原始乘客列表上遍历时修改它。
        for (Entity passenger : List.copyOf(this.getPassengers())) {
            if (passenger instanceof DullhanHead head) {
                setGroupId(head, ensureGroupId(this));
            }
            if (passenger instanceof DullhanHead head && this.getTarget() != null) {
                head.setTarget(this.getTarget());
                // 接近敌人后释放悬浮头颅，让头颅独立追击并攻击目标。
                if (this.distanceToSqr(this.getTarget()) <= 64.0D && head.getVehicle() == this) {
                    head.stopRiding();
                    // 拆乘后仍以碰撞箱底面为模型原点；头颅 tick 会继续维持低空高度。
                    head.setPos(this.getX(), this.getY() + HEAD_VERTICAL_OFFSET, this.getZ());
                }
            }
        }
        DullhanBody.synchronizeTargets(this);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof net.minecraft.world.entity.LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100), this);
        }
        return hurt;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
    }
}
