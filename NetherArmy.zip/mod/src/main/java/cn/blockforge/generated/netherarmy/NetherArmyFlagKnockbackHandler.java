package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingKnockBackEvent;

/**
 * 下界军团旗帜的击退减半：击退能力是剑的 50%。
 *
 * <p>1.21.1 原版近战命中击退的唯一来源是 {@code LivingEntity#hurt} 里固定值的
 * {@code knockback(0.4, dx, dz)}（玩家与剑都没有 {@code ATTACK_KNOCKBACK} 属性
 * 修饰符；横扫的 0.4 与暴击的 +1 也统一走 {@code LivingEntity#knockback}），
 * NeoForge 在生效前以 {@link LivingKnockBackEvent} 暴露强度。</p>
 *
 * <p>这里在事件里判定"被击退者刚在本刻被一名玩家近战命中，且该玩家主手持
 * 下界军团旗帜"，把强度乘 0.5——普通命中 0.4→0.2，暴击/击退附魔的额外分量
 * 同样减半，倍率一致。原版剑保持 0.4 不动，因此旗帜的击退恰为剑的 50%。</p>
 *
 * <p>时间戳同刻判定避免误伤：被击退者上一次受击若是更早的持旗攻击
 * （{@code lastHurtByMob} 会残留），不会把无关的爆炸/弹道击退也减半；
 * 持旗者自己挨打时（{@code attacker == knocked}）同样跳过。</p>
 */
public final class NetherArmyFlagKnockbackHandler {
    private NetherArmyFlagKnockbackHandler() {
    }

    @SubscribeEvent
    public static void onLivingKnockBack(LivingKnockBackEvent event) {
        if (event.isCanceled()) {
            return;
        }
        LivingEntity knocked = event.getEntity();
        if (knocked.level().isClientSide()) {
            return;
        }
        if (!(knocked.getLastHurtByMob() instanceof Player attacker) || attacker == knocked) {
            return;
        }
        if (knocked.getLastHurtByMobTimestamp() != knocked.level().getGameTime()) {
            return;
        }
        if (attacker.getMainHandItem().is(GeneratedMod.NETHER_ARMY_FLAG.get())) {
            event.setStrength(event.getStrength() * 0.5F);
        }
    }
}
