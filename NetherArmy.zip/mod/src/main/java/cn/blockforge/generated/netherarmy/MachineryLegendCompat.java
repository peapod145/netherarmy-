package cn.blockforge.generated.netherarmy;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;

/**
 * 《器械传说》的可选兼容层。
 *
 * <p>本类不引用器械传说的任何 Java 类型，只按稳定的基类全名与注册命名空间识别。
 * 因此删除器械传说后，所有判断都会快速返回 false，地狱军团仍可独立启动。</p>
 */
public final class MachineryLegendCompat {
    private static final String MACHINERY_ENTITY_CLASS =
            "cn.blockforge.generated.machinerylegend.entity.MachineryEntity";
    private static final String MACHINERY_ENTITY_PACKAGE =
            "cn.blockforge.generated.machinerylegend.entity.";
    private static final String MACHINERY_NAMESPACE = "machinery_legend";
    private static final double MACHINERY_HUNT_RANGE = 15.0D;
    private static final Map<Class<?>, Boolean> MACHINERY_CLASS_CACHE = new ConcurrentHashMap<>();

    private MachineryLegendCompat() {
    }

    /** 是否为器械传说的蓝图器械实体。 */
    public static boolean isMachinery(Entity entity) {
        if (!(entity instanceof Mob mob)) {
            return false;
        }
        Class<?> type = mob.getClass();
        if (!type.getName().startsWith(MACHINERY_ENTITY_PACKAGE)) {
            return false;
        }
        return MACHINERY_CLASS_CACHE.computeIfAbsent(type, MachineryLegendCompat::extendsMachineryEntity);
    }

    private static boolean extendsMachineryEntity(Class<?> type) {
        for (Class<?> current = type; current != null && current != Object.class;
             current = current.getSuperclass()) {
            if (MACHINERY_ENTITY_CLASS.equals(current.getName())) {
                return true;
            }
        }
        return false;
    }

    /** 反逆器械包括本模组反逆者控制的器械，以及器械传说自带反逆效果标记的器械。 */
    public static boolean isRebelMachinery(LivingEntity entity) {
        return isMachinery(entity)
                && (MesmerizerControl.isControlled(entity) || hasMachineryRebellion(entity));
    }

    /** 读取器械传说自己的反逆效果；注册表里不存在时自然返回 false。 */
    public static boolean hasMachineryRebellion(LivingEntity entity) {
        for (var instance : entity.getActiveEffects()) {
            ResourceLocation id = BuiltInRegistries.MOB_EFFECT.getKey(instance.getEffect().value());
            if (id != null && MACHINERY_NAMESPACE.equals(id.getNamespace())
                    && id.getPath().equals("rebellion")) {
                return true;
            }
        }
        return false;
    }

    /**
     * 兼容器械的目标判定覆盖值。
     *
     * <p>{@code null} 表示交回器械传说原逻辑；非空表示本模组必须覆盖原逻辑。
     * 这样普通器械在没有遇到兼容对象时完全保持器械传说原行为。</p>
     */
    public static Boolean machineAttackOverride(Entity attacker, LivingEntity target) {
        if (!isMachinery(attacker) || target == attacker || !target.isAlive()) {
            return null;
        }

        if (isMachinery(target)) {
            // 正常器械与反逆器械互为敌对；同一侧仍禁止互伤。
            return isRebelMachinery((LivingEntity) attacker) != isRebelMachinery(target);
        }
        if (MesmerizerControl.isWitherSkeletonFaction(target)) {
            // 正常器械继续保留对凋灵骷髅阵营的敌意；反逆器械不再索敌军团。
            return !isRebelMachinery((LivingEntity) attacker);
        }

        if (!(attacker instanceof LivingEntity livingAttacker)
                || !MesmerizerControl.isControlled(livingAttacker)) {
            return null;
        }

        // 被反逆者控制的器械只能追随反逆者当前目标，不再被原生 Enemy/Friendly
        // 判定卡住。目标为空时返回 false，让器械清掉旧目标并等待下一次同步。
        LivingEntity controller = MesmerizerControl.getController(livingAttacker);
        LivingEntity controllerTarget = controller instanceof Mob controllerMob
                ? controllerMob.getTarget() : null;
        return controllerTarget == target
                && MesmerizerControl.canAttack(livingAttacker, target);
    }

    /** 投射物版本的同一判定，供器械传说的箭、飞刀等 canHitEntity 使用。 */
    public static Boolean machineProjectileOverride(Entity owner, Entity target) {
        if (!isMachinery(owner) || !(target instanceof LivingEntity livingTarget)) {
            return null;
        }
        return machineAttackOverride(owner, livingTarget);
    }

    /** 是否应把候选实体列入本模组的器械兼容索敌名单。 */
    public static boolean isCompatibleMachineryTarget(Mob machine, LivingEntity candidate) {
        if (!isMachinery(machine) || candidate == machine || !candidate.isAlive()) {
            return false;
        }
        if (isMachinery(candidate)) {
            return Boolean.TRUE.equals(machineAttackOverride(machine, candidate));
        }
        Boolean override = machineAttackOverride(machine, candidate);
        if (override != null) {
            return override;
        }
        if (candidate instanceof net.minecraft.world.entity.player.Player player
                && (player.isCreative() || player.isSpectator())) {
            return false;
        }
        return candidate instanceof Enemy || hasMachineryRebellion(candidate);
    }

    /** 器械传说原生搜索范围，供兼容兜底索敌使用。 */
    public static double huntRange() {
        return MACHINERY_HUNT_RANGE;
    }
}
