package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * 凋灵骷髅阵营生物与《机械传说》蓝图器械的敌对关系（阵营主动索敌一侧）。
 *
 * <h3>背景</h3>
 * <p>蓝图器械（发射器、狙击台这类由蓝图生成、不能移动的实体）每 5 tick 按
 * "敌对生物（{@code Enemy}）即可打"的原生口径索敌，凋灵骷髅阵营成员本就是
 * {@code Enemy}，器械一侧的敌对早已成立；反方向却不然——阵营生物的目标
 * 目标组只锁定玩家等固定类别，器械不在任何一类的名单里，于是阵营生物对
 * 眼前的炮塔视而不见，只有挨打的份。这里补上缺失的半边。</p>
 *
 * <h3>注入方式</h3>
 * <p>与 {@link WitherFactionHostilityHandler} 给守卫生物挂阵营目标同一套路：
 * {@link EntityJoinLevelEvent}（服务端）里按 {@code targetSelector} 3 优先级挂
 * 一个只认器械的 {@link NearestAttackableTargetGoal}。优先级 1 的受击反击与
 * 传令兵护卫、优先级 2 的玩家索敌都在它之前，阵营生物照常先打老目标，
 * 没有老目标时才会把炮塔列入打击名单。目标不进 NBT，区块重载事件重放，
 * 幂等检查防止重复挂载。</p>
 *
 * <h3>器械不在场时零影响</h3>
 * <p>识别走 {@link MesmerizerControlHandler#isBlueprintMachinery} 的类名字符串
 * 判定，不引用对方任何类：删掉《机械传说》后谓词永远为假，这个 goal 只是
 * 每 10 tick 一次的空扫描，行为与不装本处理器完全一致，更不会崩溃。</p>
 *
 * <h3>被心控的器械不打</h3>
 * <p>反逆者催眠法球收编的器械即刻成友军：谓词排除 {@code isControlled}，
 * 光球命中时 {@code MesmerizerOrb} 原有的 {@code clearAllTargets} 会顺手清掉
 * 阵营生物钉在它身上的旧目标，下一轮扫描也不会再选中。</p>
 */
public final class MachineryHostilityHandler {
    private MachineryHostilityHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (!(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (!MesmerizerControl.isWitherSkeletonFaction(mob)) {
            return;
        }
        if (hasMachineryTargetGoal(mob)) {
            return;
        }
        mob.targetSelector.addGoal(3, new BlueprintMachineryTargetGoal(mob));
    }

    private static boolean hasMachineryTargetGoal(Mob mob) {
        return mob.targetSelector.getAvailableGoals().stream()
                .map(WrappedGoal::getGoal)
                .anyMatch(BlueprintMachineryTargetGoal.class::isInstance);
    }

    /** 只把《机械传说》的蓝图器械（且未被心控）列进索敌名单的近战目标组。 */
    private static final class BlueprintMachineryTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
        private BlueprintMachineryTargetGoal(Mob mob) {
            super(mob, LivingEntity.class, 10, true, false,
                    BlueprintMachineryTargetGoal::isHostileMachinery);
        }

        private static boolean isHostileMachinery(LivingEntity candidate) {
            return candidate instanceof Mob mob
                    && mob.isAlive()
                    && MesmerizerControlHandler.isBlueprintMachinery(mob)
                    // 反逆器械属于反逆者一侧：凋灵骷髅阵营不主动把它当敌人。
                    && !MachineryLegendCompat.isRebelMachinery(mob);
        }
    }
}
