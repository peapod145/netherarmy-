package cn.blockforge.generated.netherarmy;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 无头强袭骑士的躯体：基础代码照抄无头骑士躯体（悬浮头颅的宿主、编组目标同步、
 * 骑乘指挥），强袭规格：
 * <ul>
 *   <li>血量 40、自带 4 点护甲、移速与无头骑士一致、免疫击退与一切负面效果；</li>
 *   <li>每损失 1 点血量，护甲值额外提高 1 点（{@code 4 + (40 - 当前血量)}）；</li>
 *   <li>近战附带 30 秒凋零 II，已有凋零则重置时长并升一级（上限十级）；</li>
 *   <li>必定携带炼狱晶胸甲／护腿／靴子 + 地煞战斧 + 亡魂重盾；主手挥击期间取消举盾，
 *       挥击硬直结束后在地煞战斧攻击间隔内举盾，与目标近身缠斗时续持，侦得来袭抛射物时
 *       转向其方向并举盾格挡；正面格挡走原版格挡通道（免伤 + 敲退攻击者 + 格挡特效音），
 *       并按格挡伤害扣盾牌耐久，亡魂重盾确实能被打穿；背面偷袭吃满伤害；</li>
 *   <li>常规掉落与无头骑士躯体共用同一张战利品表（完全相同），装备不随普通死亡
 *       掉落，仅 0.001% 概率满耐久掉落。</li>
 * </ul>
 */
public class BlitzDullhanBody extends DullhanBody {
    private static final double BLITZ_MAX_HEALTH = 40.0D;
    private static final double BLITZ_WALK_SPEED = 0.25D; // 与无头骑士躯体一致（0.25）
    private static final double BLITZ_BASE_ARMOR = 4.0D;
    /**
     * 地煞战斧攻击冷却 1.2 秒 = 24 刻（见 GeneratedMod 注册处的攻速换算），
     * 当作"这一击之后的举盾窗口上限"。怪物侧的挥击节奏实际由
     * {@code MeleeAttackGoal#getAttackInterval()}（20 刻，军团光环下被
     * {@code LegionAuraMeleeCooldownMixin} 压到 16 刻）决定，比这个上限更快；
     * 取上限不会让举盾越过下一次挥击——真挥出下一击时这里会被重新收盾覆盖。
     */
    private static final int AXE_ATTACK_INTERVAL_TICKS = 24;
    /**
     * 主手挥击的收盾硬直：{@code LivingEntity.SWING_DURATION}（6 刻挥击动画）再加
     * 4 刻收招，共 10 刻。这段时间内盾必须放下来——地煞战斧的命中就在起手那一刻结算，
     * 若继续举盾就等于"边砍边挡"，对手毫无可乘之机。
     */
    private static final int ATTACK_SWING_LOCK_TICKS = 10;
    /** 检测到来袭抛射物后的举盾保持时长。 */
    private static final int SHIELD_REACT_TICKS = 14;
    /** 近身缠斗时的举盾续窗：每刻刷新，脱离接触后再撑 6 刻。 */
    private static final int SHIELD_COMBAT_GUARD_TICKS = 6;
    /** 与目标处于"近身缠斗"的距离上限（7 格），此范围内一直保持举盾护身。 */
    private static final double SHIELD_COMBAT_GUARD_RANGE_SQR = 49.0D;
    /** 被这一击真的打在身上后的反应举盾窗口（第一下挡不住，之后的挡）。 */
    private static final int SHIELD_ON_HURT_GUARD_TICKS = 24;
    /** 盾牌耐久结算的下限：与玩家持盾一致，3 点以下的攻击不磨损盾牌。 */
    private static final float SHIELD_WEAR_DAMAGE_FLOOR = 3.0F;
    /** 抛射物来袭检测的水平走廊半径与最大预判距离。 */
    private static final double PROJECTILE_CORRIDOR = 1.2D;
    private static final double PROJECTILE_LOOKAHEAD = 18.0D;
    private static final float EQUIPMENT_DROP_CHANCE = 0.00001F;

    private static final ResourceLocation ARMOR_GROWTH_ID = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "blitz_body_missing_health_armor");

    private float lastArmorBonus = -1.0F;
    private int shieldHoldTicks;
    /** 主手挥击后的收盾硬直剩余刻数：&gt;0 期间盾强制放下，任何起手来源都不生效。 */
    private int shieldSwingLockTicks;
    /** 最近一次主手挥击的攻击间隔截止刻（{@code tickCount} 口径）：间隔内持续架盾护身。 */
    private int attackIntervalEndTick;

    public BlitzDullhanBody(EntityType<? extends BlitzDullhanBody> type, Level level) {
        super(type, level);
        this.repinBlitzStats();
    }

    private void repinBlitzStats() {
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(BLITZ_MAX_HEALTH);
        this.setHealth(this.getMaxHealth());
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BLITZ_WALK_SPEED);
        this.getAttribute(Attributes.ARMOR).setBaseValue(BLITZ_BASE_ARMOR);
        this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return DullhanBody.createAttributes()
                .add(Attributes.MAX_HEALTH, BLITZ_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, BLITZ_WALK_SPEED)
                .add(Attributes.ARMOR, BLITZ_BASE_ARMOR)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected DullhanHorse createMount(ServerLevel level) {
        return GeneratedMod.BLITZ_DULLHAN_HORSE.get().create(level);
    }

    @Override
    protected DullhanHead createHead(ServerLevel level) {
        return GeneratedMod.BLITZ_DULLHAN_HEAD.get().create(level);
    }

    /** 免疫一切负面效果。 */
    @Override
    public boolean canBeAffected(MobEffectInstance instance) {
        if (instance.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
            return false;
        }
        return super.canBeAffected(instance);
    }

    /**
     * 强袭凋零叠加：命中后把目标凋零改写为"30 秒、比当前高一级（上限十级）"。
     * 三个部件共用本方法。父类先挂的 5 秒凋零 I 在这里被无缝并入升级流程：
     * 目标原本无凋零时读到的就是那份刚挂上的凋零 I（等级 0），+1 即凋零 II。
     */
    static void applyBlitzWither(LivingEntity target) {
        MobEffectInstance current = target.getEffect(MobEffects.WITHER);
        int amplifier = current == null ? 1 : Math.min(current.getAmplifier() + 1, 9);
        if (current != null) {
            // 原版 addEffect 不会缩短已有时长，先移除再挂，保证"重置为 30 秒"。
            target.removeEffect(MobEffects.WITHER);
        }
        target.addEffect(new MobEffectInstance(MobEffects.WITHER, 600, amplifier, false, true));
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            applyBlitzWither(living);
        }
        return hurt;
    }

    /**
     * 主手挥击的瞬间取消举盾：{@code MeleeAttackGoal#checkAndPerformAttack} 是
     * {@code swing(MAIN_HAND)} 紧接 {@code doHurtTarget}，所以这一刀落下的时刻就是
     * 收盾的时刻。硬直 {@link #ATTACK_SWING_LOCK_TICKS} 刻（挥击动画 + 收招）内盾
     * 一直保持放下，硬直结束后才按攻击间隔重新架起（见 {@link #updateShieldStance()}）。
     * 只认主手且主手不是盾：副手盾、头颅／坐骑的攻击都不该被这里影响。
     */
    @Override
    public void swing(InteractionHand hand, boolean fromThreats) {
        super.swing(hand, fromThreats);
        if (this.level().isClientSide() || hand != InteractionHand.MAIN_HAND
                || this.getItemBySlot(EquipmentSlot.MAINHAND).getItem() instanceof ShieldItem) {
            return;
        }
        this.shieldSwingLockTicks = ATTACK_SWING_LOCK_TICKS;
        this.attackIntervalEndTick = this.tickCount + AXE_ATTACK_INTERVAL_TICKS;
        this.shieldHoldTicks = 0;
        if (this.isUsingItem()) {
            this.stopUsingItem();
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.repinBlitzStats();
        // 父类 finalizeSpawn 有 30% 概率随机换装金/铁甲，强袭规格在其后统一钉回。
        this.equipBlitzGear();
        return result;
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.equipBlitzGear();
    }

    /** 必带：炼狱晶胸甲、护腿、靴子 + 地煞战斧（主手）+ 亡魂重盾（副手）；全部零掉率。 */
    private void equipBlitzGear() {
        this.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(GeneratedMod.NETHER_CRYSTAL_CHESTPLATE.get()));
        this.setItemSlot(EquipmentSlot.LEGS, new ItemStack(GeneratedMod.NETHER_CRYSTAL_LEGGINGS.get()));
        this.setItemSlot(EquipmentSlot.FEET, new ItemStack(GeneratedMod.NETHER_CRYSTAL_BOOTS.get()));
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.DISHA_BATTLE_AXE.get()));
        this.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(GeneratedMod.SOUL_SHIELD.get()));
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 0.0F);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            return;
        }
        this.updateMissingHealthArmor();
        this.updateShieldStance();
    }

    /** 每损失 1 点血量，护甲值提高 1 点：以永久修饰符叠加在 4 点基甲之上。 */
    private void updateMissingHealthArmor() {
        float missing = Math.max(0.0F, this.getMaxHealth() - this.getHealth());
        if (Math.abs(missing - this.lastArmorBonus) < 0.01F) {
            return;
        }
        this.lastArmorBonus = missing;
        AttributeInstance armor = this.getAttribute(Attributes.ARMOR);
        if (armor == null) {
            return;
        }
        armor.removeModifier(ARMOR_GROWTH_ID);
        if (missing > 0.0F) {
            armor.addPermanentModifier(new AttributeModifier(
                    ARMOR_GROWTH_ID, missing, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    /**
     * 举盾姿态：主手挥击的硬直期内强制收盾（这一刀的起手就是对手的窗口）；
     * 硬直结束后在地煞战斧的攻击间隔内、与目标近身缠斗期间、以及侦得来袭抛射物时
     * 保持举盾。检测到飞向自己的抛射物时先转向其方向，再进入（或延长）举盾窗口。
     * 窗口耗尽才收盾，收盾与举盾都由服务端驱动、经实体数据同步给客户端播放动作。
     */
    private void updateShieldStance() {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            this.shieldHoldTicks = 0;
            this.shieldSwingLockTicks = 0;
            if (this.isUsingItem()) {
                this.stopUsingItem();
            }
            return;
        }
        // 挥击硬直：盾一定收着，期间既不递减也不兑现任何起手请求，
        // 硬直前攒下的反应窗口留到硬直结束后再兑现。
        if (this.shieldSwingLockTicks > 0) {
            this.shieldSwingLockTicks--;
            if (this.isUsingItem()) {
                this.stopUsingItem();
            }
            return;
        }
        Projectile incoming = this.detectIncomingProjectile();
        if (incoming != null) {
            this.raiseShield(SHIELD_REACT_TICKS);
            this.getLookControl().setLookAt(
                    incoming.getX(), incoming.getY() + incoming.getBbHeight() * 0.5D, incoming.getZ(),
                    90.0F, 30.0F);
        }
        // 攻击间隔尚未走完：把盾重新架回护身位，窗口按剩余间隔给足，下一击起手时再收。
        // 多给 1 刻是为了避开本刻末尾的递减——否则间隔的最后一刻会算成没举盾。
        int intervalLeft = this.attackIntervalEndTick - this.tickCount;
        if (intervalLeft > 0) {
            this.raiseShield(intervalLeft + 1);
        }
        // 近身缠斗：只要锁定的目标还在一步之内，盾就一直举着（每刻续窗）。
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive() && this.distanceToSqr(target) <= SHIELD_COMBAT_GUARD_RANGE_SQR) {
            this.raiseShield(SHIELD_COMBAT_GUARD_TICKS);
        }
        if (this.shieldHoldTicks > 0) {
            this.shieldHoldTicks--;
            if (!this.isUsingItem()) {
                this.startUsingItem(InteractionHand.OFF_HAND);
            }
        } else if (this.isUsingItem()) {
            this.stopUsingItem();
        }
    }

    /**
     * 进入／延长举盾窗口，并当场把盾举起来。
     * 必须在 {@code hurt} 这类"本刻就可能挨打"的时机里直接起手，等不到下一个 tick 的
     * {@link #updateShieldStance()}：反应慢一拍就是玩家眼里的"举了盾却挡不住"。
     * 唯一的例外是主手挥击硬直：这时候盾是明确放下的，只记窗口不起手，
     * 免得挨到一击就立刻把盾抬回去、把好不容易留出的反击窗口填死。
     */
    private void raiseShield(int ticks) {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            return;
        }
        this.shieldHoldTicks = Math.max(this.shieldHoldTicks, ticks);
        if (this.shieldSwingLockTicks > 0) {
            return;
        }
        if (!this.isUsingItem()) {
            this.startUsingItem(InteractionHand.OFF_HAND);
        }
    }

    /**
     * 服务端：此刻是否处于"盾已举起"的窗口内（不等原版那 5 刻起手预热）。
     * 挥击硬直期内即使还留着旧的举盾窗口也一律算没举起，判定必须和姿态一致，
     * 否则就会出现"盾已经放下、伤害却还是被挡掉"。
     */
    private boolean isShieldRaised() {
        return this.shieldSwingLockTicks <= 0
                && this.shieldHoldTicks > 0
                && this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem;
    }

    /**
     * 举盾格挡走原版通道：{@code LivingEntity#hurt} 在本方法返回 true 之后自己完成
     * 免伤结算、敲退攻击者（{@code blockUsingShield}）、广播 29 号格挡事件（客户端的
     * 白闪粒子与盾牌闷响），并发出 {@code LivingShieldBlockEvent}——亡魂重盾的
     * "格挡反挂凋零"与盾牌附魔（护主／立体防御／重塑）只有在这条链路上才会触发。
     * 早前那版自己短路 {@code hurt} 直接 return false，伤害确实吞了，但这些反馈与结算
     * 一个都不会发生，看起来就是"举盾无效"；同时它依赖 {@code isBlocking()}，而原版
     * {@code isBlocking()} 要求起手满 5 刻，攻击间隔窗口里的头几刻完全挡不住。
     */
    @Override
    public boolean isDamageSourceBlocked(DamageSource source) {
        if (this.isShieldRaised() && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            return this.isAttackFromFront(source);
        }
        return super.isDamageSourceBlocked(source);
    }

    /**
     * 来袭方向与躯体面朝方向的夹角不超过 90° 才算"正面"，背面偷袭照常吃满伤害。
     * 与原版 {@code isDamageSourceBlocked} 同一套算法（只用水平分量比较），但正面判定
     * 放宽成"头部朝向或实体朝向任一命中即可"：骑在马上的躯体，{@code yHeadRot} 与
     * {@code YRot} 并不总是同步更新，只认一个的话会出现"明明对着人却判成背面"。
     */
    private boolean isAttackFromFront(DamageSource source) {
        Vec3 sourcePos = source.getSourcePosition();
        if (sourcePos == null) {
            Entity attacker = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
            if (attacker == null) {
                // 没有来源位置（摔落、虚空一类）不格挡，与原版一致。
                return false;
            }
            sourcePos = attacker.getEyePosition();
        }
        Vec3 toSelf = sourcePos.vectorTo(this.position());
        Vec3 flat = new Vec3(toSelf.x, 0.0D, toSelf.z);
        if (flat.lengthSqr() < 1.0E-6D) {
            return true;
        }
        Vec3 towards = flat.normalize();
        return towards.dot(this.calculateViewVector(0.0F, this.getYHeadRot())) < 0.0D
                || towards.dot(this.calculateViewVector(0.0F, this.getYRot())) < 0.0D;
    }

    /**
     * 盾牌耐久：{@code LivingEntity#hurtCurrentlyUsedShield} 在活体基类里是<b>空实现</b>，
     * 原版只有玩家（而且只认 {@code Items.SHIELD}）会掉盾耐久，怪物举盾等于无限用。
     * 这里按玩家同一套结算补齐：{@code 1 + floor(格挡伤害)}，3 点以下的攻击不磨损；
     * 耐久耗尽就把盾从副手摘掉、收盾并播破盾音效——亡魂重盾（5000 耐久）因此确实能被打穿。
     */
    @Override
    protected void hurtCurrentlyUsedShield(float amount) {
        if (this.level().isClientSide() || amount < SHIELD_WEAR_DAMAGE_FLOOR) {
            return;
        }
        EquipmentSlot slot = EquipmentSlot.OFFHAND;
        ItemStack stack = this.getItemBySlot(slot);
        if (!(stack.getItem() instanceof ShieldItem)) {
            return;
        }
        stack.hurtAndBreak(1 + Mth.floor(amount), this, slot);
        if (stack.isEmpty()) {
            this.setItemSlot(slot, ItemStack.EMPTY);
            this.shieldHoldTicks = 0;
            if (this.isUsingItem()) {
                this.stopUsingItem();
            }
            this.playSound(SoundEvents.SHIELD_BREAK, 0.8F,
                    0.8F + this.level().random.nextFloat() * 0.4F);
        }
    }

    /**
     * 取最近一颗"弹道会经过躯体正面走廊"的飞行抛射物。方向与到达距离用
     * 速度射线到躯体中心的投影估算；{@link ProjectileFlightTracker} 负责剔除
     * 插地后仍带假速度的箭矢。
     */
    private Projectile detectIncomingProjectile() {
        AABB area = this.getBoundingBox().inflate(16.0D);
        Vec3 center = this.getBoundingBox().getCenter();
        Projectile best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Projectile projectile : this.level().getEntitiesOfClass(Projectile.class, area)) {
            if (!ProjectileFlightTracker.isActuallyFlying(projectile) || projectile.getOwner() == this) {
                continue;
            }
            Vec3 toMe = center.subtract(projectile.position());
            Vec3 velocity = projectile.getDeltaMovement();
            double speed = velocity.length();
            if (speed < 1.0E-3D) {
                continue;
            }
            Vec3 direction = velocity.scale(1.0D / speed);
            double along = toMe.dot(direction);
            if (along < 0.0D || along > PROJECTILE_LOOKAHEAD) {
                continue;
            }
            double perpendicular = toMe.subtract(direction.scale(along)).length();
            double corridor = Math.max(PROJECTILE_CORRIDOR, this.getBbWidth());
            if (perpendicular <= corridor && along < bestDistance) {
                best = projectile;
                bestDistance = along;
            }
        }
        return best;
    }

    /**
     * 挨下这一击之后（没能挡住）记下举盾窗口：下一击开始才进入格挡，模拟"被打了才把盾架起来"。
     * 若此刻躯体正在主手挥击的硬直里，这个请求只记账、不起手，等硬直结束再兑现——
     * 否则挨一拳就立刻把盾抬回去，反击窗口等于没有。
     * 这里不再自己吞伤害，只负责起手——吞伤害由 {@link #isDamageSourceBlocked(DamageSource)}
     * 交给原版结算，格挡特效、敲退、盾牌耐久与附魔事件都跟着那条链路走。
     */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && amount > 0.0F && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            this.raiseShield(SHIELD_ON_HURT_GUARD_TICKS);
        }
        return hurt;
    }

    /**
     * 常规掉落与无头骑士躯体完全相同：直接共用它的战利品表。
     * 原版链路按实体注册名派生表 ID（{@code netherarmy:entities/blitz_dullhan_body}），
     * 强袭没有独立 JSON 时该表解析为空——不指回父体就会"只剩装备特判、常规掉落全空"。
     */
    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return GeneratedMod.DULLHAN_BODY.get().getDefaultLootTable();
    }

    /** 0.001% 概率掉落自身装备，掉出时为满耐久；其余情况与无头骑士一致（不掉装备）。 */
    @Override
    protected void dropEquipment() {
        if (this.isAlive()) {
            return;
        }
        super.dropEquipment(); // 各槽掉率已钉 0，父类不会掉出任何东西
        if (this.random.nextFloat() < EQUIPMENT_DROP_CHANCE) {
            EquipmentSlot[] slots = {
                    EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
                    EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
            };
            for (EquipmentSlot slot : slots) {
                ItemStack stack = this.getItemBySlot(slot);
                if (!stack.isEmpty()) {
                    ItemStack copy = stack.copy();
                    copy.setDamageValue(0);
                    this.spawnAtLocation(copy);
                }
            }
        }
    }
}
