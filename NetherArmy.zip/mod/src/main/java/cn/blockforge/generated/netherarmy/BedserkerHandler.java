package cn.blockforge.generated.netherarmy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/**
 * 床战士与凋灵的联动逻辑，共三块：
 *
 * <ul>
 *   <li>原版凋灵（不含霸主凋灵）血量降低至 25% 时，必定在其身边召唤一只床战士。
 *       走 {@link LivingDamageEvent.Post}：结算完的真实余血过线才触发，被护盾完全
 *       格挡、护盾期无敌帧期间被免疫的伤害都不会算数；凋灵 PersistentData 打一次性
 *       标记，半血冲刺回血或重载后再跌回 25% 以下也不二次召唤。</li>
 *   <li>霸主凋灵血量低于 50% 后，每次受到有效攻击有 10% 概率召唤一只床战士，
 *       判定在 {@link OverlordWitherBoss#hurt} 内（那里能准确区分"这一击真的打进去了"，
 *       三阶段起被弹开的抛射物不掷骰）。</li>
 *   <li>成就【Bed Time Trio】：玩家亲手击杀床战士逐只累计（PersistentData 计数，
 *       跨死亡与重载保留），满 3 只授予。只有最后一击归因到玩家才算数：床战士 10 秒
 *       主动自爆走 {@code discard()} 根本不发死亡事件；自爆爆炸与同伴死亡爆炸的
 *       伤害源都不挂玩家，同样不计数。</li>
 * </ul>
 */
public final class BedserkerHandler {

    /** 原版凋灵 PersistentData：25% 血线的床战士已经召唤过。 */
    private static final String VANILLA_SUMMONED_KEY = "netherarmy_withers_summoned_bedserker";
    /** 玩家 PersistentData：由玩家伤害杀死的床战士累计只数。 */
    private static final String BEDSERKER_KILLS_KEY = "netherarmy_bedserker_kills";

    private static final int BEDSERKER_KILL_TARGET = 3;

    private BedserkerHandler() {
    }

    // ------------------------------------------------------------------
    // 召唤入口（原版凋灵 25% 血线与霸主凋灵受击判定共用）
    // ------------------------------------------------------------------

    /**
     * 在凋灵身边刷新一只床战士：水平 ±6 格、向上 0~3 格的随机落点，口径与
     * {@code OverlordWitherBoss#summonMinions} 一致；标记召唤者使其继承凋灵仇恨
     * （床战士不攻击，但会一路追击该目标直至自爆）。
     */
    public static void summonNear(ServerLevel level, WitherBoss summoner) {
        Bedserker bedserker = GeneratedMod.BEDSERKER.get().create(level);
        if (bedserker == null) {
            return;
        }
        bedserker.moveTo(summoner.getX() + (summoner.getRandom().nextDouble() - 0.5D) * 12.0D,
                summoner.getY() + summoner.getRandom().nextDouble() * 3.0D,
                summoner.getZ() + (summoner.getRandom().nextDouble() - 0.5D) * 12.0D,
                summoner.getRandom().nextFloat() * 360.0F, 0.0F);
        bedserker.finalizeSpawn(level, level.getCurrentDifficultyAt(bedserker.blockPosition()),
                MobSpawnType.TRIGGERED, null);
        bedserker.setPersistenceRequired();
        WitherEnhancementHandler.markSummonedBy(bedserker, summoner);
        level.addFreshEntityWithPassengers(bedserker);
    }

    // ------------------------------------------------------------------
    // 原版凋灵：血量降至 25% 必定召唤一次
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onWitherDamaged(LivingDamageEvent.Post event) {
        if (!(event.getEntity() instanceof WitherBoss wither) || wither instanceof OverlordWitherBoss) {
            return;
        }
        if (!(wither.level() instanceof ServerLevel level) || wither.isRemoved()) {
            return;
        }
        // 致命一击直接把凋灵打死就不再召唤；血量按 mixin 后的 600 上限折算 25% 线。
        if (wither.getHealth() <= 0.0F || wither.getHealth() > wither.getMaxHealth() * 0.25F) {
            return;
        }
        CompoundTag data = wither.getPersistentData();
        if (data.getInt(VANILLA_SUMMONED_KEY) != 0) {
            return;
        }
        data.putInt(VANILLA_SUMMONED_KEY, 1);
        summonNear(level, wither);
    }

    // ------------------------------------------------------------------
    // 成就【Bed Time Trio】：玩家击杀床战士累计 3 只
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onBedserkerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof Bedserker)) {
            return;
        }
        // 主动自爆走 discard()，不发死亡事件；自爆与同伴死亡爆炸的伤害源都不挂
        // 玩家实体，因此这里天然只统计"由来自玩家的伤害导致其死亡"。
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        int count = data.getInt(BEDSERKER_KILLS_KEY) + 1;
        data.putInt(BEDSERKER_KILLS_KEY, count);
        if (count >= BEDSERKER_KILL_TARGET) {
            award(player, "bed_time_trio", "killed_three_bedserkers");
        }
    }

    private static void award(ServerPlayer player, String path, String criterion) {
        var holder = player.server.getAdvancements().get(
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, path));
        if (holder != null) {
            player.getAdvancements().award(holder, criterion);
        }
    }
}
