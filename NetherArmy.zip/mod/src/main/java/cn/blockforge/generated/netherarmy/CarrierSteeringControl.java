package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.ai.control.MoveControl;

/**
 * 运兵车的转向通道：把原版 {@code MoveControl} 的"一拍拧 90°"换成船式平滑转向。
 *
 * <h2>为什么只覆盖 {@code rotlerp} 这一条就够</h2>
 * <p>对 1.21.1 的字节码逐分支核过，整车在服务端<b>只有一个地方</b>会写车身朝向：
 * {@code MoveControl#tick} 的 MOVE_TO 分支，动作序列是</p>
 * <pre>
 *   f = (float)(Mth.atan2(dz, dx) * 180 / PI) - 90;      // 信箱方向（绝对朝向）
 *   mob.setYRot(rotlerp(mob.getYRot(), f, 90.0F));       // ← 转角上限 90°/tick（硬编码）
 *   mob.setSpeed(speedModifier * MOVEMENT_SPEED);        // 推进，与转角同分支
 * </pre>
 * <p>STRAFE 分支根本不碰 {@code yRot}（只写 {@code xxa/zza}），JUMPING 分支只补速度，
 * WAIT 分支只把前进量清零。而两条移动通道——冲锋（{@link CarrierChargeGoal} 每 tick
 * 把信箱钉在敌人身上）与游走（{@code PathNavigation} 把路径节点写进同一个信箱）——
 * 最后都汇到 MOVE_TO 这一行。所以把 {@code rotlerp}（原版就是 {@code protected}）
 * 接过来交给 {@link NetherCarrier#steerTowards}，车身转角就整条改道，且：</p>
 * <ul>
 *   <li>速度侧一行不动：{@code setSpeed} 照旧，2 秒线性加速
 *       （{@link NetherCarrier#travel}）与低血量限速全部不受影响；</li>
 *   <li>跳跃、翻障碍、{@code isWalkable} 判定留在原版分支里，不重抄一遍；</li>
 *   <li>生成/传送/存档重载用的 {@code Entity#moveTo → setYRot} 完全不经过这里，
 *       摆放朝向（比如刷怪蛋落下来的朝向）仍是即时生效，不会被平滑成"转半秒才到位"。</li>
 * </ul>
 *
 * <h2>与"船的转向"的对应关系</h2>
 * <p>原版 {@code Boat} 的转向是三件事：{@code controlBoat} 里 {@code deltaRotation}
 * 按打舵方向累加、{@code setYRot(getYRot() + deltaRotation)} 把<b>转向率</b>而不是
 * 目标角写进朝向、{@code floatBoat} 每 tick {@code deltaRotation *= invFriction}（水中
 * 0.9）让转向率自己收敛。三件事分别落在本类（把转角请求交给实体）、
 * {@link NetherCarrier#steerTowards}（率累加 + 15°/tick 帽 + 静止禁转）、
 * {@link NetherCarrier#tick}（每 tick 衰减，且不在 MOVE_TO 的 tick 也照衰减）。
 * 之所以是"率"而不是"角度插值"：起转与停转都是渐变的，不会出现目标一挪车位就
 * 瞬间甩过去的突兀感。</p>
 */
public class CarrierSteeringControl extends MoveControl {

    private final NetherCarrier carrier;

    public CarrierSteeringControl(NetherCarrier carrier) {
        super(carrier);
        this.carrier = carrier;
    }

    /**
     * MOVE_TO 分支每 tick 用本方法算出要写进 {@code yRot} 的新朝向。
     *
     * @param currentYaw 本 tick 开始时的车身朝向（即上一 tick 平滑后的结果）
     * @param wantedYaw  信箱方向（绝对朝向，度）
     * @param maxTurn    原版传入的转角帽（固定 90°），本车不用它，由
     *                   {@link NetherCarrier#MAX_STEER_DEGREES_PER_TICK} 取代
     */
    @Override
    protected float rotlerp(float currentYaw, float wantedYaw, float maxTurn) {
        return this.carrier.steerTowards(currentYaw, wantedYaw);
    }
}
