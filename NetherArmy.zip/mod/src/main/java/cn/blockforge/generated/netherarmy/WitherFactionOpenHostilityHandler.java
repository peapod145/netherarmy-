package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 凋灵骷髅阵营的开放敌意判定——"可以成为敌对对象"，并且这条判定是<b>最高级</b>。
 *
 * <p>需求口径（用户两轮明确纠正过）：只要对方不属于地狱军团的凋灵骷髅阵营，阵营生物就
 * <b>有资格</b>与它产生敌意；敌意由事件触发，两条途径——外部强制仇恨工具、被对方伤害。
 * 本类不主动对非阵营实体宣战（上一版的兜底全量索敌已删），但把"敌意一旦成立就绝对锁得住"
 * 做到了底：</p>
 *
 * <ol>
 * <li><b>受击必还手（HIGHEST + receiveCanceled）</b>：本处理器排在绝大多数模组之后，
 * 即使伤害已被别的模组（负面免疫、无敌帧、护盾类）取消，甚至被本模组自己的凋灵之首免疫取消，
 * 攻击这个动作本身已经构成敌意——照样登记加害者并写入目标。过去"挨了打却不锁攻击者"
 * 正是因为这道写入被 {@code canAttack} 之外的原版筛选（{@code isInvulnerable}、
 * {@code canBeSeenAsEnemy}、第三方声明的同盟）挡在门外。</li>
 * <li><b>军团公敌登记</b>：打完军团成员的实体进入 30 秒共享黑名单，全军团都能认出它，
 * 包括"伤害被免疫手段整份抹掉、原版 {@code lastHurtByMob} 压根没写进去"的那批。</li>
 * <li><b>0 号索敌目标组</b>：{@link WitherFactionSupremeHostility.SupremeHostilityTargetGoal}
 * 占 {@code targetSelector} 最高优先级，压过受击反击、玩家索敌与器械索敌；被第三方 AI
 * 抹掉的目标会在下一轮扫描自动补回，强制仇恨的效果不再依赖那一次 {@code setTarget} 活多久。</li>
 * <li><b>敌我终判</b>：{@code canAttack} / {@code canAttackType} / {@code isAlliedTo} 三处
 * HEAD 注入（{@code LegionSupremeCanAttackMixin} 等）把结论统一交给
 * {@link WitherFactionSupremeHostility}，原版的无敌/旁观筛选与其他模组声明的"亡灵同盟"
 * 都压不过军团自己的判断；阵营名册同时换成私有标签 {@code #netherarmy:wither_faction}
 * （{@link WitherFactionRoster}），第三方往公开原版标签里塞实体不再能把它们误认成同袍——
 * 那正是"某些 mod 的亡灵彻底锁不上"的根因。</li>
 * </ol>
 *
 * <p>放开的是"合法性筛选"，不是"豁免名单"：同袍、被心控的友军、反逆器械、创造/旁观玩家、
 * 和平难度的玩家这些既有保护由 {@link WitherFactionSupremeHostility#canLegionAttack}
 * 统一复核，一条都不会因为"最高级"而被绕过。</p>
 */
public final class WitherFactionOpenHostilityHandler {

    private WitherFactionOpenHostilityHandler() {
    }

    /** 阵营生物可把该候选列为敌对对象的终判（非阵营 + 通过统一门禁）。 */
    public static boolean canBecomeHostile(Mob attacker, LivingEntity candidate) {
        return WitherFactionSupremeHostility.canLegionAttack(attacker, candidate);
    }

    /** 给每个阵营成员挂上 0 号（最高优先级）索敌目标组；区块重载后事件重放，幂等。 */
    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (!WitherFactionRoster.isMember(mob) || mob.isNoAi()) {
            return;
        }
        if (WitherFactionSupremeHostility.hasSupremeGoal(mob)) {
            return;
        }
        mob.targetSelector.addGoal(WitherFactionSupremeHostility.TARGET_GOAL_PRIORITY,
                new WitherFactionSupremeHostility.SupremeHostilityTargetGoal(mob));
    }

    /**
     * 受击必还手：阵营成员被非阵营活体伤害（含被取消的伤害）时，立刻登记加害者并写入目标。
     * 弹道按原版归因取 {@code DamageSource#getEntity()}（弓箭、法球算在射手头上）。
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Mob victim) || victim.level().isClientSide()) {
            return;
        }
        if (!WitherFactionRoster.isMember(victim)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) {
            return;
        }
        if (!canBecomeHostile(victim, attacker)) {
            return;
        }
        // 军团公敌：全军团共享这笔账，队友看见它也会还手。
        WitherFactionSupremeHostility.noteAggressor(victim.level(), attacker);
        if (victim.getTarget() != attacker) {
            victim.setTarget(attacker);
        }
        // 钉靶：即使别的模组下一 tick 抹掉目标，0 号扫描也会自行补回。
        WitherFactionSupremeHostility.notePinnedTarget(victim, attacker);
    }
}
