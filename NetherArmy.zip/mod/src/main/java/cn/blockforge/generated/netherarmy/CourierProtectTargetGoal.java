package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;

/**
 * 保护下界传令兵：传令兵挨了打，30 格内的阵营成员立刻把打人者立为目标。
 *
 * <p>挂在阵营成员 targetSelector 最高优先级 0（高于原版自卫的
 * {@code HurtByTargetGoal} 与普通索敌）：传令兵在 10 秒（200 tick）内挨过打时，
 * 本目标优先接管。成员自己被打时，原版自卫目标仍会正常生效。</p>
 *
 * <p>友伤防呆：如果打传令兵的恰好是自己人（混战里蹭到一斧子的狂战士之类），
 * 不去记仇，免得军团内讧。凋灵 boss 不算阵营成员，真打起来追随者会照常围殴。</p>
 */
public final class CourierProtectTargetGoal extends TargetGoal {
    /** 传令兵受击后多长时间内仍值得为它出头（tick）。 */
    private static final long REVENGE_WINDOW_TICKS = 200L;
    private static final double SCAN_RADIUS_SQR =
            NetherCourier.FOLLOW_RADIUS * NetherCourier.FOLLOW_RADIUS;

    private final Mob mob;
    private LivingEntity storedTarget;
    private int scanCooldown;

    public CourierProtectTargetGoal(Mob mob) {
        super(mob, false);
        this.mob = mob;
        this.setFlags(EnumSet.noneOf(Flag.class));
    }

    @Override
    public boolean canUse() {
        LivingEntity currentTarget = this.mob.getTarget();
        if (currentTarget != null && currentTarget.isAlive()) {
            this.storedTarget = null;
            return false;
        }
        if (--this.scanCooldown > 0) {
            return this.storedTarget != null && this.storedTarget.isAlive()
                    && this.mob.canAttack(this.storedTarget);
        }
        this.scanCooldown = 10;
        this.storedTarget = null;
        long gameTime = this.mob.level().getGameTime();
        double bestDistance = Double.MAX_VALUE;
        for (NetherCourier courier : this.mob.level().getEntitiesOfClass(
                NetherCourier.class,
                this.mob.getBoundingBox().inflate(NetherCourier.FOLLOW_RADIUS))) {
            if (!courier.isAlive() || courier.distanceToSqr(this.mob) > SCAN_RADIUS_SQR) {
                continue;
            }
            LivingEntity attacker = courier.getLastHurtByMob();
            if (attacker == null || attacker == this.mob || !attacker.isAlive()
                    || gameTime - courier.getLastHurtByMobTimestamp() > REVENGE_WINDOW_TICKS) {
                continue;
            }
            if (LegionAuraHandler.isFactionMember(attacker)) {
                continue;
            }
            double distance = this.mob.distanceToSqr(attacker);
            if (distance < bestDistance && this.mob.getSensing().hasLineOfSight(courier)
                    && !WitherFactionCreativePassivityHandler.isIgnoredPlayer(attacker)
                    && this.mob.canAttack(attacker)) {
                bestDistance = distance;
                this.storedTarget = attacker;
            }
        }
        return this.storedTarget != null;
    }

    @Override
    public void start() {
        this.targetMob = this.storedTarget;
        this.mob.setTarget(this.storedTarget);
        super.start();
    }

    @Override
    public boolean canContinueToUse() {
        return this.mob.getTarget() == this.storedTarget && super.canContinueToUse();
    }

    @Override
    public void stop() {
        this.storedTarget = null;
        super.stop();
    }
}
