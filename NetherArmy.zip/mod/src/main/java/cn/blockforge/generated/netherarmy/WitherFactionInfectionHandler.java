package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/**
 * 凋灵骷髅阵营的尸鬼感染：任意阵营生物杀死僵尸/溺尸/尸壳/僵尸村民/村民，
 * 或这些实体被凋零 buff 的持续伤害杀死时，尸体当场转化为尸鬼。
 *
 * <p>阵营名册以私有标签 {@code #netherarmy:wither_faction} 为准（凋灵骷髅、狂战士、
 * 下界猎手、无头骑士躯体与马、反逆者、衰翼、尸鬼），外加凋灵本体与无头骑士头颅
 * （见 {@link WitherFactionRoster}）。弹道击杀按原版归因走
 * {@code DamageSource#getEntity()}，所以弓箭、凋灵之首、魅惑法球都算在射手头上。</p>
 *
 * <p>事件在 {@code LivingEntity#die} 的第一行触发，早于原版的 {@code killedEntity}
 * 与战利品掉落；感染会立即 discard 原实体，随后原版那段
 * {@code if (!this.isRemoved() && !this.dead)} 的分支整体跳过，因此不会重复掉落
 * 尸体装备，也不会再走一遍 {@link WitherZombie#killedEntity}（尸鬼自己击杀时
 * 两条路径的结局一致，都走 {@link WitherZombie#infect}）。</p>
 */
public final class WitherFactionInfectionHandler {

    private WitherFactionInfectionHandler() {
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !(victim.level() instanceof ServerLevel level)) {
            return;
        }
        if (!WitherZombie.isInfectable(victim)) {
            return;
        }
        DamageSource source = event.getSource();
        if (!isKilledByWitherFaction(source) && !isKilledByWitherBuff(source)) {
            return;
        }
        WitherZombie converted = WitherZombie.infect(level, (Mob) victim, victim.isSilent());
        if (converted != null && source.getEntity() instanceof WitherZombie witherZombie) {
            witherZombie.heal(10.0F);
        }
    }

    /** 击杀者（含弹道归因）属于凋灵骷髅阵营（私有名册，见 {@link WitherFactionRoster}）。 */
    private static boolean isKilledByWitherFaction(DamageSource source) {
        return WitherFactionRoster.isMember(source.getEntity());
    }

    /** 由凋零效果的持续伤害致命（伤害类型 minecraft:wither：凋零 buff、凋灵玫瑰、凋灵之首的爆炸）。 */
    private static boolean isKilledByWitherBuff(DamageSource source) {
        return source.is(DamageTypes.WITHER);
    }
}
