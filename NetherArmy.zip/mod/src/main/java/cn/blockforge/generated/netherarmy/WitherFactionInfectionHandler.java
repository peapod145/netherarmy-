package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/**
 * 凋灵骷髅阵营的尸鬼感染：任意阵营生物杀死僵尸/溺尸/尸壳/僵尸村民/村民，
 * 或这些实体被凋零 buff 的持续伤害杀死时，尸体当场转化为尸鬼。
 *
 * <p>阵营名册以 {@code minecraft:wither_skeletons} 标签为准（凋灵骷髅、狂战士、
 * 下界猎手、无头骑士躯体与马、反逆者、衰翼、尸鬼），外加凋灵本体与无头骑士头颅。
 * 弹道击杀按原版归因走 {@code DamageSource#getEntity()}，所以弓箭、凋灵之首、
 * 魅惑法球都算在射手头上。</p>
 *
 * <p>事件在 {@code LivingEntity#die} 的第一行触发，早于原版的 {@code killedEntity}
 * 与战利品掉落；感染会立即 discard 原实体，随后原版那段
 * {@code if (!this.isRemoved() && !this.dead)} 的分支整体跳过，因此不会重复掉落
 * 尸体装备，也不会再走一遍 {@link WitherZombie#killedEntity}（尸鬼自己击杀时
 * 两条路径的结局一致，都走 {@link WitherZombie#infect}）。</p>
 */
public final class WitherFactionInfectionHandler {
    /** 凋灵骷髅阵营名册（模组把所有阵营生物都登记进了这个原版标签）。 */
    private static final TagKey<EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    private WitherFactionInfectionHandler() {
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !(victim.level() instanceof ServerLevel level)) {
            return;
        }
        if (!WitherZombie.isInfectable(victim)) {
            return;
        }
        DamageSource source = event.getSource();
        if (!isKilledByWitherFaction(source) && !isKilledByWitherBuff(source)) {
            return;
        }
        WitherZombie.infect(level, (Mob) victim, victim.isSilent());
    }

    /** 击杀者（含弹道归因）属于凋灵骷髅阵营。 */
    private static boolean isKilledByWitherFaction(DamageSource source) {
        Entity killer = source.getEntity();
        return killer != null
                && (killer instanceof WitherBoss
                // 无头骑士的头颅是独立实体、不在阵营标签里，但它的复仇弹头归它自己，
                // 与躯体同属一个阵营，这里显式认账。
                || killer instanceof DullhanHead
                || killer.getType().is(WITHER_SKELETONS));
    }

    /** 由凋零效果的持续伤害致命（伤害类型 minecraft:wither：凋零 buff、凋灵玫瑰、凋灵之首的爆炸）。 */
    private static boolean isKilledByWitherBuff(DamageSource source) {
        return source.is(DamageTypes.WITHER);
    }
}
