package cn.blockforge.generated.netherarmy;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Guardian;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;

/** 魔抗附魔的负面效果减益与指定伤害免疫。 */
public final class MagicResistanceHandler {
    private static final ThreadLocal<Boolean> REPLACING_EFFECT = ThreadLocal.withInitial(() -> false);

    private MagicResistanceHandler() {
    }

    /**
     * 在原版把效果写入活动效果表之前替换实例；Added 事件发生得太晚，修改它不会可靠地影响实际效果。
     */
    @SubscribeEvent
    public static void onMobEffectApplicable(MobEffectEvent.Applicable event) {
        LivingEntity entity = event.getEntity();
        MobEffectInstance effect = event.getEffectInstance();
        if (entity.level().isClientSide()
                || REPLACING_EFFECT.get()
                || effect.getEffect().value().getCategory() != MobEffectCategory.HARMFUL) {
            return;
        }

        ResistanceValues resistance = getResistance(entity);
        if (!resistance.hasEnchantment()) {
            return;
        }

        int amplifier = effect.getAmplifier();
        if (entity.getRandom().nextFloat() < resistance.downgradeChance()) {
            amplifier--;
        }
        if (amplifier < 0) {
            event.setResult(MobEffectEvent.Applicable.Result.DO_NOT_APPLY);
            return;
        }

        int duration = effect.getDuration();
        if (!effect.isInfiniteDuration() && !effect.getEffect().value().isInstantenous()) {
            double multiplier = 1.0D - resistance.durationReduction();
            duration = Math.max(1, (int) Math.floor(duration * multiplier));
        }
        if (duration == effect.getDuration() && amplifier == effect.getAmplifier()) {
            return;
        }

        MobEffectInstance replacement = new MobEffectInstance(
                effect.getEffect(), duration, amplifier,
                effect.isAmbient(), effect.isVisible(), effect.showIcon());
        event.setResult(MobEffectEvent.Applicable.Result.DO_NOT_APPLY);
        REPLACING_EFFECT.set(true);
        try {
            entity.addEffect(replacement, event.getEffectSource());
        } finally {
            REPLACING_EFFECT.set(false);
        }
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) {
            return;
        }

        ResistanceValues resistance = getResistance(entity);
        if (!resistance.hasEnchantment() || !isProtectedDamage(entity, event.getSource(), event.getAmount())) {
            return;
        }
        if (entity.getRandom().nextFloat() < resistance.immunityChance()) {
            event.setCanceled(true);
        }
    }

    private static ResistanceValues getResistance(LivingEntity entity) {
        double[] durationReduction = {0.0D};
        float[] downgradeChance = {0.0F};
        float[] immunityChance = {0.0F};
        boolean[] hasEnchantment = {false};
        EnchantmentHelper.runIterationOnEquipment(entity, (enchantment, level, item) -> {
            if (enchantment.is(GeneratedMod.MAGIC_RESISTANCE) && level > 0) {
                hasEnchantment[0] = true;
                durationReduction[0] += durationReduction(level);
                downgradeChance[0] += downgradeChance(level);
                immunityChance[0] += immunityChance(level);
            }
        });
        return new ResistanceValues(
                hasEnchantment[0],
                Math.min(1.0D, durationReduction[0]),
                Math.min(1.0F, downgradeChance[0]),
                Math.min(1.0F, immunityChance[0]));
    }

    private static double durationReduction(int level) {
        // The requested progression is 5%, 7.5%, ... 15% at level V.
        return (level + 1) * 0.025D;
    }

    private static float downgradeChance(int level) {
        // The requested progression is 1.0%, 1.5%, ... 3.0% at level V.
        return (level + 1) * 0.005F;
    }

    private static float immunityChance(int level) {
        // The requested progression is 5%, 7.5%, ... 15% at level V.
        return (level + 1) * 0.025F;
    }

    private record ResistanceValues(
            boolean hasEnchantment,
            double durationReduction,
            float downgradeChance,
            float immunityChance) {
    }

    private static boolean isProtectedDamage(LivingEntity entity, DamageSource source, float amount) {
        Entity direct = source.getDirectEntity();
        Entity causing = source.getEntity();
        if (direct instanceof Guardian || causing instanceof Guardian) {
            return true;
        }
        if (direct instanceof EvokerFangs || causing instanceof EvokerFangs) {
            return true;
        }
        if (source.is(DamageTypes.WITHER)) {
            return true;
        }
        // Poison ticks are one-point magic damage while the poison effect is active.
        if (source.is(DamageTypes.MAGIC)
                && amount <= 1.0F
                && entity.hasEffect(net.minecraft.world.effect.MobEffects.POISON)) {
            return true;
        }
        return isInstantDamagePotion(source);
    }

    private static boolean isInstantDamagePotion(DamageSource source) {
        Entity direct = source.getDirectEntity();
        Entity causing = source.getEntity();
        if (direct instanceof AreaEffectCloud) {
            // Harm from a lingering potion cloud is indirect magic; beneficial clouds do not hurt.
            return source.is(DamageTypes.INDIRECT_MAGIC);
        }
        ThrownPotion potion = direct instanceof ThrownPotion thrown ? thrown
                : causing instanceof ThrownPotion thrown ? thrown : null;
        if (potion == null) {
            return false;
        }
        PotionContents contents = potion.getItem().get(DataComponents.POTION_CONTENTS);
        if (contents == null) {
            return false;
        }
        for (MobEffectInstance effect : contents.getAllEffects()) {
            if (effect.is(net.minecraft.world.effect.MobEffects.HARM)) {
                return true;
            }
        }
        return false;
    }
}
