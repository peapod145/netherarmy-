package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Berserker extends WitherSkeleton {
    // 与原版 Skeleton 一致：16 格索敌范围。
    private static final double SKELETON_FOLLOW_RANGE = 16.0D;

    public Berserker(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        this.xpReward = 8;
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.375D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, SKELETON_FOLLOW_RANGE);
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_AXE));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.025F);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         net.minecraft.world.entity.MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 原版 Mob 会随机设置左撇子；狂战士的金斧必须固定在右手。
        this.setLeftHanded(false);
        RandomSource random = this.getRandom();
        this.setCanPickUpLoot(random.nextFloat() < 0.10F);

        equipNormalGear(level.getLevel(), random);
        return result;
    }

    private void equipNormalGear(ServerLevel level, RandomSource random) {
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.BERSERKER_HELMET.get()));
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        equipEnchantedArmor(level, random, EquipmentSlot.CHEST, Items.GOLDEN_CHESTPLATE, 0.10F,
                List.of("protection", "fire_protection", "blast_protection", "projectile_protection", "thorns", "unbreaking", "mending"));
        equipEnchantedArmor(level, random, EquipmentSlot.LEGS, Items.GOLDEN_LEGGINGS, 0.10F,
                List.of("protection", "fire_protection", "blast_protection", "projectile_protection", "thorns", "unbreaking", "mending"));
        equipEnchantedArmor(level, random, EquipmentSlot.FEET, Items.GOLDEN_BOOTS, 0.10F,
                List.of("protection", "fire_protection", "blast_protection", "projectile_protection", "feather_falling", "depth_strider", "soul_speed", "thorns", "unbreaking", "mending"));
        // 金斧子始终携带；仅有 10% 的狂战士会获得四选二的指定附魔。
        ItemStack axe = new ItemStack(Items.GOLDEN_AXE);
        if (random.nextFloat() < 0.10F) {
            addExactlyTwoAxeEnchantments(level, random, axe);
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, axe);
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                        DifficultyInstance difficulty) {
        // 狂战士的装备附魔由本类按装备类型和概率单独生成。
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (this.getRandom().nextFloat() < 0.10F) {
            ItemStack helmet = new ItemStack(GeneratedMod.BERSERKER_HELMET.get());
            helmet.setDamageValue(this.getRandom().nextInt(helmet.getMaxDamage()));
            this.spawnAtLocation(helmet);
        }
    }

    private void equipEnchantedArmor(ServerLevel level, RandomSource random, EquipmentSlot slot,
                                     net.minecraft.world.item.Item item, float chance, List<String> enchantmentIds) {
        if (random.nextFloat() < chance) {
            ItemStack stack = new ItemStack(item);
            addRandomEnchantments(level, random, stack, slot, enchantmentIds, 3);
            this.setItemSlot(slot, stack);
        }
    }

    private void addExactlyTwoAxeEnchantments(ServerLevel level, RandomSource random, ItemStack stack) {
        HolderLookup.RegistryLookup<Enchantment> registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<String> ids = new ArrayList<>(List.of("sharpness", "fire_aspect", "unbreaking", "mending"));
        Collections.shuffle(ids, new java.util.Random(random.nextLong()));
        for (int i = 0; i < 2; i++) {
            ResourceKey<Enchantment> key = ResourceKey.create(Registries.ENCHANTMENT,
                    net.minecraft.resources.ResourceLocation.withDefaultNamespace(ids.get(i)));
            Holder.Reference<Enchantment> holder = registry.get(key).map(found -> (Holder.Reference<Enchantment>) found).orElse(null);
            if (holder != null) {
                // 这里的候选集合已经限定为四种指定附魔，直接应用可确保严格获得两种。
                stack.enchant(holder, 1 + random.nextInt(2));
            }
        }
    }

    private void addRandomEnchantments(ServerLevel level, RandomSource random, ItemStack stack, EquipmentSlot slot,
                                       List<String> ids, int maxCount) {
        HolderLookup.RegistryLookup<Enchantment> registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (String id : ids) {
            ResourceKey<Enchantment> key = ResourceKey.create(Registries.ENCHANTMENT,
                    net.minecraft.resources.ResourceLocation.withDefaultNamespace(id));
            Holder.Reference<Enchantment> holder = registry.get(key).map(found -> (Holder.Reference<Enchantment>) found).orElse(null);
            if (holder != null && holder.value().canEnchant(stack) && holder.value().matchingSlot(slot)) {
                candidates.add(holder);
            }
        }
        if (candidates.isEmpty()) return;
        Collections.shuffle(candidates, new java.util.Random(random.nextLong()));
        int count = 1 + random.nextInt(Math.min(maxCount, candidates.size()));
        List<Holder.Reference<Enchantment>> selected = new ArrayList<>();
        for (Holder.Reference<Enchantment> candidate : candidates) {
            boolean compatible = true;
            for (Holder.Reference<Enchantment> existing : selected) {
                if (!Enchantment.areCompatible(candidate, existing)) {
                    compatible = false;
                    break;
                }
            }
            if (compatible) {
                selected.add(candidate);
                int levelValue = 1 + random.nextInt(2);
                stack.enchant(candidate, Math.min(levelValue, candidate.value().getMaxLevel()));
                if (selected.size() >= count) break;
            }
        }
    }

    private static boolean isWeapon(ItemStack stack) {
        return stack.getItem() instanceof net.minecraft.world.item.AxeItem
                || stack.getItem() instanceof net.minecraft.world.item.SwordItem
                || stack.getItem() instanceof net.minecraft.world.item.TridentItem
                || stack.getItem() instanceof net.minecraft.world.item.MaceItem;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        // 狂战士只拾取武器，禁止通过拾取机制再次获得金头盔或下界合金头盔。
        return isWeapon(stack);
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return this.canPickUpLoot() && isWeapon(stack);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof net.minecraft.world.entity.LivingEntity living) {
            living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WITHER, 100), this);
        }
        return hurt;
    }

    // 免疫凋零效果不再写在这里：阵营成员的该判定已下沉到
    // WitherFactionWitherImmunityMixin（LivingEntity#canBeAffected），狂战士、床战士
    // 以及后续任何登记进 #minecraft:wither_skeletons 的新怪都自动生效。
}
