package cn.blockforge.generated.netherarmy;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 霸主凋灵之首：由霸主凋灵三个头发射的弹头。
 *
 * <h3>数值口径（相对蓝色凋灵之首）</h3>
 * <ul>
 * <li>普通霸主凋灵之首：爆炸威力 2（蓝头 1 的二倍）、直伤 16（蓝头 8 的二倍），
 * 命中附加 2 分钟凋零 III 与虚弱 I；第二至第五阶段分别以 25%、40%、50%、75% 的概率
 * 在落点生成无头骑士头颅，第一阶段不会生成。</li>
 * <li>炼狱霸主凋灵之首（紫红色弹头）：爆炸威力同 TNT（4）并留下火焰，直伤 24
 * （蓝头的三倍），落点生成持续 1 分钟的凋零 V 药水云；第二至第五阶段分别以 5%、20%、30%、55%
 * 的概率生成无头强袭骑士头颅，第一阶段不会生成。</li>
 * </ul>
 *
 * <p>飞行物理完全沿用凋灵之首（{@link WitherSkull} 基类的惯性/加速度），
 * 因此"飞行速度与凋灵之首一致"。弹头继承自 {@code WitherSkull}，
 * 阵营穿透 mixin（{@code WitherSkullFactionPassThroughMixin}）自动生效：
 * 凋灵骷髅阵营生物连"被命中"这件事都不会发生。原版命中与爆炸结算在
 * {@code WitherSkull} 里按蓝头数值写死，这里整段接管、不调用对应 super，
 * 避免双重伤害。</p>
 *
 * <p>炼狱弹头把 {@code isDangerous()} 覆写为真，从而完整接入蓝色凋灵之首的
 * 同款强化：撞击方块被 {@code WitherEnhancementHandler#onProjectileImpact}
 * 取消结算实现穿墙；每 tick 在 {@link #tick()} 里走
 * {@code WitherEnhancementHandler#tickTrackingBlueSkull} 的速度记忆、限步追踪
 * 与穿墙命中扫描，朝霸主凋灵当前目标修正弹道；制导扫描命中时经
 * {@link #resolveGuidedImpact} 回到本类的直伤/爆炸/落点头颅口径。
 * 普通弹头保持黑色凋灵之首的直行弹道不变。</p>
 */
public final class OverlordWitherSkull extends WitherSkull {
    private static final EntityDataAccessor<Boolean> DATA_PURGATORY =
            SynchedEntityData.defineId(OverlordWitherSkull.class, EntityDataSerializers.BOOLEAN);

    /** 凋零 III + 虚弱 I 的持续时间：2 分钟。 */
    private static final int CURSE_DURATION_TICKS = 20 * 120;
    /** 炼狱药水云的凋零 V 存在时间：1 分钟。 */
    private static final int PURGATORY_CLOUD_TICKS = 20 * 60;

    public OverlordWitherSkull(EntityType<? extends OverlordWitherSkull> type, Level level) {
        super(type, level);
    }

    /**
     * 发射用构造器。原版 {@code WitherSkull(Level, LivingEntity, Vec3)} 把实体类型
     * 硬编码为 {@code EntityType.WITHER_SKULL}，直接借用会让炼狱标记与自定义渲染
     * 全部失效；这里改走 {@code (EntityType, Level)} 构造器，再按
     * {@code AbstractHurtingProjectile} 同款口径补上归属、速度与朝向。
     * 注意 {@code accelerationPower} 是基类私有字段，默认 0.1——与凋灵之首一致。
     */
    public OverlordWitherSkull(Level level, LivingEntity owner, Vec3 direction, boolean purgatory) {
        this(GeneratedMod.OVERLORD_WITHER_SKULL.get(), level);
        this.setOwner(owner);
        this.setDeltaMovement(direction.normalize().scale(0.1D));
        this.hasImpulse = true;
        // 原版 WitherSkull 的模型正面在模型北面，渲染器按实体 yaw/pitch 让它朝向飞行方向；
        // 这里沿用同一套首帧朝向，避免侧头发射时沿用霸主凋灵本体角度。
        ProjectileUtil.rotateTowardsMovement(this, 1.0F);
        this.yRotO = this.getYRot();
        this.xRotO = this.getXRot();
        setPurgatory(purgatory);
    }

    public boolean isPurgatory() {
        return this.entityData.get(DATA_PURGATORY);
    }

    public void setPurgatory(boolean purgatory) {
        this.entityData.set(DATA_PURGATORY, purgatory);
    }

    /** 炼狱弹头复用蓝色凋灵之首的危险状态：低惯性、穿墙和增强制导均以此为入口。 */
    @Override
    public boolean isDangerous() {
        return this.isPurgatory() || super.isDangerous();
    }

    /** 炼狱弹头在原版移动结算之后，按霸主凋灵当前目标复用蓝头的限步追踪。 */
    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !this.isAlive() || !this.isPurgatory()) {
            return;
        }
        if (this.getOwner() instanceof WitherBoss boss) {
            WitherEnhancementHandler.tickTrackingBlueSkull(this, boss, boss.getTarget());
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_PURGATORY, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Purgatory", this.isPurgatory());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setPurgatory(tag.getBoolean("Purgatory"));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        Entity hit = result.getEntity();
        LivingEntity owner = this.getOwner() instanceof LivingEntity living ? living : null;
        float directDamage = this.isPurgatory() ? 24.0F : 16.0F;
        boolean damaged = owner != null
                ? hit.hurt(serverLevel.damageSources().witherSkull(this, owner), directDamage)
                : hit.hurt(this.damageSources().magic(), directDamage);
        if (damaged && hit instanceof LivingEntity victim
                && !MesmerizerControl.isWitherSkeletonFaction(victim)) {
            victim.addEffect(new MobEffectInstance(MobEffects.WITHER, CURSE_DURATION_TICKS, 2));
            victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CURSE_DURATION_TICKS, 0));
        }
    }

    @Override
    protected void onHit(HitResult result) {
        if (this.level().isClientSide) {
            return;
        }
        // 原版 WitherSkull#onHit 先经 super.onHit 分发 onHitEntity 再爆炸；本类整段接管
        // 后必须自己补这一步，否则 16/24 直伤与凋零/虚弱附加全部丢失。
        if (result instanceof EntityHitResult entityHit) {
            this.onHitEntity(entityHit);
        }
        Level level = this.level();
        double x = this.getX();
        double y = this.getY();
        double z = this.getZ();
        if (this.isPurgatory()) {
            // 爆炸范围同 TNT，留下火焰。溅射伤害走阵营门禁：同袍不受弹头伤害。
            level.explode(this, x, y, z, 4.0F, true, Level.ExplosionInteraction.MOB);
            if (level instanceof ServerLevel serverLevel) {
                spawnPurgatoryCloud(serverLevel, x, y, z);
                spawnHeadWithPhaseChance(serverLevel, GeneratedMod.BLITZ_DULLHAN_HEAD.get(), x, y, z,
                        this.getOverlordPhase());
            }
        } else {
            level.explode(this, x, y, z, 2.0F, false, Level.ExplosionInteraction.MOB);
            if (level instanceof ServerLevel serverLevel) {
                spawnHeadWithPhaseChance(serverLevel, GeneratedMod.DULLHAN_HEAD.get(), x, y, z,
                        this.getOverlordPhase());
            }
        }
        this.discard();
    }

    /**
     * 追踪制导自写扫描命中时的就地结算入口（{@code WitherEnhancementHandler#lockBlueSkullImpact}
     * 调用）。不能走蓝头那套写死的 8 点直伤 + 威力 1 爆炸，必须回到本类的
     * 16/24 直伤、威力 2/4 爆炸与落点生成头颅口径；onHit 会自行分发 onHitEntity，
     * 这里只调 onHit 一次，避免双重直伤。
     */
    public void resolveGuidedImpact(Entity victim) {
        this.onHit(new EntityHitResult(victim, victim.position()));
    }

    /** 炼狱弹头落点的凋零 V 药水云：存在 1 分钟。 */
    private void spawnPurgatoryCloud(ServerLevel level, double x, double y, double z) {
        AreaEffectCloud cloud = new AreaEffectCloud(level, x, y, z);
        cloud.setOwner(null);
        cloud.setRadius(3.0F);
        cloud.setRadiusPerTick(0.0F);
        cloud.setDuration(PURGATORY_CLOUD_TICKS);
        cloud.setDurationOnUse(0);
        cloud.setRadiusOnUse(0.0F);
        cloud.addEffect(new MobEffectInstance(MobEffects.WITHER, 20 * 10, 4));
        level.addFreshEntity(cloud);
        for (int i = 0; i < 24; i++) {
            level.sendParticles(net.minecraft.core.particles.ColorParticleOption.create(
                            ParticleTypes.ENTITY_EFFECT, 0x800080),
                    x + (level.random.nextDouble() - 0.5) * 3.0,
                    y + level.random.nextDouble() * 0.6,
                    z + (level.random.nextDouble() - 0.5) * 3.0,
                    1, 0.7, 0.1, 0.5, 0.0);
        }
    }

    /**
     * 按发射者当前阶段决定是否生成落点头颅。
     * <p>这里使用百分点累加：普通弹头为 25% → 40% → 50% → 75%，炼狱弹头为
     * 5% → 20% → 30% → 55%；第一阶段统一为 0%。没有霸主凋灵发射者时也按第一阶段处理，
     * 避免其他来源意外获得头颅生成。</p>
     */
    private void spawnHeadWithPhaseChance(ServerLevel level, EntityType<? extends Mob> headType,
                                          double x, double y, double z, int phase) {
        float chance = this.isPurgatory()
                ? switch (phase) {
                    case 2 -> 0.05F;
                    case 3 -> 0.20F;
                    case 4 -> 0.30F;
                    case 5 -> 0.55F;
                    default -> 0.0F;
                }
                : switch (phase) {
                    case 2 -> 0.25F;
                    case 3 -> 0.40F;
                    case 4 -> 0.50F;
                    case 5 -> 0.75F;
                    default -> 0.0F;
                };
        if (level.random.nextFloat() >= chance) {
            return;
        }
        spawnHeadAt(level, headType, x, y, z);
    }

    /** 爆炸时读取发射者的实时阶段；发射者缺失时按第一阶段处理。 */
    private int getOverlordPhase() {
        return this.getOwner() instanceof OverlordWitherBoss boss ? boss.getPhase() : 1;
    }

    /** 落点生成头颅（无头骑士/无头强袭骑士），仇恨与霸主凋灵一致。 */
    private void spawnHeadAt(ServerLevel serverLevel, EntityType<? extends Mob> headType,
                             double x, double y, double z) {
        Mob head = headType.create(serverLevel);
        if (head == null) {
            return;
        }
        head.setPos(x, y, z);
        head.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(head.blockPosition()),
                MobSpawnType.TRIGGERED, null);
        if (this.getOwner() instanceof WitherBoss boss) {
            WitherEnhancementHandler.markSummonedBy(head, boss);
        }
        serverLevel.addFreshEntity(head);
    }
}
