package cn.blockforge.generated.netherarmy;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Supplier;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.saveddata.SavedData;

/** 每个维度保存一份区块反应堆状态，多个反应核因此共享目标群系和替换游标。 */
public final class ReactorChunkState extends SavedData {
    private static final String DATA_ID = "generated_mod_nether_reactor_chunks";
    private final Map<Long, ChunkData> chunks = new HashMap<>();

    public static ReactorChunkState get(ServerLevel level, BlockPos pos) {
        Supplier<ReactorChunkState> constructor = ReactorChunkState::new;
        BiFunction<CompoundTag, net.minecraft.core.HolderLookup.Provider, ReactorChunkState> deserializer =
                ReactorChunkState::load;
        return (ReactorChunkState) level.getDataStorage().computeIfAbsent(
                new SavedData.Factory(constructor, deserializer), DATA_ID);
    }

    private static ReactorChunkState load(CompoundTag tag, net.minecraft.core.HolderLookup.Provider registries) {
        ReactorChunkState state = new ReactorChunkState();
        CompoundTag chunksTag = tag.getCompound("Chunks");
        for (String key : chunksTag.getAllKeys()) {
            long chunkKey = Long.parseLong(key);
            CompoundTag data = chunksTag.getCompound(key);
            ResourceKey<Biome> biome = data.contains("Biome")
                    ? ResourceKey.create(net.minecraft.core.registries.Registries.BIOME,
                    ResourceLocation.parse(data.getString("Biome"))) : null;
            int structureType = data.contains("StructureType")
                    ? data.getInt("StructureType")
                    : data.getBoolean("Structure") ? 1 : 0;
            state.chunks.put(chunkKey, new ChunkData(biome, structureType,
                    data.getInt("Index"), data.getInt("Reactors")));
        }
        return state;
    }

    public void activate(BlockPos reactorPos, ResourceKey<Biome> biome, int structureType) {
        long key = chunkKey(reactorPos);
        ChunkData current = chunks.get(key);
        chunks.put(key, new ChunkData(biome, structureType, current == null ? 0 : current.index,
                current == null ? 1 : current.reactors + 1));
        setDirty();
    }

    public boolean hasActiveReactor(BlockPos reactorPos) {
        ChunkData data = chunks.get(chunkKey(reactorPos));
        return data != null && data.reactors > 0;
    }

    public ResourceKey<Biome> targetBiome(BlockPos pos) {
        ChunkData data = chunks.get(chunkKey(pos));
        return data == null ? null : data.biome;
    }

    public int structureType(BlockPos pos) {
        ChunkData data = chunks.get(chunkKey(pos));
        return data == null ? 0 : data.structureType;
    }

    public boolean isStructureTarget(BlockPos pos) {
        return structureType(pos) != 0;
    }

    public int nextReplacementIndex(BlockPos pos) {
        ChunkData data = chunks.get(chunkKey(pos));
        if (data == null) {
            return 0;
        }
        int result = data.index++;
        setDirty();
        return result;
    }

    public void removeReactor(BlockPos pos) {
        long key = chunkKey(pos);
        ChunkData data = chunks.get(key);
        if (data == null) {
            return;
        }
        data.reactors--;
        if (data.reactors <= 0) {
            chunks.remove(key);
        }
        setDirty();
    }

    private static long chunkKey(BlockPos pos) {
        return ((long) (pos.getX() >> 4) << 32) ^ ((pos.getZ() >> 4) & 0xffffffffL);
    }

    @Override
    public CompoundTag save(CompoundTag tag, net.minecraft.core.HolderLookup.Provider registries) {
        CompoundTag chunksTag = new CompoundTag();
        for (Map.Entry<Long, ChunkData> entry : chunks.entrySet()) {
            CompoundTag data = new CompoundTag();
            if (entry.getValue().biome != null) {
                data.putString("Biome", entry.getValue().biome.location().toString());
            }
            data.putInt("StructureType", entry.getValue().structureType);
            data.putInt("Index", entry.getValue().index);
            data.putInt("Reactors", entry.getValue().reactors);
            chunksTag.put(Long.toString(entry.getKey()), data);
        }
        tag.put("Chunks", chunksTag);
        return tag;
    }

    private static final class ChunkData {
        private final ResourceKey<Biome> biome;
        private final int structureType;
        private int index;
        private int reactors;

        private ChunkData(ResourceKey<Biome> biome, int structureType, int index, int reactors) {
            this.biome = biome;
            this.structureType = structureType;
            this.index = index;
            this.reactors = reactors;
        }
    }
}
