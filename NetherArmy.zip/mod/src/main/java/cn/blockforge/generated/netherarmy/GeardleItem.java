package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/**
 * 格尔多：世界末日的开关。
 *
 * <p>只有玩家第一次进入世界时背包才会自带一个（见 {@link GeardleHandler}）；此后死亡重生、
 * 退出重进都不会再额外发放。不可堆叠、灵魂绑定（丢不掉、离不了背包、死亡不掉出背包），
 * 右键使用后先弹出红色确认框；确认后触发末日状态并消耗物品：聊天框红字 "D.I.E."、锁定困难、阵营生物双倍刷怪、
 * 夜晚致盲遮罩与失明、床/重生锚失效、死亡随机重生在下界——全部逻辑集中在
 * {@link GeardleHandler}。</p>
 */
public final class GeardleItem extends Item {

    public GeardleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            // 先由客户端弹出确认框；在玩家确认前不触发效果，也不消耗物品。
            PacketDistributor.sendToPlayer(serverPlayer,
                    new GeardleConfirmationPayload(hand == InteractionHand.MAIN_HAND ? 0 : 1));
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.geardle.tooltip").withStyle(ChatFormatting.RED));
    }
}
