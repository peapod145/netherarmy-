package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;

/**
 * 熔髓模型：几何与逐面 UV 按用户上传的 {@code Emberbone.bbmodel} 精确复刻。
 *
 * <p>该模型是 64×32 的凋灵骷髅式细肢体人形（头 8×8×8、躯干 8×12×4、四肢 2×12×2，
 * 总高 32 像素），渲染器套用与原版凋灵骷髅一致的 {@code scale(1.2)} 撑到 2.4 格。
 * bbmodel 里左右臂/腿的东西侧面相对原版网格式排布互换（左臂、左腿画在贴图下半区），
 * 因此不能用一个 {@code addBox} 的 texOffs 覆盖六个面，而是逐面反解 texOffs：
 * 原版 {@code ModelPart.Cube} 各面的矩形为 NORTH=(U+d,V+d)、SOUTH=(U+2d+w,V+d)、
 * WEST=(U,V+d)、EAST=(U+d+w,V+d)、顶面=(U+d,V)、底面=(U+d+w,V)（U,V 为 texOffs，
 * w/h/d 为立方体尺寸），把 bbmodel 每个面的矩形左上角喂进 {@link #faces} 即可。</p>
 *
 * <p>骨架层级与枢轴沿用 bbmodel 的 group origin（换算到原版模型空间：模型 Y 轴向下，
 * 原版 y = 24 − bbmodel y）：头/躯干枢轴在 y=0，双臂在 y=2（肩），双腿在 y=12（胯）。
 * 动画完全交给 {@link HumanoidModel}：行走摆臂、攻击挥臂、视线的头颈旋转与游泳姿态
 * 都是原版人形那套，本类不再覆写 {@code setupAnim}。</p>
 */
public class EmberboneModel extends HumanoidModel<Emberbone> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "emberbone"), "main");

    public EmberboneModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // 头：bbmodel head（x -4..4，y 24..32，z -4..4，就是原版头部的标准网格）。
        root.addOrReplaceChild("head", faces(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F,
                        8, 8, 24, 8, 0, 8, 16, 8, 8, 0, 16, 0),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // hat：HumanoidModel 构造器无条件取用该部件（缺失即抛 NoSuchElementException，
        // 客户端启动期构建渲染器时会让游戏卡在加载界面）。本贴图没有第二层头部几何，
        // 与其它人形模型一样注册一个空部件。
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);

        // 躯干：bbmodel body（东西侧面相对原版网格互换，逐面 UV 原样保留）。
        root.addOrReplaceChild("body", faces(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F,
                        20, 20, 32, 20, 16, 20, 28, 20, 20, 16, 28, 16),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // 模型右臂（世界 -x 侧）：bbmodel left_arm 立方体（x -6..-4），UV 在贴图下半区。
        root.addOrReplaceChild("right_arm", faces(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        42, 18, 46, 18, 44, 18, 40, 18, 42, 16, 44, 16),
                PartPose.offset(-5.0F, 2.0F, 0.0F));

        // 模型左臂（世界 +x 侧）：bbmodel right_arm 立方体（x 4..6）。
        root.addOrReplaceChild("left_arm", faces(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        42, 18, 46, 18, 40, 18, 44, 18, 42, 16, 44, 16),
                PartPose.offset(5.0F, 2.0F, 0.0F));

        // 模型右腿（世界 -x 侧）：bbmodel left_leg 立方体（x -3..-1）。
        root.addOrReplaceChild("right_leg", faces(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        2, 18, 6, 18, 4, 18, 0, 18, 2, 16, 4, 16),
                PartPose.offset(-2.0F, 12.0F, 0.0F));

        // 模型左腿（世界 +x 侧）：bbmodel right_leg 立方体（x 1..3）。
        root.addOrReplaceChild("left_leg", faces(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        2, 18, 6, 18, 0, 18, 4, 18, 2, 16, 4, 16),
                PartPose.offset(2.0F, 12.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 32);
    }

    /**
     * 把一个立方体的六个面分别摆到贴图上的指定矩形。
     *
     * <p>原版 Cube 模型空间 Y 轴向下，挂 {@code Direction.DOWN} 标签的面（矩形 (U+d,V)）
     * 是视觉顶面，{@code Direction.UP}（矩形 (U+d+w,V)）是视觉底面，因此 bbmodel 的
     * 顶面喂给 DOWN、底面喂给 UP。</p>
     *
     * @param x,y,z     立方体最小角（部件局部坐标）
     * @param w,h,d     立方体尺寸
     * @param nU,nV     北面矩形左上角；sU,sV 南面；eU,eV 东面；wU,wV 西面；
     *                  uU,uV 顶面；dU,dV 底面（矩形宽高由立方体尺寸决定）
     */
    private static CubeListBuilder faces(float x, float y, float z, float w, float h, float d,
                                         int nU, int nV, int sU, int sV,
                                         int eU, int eV, int wU, int wV,
                                         int uU, int uV, int dU, int dV) {
        int di = (int) d;
        int wi = (int) w;
        CubeListBuilder builder = CubeListBuilder.create();
        face(builder, Direction.NORTH, nU - di, nV - di, x, y, z, w, h, d);
        face(builder, Direction.SOUTH, sU - 2 * di - wi, sV - di, x, y, z, w, h, d);
        face(builder, Direction.WEST, wU, wV - di, x, y, z, w, h, d);
        face(builder, Direction.EAST, eU - di - wi, eV - di, x, y, z, w, h, d);
        face(builder, Direction.DOWN, uU - di, uV, x, y, z, w, h, d);
        face(builder, Direction.UP, dU - di - wi, dV, x, y, z, w, h, d);
        return builder;
    }

    private static void face(CubeListBuilder builder, Direction dir, int texU, int texV,
                             float x, float y, float z, float w, float h, float d) {
        builder.texOffs(texU, texV).addBox(x, y, z, w, h, d, EnumSet.of(dir));
    }
}
