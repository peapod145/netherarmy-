package cn.blockforge.generated.netherarmy;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** 玩家被反逆者光球命中后的视觉与攻击限制效果。 */
public final class RebellionMobEffect extends MobEffect {
    public RebellionMobEffect() {
        super(MobEffectCategory.HARMFUL, 0x8B2FB8);
    }
}
