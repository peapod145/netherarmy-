package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.SoulFireFlareRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * 把原版"着火生物"的全身橙焰覆盖层原地替换成灵魂火版本（见 {@link SoulFireFlareRenderer}）。
 *
 * <p>烈焰人远程攻击时靠 {@code Blaze#isOnFire() -> isCharging()} 触发这条原版火焰覆盖层；
 * 诡影使徒沿用同一开关，只是火焰贴图换成灵魂火。被凋零飞弹灵魂火烧灼的生物与飞行中的
 * 凋零飞弹同样走这里。普通着火的生物不受影响（走 @Invoker 回退到原版橙焰）。
 * 注册在 mixins.json 的 "client" 段，仅客户端应用。</p>
 */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherSoulFireMixin {
    @Redirect(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;renderFlame("
                    + "Lcom/mojang/blaze3d/vertex/PoseStack;"
                    + "Lnet/minecraft/client/renderer/MultiBufferSource;"
                    + "Lnet/minecraft/world/entity/Entity;"
                    + "Lorg/joml/Quaternionf;)V"))
    private void netherarmy$renderSoulOrNormalFlame(EntityRenderDispatcher dispatcher,
                                                    PoseStack poseStack, MultiBufferSource buffers,
                                                    Entity entity, Quaternionf orientation) {
        if (SoulFireFlareRenderer.usesSoulFlame(entity)) {
            SoulFireFlareRenderer.render(poseStack, buffers, entity, orientation);
        } else {
            this.netherarmy$renderFlame(poseStack, buffers, entity, orientation);
        }
    }

    /** 原版橙焰渲染入口（同目标类私有方法，由 Mixin 生成转发）。 */
    @Invoker("renderFlame")
    protected abstract void netherarmy$renderFlame(PoseStack poseStack, MultiBufferSource buffers,
                                                   Entity entity, Quaternionf orientation);
}
