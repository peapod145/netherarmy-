package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.WitherSkeleton;

/**
 * 地狱军团的凋灵骷髅阵营名册——"是不是自己人"的唯一权威口径。
 *
 * <h3>为什么不能用原版标签判定</h3>
 * <p>本模组把军团成员登记在 {@code #minecraft:wither_skeletons} 里（让原版与第三方模组
 * 的"敌视凋灵骷髅"AI 认得出我们），那份标签是<b>公开的、可被任意模组与数据包追加的</b>：
 * {@code replace:false} 的合并语义下，只要别的模组也给这个标签写过自己的实体（几乎所有
 * 带凋灵骷髅系生物的模组都会这么写），那只怪就会一并落进我们读的同一份标签里。</p>
 *
 * <p>后果正是用户反复反馈的"无法索敌其他 mod 的亡灵生物"：阵营判定一旦把第三方亡灵误认成
 * 同袍，{@link MesmerizerControl#canAttack} 直接判互不可攻击，于是
 * <ul>
 * <li>主动索敌——目标谓词里的阵营排除把它当自己人跳过；</li>
 * <li>受击反击——{@code MesmerizerControlHandler#onIncomingDamage} 把它打军团的那一下当成
 * 同袍误伤取消，{@code lastHurtByMob} 根本写不进去，原版复仇目标组自然不会锁；</li>
 * <li>强制仇恨工具——{@code MesmerizerControlHandler#onChangeTarget} 以"同袍不可攻击"为由
 * 取消这次 {@code setTarget}。</li>
 * </ul>
 * 三条通道同时失效，表现就是"无论怎么弄都锁不上某些 mod 的亡灵"。</p>
 *
 * <h3>名册怎么读</h3>
 * <p>本模组自己的私有标签 {@code #netherarmy:wither_faction}（{@code replace:true}，
 * 只有我们能写）+ 三条兜底 {@code instanceof}：原版凋灵骷髅与凋灵（按类认，不依赖任何标签，
 * 免得数据包改了标签就把原版怪放进来）、以及无头骑士头颅。这份私有标签现在只列两项——
 * 原版凋灵骷髅，以及嵌套的军团亡灵名册 {@link NetherLegionUndead#UNDEAD}：军团的亡灵编制
 * 单位与阵营编制单位本就是同一批怪，登记一处（{@code nether_legion_undead}）即可同时拿到
 * 亡灵机制与阵营敌我，不再有两份名单互相抄漏的风险。</p>
 *
 * <p>头颅的口径变化：{@code DullahanHead} 是史莱姆系实体，早期为了让它能被治疗药水伤害等手段
 * 正确作用，只在机制标签里直列、故意不进名册标签（进了 {@code GeardleHandler} 那类"按标签枚举
 * 刷怪候选池"的地方会把浮空头颅当普通阵营怪刷出来）。如今它随军团亡灵名册一并进阵营，
 * 那份候选池改为显式剔除头颅，行为与以前逐字一致。</p>
 *
 * <p>对外那份 {@code #minecraft:wither_skeletons} 保持原样继续发布：它的作用是让外部 AI
 * 认得出军团，不再作为本模组的敌我依据，也不再被塞进原版的亡灵机制标签里。</p>
 */
public final class WitherFactionRoster {

    /** 私有名册标签：只有本模组能写入，第三方模组与数据包的追加一律不影响敌我判定。 */
    public static final TagKey<EntityType<?>> FACTION = TagKey.create(
            Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_faction"));

    private WitherFactionRoster() {
    }

    /** 该实体是否属于地狱军团的凋灵骷髅阵营。 */
    public static boolean isMember(Entity entity) {
        if (entity == null) {
            return false;
        }
        return entity instanceof WitherBoss
                || entity instanceof WitherSkeleton
                || entity instanceof DullahanHead
                || entity.getType().is(FACTION)
                || NetherLegionUndead.isLegionUndead(entity);
    }

    /**
     * 类型级名册判定：只有类型、拿不到实体时使用（{@code Mob#canAttackType} 这类钩子）。
     *
     * <p>凋灵本体只按 {@code instanceof} 认，这里补一条类型判断，保证两条口径一致。</p>
     */
    public static boolean isMemberType(EntityType<?> type) {
        return type == EntityType.WITHER_SKELETON
                || type == EntityType.WITHER
                || type == GeneratedMod.DULLAHAN_HEAD.get()
                || type == GeneratedMod.BLITZ_DULLAHAN_HEAD.get()
                || type.is(FACTION)
                || NetherLegionUndead.isLegionUndeadType(type);
    }
}
