package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import java.util.List;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * 追随下界传令兵：30 格内的阵营生物主动靠拢到传令兵身边。
 *
 * <p>挂在每个阵营成员（{@link LegionFactionHandler} 在实体进世界时注入）的
 * goalSelector 上，优先级 4——与凋灵骷髅系的近战目标同级：一旦成员自己锁定了
 * 目标（被攻击、看到玩家/猪灵），本目标立刻让位（{@code canUse/canContinueToUse}
 * 都要求 {@code getTarget() == null}），战斗结束再继续跟队，不会出现"举着剑
 * 往传令兵身上挤"的死锁。</p>
 *
 * <p>寻路分两段：12 格内直接 {@code moveTo(courier)}；更远时原版导航受
 * FOLLOW_RANGE（凋灵骷髅系只有 16 格）限制够不着 30 格外的目标，就朝传令兵
 * 方向中继一个 12 格的落点，逐段逼近——这就是"主动追随"。中继落点只取
 * <b>水平分量</b>：凋灵骷髅系的 FOLLOW_RANGE 与上下层高差让 3D 归一化的落点
 * 常悬在半空或墙里，A* 找不到路径，成员就会原地站桩。</p>
 *
 * <p>目标自愈：成员仇恨若来自外部直接 {@code setTarget}（典型是
 * {@link NetherCourier#hurt} 后的全员转移仇恨）而没有任何目标系统接管它，
 * 1.21.1 原版在目标死亡后<b>不会</b>自动清掉这条仇恨——残留会永远压住本目标
 * 的 {@code getTarget() == null} 前提，表现为"被判定进队伍却不跟随"。
 * {@link #clearDeadTarget()} 在每次判定前把这种"死目标/已出世界的目标"清掉。</p>
 */
public final class CourierFollowGoal extends Goal {
    private static final double FOLLOW_RADIUS_SQR =
            NetherCourier.FOLLOW_RADIUS * NetherCourier.FOLLOW_RADIUS;
    /** 距离小于此值就地停下，不再挤在传令兵身上。 */
    private static final double KEEP_DISTANCE = 5.0D;
    /** 单次寻路推进的最大距离（也是导航中继段的长度）。 */
    private static final double CHAIN_DISTANCE = 12.0D;

    private final Mob mob;
    private NetherCourier courier;
    private int courierSearchCooldown;
    private int repathCooldown;

    public CourierFollowGoal(Mob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        clearDeadTarget();
        if (this.mob.getTarget() != null) {
            return false;
        }
        if (--this.courierSearchCooldown > 0) {
            return this.courier != null && this.courier.isAlive();
        }
        this.courierSearchCooldown = 10;
        this.courier = this.findCourier();
        return this.courier != null;
    }

    @Override
    public boolean canContinueToUse() {
        return this.mob.getTarget() == null
                && this.courier != null && this.courier.isAlive()
                && this.mob.distanceToSqr(this.courier) <= FOLLOW_RADIUS_SQR;
    }

    @Override
    public void stop() {
        this.courier = null;
        this.repathCooldown = 0;
    }

    @Override
    public void tick() {
        NetherCourier leader = this.courier;
        double distance = this.mob.distanceTo(leader);
        if (distance < KEEP_DISTANCE) {
            this.mob.getNavigation().stop();
            return;
        }
        if (this.repathCooldown-- > 0 && this.mob.getNavigation().isInProgress()) {
            return;
        }
        this.repathCooldown = 10;
        if (distance <= CHAIN_DISTANCE) {
            this.mob.getNavigation().moveTo(leader, 1.0D);
        } else {
            // 只取水平分量做中继：3D 归一化在高差地形（下界多层台地、堡垒台阶）
            // 会把落点甩到半空或墙里，寻路直接失败、成员原地站桩——这正是
            // "判定进队却不跟随"偶发复现的另一半根因。平面落点交给地面导航
            // 自己爬台阶。
            Vec3 toCourier = leader.position().subtract(this.mob.position());
            double planar = Math.sqrt(toCourier.x * toCourier.x + toCourier.z * toCourier.z);
            if (planar < 1.0E-4D) {
                return;
            }
            double step = Math.min(CHAIN_DISTANCE, planar);
            Vec3 target = this.mob.position().add(toCourier.x / planar * step, 0.0D, toCourier.z / planar * step);
            this.mob.getNavigation().moveTo(target.x, this.mob.getY(), target.z, 1.0D);
        }
    }

    /**
     * 清掉"无人认领"的死目标：仇恨实体已死亡或已离开世界时，原版不会自己
     * 解除（{@code Mob} 没有目标死亡自动清空，接管过它的目标也早已停止运行），
     * 残留会把追随判定永远挡在 {@code getTarget() != null} 之外。
     */
    private void clearDeadTarget() {
        LivingEntity target = this.mob.getTarget();
        if (target != null && (!target.isAlive() || target.isRemoved())) {
            this.mob.setTarget(null);
        }
    }

    private NetherCourier findCourier() {
        List<NetherCourier> nearby = this.mob.level().getEntitiesOfClass(
                NetherCourier.class,
                this.mob.getBoundingBox().inflate(NetherCourier.FOLLOW_RADIUS),
                NetherCourier::isAlive);
        NetherCourier best = null;
        double bestDistance = FOLLOW_RADIUS_SQR;
        for (NetherCourier candidate : nearby) {
            double distance = candidate.distanceToSqr(this.mob);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }
}
