package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 御首者本体层：几何与逐面 UV 按作者上传的 head_dominator.bbmodel 精确复刻
 * （主贴图 headdomintaor.png，64x32）。由 tools/gen_head_dominator_quads.py 生成。
 *
 * <p>为什么不用 CubeListBuilder 的 texOffs：bbmodel 是 per-face UV，作者手绘的 UV
 * 矩形尺寸与盒子尺寸并不相等（最明显的是杖头——inflate -3 后盒子只有 2x2x2，
 * 贴图 UV 仍是 8x8）。Java 的标准 API 只能画"UV 尺寸 == 盒子尺寸"的面，反解 texOffs
 * 也复刻不了这种拉伸，游戏里会变成只取矩形左上角一小块。这里改走
 * {@link HackerQuads}：骨骼仍是 ModelPart（动画照旧），几何/UV 由下面几张表直接
 * 发射四边形，UV 用的是 bbmodel 原始矩形，与 Blockbench 预览逐像素一致。</p>
 *
 * <p>法杖杆与悬浮装饰簇（32x32 杖纹贴图）拆到 {@link HeadDominatorStaffModel}、
 * 披风（16x32）拆到 {@link HeadDominatorCapeModel}，三层姿态由
 * {@link HeadDominatorPose} 统一结算。group2（杖头）用主贴图，留在本层。</p>
 *
 * <p>表内顶点是"未旋转的盒顶点相对骨骼枢轴"（java = (ox - x, oy - y, z - oz)），
 * 静态旋转（杖头 X-25°）仍留在 PartPose 里，动画行为与改造前逐帧一致。
 * 模型按 32px（2.0 格）搭建，渲染器与凋灵骷髅同款 1.2x 放大到 2.4 格。</p>
 */
public class HeadDominatorModel extends EntityModel<HeadDominator> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "head_dominator"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 32;

    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart staff;
    private final ModelPart group2;

    /** 躯干 + 腰带（腰带 inflate 0.25 已并进几何）。 */
    private static final float[] BODY = {
            -4.0F, -12.0F, -2.0F, 4.0F, -12.0F, -2.0F, 4.0F, 0.0F, -2.0F, -4.0F,
            0.0F, -2.0F, 20.0F, 20.0F, 28.0F, 32.0F, 0.0F, 0.0F, -1.0F, 4.0F,
            -12.0F, 2.0F, -4.0F, -12.0F, 2.0F, -4.0F, 0.0F, 2.0F, 4.0F, 0.0F,
            2.0F, 32.0F, 20.0F, 40.0F, 32.0F, 0.0F, 0.0F, 1.0F, -4.0F, -12.0F,
            2.0F, -4.0F, -12.0F, -2.0F, -4.0F, 0.0F, -2.0F, -4.0F, 0.0F, 2.0F,
            16.0F, 20.0F, 20.0F, 32.0F, -1.0F, 0.0F, 0.0F, 4.0F, -12.0F, -2.0F,
            4.0F, -12.0F, 2.0F, 4.0F, 0.0F, 2.0F, 4.0F, 0.0F, -2.0F, 28.0F,
            20.0F, 32.0F, 32.0F, 1.0F, 0.0F, 0.0F, 4.0F, -12.0F, -2.0F, -4.0F,
            -12.0F, -2.0F, -4.0F, -12.0F, 2.0F, 4.0F, -12.0F, 2.0F, 20.0F, 16.0F,
            28.0F, 20.0F, 0.0F, -1.0F, 0.0F, 4.0F, 0.0F, 2.0F, -4.0F, 0.0F,
            2.0F, -4.0F, 0.0F, -2.0F, 4.0F, 0.0F, -2.0F, 28.0F, 16.0F, 36.0F,
            20.0F, 0.0F, 1.0F, 0.0F, -4.25F, -1.75F, -2.25F, 4.25F, -1.75F, -2.25F,
            4.25F, -0.25F, -2.25F, -4.25F, -0.25F, -2.25F, 44.0F, 30.0F, 52.0F, 32.0F,
            0.0F, 0.0F, -1.0F, 4.25F, -1.75F, 2.25F, -4.25F, -1.75F, 2.25F, -4.25F,
            -0.25F, 2.25F, 4.25F, -0.25F, 2.25F, 55.0F, 30.0F, 63.0F, 32.0F, 0.0F,
            0.0F, 1.0F, -4.25F, -1.75F, 2.25F, -4.25F, -1.75F, -2.25F, -4.25F, -0.25F,
            -2.25F, -4.25F, -0.25F, 2.25F, 40.0F, 30.0F, 44.0F, 32.0F, -1.0F, 0.0F,
            0.0F, 4.25F, -1.75F, -2.25F, 4.25F, -1.75F, 2.25F, 4.25F, -0.25F, 2.25F,
            4.25F, -0.25F, -2.25F, 52.0F, 30.0F, 56.0F, 32.0F, 1.0F, 0.0F, 0.0F,
            4.25F, -1.75F, -2.25F, -4.25F, -1.75F, -2.25F, -4.25F, -1.75F, 2.25F, 4.25F,
            -1.75F, 2.25F, 48.0F, 22.0F, 56.0F, 26.0F, 0.0F, -1.0F, 0.0F, 4.25F,
            -0.25F, 2.25F, -4.25F, -0.25F, 2.25F, -4.25F, -0.25F, -2.25F, 4.25F, -0.25F,
            -2.25F, 48.0F, 26.0F, 56.0F, 30.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] HEAD = {
            -4.0F, -8.0F, -4.0F, 4.0F, -8.0F, -4.0F, 4.0F, 0.0F, -4.0F, -4.0F,
            0.0F, -4.0F, 8.0F, 8.0F, 16.0F, 16.0F, 0.0F, 0.0F, -1.0F, 4.0F,
            -8.0F, 4.0F, -4.0F, -8.0F, 4.0F, -4.0F, 0.0F, 4.0F, 4.0F, 0.0F,
            4.0F, 24.0F, 8.0F, 32.0F, 16.0F, 0.0F, 0.0F, 1.0F, -4.0F, -8.0F,
            4.0F, -4.0F, -8.0F, -4.0F, -4.0F, 0.0F, -4.0F, -4.0F, 0.0F, 4.0F,
            0.0F, 8.0F, 8.0F, 16.0F, -1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F,
            4.0F, -8.0F, 4.0F, 4.0F, 0.0F, 4.0F, 4.0F, 0.0F, -4.0F, 16.0F,
            8.0F, 24.0F, 16.0F, 1.0F, 0.0F, 0.0F, 4.0F, -8.0F, -4.0F, -4.0F,
            -8.0F, -4.0F, -4.0F, -8.0F, 4.0F, 4.0F, -8.0F, 4.0F, 8.0F, 0.0F,
            16.0F, 8.0F, 0.0F, -1.0F, 0.0F, 4.0F, 0.0F, 4.0F, -4.0F, 0.0F,
            4.0F, -4.0F, 0.0F, -4.0F, 4.0F, 0.0F, -4.0F, 16.0F, 0.0F, 24.0F,
            8.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_LEG = {
            -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
            12.0F, -1.0F, 2.0F, 18.0F, 4.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
            0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
            1.0F, 6.0F, 18.0F, 8.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
            1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
            0.0F, 18.0F, 2.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
            1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 4.0F,
            18.0F, 6.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
            0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 2.0F, 16.0F,
            4.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
            1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 4.0F, 16.0F, 6.0F,
            18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_LEG = {
            -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
            12.0F, -1.0F, 2.0F, 18.0F, 4.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
            0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
            1.0F, 6.0F, 18.0F, 8.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
            1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
            0.0F, 18.0F, 2.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
            1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 4.0F,
            18.0F, 6.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
            0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 2.0F, 16.0F,
            4.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
            1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 4.0F, 16.0F, 6.0F,
            18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_ARM = {
            -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
            12.0F, -1.0F, 42.0F, 18.0F, 44.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
            0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
            1.0F, 46.0F, 18.0F, 48.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
            1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
            40.0F, 18.0F, 42.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
            1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 44.0F,
            18.0F, 46.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
            0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 42.0F, 16.0F,
            44.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
            1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 44.0F, 16.0F, 46.0F,
            18.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_ARM = {
            -1.0F, 0.0F, -1.0F, 1.0F, 0.0F, -1.0F, 1.0F, 12.0F, -1.0F, -1.0F,
            12.0F, -1.0F, 42.0F, 18.0F, 44.0F, 30.0F, 0.0F, 0.0F, -1.0F, 1.0F,
            0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 12.0F, 1.0F, 1.0F, 12.0F,
            1.0F, 46.0F, 18.0F, 48.0F, 30.0F, 0.0F, 0.0F, 1.0F, -1.0F, 0.0F,
            1.0F, -1.0F, 0.0F, -1.0F, -1.0F, 12.0F, -1.0F, -1.0F, 12.0F, 1.0F,
            40.0F, 18.0F, 42.0F, 30.0F, -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F,
            1.0F, 0.0F, 1.0F, 1.0F, 12.0F, 1.0F, 1.0F, 12.0F, -1.0F, 44.0F,
            18.0F, 46.0F, 30.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, -1.0F, -1.0F,
            0.0F, -1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 42.0F, 16.0F,
            44.0F, 18.0F, 0.0F, -1.0F, 0.0F, 1.0F, 12.0F, 1.0F, -1.0F, 12.0F,
            1.0F, -1.0F, 12.0F, -1.0F, 1.0F, 12.0F, -1.0F, 44.0F, 16.0F, 46.0F,
            18.0F, 0.0F, 1.0F, 0.0F
    };
    /** 杖头：盒子 2x2x2（inflate -3），UV 是 8x8 的整块杖头图案。 */
    private static final float[] GROUP2 = {
            -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, -1.0F,
            1.0F, -1.0F, 40.0F, 8.0F, 48.0F, 16.0F, 0.0F, 0.0F, -1.0F, 1.0F,
            -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F,
            1.0F, 56.0F, 8.0F, 64.0F, 16.0F, 0.0F, 0.0F, 1.0F, -1.0F, -1.0F,
            1.0F, -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F,
            32.0F, 8.0F, 40.0F, 16.0F, -1.0F, 0.0F, 0.0F, 1.0F, -1.0F, -1.0F,
            1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 48.0F,
            8.0F, 56.0F, 16.0F, 1.0F, 0.0F, 0.0F, 1.0F, -1.0F, -1.0F, -1.0F,
            -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 40.0F, 0.0F,
            48.0F, 8.0F, 0.0F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F, -1.0F, 1.0F,
            1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 48.0F, 0.0F, 56.0F,
            8.0F, 0.0F, 1.0F, 0.0F
    };

    public HeadDominatorModel(ModelPart root) {
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.staff = root.getChild("staff");
        this.group2 = this.staff.getChild("group2");
    }

    @Override
    public void setupAnim(HeadDominator entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HeadDominatorPose.apply(this.body, this.head, this.rightLeg, this.leftLeg,
                this.rightArm, this.leftArm, this.staff, this.group2,
                entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        HackerQuads.emit(poseStack, buffer, this.body, BODY, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.head, HEAD, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightLeg, RIGHT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftLeg, LEFT_LEG, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.rightArm, RIGHT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.leftArm, LEFT_ARM, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        // 杖头挂在 staff 骨下：先落 staff 的抬杖位移，再发 group2 的四边形。
        poseStack.pushPose();
        this.staff.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.group2, GROUP2, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // 只搭骨骼枢轴，几何全部由上面的直发表提供。
        root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0F, 12F, 0F));
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(1.9F, 12F, 0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(-1.9F, 12F, 0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(5F, 2F, 0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(-5F, 2F, 0F));
        PartDefinition staff = root.addOrReplaceChild("staff", CubeListBuilder.create(),
                PartPose.offset(-5F, 24F, -8F));
        // bbmodel 里杖头的 X+25° 换算到 java 是 -25°，与改造前一样留在 PartPose。
        staff.addOrReplaceChild("group2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -34F, 0F, -25F, 0F, 0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
