package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;

/**
 * 御首者本体层模型：几何与逐面 UV 按用户上传的 head_dominator.bbmodel 精确复刻
 * （主贴图 headdomintaor.png，64x32；躯干/头/四肢的 UV 与原版凋灵骷髅人形网格完全吻合）。
 *
 * <p>法杖杆与悬浮装饰簇（32x32 杖纹贴图）、披风（16x32 披风贴图）各用一张独立贴图，
 * 拆到 {@link HeadDominatorStaffModel} / {@link HeadDominatorCapeModel} 分层渲染；
 * 本层保留挂杖头 group2 骨骼——杖头立方体用的是主贴图。三层的姿态由
 * {@link HeadDominatorPose} 统一结算，保证抬杖/旋转跨层同步。</p>
 *
 * <p>bbmodel 里披风领口的两块 1px 薄板 inflate -1 后高度为负（Blockbench 中即不可见），
 * 不纳入模型。模型按 32px（2.0 格）搭建，渲染器与凋灵骷髅同款 1.2x 放大到 2.4 格。</p>
 *
 * <p>换算口径见 {@link HeadDominatorPose} 类注释：java = (−x_bb, 24−y_bb, z_bb)。
 * 因此 bb 里位于 +5 的持杖臂映射到 java 的 −5（游戏内角色的右手边，与 Blockbench
 * 预览一致）；UV 的 east/west 槽位互换正是这套镜像映射的正确落位，保持不变。</p>
 */
public class HeadDominatorModel extends EntityModel<HeadDominator> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "head_dominator"), "main");

    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart staff;
    private final ModelPart group2;

    public HeadDominatorModel(ModelPart root) {
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.staff = root.getChild("staff");
        this.group2 = this.staff.getChild("group2");
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        body.render(poseStack, buffer, packedLight, packedOverlay, color);
        head.render(poseStack, buffer, packedLight, packedOverlay, color);
        rightLeg.render(poseStack, buffer, packedLight, packedOverlay, color);
        leftLeg.render(poseStack, buffer, packedLight, packedOverlay, color);
        rightArm.render(poseStack, buffer, packedLight, packedOverlay, color);
        leftArm.render(poseStack, buffer, packedLight, packedOverlay, color);
        // staff 部件本身无立方体（纯枢轴），render() 自动带走 group2 杖头子树。
        staff.render(poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public void setupAnim(HeadDominator entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HeadDominatorPose.apply(this.body, this.head, this.rightLeg, this.leftLeg,
                this.rightArm, this.leftArm, this.staff, this.group2,
                entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition parent = mesh.getRoot();
        // body 骨：躯干（bb y12..24）+ 腰带（bb y12.5..13.5，inflate .25 已并入几何）
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 20F, 20F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.SOUTH, 32F, 20F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.WEST, 16F, 20F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.EAST, 28F, 20F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.UP, 20F, 16F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.DOWN, 28F, 16F, -4F, -12F, -2F, 8F, 12F, 4F);
            face(builder, Direction.NORTH, 44F, 30F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            face(builder, Direction.SOUTH, 55F, 30F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            face(builder, Direction.WEST, 40F, 30F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            face(builder, Direction.EAST, 52F, 30F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            face(builder, Direction.UP, 48F, 22F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            face(builder, Direction.DOWN, 48F, 26F, -4.25F, -1.75F, -2.25F, 8.5F, 1.5F, 4.5F);
            parent.addOrReplaceChild("body", builder, PartPose.offset(0F, 12F, 0F));
        }
        // head 骨（bb y24..32，原版 8x8x8 头部网格）
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 8F, 8F, -4F, -8F, -4F, 8F, 8F, 8F);
            face(builder, Direction.SOUTH, 24F, 8F, -4F, -8F, -4F, 8F, 8F, 8F);
            face(builder, Direction.WEST, 0F, 8F, -4F, -8F, -4F, 8F, 8F, 8F);
            face(builder, Direction.EAST, 16F, 8F, -4F, -8F, -4F, 8F, 8F, 8F);
            face(builder, Direction.UP, 8F, 0F, -4F, -8F, -4F, 8F, 8F, 8F);
            face(builder, Direction.DOWN, 16F, 0F, -4F, -8F, -4F, 8F, 8F, 8F);
            parent.addOrReplaceChild("head", builder, PartPose.offset(0F, 0F, 0F));
        }
        // right_leg 骨
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 2F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.SOUTH, 6F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.WEST, 0F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.EAST, 4F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.UP, 2F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.DOWN, 4F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            parent.addOrReplaceChild("right_leg", builder, PartPose.offset(1.9F, 12F, 0F));
        }
        // left_leg 骨
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 2F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.SOUTH, 6F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.WEST, 0F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.EAST, 4F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.UP, 2F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.DOWN, 4F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            parent.addOrReplaceChild("left_leg", builder, PartPose.offset(-1.9F, 12F, 0F));
        }
        // right_arm 骨
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 42F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.SOUTH, 46F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.WEST, 40F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.EAST, 44F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.UP, 42F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.DOWN, 44F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            parent.addOrReplaceChild("right_arm", builder, PartPose.offset(5F, 2F, 0F));
        }
        // left_arm 骨
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 42F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.SOUTH, 46F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.WEST, 40F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.EAST, 44F, 18F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.UP, 42F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            face(builder, Direction.DOWN, 44F, 16F, -1F, 0F, -1F, 2F, 12F, 2F);
            parent.addOrReplaceChild("left_arm", builder, PartPose.offset(-5F, 2F, 0F));
        }
        // staff 骨（施法时抬杖）→ group2 骨（杖头，主贴图；X-25° 烘进 PartPose，动画只转 yRot）
        PartDefinition staff = parent.addOrReplaceChild("staff", CubeListBuilder.create(), PartPose.offset(-5F, 24F, -8F));
        {
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 40F, 8F, -1F, -1F, -1F, 2F, 2F, 2F);
            face(builder, Direction.SOUTH, 56F, 8F, -1F, -1F, -1F, 2F, 2F, 2F);
            face(builder, Direction.WEST, 32F, 8F, -1F, -1F, -1F, 2F, 2F, 2F);
            face(builder, Direction.EAST, 48F, 8F, -1F, -1F, -1F, 2F, 2F, 2F);
            face(builder, Direction.UP, 40F, 0F, -1F, -1F, -1F, 2F, 2F, 2F);
            face(builder, Direction.DOWN, 48F, 0F, -1F, -1F, -1F, 2F, 2F, 2F);
            staff.addOrReplaceChild("group2", builder, PartPose.offsetAndRotation(0F, -34F, 0F, -25F, 0F, 0F));
        }
        return LayerDefinition.create(mesh, 64, 32);
    }

    private static void face(CubeListBuilder builder, Direction dir, float u, float v,
                             float x, float y, float z, float w, float h, float d) {
        HeadDominatorPose.face(builder, dir, u, v, x, y, z, w, h, d);
    }
}
