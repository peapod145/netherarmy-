package cn.blockforge.generated.netherarmy;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.structures.NetherFortressStructure;

/**
 * netherarmy:fortress 的原版下界要塞实现，带有轻量的结构集抽签预判。
 *
 * <p>1.21.1 的 /locate structure 会在服务端主线程上检查候选区块。原版要塞的
 * findGenerationPoint 无条件返回候选点，因此在 nether_complexes 抽中 bastion
 * 或下界戍城的候选区块上也会触发同步区块生成。这里复刻 createStructures 的加权
 * 抽签（见 {@link StructureSetSelection}），让未抽中本要塞的候选区块直接返回空。</p>
 *
 * <p>抽签之外还有两件事只在 {@code /locate} 这类存在性查询路径上生效（见
 * {@link StructureLocateGuard}）：一是查询里不做"抽中的结构判空就剔除重抽"的昂贵委托，
 * 二是本批扫描的判定预算用完后直接判空。要塞在 nether_complexes 里只占 6/17，
 * 附近没有要塞时原版会把半径内的四万多个候选全部验一遍，主线程表现为"指令一敲卡住"，
 * 预算是这条路径的兜底。真正的区块生成不走查询路径，判定照旧。</p>
 */
public class NetherArmyFortressStructure extends NetherFortressStructure {
    public static final MapCodec<NetherArmyFortressStructure> CODEC =
            simpleCodec(NetherArmyFortressStructure::new);

    public NetherArmyFortressStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        boolean query = StructureLocateGuard.inPresenceCheck();
        if (query && !StructureLocateGuard.tryBeginWork()) {
            // /locate 这批扫描的判定预算已经用完：立刻判空，原版也不会再为它同步生成区块
            return Optional.empty();
        }
        if (!StructureSetSelection.isSelectedForThisChunk(context, this, query)) {
            return Optional.empty();
        }
        return super.findGenerationPoint(context);
    }

    @Override
    public StructureType<?> type() {
        return GeneratedMod.NETHER_ARMY_FORTRESS_TYPE.get();
    }
}
