package cn.blockforge.generated.netherarmy;

import com.mojang.serialization.MapCodec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.LegacyRandomSource;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.level.levelgen.structure.structures.NetherFortressStructure;

/**
 * netherarmy:fortress 的原版下界要塞实现，带有轻量的结构集抽签预判。
 *
 * <p>1.21.1 的 /locate structure 会在服务端主线程上检查候选区块。原版要塞的
 * findGenerationPoint 无条件返回候选点，因此在 nether_complexes 抽中 bastion 的
 * 候选区块上也会触发同步区块生成。这里复刻 createStructures 的加权抽签，让未抽中
 * 本要塞的候选区块直接返回空，避免 locate 为了验证错误候选点而批量生成区块。</p>
 */
public class NetherArmyFortressStructure extends NetherFortressStructure {
    public static final MapCodec<NetherArmyFortressStructure> CODEC =
            simpleCodec(NetherArmyFortressStructure::new);

    public NetherArmyFortressStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        if (!isSelectedForThisChunk(context)) {
            return Optional.empty();
        }
        return super.findGenerationPoint(context);
    }

    @Override
    public StructureType<?> type() {
        return GeneratedMod.NETHER_ARMY_FORTRESS_TYPE.get();
    }

    private boolean isSelectedForThisChunk(Structure.GenerationContext context) {
        Registry<StructureSet> structureSets =
                context.registryAccess().registryOrThrow(Registries.STRUCTURE_SET);
        StructureSet owningSet = null;
        int owningSetCount = 0;

        for (Holder<StructureSet> holder : structureSets.holders().toList()) {
            StructureSet set = holder.value();
            for (StructureSet.StructureSelectionEntry entry : set.structures()) {
                if (entry.structure().value() == this) {
                    owningSet = set;
                    owningSetCount++;
                    break;
                }
            }
        }

        // 没有唯一的 random_spread 所属集时，不改变原版行为。
        if (owningSetCount != 1 || !(owningSet.placement() instanceof RandomSpreadStructurePlacement)) {
            return true;
        }

        List<StructureSet.StructureSelectionEntry> entries = new ArrayList<>(owningSet.structures());
        if (entries.size() == 1) {
            return true;
        }

        int totalWeight = 0;
        for (StructureSet.StructureSelectionEntry entry : entries) {
            totalWeight += entry.weight();
        }

        WorldgenRandom random = new WorldgenRandom(new LegacyRandomSource(0L));
        ChunkPos chunkPos = context.chunkPos();
        random.setLargeFeatureSeed(context.seed(), chunkPos.x, chunkPos.z);

        while (!entries.isEmpty()) {
            int roll = random.nextInt(totalWeight);
            int selectedIndex = 0;
            for (int i = 0; i < entries.size(); i++) {
                roll -= entries.get(i).weight();
                if (roll < 0) {
                    selectedIndex = i;
                    break;
                }
            }

            StructureSet.StructureSelectionEntry selected = entries.get(selectedIndex);
            if (selected.structure().value() == this) {
                return true;
            }

            // 原版抽中的结构能够生成时就结束本区块的抽签；只有无效结构才会被剔除重抽。
            if (selected.structure().value().findValidGenerationPoint(context).isPresent()) {
                return false;
            }
            totalWeight -= selected.weight();
            entries.remove(selectedIndex);
        }
        return false;
    }
}
