package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;

import java.util.List;

/** 亡魂重盾：高耐久盾牌，格挡时由事件处理器施加凋零。 */
public final class SoulShieldItem extends ShieldItem {
    public SoulShieldItem(Item.Properties properties) {
        super(properties);
    }

    /**
     * 原版盾牌继承 {@link Item#getEnchantmentValue()} 的默认实现（0），所以附魔台算出的
     * 附魔成本恒为 0、三个槽位全部不可用。这里给出非 0 的附魔能力，亡魂重盾才能进附魔台。
     */
    @Override
    public int getEnchantmentValue() {
        return 1;
    }

    /**
     * 掉落物免疫爆炸：{@code ItemEntity#hurt} 在真正扣血前会问
     * {@code ItemStack#canBeHurtBy}，这里把 {@code IS_EXPLOSION} 挡掉（与下界之星同款待遇）。
     * 火烧免疫由注册处的 {@code fireResistant} 组件负责。
     */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                net.minecraft.world.item.TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.soul_shield.tooltip.wither")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.netherarmy.soul_shield.tooltip.speed")
                .withStyle(ChatFormatting.GRAY));
    }
}
