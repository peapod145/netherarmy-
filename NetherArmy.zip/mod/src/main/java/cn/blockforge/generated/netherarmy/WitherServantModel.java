package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.EnumSet;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;

/**
 * 凋灵仆役模型：几何与逐面 UV 按用户上传的 wither_servant.bbmodel 精确复刻
 * （64×32 幼年凋灵骷髅式贴图布局，头 8³、躯干 8×10×4、四肢 2×9×2）。
 *
 * <p>与原版凋灵骷髅不同，本模型按 bbmodel 原尺寸 1:1 烘焙（25px 总高），
 * 渲染器不做 1.2 倍放大；部件枢轴取小体型自己的位置（头/躯干 6、臂 7、
 * 腿 15，脚底在模型 y=24）。<b>注意</b>：{@code HumanoidModel#setupAnim} 每帧
 * 收尾都会把各枢轴写回"标准成年人体型"（头/躯干 0、臂 2、腿 12），仆役是
 * 偏小体型的生物，直接沿用就会出现整体悬浮、躯干与腿部脱节——本类在
 * {@link #setupAnim} 末尾把枢轴还原回自己的小体型网格，而不是拿正常生物的
 * 体型来缩放本体。</p>
 *
 * <p>拉弓/举盾/持弩这些手臂姿势通道由 {@code HumanoidModel} 的私有
 * {@code poseRightArm}/{@code poseLeftArm} 按 {@code ArmPose} 字段驱动，但
 * {@code ArmPose} 只在 {@code PlayerRenderer} 里被赋值，怪物侧永远是 EMPTY；
 * 且 {@code usedItemHand/useItem} 并不同步到客户端，姿势判定只能走
 * {@link #prepareMobModel} 里的"同步装备槽 + 实体位"路径（角度通道与体型
 * 无关，小身架可安全复用），{@link #translateToHand} 再按 2px 细臂、9px 臂长
 * 修正持物锚点。</p>
 *
 * <p>bbmodel 里躯干顶/底面与左右臂、左右腿的 UV 矩形互换了位置或做了镜像
 * （经典皮肤共用四肢贴图行的写法），单一 texOffs 摆不出来，逐面换算偏移，
 * 与 {@link WitherZombieModel#faces} 同一套解法；2px 宽的四肢镜像差异仅
 * 体现为左右 1 列像素互换，观感与 Blockbench 预览一致。</p>
 */
public class WitherServantModel extends HumanoidModel<WitherServant> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_servant"), "main");
    public static final ModelLayerLocation INNER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_servant"), "inner_armor");
    public static final ModelLayerLocation OUTER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_servant"), "outer_armor");

    public WitherServantModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
    }

    @Override
    public void prepareMobModel(WitherServant entity, float limbSwing, float limbSwingAmount,
                                float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        // ArmPose 只有 PlayerRenderer 会替玩家填，怪物侧全靠自己：不填的话
        // setupAnim 里 poseRightArm/poseLeftArm 永远走 EMPTY 分支，
        // 举盾格挡、拉弓、弩装填/持满这些原版姿势一个都不会出现。
        // 又因为 usedItemHand/useItem 字段不同步到客户端（只有 isUsingItem 一个
        // 标志位同步），姿势全部从同步的装备槽 + 实体自布的举盾位推断。
        this.rightArmPose = ArmPose.EMPTY;
        this.leftArmPose = ArmPose.EMPTY;
        HumanoidArm mainArm = entity.getMainArm();
        ArmPose mainPose = mainHandPose(entity);
        if (mainPose != ArmPose.EMPTY) {
            if (mainArm == HumanoidArm.RIGHT) {
                this.rightArmPose = mainPose;
            } else {
                this.leftArmPose = mainPose;
            }
        }
        if (entity.isBlockingShield()) {
            // 举盾位与主手远程姿势可以共存：HumanoidModel 两臂各走各的姿势链。
            if (mainArm == HumanoidArm.RIGHT) {
                this.leftArmPose = ArmPose.BLOCK;
            } else {
                this.rightArmPose = ArmPose.BLOCK;
            }
        }
    }

    /**
     * 主手远程姿势：拉弓/上弩阶段看 isUsingItem 标志位（具体在用什么从同步的
     * 主手装备栈判断——useItem 字段客户端读不到）；待机姿势走骷髅同款常举弓、
     * 掠夺者同款持满弩通道。
     */
    private static ArmPose mainHandPose(WitherServant entity) {
        ItemStack main = entity.getMainHandItem();
        if (entity.isUsingItem()) {
            UseAnim anim = main.getUseAnimation();
            if (anim == UseAnim.BOW) {
                return ArmPose.BOW_AND_ARROW;
            }
            if (anim == UseAnim.CROSSBOW) {
                // 已上弦没放出去 = 持满待机；还在上弦过程 = CROSSBOW_CHARGE。
                return CrossbowItem.isCharged(main) ? ArmPose.CROSSBOW_HOLD : ArmPose.CROSSBOW_CHARGE;
            }
        }
        if (entity.isChargingCrossbow() && main.is(Items.CROSSBOW)) {
            return ArmPose.CROSSBOW_CHARGE;
        }
        if (main.is(Items.CROSSBOW) && CrossbowItem.isCharged(main)) {
            return ArmPose.CROSSBOW_HOLD;
        }
        if (main.is(Items.TRIDENT) && entity.isAggressive()) {
            // 与 DrownedModel#prepareMobModel 同款：持三叉戟且进入敌对状态就举臂。
            return ArmPose.THROW_SPEAR;
        }
        if (entity.isHoldingBowForShooting()) {
            return ArmPose.BOW_AND_ARROW;
        }
        return ArmPose.EMPTY;
    }

    @Override
    public void setupAnim(WitherServant entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // 原版 setupAnim 每次都会把部件枢轴钉回"正常体型"的成年Steve网格
        // （head.y=0/body.y=0/arm.y=2/leg.y=12，见 HumanoidModel 非潜行分支）。
        // 仆役是按 bbmodel 原尺寸 1:1 烘焙的 25px 小体型（脚底 y=24、腿枢轴 y=15），
        // 直接继承会把腿钉到 12——离地 3px 悬浮、腿顶与 8..18 的躯干脱节 6px。
        // 姿势通道本身只写旋转量，改回枢轴不影响上面的拉弓/举盾/挥臂。
        restoreSmallBodyPivots();
        // 原版 setupAnim 内部就把 hat 抄成（被踩过的）head，按归位后的 head 重抄一次。
        this.hat.copyFrom(this.head);
    }

    /** 把部件枢轴改回本模型烘焙值；render 里 poseRightArm 之后也会重跑一次保证落点。 */
    private void restoreSmallBodyPivots() {
        this.head.y = 6.0F;
        this.body.y = 6.0F;
        this.rightArm.y = 7.0F;
        this.leftArm.y = 7.0F;
        this.rightLeg.y = 15.0F;
        this.leftLeg.y = 15.0F;
        this.rightArm.x = -5.0F;
        this.leftArm.x = 5.0F;
        this.rightLeg.x = -1.75F;
        this.leftLeg.x = 1.75F;
        this.rightLeg.z = 0.0F;
        this.leftLeg.z = 0.0F;
    }

    /**
     * 持物锚点：{@code ItemInHandLayer} 在 {@code translateToHand} 之后还会串一个
     * Rx(-90)·Ry(180)，再沿当时局部 X 外推 1/16——合成回模型空间对左右手都表现为
     * "往身体外侧顶 1px"。原版 {@code SkeletonModel#translateToHand} 先做 ±1px 内收
     * 正好把它抵消：凋灵骷髅臂枢轴 -5、方块 -6..-4，抵消后落回 -5 = 方块正中。
     *
     * <p>仆役的手臂方块按 bbmodel 烘焙成 <b>枢轴内侧</b>（右臂 -5..-3、左臂 3..5），
     * 沿用 ±1px 就抵消不完：锚点收到 -4，再被外推 1px 回到 -5，正好压在手臂
     * <b>外缘</b>上，武器因此看着从手臂外侧探出来（就是"手持物品偏外"）。
     * 改成 ±2px：锚点先到方块内缘 -3，外推 1px 后回到 -4 = 方块中心，
     * 与凋灵骷髅的相对位置一致。</p>
     *
     * <p>再沿臂轴校准：{@code ItemInHandLayer} 的持物平移在臂轴上固定带 +0.625 格
     * （= 10px）分量，物品原点因此落在臂轴 10px 处；标准臂长 12px 时那里贴着拳端，
     * 仆役臂长只有 9px。先前按 -3px 上移把原点收到 7px——缩进臂内 2px，就是用户
     * 反馈的"手持物品太靠里"。现改为 -1px，把原点压回臂轴 9px 的拳端，
     * 与凋灵骷髅「物品长在拳头上」的相对位置一致。</p>
     */
    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        ModelPart armpart = getArm(arm);
        float f = arm == HumanoidArm.RIGHT ? 2.0F : -2.0F;
        armpart.x += f;
        armpart.translateAndRotate(poseStack);
        armpart.x -= f;
        // 此时姿态系已随臂旋转，+Y 沿臂向下（指向拳头），取 -1/16 对准臂轴 9px 的拳端。
        poseStack.translate(0.0F, -1.0F / 16.0F, 0.0F);
    }

    @Override
    public void copyPropertiesTo(HumanoidModel<WitherServant> other) {
        super.copyPropertiesTo(other);
        // HumanoidArmorLayer 每帧只走 copyPropertiesTo、从不重跑甲层模型的 setupAnim：
        // copyFrom 已带上改好的枢轴，但保险起见把甲层模型的枢轴也钉回小体型值，
        // 避免其它调用方（自定义盔甲钩子等）在 copy 之后又触发一次 super.setupAnim。
        if (other instanceof WitherServantModel servantModel) {
            servantModel.restoreSmallBodyPivots();
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // 头：bbmodel head（世界 y 17..25），枢轴在颈线（模型 y=6）。
        root.addOrReplaceChild("head", faces(-4.0F, -7.0F, -4.0F, 8.0F, 8.0F, 8.0F,
                        8, 8, 24, 8, 0, 8, 16, 8, 8, 0, 16, 0),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        // hat：HumanoidModel 构造器无条件取用该部件，贴图没有第二层头部几何，注册空部件。
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);

        // 躯干：bbmodel body（世界 y 8..18）。顶/底面矩形与原版网格互换，逐面摆位。
        root.addOrReplaceChild("body", faces(-4.0F, 0.0F, -2.0F, 8.0F, 10.0F, 4.0F,
                        20, 21, 32, 21, 16, 21, 28, 21, 20, 17, 28, 17),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        // 模型右臂（世界 -x 侧）：bbmodel left_arm（x -5..-3，共用右臂贴图行）。
        root.addOrReplaceChild("right_arm", faces(0.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F,
                        42, 21, 46, 21, 44, 21, 40, 21, 42, 19, 44, 19),
                PartPose.offset(-5.0F, 7.0F, 0.0F));

        // 模型左臂（世界 +x 侧）：bbmodel right_arm（x 3..5）。
        root.addOrReplaceChild("left_arm", faces(-2.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F,
                        42, 21, 46, 21, 40, 21, 44, 21, 42, 19, 44, 19),
                PartPose.offset(5.0F, 7.0F, 0.0F));

        // 模型右腿（世界 -x 侧）：bbmodel left_leg（x -2.75..-0.75，共用右腿贴图行）。
        root.addOrReplaceChild("right_leg", faces(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F,
                        2, 20, 6, 20, 4, 20, 0, 20, 2, 18, 4, 18),
                PartPose.offset(-1.75F, 15.0F, 0.0F));

        // 模型左腿（世界 +x 侧）：bbmodel right_leg（x 0.75..2.75）。
        root.addOrReplaceChild("left_leg", faces(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F,
                        2, 20, 6, 20, 0, 20, 4, 20, 2, 18, 4, 18),
                PartPose.offset(1.75F, 15.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 32);
    }

    /** 内甲层：与本体同枢轴、同尺寸，略膨胀以贴合拾来的护腿。 */
    public static LayerDefinition createInnerArmorLayer() {
        return createArmorLayer(new CubeDeformation(0.4F));
    }

    /** 外甲层：头盔/胸甲/靴子，膨胀略大于内甲。 */
    public static LayerDefinition createOuterArmorLayer() {
        return createArmorLayer(new CubeDeformation(0.8F));
    }

    /**
     * 穿戴护甲走原版 64×32 人形甲 UV（不是仆役本体贴图），所以用标准 texOffs
     * 即可；部件枢轴必须与本体一致，否则盔甲会漂在半空。
     */
    private static LayerDefinition createArmorLayer(CubeDeformation deform) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 8.0F, 8.0F, deform),
                PartPose.offset(0.0F, 6.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 10.0F, 4.0F, deform),
                PartPose.offset(0.0F, 6.0F, 0.0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                        .texOffs(40, 16).addBox(0.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F, deform),
                PartPose.offset(-5.0F, 7.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create()
                        .texOffs(40, 16).mirror().addBox(-2.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F, deform),
                PartPose.offset(5.0F, 7.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F, deform),
                PartPose.offset(-1.75F, 15.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                        .texOffs(0, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F, deform),
                PartPose.offset(1.75F, 15.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    /**
     * 把一个立方体的六个面分别摆到贴图上的指定矩形（与 {@link WitherZombieModel} 同款解法）。
     *
     * <p>注意原版 Cube 的面标签与视觉方向相反：模型空间 Y 轴向下，挂 {@code Direction.DOWN}
     * 标签的面（矩形 (U+d,V)）才是视觉顶面，{@code Direction.UP}（矩形 (U+d+w,V)）是视觉
     * 底面——原版 Steve 的头盖骨矩形 (8,0) 就挂在 DOWN 标签下。因此 bbmodel 的顶面要喂给
     * DOWN、底面喂给 UP；接反的表现是头顶/肩顶露出底面的透明区，即"模型和贴图错位"。</p>
     *
     * @param x,y,z     立方体最小角（部件局部坐标）
     * @param w,h,d     立方体尺寸
     * @param nU,nV     北面矩形左上角；sU,sV 南面；eU,eV 东面；wU,wV 西面；
     *                  uU,uV 顶面；dU,dV 底面（矩形宽高由立方体尺寸决定）
     */
    private static CubeListBuilder faces(float x, float y, float z, float w, float h, float d,
                                         int nU, int nV, int sU, int sV,
                                         int eU, int eV, int wU, int wV,
                                         int uU, int uV, int dU, int dV) {
        int di = (int) d;
        int wi = (int) w;
        CubeListBuilder builder = CubeListBuilder.create();
        face(builder, Direction.NORTH, nU - di, nV - di, x, y, z, w, h, d);
        face(builder, Direction.SOUTH, sU - 2 * di - wi, sV - di, x, y, z, w, h, d);
        face(builder, Direction.WEST, wU, wV - di, x, y, z, w, h, d);
        face(builder, Direction.EAST, eU - di - wi, eV - di, x, y, z, w, h, d);
        face(builder, Direction.DOWN, uU - di, uV, x, y, z, w, h, d);
        face(builder, Direction.UP, dU - di - wi, dV, x, y, z, w, h, d);
        return builder;
    }

    private static void face(CubeListBuilder builder, Direction dir, int texU, int texV,
                             float x, float y, float z, float w, float h, float d) {
        builder.texOffs(texU, texV).addBox(x, y, z, w, h, d, EnumSet.of(dir));
    }
}
