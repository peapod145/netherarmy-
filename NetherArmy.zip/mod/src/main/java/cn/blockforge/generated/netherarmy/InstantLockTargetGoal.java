package cn.blockforge.generated.netherarmy;

import java.util.function.Predicate;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;

/**
 * 即时锁定索敌目标组：修掉本模组生物"发愣一会才锁到敌"。
 *
 * <p>原版 {@link NearestAttackableTargetGoal#canUse()} 每 tick 只做一次
 * {@code randomInterval} 分之一概率的抽签（默认 1/10，刷怪密度高时更久），
 * 没抽中就整轮跳过扫描——这就是"明明看见敌人却要站一会儿才动手"的根源。
 * 本子类只覆写这一个方法：每 tick 直接 {@code findTarget()}，其余全部走
 * 原版通道（目标合法性、{@code mustSee}/{@code mustReach}、{@code start()}
 * 里的 {@code setTarget} 总闸），阵营门禁与创造/旁观保护不受影响。</p>
 *
 * <p>上一轮曾用 mixin 全局注入原版 {@code canUse} 实现同样效果，但那需要在生产
 * 环境按名字定位父类 {@code TargetGoal#mob} 影子字段，实机 NeoForge 报
 * {@code InvalidMixinException: @Shadow field mob was not located ... No refMap loaded}
 * 直接崩溃启动。子类方案仅替换本模组实体类 {@code registerGoals} 里挂的目标组，
 * 不触碰原版类，也没有映射兼容性问题。</p>
 *
 * <p>构造参数与原版四个公开构造一一对应，替换接入点时行为口径完全一致。</p>
 */
public class InstantLockTargetGoal<T extends LivingEntity> extends NearestAttackableTargetGoal<T> {

    public InstantLockTargetGoal(Mob mob, Class<T> targetType, boolean mustSee) {
        super(mob, targetType, mustSee);
    }

    public InstantLockTargetGoal(Mob mob, Class<T> targetType, boolean mustSee, boolean useInvertedCalculation) {
        super(mob, targetType, mustSee, useInvertedCalculation);
    }

    public InstantLockTargetGoal(Mob mob, Class<T> targetType, boolean mustSee, Predicate<LivingEntity> extraPredicate) {
        super(mob, targetType, mustSee, extraPredicate);
    }

    public InstantLockTargetGoal(Mob mob, Class<T> targetType, int randomInterval, boolean mustSee,
                                 boolean mustReach, Predicate<LivingEntity> extraPredicate) {
        super(mob, targetType, randomInterval, mustSee, mustReach, extraPredicate);
    }

    @Override
    public boolean canUse() {
        this.findTarget();
        return this.target != null;
    }
}
