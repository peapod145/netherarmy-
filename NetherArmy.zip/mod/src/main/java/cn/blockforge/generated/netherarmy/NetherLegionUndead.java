package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

/**
 * 地狱军团亡灵名册——本模组独占的"这是亡灵"判定，与原版 {@code #minecraft:undead} 平行存在。
 *
 * <h3>为什么要另立一份</h3>
 * <p>以前军团成员的亡灵属性是靠往公开标签里塞 {@code #minecraft:wither_skeletons} 实现的：
 * {@code undead}、{@code inverted_healing_and_harm}、{@code ignores_poison_and_regen}、
 * {@code sensitive_to_smite}、{@code wither_friends} 五份 {@code data/minecraft/tags/entity_type}
 * 文件都嵌套着那份公告牌。{@code replace:false} 的合并语义意味着任何人都能往里追加，于是
 * 第三方模组把自己的凋灵骷髅系生物写进来之后，"军团亡灵"这套判定就顺带把别人的怪也算了进去——
 * 既污染了阵营名册（见 {@link WitherFactionRoster}），也让军团的亡灵机制口径不受我们控制。</p>
 *
 * <p>现在改成与阵营名册同一套私有设计：只属于本模组的
 * {@code #netherarmy:nether_legion_undead}（{@code replace:true}，别人写不进）是唯一的军团亡灵
 * 口径，原版那五份标签文件只保留一条"把这份名册并进来看"的引用。原版凋灵骷髅与原版凋灵
 * <b>不在</b>这份名册里：它们是原版的怪，不是地狱军团编制单位，而它们本该有的亡灵属性由原版自己的
 * 数据包提供（{@code undead = #skeletons + #zombies + minecraft:wither + minecraft:phantom}，
 * 凋灵骷髅在 {@code #minecraft:skeletons} 里、凋灵是直列成员），所以摘掉我们的引用不会让它们掉出
 * 亡灵之列，也不会产生任何"标签里查无此类型"的加载错误。</p>
 *
 * <h3>"效果一致"怎么保证</h3>
 * <p>名册里的每一项都仍然进 {@code #minecraft:undead}，而原版的
 * {@code inverted_healing_and_harm}（治疗药水造成伤害、伤害药水反过来治疗）、
 * {@code ignores_poison_and_regen}（免疫中毒与再生）、{@code sensitive_to_smite}（惩戒附魔增伤）、
 * {@code wither_friends}（凋灵不以其为目标）、{@code can_breathe_under_water}（亡灵不需要呼吸）
 * 全部嵌套 {@code #minecraft:undead}，所以这套名册享受的机制与原版亡灵完全一致；那四条机制标签
 * 我们同时直连名册，万一别的数据包改了 {@code undead} 的嵌套，军团成员的亡灵性质也不会掉。
 * 除此之外，{@code WitherFactionWitherImmunityMixin} 那条"免疫凋零效果"走的是阵营名册，
 * 与这里无关。</p>
 *
 * <h3>"另一种独立判定"用在哪里</h3>
 * <p>本模组自己的代码不再依赖原版 {@code #minecraft:undead} 认亡灵：需要"一切亡灵"的口径
 * （圣光炸弹、超度附魔）走 {@link #isUndeadType}，即"原版 undead 或军团名册"两者取并；
 * 需要"只认自家亡灵"的口径走 {@link #isLegionUndeadType}。阵营判定则反过来把这份名册并进来
 * （见 {@link WitherFactionRoster#isMember}），新怪只登一处就同时拿到亡灵机制与阵营敌我。</p>
 */
public final class NetherLegionUndead {

    /** 私有军团亡灵标签：只有本模组能写入，第三方追加不影响军团的亡灵口径。 */
    public static final TagKey<EntityType<?>> UNDEAD = TagKey.create(
            Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_legion_undead"));

    private NetherLegionUndead() {
    }

    /**
     * 该类型是否属于地狱军团亡灵名册。
     *
     * <p>头颅两条 {@code instanceof} 之外的类型判断是兜底：无头骑士的头颅由躯体死亡时
     * 现场 {@code spawn}，一旦被外部数据包从标签里摘掉，军团就会认不出自家头颅（心控豁免、
     * 凋灵之首穿人、装备整理全链条失效），所以这两条按类型钉死。</p>
     */
    public static boolean isLegionUndeadType(EntityType<?> type) {
        if (type == null) {
            return false;
        }
        return type.is(UNDEAD)
                || type == GeneratedMod.DULLAHAN_HEAD.get()
                || type == GeneratedMod.BLITZ_DULLAHAN_HEAD.get();
    }

    /** 该实体是否属于地狱军团亡灵名册。 */
    public static boolean isLegionUndead(Entity entity) {
        return entity != null && isLegionUndeadType(entity.getType());
    }

    /**
     * 亡灵机制口径：原版 {@code #minecraft:undead} 与军团名册取并集。
     *
     * <p>给"该不该按亡灵对待它"这类玩法判定用（圣光炸弹的额外伤害、超度附魔的加成、
     * 心控友军的亡灵免攻击）。并上原版标签是为了继续覆盖骷髅、僵尸、凋灵这些不是军团编制的
     * 亡灵；并上私有名册是为了即便别的数据包把我们的成员从 {@code undead} 里摘掉，
     * 自家武器与自家规则仍然把它们当亡灵。</p>
     */
    public static boolean isUndeadType(EntityType<?> type) {
        return type != null && (type.is(EntityTypeTags.UNDEAD) || isLegionUndeadType(type));
    }

    /** 实体版的 {@link #isUndeadType}。 */
    public static boolean isUndead(Entity entity) {
        return entity != null && isUndeadType(entity.getType());
    }
}
