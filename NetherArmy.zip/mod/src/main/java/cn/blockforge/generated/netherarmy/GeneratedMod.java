package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.JukeboxSong;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingConversionEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

@Mod(GeneratedMod.MOD_ID)
public final class GeneratedMod {
    /**
     * 启动横幅日志，用途是"自证加载进度"：卡在加载界面时，用户在
     * {@code logs/latest.log} 里搜 {@code netherarmy}——
     * 一条都没有＝jar 根本没被加载（装错目录/旧 jar 冲突）；
     * 有 constructed 没有 setup＝卡在本模组构造与原版启动之间；
     * 两条都有＝本模组加载完毕，卡顿与它无关。
     */
    public static final org.slf4j.Logger LOGGER =
            org.slf4j.LoggerFactory.getLogger("netherarmy");
    public static final String MOD_ID = "netherarmy";
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    // 状态效果与粒子注册块必须排在物品之前：坏苹果的 FOOD 组件效果引用
    // SPELL_CARD_RULES，静态初始化按文本顺序执行，放后面会构成非法前向引用。
    public static final DeferredRegister<MobEffect> MOB_EFFECTS =
            DeferredRegister.create(BuiltInRegistries.MOB_EFFECT, MOD_ID);
    public static final DeferredHolder<MobEffect, RebellionMobEffect> REBELLION =
            MOB_EFFECTS.register("rebellion", RebellionMobEffect::new);
    public static final DeferredHolder<MobEffect, MesmerizedMobEffect> MESMERIZED =
            MOB_EFFECTS.register("mesmerized", MesmerizedMobEffect::new);
    /** 符卡规则：持有者只吃抛射物伤害、也只能以抛射物伤人（见 {@link SpellCardRulesHandler}）。 */
    public static final DeferredHolder<MobEffect, SpellCardRulesMobEffect> SPELL_CARD_RULES =
            MOB_EFFECTS.register("spell_card_rules", SpellCardRulesMobEffect::new);
    /** 重力反转：反转士施加，实体上下颠倒、重力反向（见 {@link GravityReversalMobEffect}）。 */
    public static final DeferredHolder<MobEffect, GravityReversalMobEffect> GRAVITY_REVERSAL =
            MOB_EFFECTS.register("gravity_reversal", GravityReversalMobEffect::new);

    public static final DeferredRegister<net.minecraft.core.particles.ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, MOD_ID);
    /** 符卡规则的黑白交替粒子（客户端提供者见 GeneratedModClient）。 */
    public static final DeferredHolder<net.minecraft.core.particles.ParticleType<?>,
            net.minecraft.core.particles.SimpleParticleType> SPELL_CARD_RULES_PARTICLE =
            PARTICLE_TYPES.register("spell_card_rules",
                    () -> new net.minecraft.core.particles.SimpleParticleType(false));
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
            DeferredRegister.create(Registries.STRUCTURE_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENU_TYPES =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    /**
     * 灵魂火状态改走 NeoForge 实体附件，不再向 {@code Entity#defineSynchedData} 注入。
     * 1.21.1 中该方法是抽象方法、没有方法体，Mixin 的 {@code @At("TAIL")} 找不到 RETURN，
     * 启动阶段（应用 mixin 时）就会崩溃；实体附件由 NeoForge 管理，并用 StreamCodec
     * 自动同步给客户端，无需向原版类分配新的同步数据 ID。
     */
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MOD_ID);
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<Boolean>> SOUL_FLAME =
            ATTACHMENT_TYPES.register("soul_flame",
                    () -> AttachmentType.builder(() -> false)
                            .sync(ByteBufCodecs.BOOL)
                            .build());
    /**
     * "该实体此刻是否处于重力反转中"的客户端可见副本，写入与读取统一走
     * {@link GravityReversalState}。
     *
     * <p>为什么不能直接在客户端读效果：1.21.1 的服务端<b>不向客户端同步非玩家生物的状态效果</b>。
     * {@code ServerEntity.sendDirtyEntityData()} 里只剩实体数据与属性两件事，全库里
     * {@code ClientboundUpdateMobEffectPacket} 的发送点只有玩家自己（{@code ServerPlayer}）、
     * 玩家正骑乘的生物（{@code LivingEntity#sendEffectToPassengers}）和进服补发
     * （{@code PlayerList#sendActiveEffects}）三处，普通生物的效果包根本没人发。于是客户端
     * {@code entity.hasEffect(...)} 对怪恒为 false——渲染半边因此永远判定"没被反转"，
     * 而服务端算出来的物理照常生效，表现就是"除了玩家，怪的模型都不颠倒"。</p>
     *
     * <p>附件由 NeoForge 自动同步，且玩家开始追踪该实体时会补发一次初始值
     * （{@code AttachmentSync.syncInitialEntityAttachments}），所以中途才走近的玩家也能看到
     * 正确的翻转状态。</p>
     */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<Boolean>> GRAVITY_REVERSED =
            ATTACHMENT_TYPES.register("gravity_reversed",
                    () -> AttachmentType.builder(() -> false)
                            .sync(ByteBufCodecs.BOOL)
                            .build());

    /** 自有铁砧菜单类型：右键铁砧时统一由它打开，用于放行"0 经验"修复产物的拿取。 */
    public static final DeferredHolder<MenuType<?>, MenuType<SoulShieldAnvilMenu>> SOUL_SHIELD_ANVIL_MENU =
            MENU_TYPES.register("soul_shield_anvil",
                    () -> new MenuType<>(SoulShieldAnvilMenu::new, FeatureFlags.VANILLA_SET));

    public static final DeferredHolder<StructureType<?>, StructureType<NetherSurfaceJigsawStructure>>
            NETHER_SURFACE_JIGSAW_TYPE = STRUCTURE_TYPES.register(
                    "nether_surface_jigsaw",
                    () -> () -> NetherSurfaceJigsawStructure.CODEC);
    public static final DeferredHolder<StructureType<?>, StructureType<NetherArmyFortressStructure>>
            NETHER_ARMY_FORTRESS_TYPE = STRUCTURE_TYPES.register(
                    "nether_army_fortress",
                    () -> () -> NetherArmyFortressStructure.CODEC);

    public static final ResourceKey<Enchantment> MAGIC_RESISTANCE = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "magic_resistance"));
    public static final ResourceKey<Enchantment> SOUL_PURIFICATION = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "soul_purification"));
    public static final ResourceKey<Enchantment> PROTECTOR = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "protector"));
    public static final ResourceKey<Enchantment> REMODEL = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "remodel"));
    public static final ResourceKey<Enchantment> THREE_DIMENSIONAL_DEFENSE = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "three_dimensional_defense"));
    public static final ResourceKey<Enchantment> BLUNT_BUFFER = ResourceKey.create(
            Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(MOD_ID, "blunt_buffer"));
    /**
     * 怨灵近战使用的虚空伤害类型：完全对齐原版 {@code minecraft:out_of_world}
     * （实体掉出世界时吃的那种伤害）。伤害本身的 scaling / exhaustion / effects
     * 与原版注册值逐项相同，标签成员由 {@code data/minecraft/tags/damage_type/} 下的
     * 附加（replace:false）标签文件补齐虚空伤害参与结算的全部四项：
     * bypasses_armor（无视护甲，并因此被 bypasses_shield 递归包含，盾牌挡不住）、
     * bypasses_invulnerability（不吃无敌帧，也不给不死图腾和创造模式免伤）、
     * bypasses_resistance（无视抗性提升）、no_knockback（不推开受击者）。
     * 唯一没套用的是 always_most_significant_fall，它只归并摔落类死亡文案，
     * 套上会顶掉怨灵自己的死亡提示。
     */
    public static final ResourceKey<net.minecraft.world.damagesource.DamageType> WITHER_GHOST_VOID =
            ResourceKey.create(Registries.DAMAGE_TYPE,
                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "void_touch"));

    public static final DeferredHolder<EntityType<?>, EntityType<Berserker>> BERSERKER =
            ENTITY_TYPES.register("berserker", () -> EntityType.Builder.of(Berserker::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.4F).fireImmune().ridingOffset(-0.875F).clientTrackingRange(8)
                    .build("berserker"));
    public static final DeferredHolder<EntityType<?>, EntityType<Bedserker>> BEDSERKER =
            ENTITY_TYPES.register("bedserker", () -> EntityType.Builder.of(Bedserker::new, MobCategory.MONSTER)
                    // 站姿箱；躺下后由 Bedserker#makeBoundingBox 换成贴合床形的外接盒。
                    .sized(Bedserker.STANDING_DIMENSIONS.width(), Bedserker.STANDING_DIMENSIONS.height())
                    .fireImmune().ridingOffset(-0.875F).clientTrackingRange(10)
                    .build("bedserker"));
    public static final DeferredHolder<EntityType<?>, EntityType<NetherHunter>> NETHER_HUNTER =
            ENTITY_TYPES.register("nether_hunter", () -> EntityType.Builder.of(NetherHunter::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.4F).fireImmune().ridingOffset(-0.875F).clientTrackingRange(8)
                    .build("nether_hunter"));
    public static final DeferredHolder<EntityType<?>, EntityType<DullhanBody>> DULLHAN_BODY =
            ENTITY_TYPES.register("dullhan_body", () -> EntityType.Builder.of(DullhanBody::new, MobCategory.MONSTER)
                    // 只保留无头躯干的实际高度；头部由独立实体负责判定。
                    .sized(0.7F, 1.8F).fireImmune().ridingOffset(-0.875F).clientTrackingRange(8)
                    .build("dullhan_body"));
    public static final DeferredHolder<EntityType<?>, EntityType<DullhanHead>> DULLHAN_HEAD =
            ENTITY_TYPES.register("dullhan_head", () -> EntityType.Builder.of(DullhanHead::new, MobCategory.MONSTER)
                    // 8 像素头颅经渲染器 1.2 倍放大后为 0.6 格，判定箱与模型保持一致。
                    .sized(0.6F, 0.6F).eyeHeight(0.3F).fireImmune().ridingOffset(0.3F).clientTrackingRange(8)
                    .build("dullhan_head"));
    public static final DeferredHolder<EntityType<?>, EntityType<DullhanHorse>> DULLHAN_HORSE =
            ENTITY_TYPES.register("dullhan_horse", () -> EntityType.Builder.of(DullhanHorse::new, MobCategory.MONSTER)
                    // 渲染走原版骷髅马模型（UndeadHorseRenderer，不缩放），鞍高照抄
                    // SKELETON_HORSE 的 passengerAttachments(1.31875)。此前没注册，
                    // 乘客挂点回退到判定箱顶 1.6，无头躯体（髋锚 0.875，同凋灵骷髅）
                    // 比骑真骷髅马的下界猎手整只高 0.28，像浮在马背上方。
                    .sized(1.4F, 1.6F).fireImmune().passengerAttachments(1.31875F).clientTrackingRange(10)
                    .build("dullhan_horse"));
    // 无头强袭骑士三件套：判定与乘骑参数沿用无头骑士，行为差异全部在实体类里。
    public static final DeferredHolder<EntityType<?>, EntityType<BlitzDullhanBody>> BLITZ_DULLHAN_BODY =
            ENTITY_TYPES.register("blitz_dullhan_body",
                    () -> EntityType.Builder.<BlitzDullhanBody>of(BlitzDullhanBody::new, MobCategory.MONSTER)
                            .sized(0.7F, 1.8F).fireImmune().ridingOffset(-0.875F).clientTrackingRange(8)
                            .build("blitz_dullhan_body"));
    public static final DeferredHolder<EntityType<?>, EntityType<BlitzDullhanHead>> BLITZ_DULLHAN_HEAD =
            ENTITY_TYPES.register("blitz_dullhan_head",
                    () -> EntityType.Builder.<BlitzDullhanHead>of(BlitzDullhanHead::new, MobCategory.MONSTER)
                            .sized(0.6F, 0.6F).eyeHeight(0.3F).fireImmune().ridingOffset(0.3F).clientTrackingRange(8)
                            .build("blitz_dullhan_head"));
    public static final DeferredHolder<EntityType<?>, EntityType<BlitzDullhanHorse>> BLITZ_DULLHAN_HORSE =
            ENTITY_TYPES.register("blitz_dullhan_horse",
                    () -> EntityType.Builder.<BlitzDullhanHorse>of(BlitzDullhanHorse::new, MobCategory.MONSTER)
                            .sized(1.4F, 1.6F).fireImmune().passengerAttachments(1.31875F).clientTrackingRange(10)
                            .build("blitz_dullhan_horse"));
    public static final DeferredHolder<EntityType<?>, EntityType<Mesmerizer>> MESMERIZER =
            ENTITY_TYPES.register("mesmerizer", () -> EntityType.Builder.of(Mesmerizer::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.4F).fireImmune().ridingOffset(-0.875F).clientTrackingRange(8)
                    .build("mesmerizer"));
    public static final DeferredHolder<EntityType<?>, EntityType<MesmerizerOrb>> MESMERIZER_ORB =
            ENTITY_TYPES.register("mesmerizer_orb", () -> EntityType.Builder.<MesmerizerOrb>of(MesmerizerOrb::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(8).updateInterval(1)
                    .build("mesmerizer_orb"));
    public static final DeferredHolder<EntityType<?>, EntityType<Witherphantom>> WITHERPHANTOM =
            ENTITY_TYPES.register("witherphantom", () -> EntityType.Builder.<Witherphantom>of(Witherphantom::new, MobCategory.MONSTER)
                    // 幻翼 0.9×0.5 的 1.5 倍；免疫火焰（凋灵骷髅性质）。
                    .sized(1.35F, 0.75F).eyeHeight(0.2625F).fireImmune().clientTrackingRange(10)
                    .build("witherphantom"));
    public static final DeferredHolder<EntityType<?>, EntityType<ShadowApostle>> SHADOW_APOSTLE =
            ENTITY_TYPES.register("shadow_apostle", () -> EntityType.Builder.<ShadowApostle>of(
                            ShadowApostle::new, MobCategory.MONSTER)
                    .sized(0.8F, 1.8F).fireImmune().clientTrackingRange(10).updateInterval(1)
                    .build("shadow_apostle"));
    public static final DeferredHolder<EntityType<?>, EntityType<WitherZombie>> WITHER_ZOMBIE =
            ENTITY_TYPES.register("witherzombie", () -> EntityType.Builder.<WitherZombie>of(WitherZombie::new, MobCategory.MONSTER)
                    // 判定箱沿用僵尸（0.6×1.95），幼年尺寸由实体侧换算；免疫火焰。
                    // ridingOffset 取原版僵尸同款 -0.7：幼年尸鬼骑衰翼时挂点随 0.5 倍
                    // 尺寸换算成 0.35，坐骑判定箱顶内凹 0.35 格——与小僵尸骑鸡的下沉
                    // 姿态一致（此前未注册，挂点落在脚底，小尸鬼双脚"站"在衰翼头顶，
                    // 整只悬在坐骑上方）。
                    .sized(0.6F, 1.95F).fireImmune().ridingOffset(-0.7F).clientTrackingRange(8)
                    .build("witherzombie"));
    public static final DeferredHolder<EntityType<?>, EntityType<WitherServant>> WITHER_SERVANT =
            ENTITY_TYPES.register("wither_servant", () -> EntityType.Builder.<WitherServant>of(WitherServant::new, MobCategory.MONSTER)
                    // 25px 幼年体模型按 1:1 渲染（不做凋灵骷髅式 1.2 倍放大），
                    // 判定箱 0.6×1.55 贴住模型；免疫火焰（凋灵骷髅性质）。
                    // ridingOffset 取本模型烘焙的髋高：腿枢轴 y=15、脚底 y=24，胯离脚底
                    // 9px = 0.5625 格。调皮个体骑阵营生物时（被骑者未注册乘客挂点，挂点
                    // 默认落在判定箱顶），胯部落在头顶、两腿垂在脸前——与小僵尸骑鸡、
                    // 掠夺者骑劫掠兽同套"髋部锚点"约定。此前实体侧曾按「被骑者身高 −
                    // 自身眼高×0.35」覆写挂点，方向整个反了，被骑者越高把仆役压得越深。
                    .sized(0.6F, 1.55F).fireImmune().ridingOffset(-0.5625F).clientTrackingRange(10)
                    .build("wither_servant"));
    public static final DeferredHolder<EntityType<?>, EntityType<Suppressor>> SUPPRESSOR =
            ENTITY_TYPES.register("suppressor", () -> EntityType.Builder.<Suppressor>of(Suppressor::new, MobCategory.MONSTER)
                    // 与凋灵骷髅同款判定箱：32px 标准人形模型在渲染器里 scale(1.2)
                    // 撑到 2.4 格（同御首者/传令兵/黑客），眼高 2.1；免疫火焰（凋灵骷髅性质）。
                    .sized(0.6F, 2.4F).eyeHeight(2.1F).fireImmune().clientTrackingRange(10)
                    .build("suppressor"));
    public static final DeferredHolder<EntityType<?>, EntityType<ImmortalWarrior>> IMMORTAL_WARRIOR =
            ENTITY_TYPES.register("immortal_warrior", () -> EntityType.Builder.<ImmortalWarrior>of(
                            ImmortalWarrior::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.4F).fireImmune().clientTrackingRange(10)
                    .build("immortal_warrior"));
     public static final DeferredHolder<EntityType<?>, EntityType<ImmortalWarriorRemains>> IMMORTAL_WARRIOR_REMAINS =
             ENTITY_TYPES.register("immortal_warrior_remains", () -> EntityType.Builder.<ImmortalWarriorRemains>of(
                             ImmortalWarriorRemains::new, MobCategory.MONSTER)
                     // 残骸碰撞箱高度单独降为 0.75 格（宽度维持 0.6，正常不死武士仍是 2.4）。
                     .sized(0.6F, 0.75F).fireImmune().clientTrackingRange(10)
                     .build("immortal_warrior_remains"));
    public static final DeferredHolder<EntityType<?>, EntityType<NetherCourier>> NETHER_COURIER =
            ENTITY_TYPES.register("nether_courier", () -> EntityType.Builder.<NetherCourier>of(NetherCourier::new, MobCategory.MONSTER)
                    // 体型与凋灵骷髅完全一致（0.6×2.4）。原版凋灵骷髅的 32px 人形模型
                    // 本身只有 2.0 格高，靠渲染器 scale(1.2) 撑到 2.4 格；传令兵同款
                    // 处理（见 NetherCourierRenderer#scale），视觉身高与周围凋灵骷髅齐平。
                    .sized(0.6F, 2.4F).fireImmune().clientTrackingRange(10)
                    .build("nether_courier"));
    public static final DeferredHolder<EntityType<?>, EntityType<NetherCarrier>> NETHER_CARRIER =
            ENTITY_TYPES.register("nether_carrier", () -> EntityType.Builder.<NetherCarrier>of(NetherCarrier::new, MobCategory.MONSTER)
                    // 模型含车轮撞角长 9.94 格、宽 3.75 格、高 4.44 格，而 sized() 只收
                    // 一个正方形底面边长：取 3.7×4.4 贴住车身（再宽就挤不进 4 格宽的走廊）。
                    // 整车模型沿车头方向前移 2 格（NetherCarrierModel 的 frame 枢轴），判定箱
                    // 因此罩住车体后 3/4、车尾只探出约 1.1 格；探出约 5.1 格的车头交给
                    // NetherCarrier 的"鼻尖判定盒"结算撞击与破方块，而车头/车尾探出段的
                    // "可被攻击判定"由挂车载荷的 CarrierHitbox 隐形子盒补齐（见其类注释）。
                    .sized(3.7F, 4.4F).fireImmune().clientTrackingRange(12)
                    .build("nether_carrier"));
    public static final DeferredHolder<EntityType<?>, EntityType<CarrierHitbox>> NETHER_CARRIER_HITBOX =
            ENTITY_TYPES.register("carrier_hitbox", () -> EntityType.Builder.<CarrierHitbox>of(CarrierHitbox::new, MobCategory.MISC)
                    // 运兵车的车头/车尾补位判定盒：隐形乘客实体，只为"打得到车头"存在。
                    // sized() 只是类型级兜底——两种盒子的真实尺寸由实例按盒种现算
                    // （CarrierHitbox#makeBoundingBox），这里取车头盒的 3.6×3.2。
                    // MISC 类不进刷怪笼/自然生成；追踪范围与本尊一致（12）。
                    .sized(3.6F, 3.2F).fireImmune().noSummon().clientTrackingRange(12)
                    .build("carrier_hitbox"));
    public static final DeferredHolder<EntityType<?>, EntityType<HeadDominator>> HEAD_DOMINATOR =
            ENTITY_TYPES.register("head_dominator", () -> EntityType.Builder.<HeadDominator>of(HeadDominator::new, MobCategory.MONSTER)
                    // 判定箱与凋灵骷髅完全同款（0.72×2.4）：御首者模型同为 32px 人形网格，
                    // 渲染器套用 WitherSkeletonRenderer 的 1.2× 放大，视觉身高一致。
                    .sized(0.72F, 2.4F).fireImmune().clientTrackingRange(10)
                    .build("head_dominator"));
    /** 黑客是村庄中的中立生物，不占敌对生物刷怪上限。 */
    public static final DeferredHolder<EntityType<?>, EntityType<Hacker>> HACKER =
            ENTITY_TYPES.register("hacker", () -> EntityType.Builder.<Hacker>of(Hacker::new, MobCategory.CREATURE)
                    // 判定箱与凋灵骷髅完全同款（0.6×2.4）：黑客属凋灵骷髅类生物；
                    // 32px 人形网格在渲染器里套用凋灵骷髅渲染器的 1.2× 放大撑满 2.4 格，
                    // 与御首者/无头躯干的处理一致。
                    // fireImmune 是 Java 版凋灵骷髅火焰/岩浆免疫的真正来源：
                    // Entity#fireImmune() 读的是 EntityType 上的这个标记，与实体标签无关
                    // （undead/wither_skeletons 等标签只管属性交互，不免疫火焰）。
                    // 补上后：站进火里/掉进岩浆/被火球命中全部无效，与凋灵骷髅一致。
                    .sized(0.6F, 2.4F).fireImmune().clientTrackingRange(10).build("hacker"));
    /** 怨灵不使用 fireImmune 标记，才能保留被火焰攻击点燃的状态。 */
    public static final DeferredHolder<EntityType<?>, EntityType<WitherGhost>> WITHER_GHOST =
            ENTITY_TYPES.register("wither_ghost", () -> EntityType.Builder.<WitherGhost>of(
                            WitherGhost::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.0F).clientTrackingRange(10).build("wither_ghost"));
    public static final DeferredHolder<EntityType<?>, EntityType<OverlordWitherBoss>> OVERLORD_WITHER =
            ENTITY_TYPES.register("overlord_wither", () -> EntityType.Builder.<OverlordWitherBoss>of(
                            OverlordWitherBoss::new, MobCategory.MONSTER)
                    .sized(0.9F, 3.5F).noSummon().fireImmune().immuneTo(Blocks.WITHER_ROSE)
                    .clientTrackingRange(10).updateInterval(2).build("overlord_wither"));
    public static final DeferredHolder<EntityType<?>, EntityType<OverlordWitherSkull>> OVERLORD_WITHER_SKULL =
            ENTITY_TYPES.register("overlord_wither_skull", () -> EntityType.Builder.<OverlordWitherSkull>of(
                            OverlordWitherSkull::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F).fireImmune().clientTrackingRange(4)
                    .updateInterval(10).build("overlord_wither_skull"));
    public static final DeferredHolder<EntityType<?>, EntityType<WitherCharge>> WITHER_CHARGE =
            ENTITY_TYPES.register("wither_charge", () -> EntityType.Builder.<WitherCharge>of(
                            WitherCharge::new, MobCategory.MISC)
                    .sized(0.3125F, 0.3125F).clientTrackingRange(8).updateInterval(1)
                    .build("wither_charge"));
    public static final DeferredHolder<EntityType<?>, EntityType<HolyBomb>> HOLY_BOMB =
            ENTITY_TYPES.register("holy_bomb", () -> EntityType.Builder.<HolyBomb>of(
                            HolyBomb::new, MobCategory.MISC)
                    .sized(0.3125F, 0.3125F).clientTrackingRange(8).updateInterval(1)
                    .build("holy_bomb"));
    private static final EnumMap<ArmorItem.Type, Integer> BERSERKER_HELMET_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> MESMERIZER_CROWN_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> NETHER_CRYSTAL_HELMET_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> NETHER_CRYSTAL_CHESTPLATE_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> NETHER_CRYSTAL_LEGGINGS_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> NETHER_CRYSTAL_BOOTS_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    /** 炼狱晶锁链马铠：独立材料，护甲值只落在 BODY 槽（马匹躯干），共 30 点。 */
    private static final EnumMap<ArmorItem.Type, Integer> NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE =
            new EnumMap<>(ArmorItem.Type.class);
    static {
        BERSERKER_HELMET_DEFENSE.put(ArmorItem.Type.HELMET, 4);
        BERSERKER_HELMET_DEFENSE.put(ArmorItem.Type.CHESTPLATE, 0);
        BERSERKER_HELMET_DEFENSE.put(ArmorItem.Type.LEGGINGS, 0);
        BERSERKER_HELMET_DEFENSE.put(ArmorItem.Type.BOOTS, 0);
        BERSERKER_HELMET_DEFENSE.put(ArmorItem.Type.BODY, 0);
        MESMERIZER_CROWN_DEFENSE.put(ArmorItem.Type.HELMET, 4);
        MESMERIZER_CROWN_DEFENSE.put(ArmorItem.Type.CHESTPLATE, 0);
        MESMERIZER_CROWN_DEFENSE.put(ArmorItem.Type.LEGGINGS, 0);
        MESMERIZER_CROWN_DEFENSE.put(ArmorItem.Type.BOOTS, 0);
        MESMERIZER_CROWN_DEFENSE.put(ArmorItem.Type.BODY, 0);
        // 炼狱晶套：护甲 6/10/8/6，四件各用独立材料，韧性逐件不同、击退抗性只给头盔。
        NETHER_CRYSTAL_HELMET_DEFENSE.put(ArmorItem.Type.HELMET, 6);
        NETHER_CRYSTAL_CHESTPLATE_DEFENSE.put(ArmorItem.Type.CHESTPLATE, 10);
        NETHER_CRYSTAL_LEGGINGS_DEFENSE.put(ArmorItem.Type.LEGGINGS, 8);
        NETHER_CRYSTAL_BOOTS_DEFENSE.put(ArmorItem.Type.BOOTS, 6);
        // 马铠材料：30 点护甲全部落在 BODY 槽；人形槽位一律为 0。
        NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE.put(ArmorItem.Type.HELMET, 0);
        NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE.put(ArmorItem.Type.CHESTPLATE, 0);
        NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE.put(ArmorItem.Type.LEGGINGS, 0);
        NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE.put(ArmorItem.Type.BOOTS, 0);
        NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE.put(ArmorItem.Type.BODY, 30);
    }

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> BERSERKER_HELMET_MATERIAL =
            ARMOR_MATERIALS.register("berserker_helmet", () -> new ArmorMaterial(
                    BERSERKER_HELMET_DEFENSE,
                    15,
                    SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(Items.STONE),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "berserker_helmet"))),
                    2.0F,
                    0.0F));
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> MESMERIZER_CROWN_MATERIAL =
            ARMOR_MATERIALS.register("mesmerizer_crown", () -> new ArmorMaterial(
                    MESMERIZER_CROWN_DEFENSE,
                    15,
                    SoundEvents.ARMOR_EQUIP_GOLD,
                    () -> Ingredient.of(Items.GOLD_INGOT),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "mesmerizer_crown"))),
                    0.0F,
                    0.0F));

    public static final DeferredItem<Item> BERSERKER_HELMET = ITEMS.register(
            "berserker_helmet",
            () -> new BerserkerHelmetItem(BERSERKER_HELMET_MATERIAL,
                    new Item.Properties().stacksTo(1).durability(1000)));
    public static final DeferredItem<Item> MESMERIZER_CROWN = ITEMS.register(
            "mesmerizer_crown",
            () -> new MesmerizerCrownItem(MESMERIZER_CROWN_MATERIAL,
                    new Item.Properties().stacksTo(1).component(DataComponents.UNBREAKABLE, new Unbreakable(true))));

    // ------------------------------------------------------------------
    // 炼狱晶套（头盔/胸甲/护腿/靴子）
    //   护甲与韧性：6+6 / 10+10 / 8+8 / 6+6；耐久 5000 / 10000 / 7500 / 5000；
    //   附魔值 15（与下界合金同级），修复材料为炼狱晶锭。
    //   头盔材料自带击退抗性 +25%（ArmorMaterial.knockbackResistance）。
    //   其余"穿戴时"属性类能力走物品属性组件（HEAD/FEET 槽组）：
    //     头盔：氧气加成 +0.5（空气消耗概率性跳过，呼吸时间 ×1.5 = +50%）、
    //           游泳速度 +25%（NeoForge SWIM_SPEED，1.21.1 起对玩家水中移动生效）；
    //     靴子：移动速度 +25%、跳跃强度 ×√1.25（跳跃高度 ∝ 起跳速度平方，
    //           强度乘 √1.25-1≈+11.8% 即高度 +25%）。
    //   伤害减免、回血、buff 时长、饥饿消耗、进食速度等运行时逻辑见
    //   NetherCrystalSetBonusHandler 与两个 mixin。
    // ------------------------------------------------------------------
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> NETHER_CRYSTAL_HELMET_MATERIAL =
            ARMOR_MATERIALS.register("nether_crystal_helmet", () -> new ArmorMaterial(
                    NETHER_CRYSTAL_HELMET_DEFENSE, 15, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(GeneratedMod.NETHER_CRYSTAL_INGOT.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_crystal"))),
                    6.0F, 0.25F));
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> NETHER_CRYSTAL_CHESTPLATE_MATERIAL =
            ARMOR_MATERIALS.register("nether_crystal_chestplate", () -> new ArmorMaterial(
                    NETHER_CRYSTAL_CHESTPLATE_DEFENSE, 15, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(GeneratedMod.NETHER_CRYSTAL_INGOT.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_crystal"))),
                    10.0F, 0.0F));
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> NETHER_CRYSTAL_LEGGINGS_MATERIAL =
            ARMOR_MATERIALS.register("nether_crystal_leggings", () -> new ArmorMaterial(
                    NETHER_CRYSTAL_LEGGINGS_DEFENSE, 15, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(GeneratedMod.NETHER_CRYSTAL_INGOT.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_crystal"))),
                    8.0F, 0.0F));
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> NETHER_CRYSTAL_BOOTS_MATERIAL =
            ARMOR_MATERIALS.register("nether_crystal_boots", () -> new ArmorMaterial(
                    NETHER_CRYSTAL_BOOTS_DEFENSE, 15, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(GeneratedMod.NETHER_CRYSTAL_INGOT.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_crystal"))),
                    6.0F, 0.0F));
    /**
     * 炼狱晶锁链马铠材料。材料注册键必须叫 nether_crystal_horse_armor：
     * 1.21.1 的 AnimalArmorItem 按 "textures/entity/horse/armor/horse_armor_&lt;材料键&gt;.png"
     * 解析马身贴图，即 netherarmy:textures/entity/horse/armor/horse_armor_nether_crystal_horse_armor.png
     * （用户上传的 64×64 贴图，UV 布局与原版马铠完全一致）。
     * 防御只落在 BODY 槽：30 点护甲，无韧性、无击退抗性。
     */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> NETHER_CRYSTAL_HORSE_ARMOR_MATERIAL =
            ARMOR_MATERIALS.register("nether_crystal_horse_armor", () -> new ArmorMaterial(
                    NETHER_CRYSTAL_HORSE_ARMOR_DEFENSE, 15, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(GeneratedMod.NETHER_CRYSTAL_INGOT.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_crystal"))),
                    0.0F, 0.0F));

    public static final DeferredItem<Item> NETHER_CRYSTAL_HELMET = ITEMS.register(
            "nether_crystal_helmet",
            () -> new NetherCrystalArmorItem(NETHER_CRYSTAL_HELMET_MATERIAL, ArmorItem.Type.HELMET,
                    "item.netherarmy.nether_crystal_helmet.tooltip",
                    // fireResistant：掉落物火焰/岩浆免疫；爆炸免疫见 NetherCrystalArmorItem#canBeHurtBy。
                    new Item.Properties().stacksTo(1).durability(5000).fireResistant()
                            // NeoForge 1.21.1：属性组件非空即顶掉 ArmorItem 默认护甲修饰符
                            // （IItemStackExtension#getAttributeModifiers），护甲/韧性/击退抗性
                            // 须一并显式写入，否则穿上来护甲值为 0。
                            .attributes(ItemAttributeModifiers.builder()
                                    .add(Attributes.ARMOR, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_helmet_defense"),
                                            6.0D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.HEAD)
                                    .add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_helmet_toughness"),
                                            6.0D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.HEAD)
                                    .add(Attributes.KNOCKBACK_RESISTANCE, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_helmet_knockback"),
                                            0.25D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.HEAD)
                                    .add(Attributes.OXYGEN_BONUS, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_oxygen_bonus"),
                                            0.5D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.HEAD)
                                    .add(net.neoforged.neoforge.common.NeoForgeMod.SWIM_SPEED,
                                            new AttributeModifier(
                                                    ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                            "nether_crystal_swim_speed"),
                                                    0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                            EquipmentSlotGroup.HEAD)
                                    .build())));
    public static final DeferredItem<Item> NETHER_CRYSTAL_CHESTPLATE = ITEMS.register(
            "nether_crystal_chestplate",
            () -> new NetherCrystalArmorItem(NETHER_CRYSTAL_CHESTPLATE_MATERIAL, ArmorItem.Type.CHESTPLATE,
                    "item.netherarmy.nether_crystal_chestplate.tooltip",
                    new Item.Properties().stacksTo(1).durability(10000).fireResistant()));
    public static final DeferredItem<Item> NETHER_CRYSTAL_LEGGINGS = ITEMS.register(
            "nether_crystal_leggings",
            () -> new NetherCrystalArmorItem(NETHER_CRYSTAL_LEGGINGS_MATERIAL, ArmorItem.Type.LEGGINGS,
                    "item.netherarmy.nether_crystal_leggings.tooltip",
                    new Item.Properties().stacksTo(1).durability(7500).fireResistant()));
    public static final DeferredItem<Item> NETHER_CRYSTAL_BOOTS = ITEMS.register(
            "nether_crystal_boots",
            () -> new NetherCrystalArmorItem(NETHER_CRYSTAL_BOOTS_MATERIAL, ArmorItem.Type.BOOTS,
                    "item.netherarmy.nether_crystal_boots.tooltip",
                    new Item.Properties().stacksTo(1).durability(5000).fireResistant()
                            // 同头盔：非空属性组件会顶掉默认护甲修饰符，护甲/韧性显式写入。
                            .attributes(ItemAttributeModifiers.builder()
                                    .add(Attributes.ARMOR, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_boots_defense"),
                                            6.0D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.FEET)
                                    .add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_boots_toughness"),
                                            6.0D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.FEET)
                                    .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_speed"),
                                            0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                            EquipmentSlotGroup.FEET)
                                    .add(Attributes.JUMP_STRENGTH, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_jump"),
                                            // 跳跃高度 ∝ 起跳强度平方：×√1.25 → 高度 +25%
                                            Math.sqrt(1.25D) - 1.0D,
                                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                            EquipmentSlotGroup.FEET)
                                    .build())));
    /**
     * 炼狱晶锁链马铠。1.21.1 原版马铠即 AnimalArmorItem(EQUESTRIAN)：
     * 穿戴走 Horse#isBodyArmorItem／马匹物品栏 BODY 槽的现成链路，
     * 渲染走原版 HorseArmorLayer（普通马）与本模组 DullhanHorseArmorLayer
     * （无头骑士的马），贴图取材料键推导出的马铠 64×64 覆盖贴图。
     * 与原版马铠一致可损耗，耐久 5000（与炼狱晶头盔/靴子同量级），
     * 铁砧修复材料为炼狱晶锭（走材料的 repairIngredient）。
     *
     * 附加特性（BODY 槽组属性修饰符，马铠经 Mob#setBodyArmorItem 挂进
     * EquipmentSlot.BODY，LivingEntity 装备属性收集自动挂载）：
     *   护甲 30（NeoForge 1.21.1 中自定义属性组件非空会顶掉 ArmorItem 默认
     *   护甲修饰符，须显式写入，见 IItemStackExtension#getAttributeModifiers）、
     *   马匹移速 +25%、马匹跳跃强度 +25%。繁殖冷却 -25% 无对应属性，
     *   由 HorseBreedingCooldownMixin 在 Animal#finalizeSpawnChildFromBreeding
     *   尾部把亲代冷却 6000 刻缩短为 4500 刻。
     * 组件整体 withTooltip(false)，提示由 NetherCrystalHorseArmorItem 手写（深红）。
     */
    public static final DeferredItem<Item> NETHER_CRYSTAL_HORSE_ARMOR = ITEMS.register(
            "nether_crystal_horse_armor",
            () -> new NetherCrystalHorseArmorItem(NETHER_CRYSTAL_HORSE_ARMOR_MATERIAL, false,
                    new Item.Properties().stacksTo(1).durability(5000).fireResistant()
                            .attributes(ItemAttributeModifiers.builder()
                                    .add(Attributes.ARMOR, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_horse_armor_defense"),
                                            30.0D, AttributeModifier.Operation.ADD_VALUE),
                                            EquipmentSlotGroup.BODY)
                                    .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_horse_armor_speed"),
                                            0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                            EquipmentSlotGroup.BODY)
                                    .add(Attributes.JUMP_STRENGTH, new AttributeModifier(
                                            ResourceLocation.fromNamespaceAndPath(MOD_ID,
                                                    "nether_crystal_horse_armor_jump"),
                                            0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                            EquipmentSlotGroup.BODY)
                                    .build().withTooltip(false))));
    public static final DeferredItem<Item> BERSERKER_SPAWN_EGG = ITEMS.register(
            "berserker_spawn_egg",
            () -> new PlainSpawnEggItem(BERSERKER, 0x343434, 0x750F11, new Item.Properties()));
     public static final DeferredItem<Item> BEDSERKER_SPAWN_EGG = ITEMS.register(
             "bedserker_spawn_egg",
             () -> new PlainSpawnEggItem(BEDSERKER, 0x343434, 0xA51D26, new Item.Properties()));

    public static final DeferredItem<Item> NETHER_HUNTER_SPAWN_EGG = ITEMS.register(
            "nether_hunter_spawn_egg",
            () -> new PlainSpawnEggItem(NETHER_HUNTER, 0x343434, 0x3BB123, new Item.Properties()));
    public static final DeferredItem<Item> DULLHAN_SPAWN_EGG = ITEMS.register(
            "dullhan_spawn_egg",
            () -> new PlainSpawnEggItem(DULLHAN_BODY, 0x28252A, 0x8D2525, new Item.Properties()));
    public static final DeferredItem<Item> BLITZ_DULLHAN_SPAWN_EGG = ITEMS.register(
            "blitz_dullhan_spawn_egg",
            () -> new PlainSpawnEggItem(BLITZ_DULLHAN_BODY, 0x28252A, 0xD9A21B, new Item.Properties()));
    public static final DeferredItem<Item> MESMERIZER_SPAWN_EGG = ITEMS.register(
            "mesmerizer_spawn_egg",
            () -> new PlainSpawnEggItem(MESMERIZER, 0x25252A, 0x8B1E91, new Item.Properties()));
    public static final DeferredItem<Item> WITHERPHANTOM_SPAWN_EGG = ITEMS.register(
            "witherphantom_spawn_egg",
            () -> new PlainSpawnEggItem(WITHERPHANTOM, 0x1B2A33, 0x4E9E42, new Item.Properties()));
    public static final DeferredItem<Item> WITHER_ZOMBIE_SPAWN_EGG = ITEMS.register(
            "witherzombie_spawn_egg",
            () -> new PlainSpawnEggItem(WITHER_ZOMBIE, 0x2B1F2E, 0x5E7A2E, new Item.Properties()));
    public static final DeferredItem<Item> IMMORTAL_WARRIOR_SPAWN_EGG = ITEMS.register(
            "immortal_warrior_spawn_egg",
            () -> new PlainSpawnEggItem(IMMORTAL_WARRIOR, 0x252525, 0xB9B9B9, new Item.Properties()));
     public static final DeferredItem<Item> NETHER_COURIER_SPAWN_EGG = ITEMS.register(
            "nether_courier_spawn_egg",
            () -> new PlainSpawnEggItem(NETHER_COURIER, 0x232323, 0x8B1A1A, new Item.Properties()));
    public static final DeferredItem<Item> NETHER_CARRIER_SPAWN_EGG = ITEMS.register(
            "nether_carrier_spawn_egg",
            () -> new PlainSpawnEggItem(NETHER_CARRIER, 0x2C1113, 0x9A2B22, new Item.Properties()));
    public static final DeferredItem<Item> HEAD_DOMINATOR_SPAWN_EGG = ITEMS.register(
            "head_dominator_spawn_egg",
            () -> new PlainSpawnEggItem(HEAD_DOMINATOR, 0x14141C, 0x2E4A8F, new Item.Properties()));
    public static final DeferredItem<Item> HACKER_SPAWN_EGG = ITEMS.register(
            "hacker_spawn_egg",
            () -> new PlainSpawnEggItem(HACKER, 0x17202A, 0x18A9D8, new Item.Properties()));
    public static final DeferredItem<Item> SHADOW_APOSTLE_SPAWN_EGG = ITEMS.register(
            "shadow_apostle_spawn_egg",
            () -> new PlainSpawnEggItem(SHADOW_APOSTLE, 0x101018, 0x7A43A8, new Item.Properties()));
    public static final DeferredItem<Item> WITHER_GHOST_SPAWN_EGG = ITEMS.register(
            "wither_ghost_spawn_egg",
            () -> new PlainSpawnEggItem(WITHER_GHOST, 0x111317, 0xA7C35C, new Item.Properties()));
    public static final DeferredItem<Item> WITHER_SERVANT_SPAWN_EGG = ITEMS.register(
            "wither_servant_spawn_egg",
            () -> new PlainSpawnEggItem(WITHER_SERVANT, 0x2B1F2E, 0x5E7A2E, new Item.Properties()));
    public static final DeferredItem<Item> SUPPRESSOR_SPAWN_EGG = ITEMS.register(
            "suppressor_spawn_egg",
            () -> new PlainSpawnEggItem(SUPPRESSOR, 0x14161B, 0x53D9D0, new Item.Properties()));
    /** 凋零飞弹：堆叠 16 个，发射后有风弹同款 10 tick 冷却。 */
    public static final DeferredItem<Item> WITHER_CHARGE_ITEM = ITEMS.register(
            "wither_charge", () -> new WitherChargeItem(new Item.Properties().stacksTo(16)));
    /** 圣光炸弹：堆叠 16 个，投掷后冷却 2 秒。 */
    public static final DeferredItem<Item> HOLY_BOMB_ITEM = ITEMS.register(
            "holy_bomb", () -> new HolyBombItem(new Item.Properties().stacksTo(16)));
    /** 反逆控制器：仅作为反逆者（Mesmerizer）手持的物品存在，不是玩家物品，不加入任何创造栏目。 */
    public static final DeferredItem<Item> MESMERIZER_CONTROLLER = ITEMS.registerSimpleItem("mesmerizer_controller");
    public static final DeferredItem<Item> MESMERIZER_ORB_ITEM = ITEMS.registerSimpleItem("mesmerizer_orb");

    /**
     * 炼狱晶矿。与红石火把同款发光机制：方块自带 block light，
     * 贴图的高亮红晶核因此永远按满受光渲染（暗处自发光）。
     * 光照强度 = 红石火把 7 的 2 倍 = 14。
     */
    public static final DeferredBlock<DropExperienceBlock> NETHER_CRYSTAL_ORE = BLOCKS.register(
            "nether_crystal_ore", () -> new DropExperienceBlock(UniformInt.of(10, 50),
                    BlockBehaviour.Properties.ofFullCopy(net.minecraft.world.level.block.Blocks.DIAMOND_ORE)
                            .requiresCorrectToolForDrops()
                            .lightLevel(state -> 14)));
    /** 炼狱晶块。发光同 {@link #NETHER_CRYSTAL_ORE}：光照强度为红石火把（7）的 2 倍 = 14。 */
    public static final DeferredBlock<Block> NETHER_CRYSTAL_BLOCK = BLOCKS.register(
            "nether_crystal_block", () -> new Block(BlockBehaviour.Properties.ofFullCopy(
                    net.minecraft.world.level.block.Blocks.ANCIENT_DEBRIS)
                    .requiresCorrectToolForDrops()
                    .lightLevel(state -> 14)));
    public static final DeferredItem<Item> NETHER_CRYSTAL_ORE_ITEM = ITEMS.register(
            "nether_crystal_ore", () -> new BlockItem(NETHER_CRYSTAL_ORE.get(), new Item.Properties()));
    public static final DeferredItem<Item> NETHER_CRYSTAL_BLOCK_ITEM = ITEMS.register(
            "nether_crystal_block", () -> new BlockItem(NETHER_CRYSTAL_BLOCK.get(), new Item.Properties()));
    public static final DeferredItem<Item> NETHER_CRYSTAL_SHARD = ITEMS.registerSimpleItem("nether_crystal_shard");
    /**
     * 炼狱晶锭。掉落物免疫火焰/岩浆与爆炸（下界合金锭同款待遇）：火/岩浆走注册处的
     * {@code fireResistant} 组件（{@code ItemEntity#fireImmune()} 的判定来源），爆炸由
     * {@link NetherCrystalIngotItem#canBeHurtBy} 拦 {@code IS_EXPLOSION}。用锭制成的
     * 炼狱晶四件套、锁链马铠、亡魂重盾、地煞战斧带同一对组合。
     */
    public static final DeferredItem<Item> NETHER_CRYSTAL_INGOT = ITEMS.register(
            "nether_crystal_ingot",
            () -> new NetherCrystalIngotItem(new Item.Properties().fireResistant()));
    /**
     * 枯肉。5 点饥饿 + 15 点饱和度：1.21.1 的饱和度按
     * {@code nutrition × saturationModifier × 2} 结算，故倍率取 15 / (5×2) = 1.5。
     * 食用后的 80%/20% 互斥随机效果见 {@link WitherFleshItem}。
     */
    public static final DeferredItem<Item> WITHER_FLESH = ITEMS.register("wither_flesh",
            () -> new WitherFleshItem(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(5).saturationModifier(1.5F).build())));
    /**
     * 坏苹果。10 点饥饿 + 8 点饱和度：1.21.1 饱和度按
     * {@code nutrition × saturationModifier × 2} 结算，故倍率取 8 / (10×2) = 0.4。
     * 食用后必定获得 2 分钟（2400 刻）符卡规则；效果走 {@code FOOD} 组件的
     * 100% 概率通道，与枯肉的手工掷骰不同，无需自定义 Item 子类。
     * {@code alwaysEdible}：不饿也能吃——NeoForge 补丁让 {@code ItemStack#use} 的饥饿
     * 门槛按 {@code FoodProperties#canAlwaysEat} 放行，饥饿满格时照样开吃补符卡规则。
     */
    public static final DeferredItem<Item> BAD_APPLE = ITEMS.register("bad_apple",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(10).saturationModifier(0.4F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(SPELL_CARD_RULES, 2400), 1.0F)
                    .build())));
    /**
     * 神·附魔金苹果。食用恢复的饥饿值与饱和度与苹果完全一致
     * （nutrition 2、saturationModifier 0.4，与 {@code Items#APPLE} 同参数）；
     * 吃完后同时获得 7 种、各持续 1 分钟（1200 刻）的效果：
     * 生命恢复 V、抗性提升 V、伤害吸收 V、防火、急迫 V、生命提升 V、饱和 V
     * （amplifier 4 即 V 级；防火本身无等级差异，与其他效果统一给到 V）。
     * 金色物品名与附魔金苹果同款的动态紫色光泽见 {@link GodGoldenAppleItem}。
     */
    public static final DeferredItem<Item> GOD_GOLDEN_APPLE = ITEMS.register("god_golden_apple",
            () -> new GodGoldenAppleItem(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2).saturationModifier(0.4F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.HEALTH_BOOST, 1200, 4), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.SATURATION, 1200, 4), 1.0F)
                    .build())));
    public static final DeferredItem<Item> SOUL_SHIELD = ITEMS.register("soul_shield", () -> new SoulShieldItem(
            // rarity(EPIC)：与原版三叉戟/重锤同款机制，物品名自动取 Rarity.EPIC 的
            // ChatFormatting.LIGHT_PURPLE（淡紫色），不需要另写 getName 覆盖。
            new Item.Properties().stacksTo(1).durability(5000).fireResistant().rarity(Rarity.EPIC)
                    .attributes(ItemAttributeModifiers.builder()
                    .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "soul_shield_speed_penalty"), -0.10D,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL), EquipmentSlotGroup.HAND).build())));

    /**
     * 地煞战斧。数值落点说明：
     * <ul>
     *   <li>伤害 18：{@code Attributes.ATTACK_DAMAGE} 的基线是 1.0，所以修饰符取 17.0，
     *       {@code ItemAttributeModifiers#compute} 结算后每击 18 点。</li>
     *   <li>冷却 1.2 秒：{@code Player#getCurrentItemAttackStrengthDelay} = 20 / 攻速 刻，
     *       要 24 刻（1.2 秒）满蓄力就得攻速 1/1.2≈0.8333；攻速基线 4.0，修饰符取 -3.1666…。</li>
     *   <li>耐久 5000：由 {@link DishaBattleAxeItem.DishaTier#getUses()} 经
     *       {@code TieredItem} 构造器写入，不需要再调 {@code durability}。</li>
     *   <li>{@code fireResistant}：让掉落物在火/岩浆里不烧毁（爆炸免疫见物品类的
     *       {@code canBeHurtBy}）。</li>
     *   <li>攻击距离比铁剑远 25%：玩家 {@code minecraft:entity_interaction_range} 基线 3.0 格，
     *       主手持斧时按 {@code ADD_MULTIPLIED_BASE} +0.25 结算成 3.75 格。
     *       该属性同时喂给客户端准星拾取（{@code Player#entityInteractionRange}）与服务端
     *       交互校验（{@code Player#canInteractWithEntity}），所以"看得见就打得到"两侧一致。</li>
     * </ul>
     */
    public static final DishaBattleAxeItem.DishaTier DISHA_TIER = new DishaBattleAxeItem.DishaTier();
    /** 皇家长剑的工具材料：耐久 864，修复材料为炼狱晶碎片。 */
    public static final RoyalLongswordItem.RoyalTier ROYAL_LONGSWORD_TIER = new RoyalLongswordItem.RoyalTier();
    /**
     * 皇家长剑与地煞战斧的攻击距离倍率。
     *
     * <p>落在 {@code Attributes.ENTITY_INTERACTION_RANGE}（玩家基线 3.0 格）上，用
     * {@code ADD_MULTIPLIED_BASE} 表达倍率，取 {@code 1.25 - 1 = 0.25}：倍率乘在基线上，
     * 既不会被其他装备的加值稀释，也不会把其他装备的加值一起放大到 1.25 倍。
     * 只有主手持斧时生效（{@code EquipmentSlotGroup.MAINHAND}），收起或换到副手即失效。</p>
     */
    public static final double DISHA_ATTACK_REACH_MULTIPLIER = 1.25D;
    public static final DeferredItem<Item> DISHA_BATTLE_AXE = ITEMS.register("disha_battle_axe",
            () -> new DishaBattleAxeItem(DISHA_TIER, new Item.Properties().stacksTo(1).fireResistant()
                    // 与亡魂重盾一致：Rarity.EPIC 让物品名走原版重锤/三叉戟的淡紫色。
                    .rarity(Rarity.EPIC)
                    .attributes(ItemAttributeModifiers.builder()
                            .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID,
                                    17.0D, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                            .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID,
                                    1.0D / 1.2D - 4.0D, AttributeModifier.Operation.ADD_VALUE),
                                    EquipmentSlotGroup.MAINHAND)
                            .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "disha_attack_reach"),
                                    DISHA_ATTACK_REACH_MULTIPLIER - 1.0D,
                                    AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                                    EquipmentSlotGroup.MAINHAND)
                            .build())));

    /** 皇家长剑：伤害 7、攻速 1.4、耐久 864，攻击距离比铁剑远 20%。 */
    public static final DeferredItem<Item> ROYAL_LONGSWORD = ITEMS.register("royal_longsword",
            () -> new RoyalLongswordItem(ROYAL_LONGSWORD_TIER,
                    new Item.Properties().stacksTo(1).fireResistant()));

    /**
     * 下界军团旗帜。数值落点说明：
     * <ul>
     *   <li>伤害 4：{@code Attributes.ATTACK_DAMAGE} 基线 1.0，修饰符取 3.0。</li>
     *   <li>攻击间隔 0.25 秒：玩家攻速基线 4.0，20/4 = 5 刻 = 0.25 秒。{@code ATTACK_SPEED}
     *       上带一条加值为 0、id 为 {@code base_attack_speed} 的修饰符：结算后攻速仍是
     *       4.0 + 0 = 4.0，数值不变，它唯一的作用是让提示框按原版近战武器同款深绿格式
     *       显示"攻击速度 4.0"——原版 {@code ItemStack#addModifierTooltip} 只对
     *       {@code Item.BASE_ATTACK_SPEED_ID} 这条基线修饰符走"等于"显示分支，
     *       显示值为修饰符加值 + 玩家攻速基线。</li>
     *   <li>持有时速度 +0.25：{@code MOVEMENT_SPEED} 按
     *       {@code ADD_MULTIPLIED_TOTAL} +25%，双手持握都生效
     *       （{@code EquipmentSlotGroup.HAND}，与亡魂重盾的减速同一落点）。</li>
     *   <li>攻击距离比剑远 15%：{@code ENTITY_INTERACTION_RANGE} 基线 3.0 格，
     *       主手 {@code ADD_MULTIPLIED_BASE} +0.15 → 3.45 格。</li>
     *   <li>无限耐久 / 不可附魔：不带 {@code durability} 组件、不进任何
     *       {@code #minecraft:enchantable/*} 标签；击退减半见
     *       {@link NetherArmyFlagKnockbackHandler}，攻击时的黑烟与半径 5 格凋零冲击波见
     *       {@link NetherArmyFlagWitherAoeHandler}（玩家与怪物各自的触发通道 + 同刻去重）。</li>
     * </ul>
     */
    public static final DeferredItem<Item> NETHER_ARMY_FLAG = ITEMS.register("nether_army_flag",
            () -> new NetherArmyFlagItem(new Item.Properties().stacksTo(1)
                    .attributes(ItemAttributeModifiers.builder()
                            .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID,
                                    3.0D, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                            .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID,
                                    0.0D, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                            .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(
                                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_army_flag_speed"),
                                    0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                    EquipmentSlotGroup.HAND)
                            .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "nether_army_flag_reach"),
                                    0.15D, AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                                    EquipmentSlotGroup.MAINHAND)
                            .build())));

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, MOD_ID);
    /** 反逆者子弹（光球）的命中音效，对应 sounds.json 中同名条目。 */
    public static final DeferredHolder<SoundEvent, SoundEvent> MESMERIZER_ORB_HIT =
            SOUND_EVENTS.register("mesmerizer_orb_hit", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "mesmerizer_orb_hit")));
    /** 凋灵舞曲唱片的播放音效，对应 sounds.json 中 music_disc.wither_dance 条目（流式播放）。 */
    /** 黑客电脑动画完成音效。 */
    public static final DeferredHolder<SoundEvent, SoundEvent> HACKER_USE_COMPUTER =
            SOUND_EVENTS.register("hacker_use_computer", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "hacker_use_computer")));
    public static final DeferredHolder<SoundEvent, SoundEvent> MUSIC_DISC_WITHER_DANCE_SOUND =
            SOUND_EVENTS.register("music_disc.wither_dance", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "music_disc.wither_dance")));
    /**
     * 凋灵舞曲曲目：指向本模组数据包条目 {@code netherarmy:wither_dance}
     * （{@code data/netherarmy/jukebox_song/wither_dance.json}，时长 203.27 秒）。
     * 与原版唱片同一套数据驱动机制，入唱片机、比较器输出、"正在播放"提示全部走原版。
     */
    public static final ResourceKey<JukeboxSong> MUSIC_DISC_WITHER_DANCE_SONG = ResourceKey.create(
            Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(MOD_ID, "wither_dance"));
    /**
     * 凋灵舞曲唱片。堆叠 1、名字淡紫色（见 {@link WitherDanceMusicDiscItem}），
     * 贴图 {@code assets/netherarmy/textures/item/music_disc_wither_dance.png}，
     * 模型沿用原版 {@code item/template_music_disc}，与其他唱片同一渲染规格。
     */
    public static final DeferredItem<Item> MUSIC_DISC_WITHER_DANCE = ITEMS.register("music_disc_wither_dance",
            () -> new WitherDanceMusicDiscItem(new Item.Properties().stacksTo(1)
                    .jukeboxPlayable(MUSIC_DISC_WITHER_DANCE_SONG)));
    public static final DeferredBlock<NetherReactorBlock> NETHER_REACTOR_BLOCK =
            BLOCKS.register("nether_reactor_core", () -> new NetherReactorBlock(NetherReactorBlock.defaultProperties()));
    public static final DeferredItem<Item> NETHER_REACTOR_BLOCK_ITEM = ITEMS.register(
            "nether_reactor_core", () -> new BlockItem(NETHER_REACTOR_BLOCK.get(), new Item.Properties().fireResistant()));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<NetherReactorBlockEntity>>
            NETHER_REACTOR_BLOCK_ENTITY = BLOCK_ENTITY_TYPES.register("nether_reactor_core",
            () -> BlockEntityType.Builder.of(NetherReactorBlockEntity::new,
                    NETHER_REACTOR_BLOCK.get()).build(null));

    /** 萱浮的沙子：非重力、可悬空的沙子堆，摆放朝向随玩家，悬空时漏沙子粒子，空手右键猫叫并掉出一个糖；
     *  像基岩一样不可挖掘，生存下唯一收取方式是手持糖 Shift+右键直接掉落。 */
    public static final DeferredBlock<XuanfuSandBlock> XUANFU_SAND_BLOCK = BLOCKS.register(
            "xuanfu_sand", () -> new XuanfuSandBlock(BlockBehaviour.Properties.of()
                    .mapColor(net.minecraft.world.level.material.MapColor.SAND)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.SAND)));
    public static final DeferredItem<Item> XUANFU_SAND_ITEM = ITEMS.register(
            "xuanfu_sand", () -> new BlockItem(XUANFU_SAND_BLOCK.get(), new Item.Properties()));
    /** 仅作为【萱萱】进度图标使用的物品，不主动加入任何创造栏目分组。 */
    public static final DeferredItem<Item> XUANXUAN_ICON = ITEMS.registerSimpleItem("xuanxuan_icon");
    /** 格尔多：不可堆叠、灵魂绑定，第一次登录自动进入玩家背包。 */
    public static final DeferredItem<Item> GEARDLE = ITEMS.register("geardle",
            () -> new GeardleItem(new Item.Properties().stacksTo(1).fireResistant()));

    /** 模组物品统一收纳的【地狱军团】创造栏目。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> NETHER_LEGION_TAB =
            CREATIVE_TABS.register("nether_legion", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.netherarmy.nether_legion"))
                    .icon(() -> new ItemStack(GEARDLE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(GEARDLE.get());
                         output.accept(ROYAL_LONGSWORD.get());
                        output.accept(DISHA_BATTLE_AXE.get());
                        output.accept(NETHER_ARMY_FLAG.get());
                        output.accept(SOUL_SHIELD.get());
                        output.accept(BERSERKER_HELMET.get());
                        output.accept(MESMERIZER_CROWN.get());
                        output.accept(NETHER_CRYSTAL_HELMET.get());
                        output.accept(NETHER_CRYSTAL_CHESTPLATE.get());
                        output.accept(NETHER_CRYSTAL_LEGGINGS.get());
                        output.accept(NETHER_CRYSTAL_BOOTS.get());
                        output.accept(NETHER_CRYSTAL_HORSE_ARMOR.get());
                        output.accept(WITHER_FLESH.get());
                        output.accept(BAD_APPLE.get());
                        output.accept(GOD_GOLDEN_APPLE.get());
                        output.accept(NETHER_CRYSTAL_SHARD.get());
                        output.accept(NETHER_CRYSTAL_INGOT.get());
                        output.accept(NETHER_CRYSTAL_ORE_ITEM.get());
                        output.accept(NETHER_CRYSTAL_BLOCK_ITEM.get());
                        output.accept(NETHER_REACTOR_BLOCK_ITEM.get());
                        output.accept(XUANFU_SAND_ITEM.get());
                        output.accept(MUSIC_DISC_WITHER_DANCE.get());
                        output.accept(BERSERKER_SPAWN_EGG.get());
                        output.accept(BEDSERKER_SPAWN_EGG.get());
                        output.accept(NETHER_HUNTER_SPAWN_EGG.get());
                        output.accept(DULLHAN_SPAWN_EGG.get());
                        output.accept(BLITZ_DULLHAN_SPAWN_EGG.get());
                        output.accept(MESMERIZER_SPAWN_EGG.get());
                        output.accept(WITHERPHANTOM_SPAWN_EGG.get());
                        output.accept(WITHER_ZOMBIE_SPAWN_EGG.get());
                        output.accept(IMMORTAL_WARRIOR_SPAWN_EGG.get());
                         output.accept(NETHER_COURIER_SPAWN_EGG.get());
                        output.accept(NETHER_CARRIER_SPAWN_EGG.get());
                        output.accept(HEAD_DOMINATOR_SPAWN_EGG.get());
                        output.accept(HACKER_SPAWN_EGG.get());
                        output.accept(WITHER_GHOST_SPAWN_EGG.get());
                        output.accept(SHADOW_APOSTLE_SPAWN_EGG.get());
                        output.accept(WITHER_SERVANT_SPAWN_EGG.get());
                        output.accept(SUPPRESSOR_SPAWN_EGG.get());
                        output.accept(WITHER_CHARGE_ITEM.get());
                        output.accept(HOLY_BOMB_ITEM.get());
                        HolderLookup.RegistryLookup<Enchantment> enchantments =
                                parameters.holders().lookupOrThrow(Registries.ENCHANTMENT);
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, MAGIC_RESISTANCE)));
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, SOUL_PURIFICATION)));
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, PROTECTOR)));
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, REMODEL)));
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, THREE_DIMENSIONAL_DEFENSE)));
                        output.accept(EnchantedBookItem.createForEnchantment(
                                maxLevelEnchantment(enchantments, BLUNT_BUFFER)));
                    })
                    .build());

    private static EnchantmentInstance maxLevelEnchantment(HolderLookup.RegistryLookup<Enchantment> lookup,
                                                            ResourceKey<Enchantment> key) {
        Holder<Enchantment> holder = lookup.getOrThrow(key);
        return new EnchantmentInstance(holder, holder.value().getMaxLevel());
    }

    private static final String CREEPER_IGNITER_TAG = "generated_mod_creeper_igniter";
    private static final String WITHER_SKELETON_EQUIPMENT_TAG = "generated_mod_wither_skeleton_equipment";
    private static final float WITHER_SKELETON_GOLD_ARMOR_CHANCE = 0.10F;
    private static final float WITHER_SKELETON_NETHERITE_ARMOR_CHANCE = 0.01F;
    private static final float WITHER_SKELETON_GOLD_ENCHANTMENT_CHANCE = 0.02F;
    private static final float WITHER_SKELETON_BOW_CHANCE = 0.10F;
    private static final float WITHER_SKELETON_NETHERITE_SWORD_CHANCE = 0.01F;
    /** 凋灵骷髅死亡后原地产生怨灵的概率。 */
    private static final float WITHER_SKELETON_GHOST_CHANCE = 0.10F;

    public GeneratedMod(IEventBus modBus, ModContainer container) {
        LOGGER.info("[netherarmy] mod constructed, version {}",
                container.getModInfo().getVersion());
        ENTITY_TYPES.register(modBus);
        ARMOR_MATERIALS.register(modBus);
        BLOCKS.register(modBus);
        BLOCK_ENTITY_TYPES.register(modBus);
        STRUCTURE_TYPES.register(modBus);
        ITEMS.register(modBus);
        CREATIVE_TABS.register(modBus);
        MOB_EFFECTS.register(modBus);
        PARTICLE_TYPES.register(modBus);
        MENU_TYPES.register(modBus);
        SOUND_EVENTS.register(modBus);
        ATTACHMENT_TYPES.register(modBus);
        modBus.addListener(this::registerAttributes);
        modBus.addListener(this::registerSpawnPlacements);
        modBus.addListener(this::commonSetup);
        modBus.addListener(this::addCreativeTabContents);
        modBus.addListener(BadAppleUrlSync::registerPayloads);
        modBus.addListener(GeardleSync::registerPayloads);
        modBus.addListener(LegionFactionHandler::addArmorAttributeFloors);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(this);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFactionHostilityHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(MachineryHostilityHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherEnhancementHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(OverlordWitherHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(SuppressorProjectileHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(HeadDominatorSkullHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFactionInfectionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(ShadowApostleConversionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(SoulFireDamageHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFactionArmorTrimHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherZombiePreyFleeHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherServantCorruptionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFleshFeedingHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(MesmerizerControlHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(LegionVisionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(BeaconEnhancementHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(MagicResistanceHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(GlowingDamageHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(SoulPurificationHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(ShieldEnchantmentHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(BaneOfArthropodsKillHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(SoulShieldAnvilRepair.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(CrystalShardFuelHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(SpellCardRulesHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(BadAppleUrlSync.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(NetherArmyFlagKnockbackHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(NetherArmyFlagWitherAoeHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(LegionFactionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFactionCreativePassivityHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(WitherFactionRetaliationHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(LegionAuraHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(NetherPatrolSpawner.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(DullhanTrapSpawner.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(NetherArmyCommands.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(HunterHuntAdvancementHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(BedserkerHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(FortressSpawnBlacklistHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(BlitzDullhanFortressSpawnHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(XuanfuSandInteractionHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(HackerCountermeasureHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(VillageHackerSpawner.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(NetherCrystalSetBonusHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(GeardleHandler.class);
         net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(RoyalLongswordDamageHandler.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(GeardleEquipHandler.class);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(BERSERKER.get(), Berserker.createAttributes().build());
         event.put(BEDSERKER.get(), Bedserker.createAttributes().build());
        event.put(NETHER_HUNTER.get(), NetherHunter.createAttributes().build());
        event.put(DULLHAN_BODY.get(), DullhanBody.createAttributes().build());
        event.put(DULLHAN_HEAD.get(), DullhanHead.createAttributes().build());
        event.put(DULLHAN_HORSE.get(), DullhanHorse.createAttributes().build());
        event.put(BLITZ_DULLHAN_BODY.get(), BlitzDullhanBody.createAttributes().build());
        event.put(BLITZ_DULLHAN_HEAD.get(), BlitzDullhanHead.createAttributes().build());
        event.put(BLITZ_DULLHAN_HORSE.get(), BlitzDullhanHorse.createAttributes().build());
        event.put(MESMERIZER.get(), Mesmerizer.createAttributes().build());
        event.put(WITHERPHANTOM.get(), Witherphantom.createAttributes().build());
        event.put(SHADOW_APOSTLE.get(), ShadowApostle.createAttributes().build());
        event.put(WITHER_ZOMBIE.get(), WitherZombie.createAttributes().build());
        event.put(WITHER_SERVANT.get(), WitherServant.createAttributes().build());
        event.put(SUPPRESSOR.get(), Suppressor.createAttributes().build());
        event.put(IMMORTAL_WARRIOR.get(), ImmortalWarrior.createAttributes().build());
         event.put(IMMORTAL_WARRIOR_REMAINS.get(), ImmortalWarriorRemains.createAttributes().build());
         event.put(NETHER_COURIER.get(), NetherCourier.createAttributes().build());
        event.put(NETHER_CARRIER.get(), NetherCarrier.createAttributes().build());
        event.put(HEAD_DOMINATOR.get(), HeadDominator.createAttributes().build());
        event.put(HACKER.get(), Hacker.createAttributes().build());
        event.put(WITHER_GHOST.get(), WitherGhost.createAttributes().build());
        event.put(OVERLORD_WITHER.get(), OverlordWitherBoss.createAttributes().build());
    }

    /**
     * 衰翼只在岩浆海上刷新。
     *
     * <p>放置类型用 {@code NO_RESTRICTIONS} 而不是 ON_GROUND：1.21.1 的 ON_GROUND 对
     * {@code pos.below()} 做 {@code BlockState#isValidSpawn}（要求顶面承重且发光亮度 &lt; 14），
     * 而岩浆发光恒为 15——凡"脚下必须是岩浆"的生成点在 ON_GROUND 下永远非法，衰翼实际
     * 一只都不会自然刷出。地板（岩浆）与上方两格空位的校验整体移入自定义生成规则
     * {@link Witherphantom#checkWitherphantomSpawnRules}。</p>
     */
    private void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(WITHERPHANTOM.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Witherphantom::checkWitherphantomSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 尸鬼：下界任意地形（含岩浆海、排除基岩层）——同理不能用 ON_GROUND，岩浆地板
        // 过不了 isValidSpawn 的光照/承重校验，地板与空位判定整体移入自定义规则。
        event.register(WITHER_ZOMBIE.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                WitherZombie::checkWitherZombieSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 原版凋灵骷髅属于本模组的凋灵骷髅阵营：在下界沿用阵营成员的任意亮度
        // 刷怪规则，其他维度保留原版的亮度限制。
        event.register(EntityType.WITHER_SKELETON,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> level.getLevel().dimension() == Level.NETHER
                        ? Monster.checkAnyLightMonsterSpawnRules(type, level, reason, pos, random)
                        : Monster.checkMonsterSpawnRules(type, level, reason, pos, random),
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 怨灵：只在黑暗处随机自然刷新（配合 biome_modifier 限定 #minecraft:is_nether，
        // 实际只出现在下界）。沿用原版僵尸/骷髅/苦力怕的 checkMonsterSpawnRules：亮度须
        // 低于维度的怪物生成光照上限（下界为 7），火把、萤石、岩浆等亮处不刷，全黑洞穴
        // 与建筑暗角才刷（怨灵自身的【虚化】破功阈值另设为亮度 ≥10，比刷怪光照更宽松，
        // 因此刷出的怨灵在火把附近仍能保持虚化）。ON_GROUND 保证刷在
        // 可承重的地面上（刷出后靠恼鬼同款漂浮运动升空），岩浆/发光方块由
        // isValidSpawn 的光照校验自然排除。
        event.register(WITHER_GHOST.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(SHADOW_APOSTLE.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 下界猎手/狂战士/无头骑士/传令兵/反逆者：与原版凋灵骷髅同一套规则
        // （任意光照 + 脚下可站立）。不注册时 SpawnPlacements.checkSpawnRules
         event.register(BEDSERKER.get(),
                 SpawnPlacementTypes.ON_GROUND,
                 Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                 Monster::checkAnyLightMonsterSpawnRules,
                 RegisterSpawnPlacementsEvent.Operation.REPLACE);

        // 默认恒 true，但 isSpawnPositionOk 仍会走 NO_RESTRICTIONS，容易把怪
        // 刷进岩浆或半格方块里；结构 spawn_overrides 走的是自然刷怪路径，必须
        // 有 ON_GROUND 才能稳定落地。
        event.register(BERSERKER.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(NETHER_HUNTER.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(DULLHAN_BODY.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 强袭躯体与无头骑士使用同一套落地规则；稀有刷新处理器在补生成时显式复用这些校验。
        event.register(BLITZ_DULLHAN_BODY.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(NETHER_COURIER.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(NETHER_CARRIER.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(IMMORTAL_WARRIOR.get(),
                 SpawnPlacementTypes.ON_GROUND,
                 Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                 Monster::checkAnyLightMonsterSpawnRules,
                 RegisterSpawnPlacementsEvent.Operation.REPLACE);
         event.register(MESMERIZER.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 御首者：凋灵骷髅阵营远程施法者，与反逆者/传令兵同一套落地规则（任意光照 + 脚下可站立）。
        event.register(HEAD_DOMINATOR.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 无头骑士马（骷髅马亚种）：阵营成员。原版骷髅马沿用"暗处才刷"的怪物规则，
        // 陷阱马投放路径不走刷怪位置校验、不受影响，但按阵营设计统一改为
        // 任意亮度 + 脚下可站立，与其他阵营怪物一致。
        event.register(DULLHAN_HORSE.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> level.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && Mob.checkMobSpawnRules(type, level, reason, pos, random),
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        // 霸主凋灵：只能由祭坛仪式（三颗凋灵骷髅头颅 + 灵魂沙/下界反应核/灵魂沙 + 灵魂沙）
        // 召唤。它挂在 #minecraft:wither_skeletons 阵营标签里是为了敌我判定，一旦有刷怪逻辑
        // 按标签取候选池（格尔多阵营刷怪、生物群系/结构 spawn_overrides、其他模组的自然刷怪）
        // 就可能把它当普通阵营怪生成。这里注册恒为 false 的生成校验兜底；仪式走的是直接
        // create + addFreshEntity，不经过刷怪位置校验，所以召唤不受影响。
        event.register(OVERLORD_WITHER.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> false,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(WITHER_CHARGE.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> false,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(HOLY_BOMB.get(),
                SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> false,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        LOGGER.info("[netherarmy] common setup done");
        event.enqueueWork(() -> {
            net.minecraft.world.level.block.DispenserBlock.registerProjectileBehavior(WITHER_CHARGE_ITEM.get());
            net.minecraft.world.level.block.DispenserBlock.registerProjectileBehavior(HOLY_BOMB_ITEM.get());
        });
    }

    public void addCreativeTabContents(BuildCreativeModeTabContentsEvent event) {
        if (!event.getTabKey().equals(CreativeModeTabs.COMBAT)) {
            return;
        }
        // 原版战斗栏目会按附魔注册表自动生成最高等级附魔书；把本模组的六本移到专属栏目。
        List<ItemStack> remove = new ArrayList<>();
        for (ItemStack stack : event.getParentEntries()) {
            var stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
            if (stored == null) {
                continue;
            }
            for (Holder<Enchantment> holder : stored.keySet()) {
                if (isNetherArmyEnchantment(holder)) {
                    remove.add(stack);
                    break;
                }
            }
        }
        for (ItemStack stack : remove) {
            event.remove(stack, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
        }
    }

    private static boolean isNetherArmyEnchantment(Holder<Enchantment> holder) {
        return holder.is(MAGIC_RESISTANCE) || holder.is(SOUL_PURIFICATION)
                || holder.is(PROTECTOR) || holder.is(REMODEL)
                || holder.is(THREE_DIMENSIONAL_DEFENSE) || holder.is(BLUNT_BUFFER);
    }

    @SubscribeEvent
    public void onReactorItemExplosion(ExplosionEvent.Detonate event) {
        event.getAffectedEntities().removeIf(entity -> entity instanceof net.minecraft.world.entity.item.ItemEntity item
                && item.getItem().is(NETHER_REACTOR_BLOCK_ITEM.get()));
    }

    /** 狂战士自爆爆炸：剥除对一切生物的伤害，由 {@link #onDeath} 统一按 10/5 点结算。 */
    @SubscribeEvent
    public void onBerserkerSelfDestructDetonate(ExplosionEvent.Detonate event) {
        if (berserkerSelfDestructActive) {
            event.getAffectedEntities().removeIf(entity -> entity instanceof net.minecraft.world.entity.LivingEntity);
        }
    }

    @SubscribeEvent
    public void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!event.getEntity().getItemBySlot(EquipmentSlot.HEAD).is(BERSERKER_HELMET.get())) {
            return;
        }
        if (event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
            event.setAmount(event.getAmount() * 0.75F);
        }
    }

    @SubscribeEvent
    public void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();
        if (!left.is(BERSERKER_HELMET.get()) || !isHelmetRepairMaterial(right) || left.getDamageValue() <= 0) {
            return;
        }
        ItemStack output = left.copy();
        output.setDamageValue(Math.max(0, left.getDamageValue() - 250));
        event.setOutput(output);
        event.setCost(1L);
        event.setMaterialCost(1);
    }

    private static boolean isHelmetRepairMaterial(ItemStack stack) {
        return stack.is(Items.COBBLESTONE) || stack.is(Items.BLACKSTONE) || stack.is(Items.STONE);
    }

    @SubscribeEvent
    public void onNetherMobConversion(LivingConversionEvent.Pre event) {
        LivingEntity entity = event.getEntity();
        if (!(entity instanceof Hoglin || entity instanceof Piglin || entity instanceof PiglinBrute)
                || !(entity.level() instanceof ServerLevel level)
                || !level.dimension().equals(Level.OVERWORLD)
                || !(event.getOutcome() == EntityType.ZOGLIN
                || event.getOutcome() == EntityType.ZOMBIFIED_PIGLIN)) {
            return;
        }
        if (ReactorChunkState.get(level, entity.blockPosition()).hasActiveReactor(entity.blockPosition())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onWitherSkeletonFinalizeSpawn(FinalizeSpawnEvent event) {
        if (!(event.getEntity() instanceof WitherSkeleton skeleton)
                || skeleton.getType() != EntityType.WITHER_SKELETON
                || event.getLevel().getLevel().isClientSide()) {
            return;
        }
        // 世界进入第五天后由 GeardleEquipHandler 在实体入世界后接管分阶段装备，避免两套概率叠加。
        if (event.getLevel().getLevel().getDayTime() > 5L * 24000L) {
            return;
        }
        if (skeleton.getPersistentData().getBoolean(WITHER_SKELETON_EQUIPMENT_TAG)) {
            return;
        }
        skeleton.getPersistentData().putBoolean(WITHER_SKELETON_EQUIPMENT_TAG, true);

        ServerLevel level = event.getLevel().getLevel();
        RandomSource random = skeleton.getRandom();
        equipWitherSkeletonArmor(level, skeleton, random, EquipmentSlot.HEAD,
                Items.GOLDEN_HELMET, Items.NETHERITE_HELMET);
        equipWitherSkeletonArmor(level, skeleton, random, EquipmentSlot.CHEST,
                Items.GOLDEN_CHESTPLATE, Items.NETHERITE_CHESTPLATE);
        equipWitherSkeletonArmor(level, skeleton, random, EquipmentSlot.LEGS,
                Items.GOLDEN_LEGGINGS, Items.NETHERITE_LEGGINGS);
        equipWitherSkeletonArmor(level, skeleton, random, EquipmentSlot.FEET,
                Items.GOLDEN_BOOTS, Items.NETHERITE_BOOTS);

        ItemStack weapon;
        if (random.nextFloat() < WITHER_SKELETON_NETHERITE_SWORD_CHANCE) {
            weapon = new ItemStack(Items.NETHERITE_SWORD);
        } else if (random.nextFloat() < WITHER_SKELETON_BOW_CHANCE) {
            weapon = new ItemStack(Items.BOW);
        } else {
            weapon = new ItemStack(Items.STONE_SWORD);
        }
        skeleton.setItemSlot(EquipmentSlot.MAINHAND, weapon);
        skeleton.setDropChance(EquipmentSlot.MAINHAND, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
        skeleton.reassessWeaponGoal();
    }

    private static void equipWitherSkeletonArmor(ServerLevel level, WitherSkeleton skeleton, RandomSource random,
                                                  EquipmentSlot slot, Item goldArmor, Item netheriteArmor) {
        float roll = random.nextFloat();
        if (roll >= WITHER_SKELETON_NETHERITE_ARMOR_CHANCE + WITHER_SKELETON_GOLD_ARMOR_CHANCE) {
            return;
        }
        boolean netherite = roll < WITHER_SKELETON_NETHERITE_ARMOR_CHANCE;
        ItemStack armor = new ItemStack(netherite ? netheriteArmor : goldArmor);
        if (!netherite && random.nextFloat() < WITHER_SKELETON_GOLD_ENCHANTMENT_CHANCE) {
            addRandomArmorEnchantment(level, random, armor, slot);
        }
        skeleton.setItemSlot(slot, armor);
        skeleton.setDropChance(slot, Mob.DEFAULT_EQUIPMENT_DROP_CHANCE);
    }

    private static void addRandomArmorEnchantment(ServerLevel level, RandomSource random, ItemStack stack,
                                                   EquipmentSlot slot) {
        HolderLookup.RegistryLookup<Enchantment> registry =
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (Holder.Reference<Enchantment> holder : registry.listElements().toList()) {
            Enchantment enchantment = holder.value();
            if (holder.is(Enchantments.BINDING_CURSE) || holder.is(Enchantments.VANISHING_CURSE)) {
                continue;
            }
            if (enchantment.canEnchant(stack) && enchantment.matchingSlot(slot)) {
                candidates.add(holder);
            }
        }
        if (!candidates.isEmpty()) {
            Holder.Reference<Enchantment> selected = candidates.get(random.nextInt(candidates.size()));
            stack.enchant(selected, Math.min(1 + random.nextInt(2), selected.value().getMaxLevel()));
        }
    }

    @SubscribeEvent
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Creeper creeper)
                || !(event.getEntity() instanceof ServerPlayer player)
                || !(event.getItemStack().is(Items.FLINT_AND_STEEL)
                || event.getItemStack().is(Items.FIRE_CHARGE))) {
            return;
        }
        creeper.getPersistentData().putUUID(CREEPER_IGNITER_TAG, player.getUUID());
    }

    /**
     * 狂战士自爆拦截开关：置位期间爆炸只做视效与方块破坏，对一切生物的伤害
     * 从爆炸结算里剥除，统一由 {@link #onDeath} 按"固定 10 点、凋灵骷髅阵营
     * 减半为 5 点"结算。{@code Level.explode} 同步结算，
     * {@link ExplosionEvent.Detonate} 必在置位窗口内触发，且全部发生在服务端
     * 主线程，普通布尔即可（try/finally 保证异常下也会复位）。
     */
    private boolean berserkerSelfDestructActive = false;

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof Mesmerizer mesmerizer && !mesmerizer.level().isClientSide()) {
            MesmerizerControl.releaseAllControlledBy(mesmerizer);
            return;
        }
        if (event.getEntity() instanceof DullhanHead head && !head.level().isClientSide()) {
            ServerLevel level = (ServerLevel) head.level();
            LivingEntity target = head.getTarget();
            if (target == null || !target.isAlive()) {
                Entity attacker = event.getSource().getEntity();
                if (attacker instanceof LivingEntity living && living.isAlive()) {
                    target = living;
                }
            }
            if (target != null && target.isAlive()) {
                net.minecraft.world.phys.Vec3 direction = target.getEyePosition()
                        .subtract(head.getEyePosition()).normalize();
                if (direction.lengthSqr() > 1.0E-6D) {
                    WitherSkull skull = new WitherSkull(level, head, direction);
                    skull.setPos(head.getEyePosition().add(direction.scale(0.2D)));
                    skull.setDangerous(false);
                    level.addFreshEntity(skull);
                }
            }
            return;
        }
        // 凋灵骷髅死亡时 10% 概率在原地产生怨灵。严格限定原版凋灵骷髅实体类型：
        // 怨灵本身（继承凋灵骷髅）与本模组各凋灵亚种死亡都不会再触发，杜绝链式生成。
        if (event.getEntity() instanceof WitherSkeleton skeleton
                && skeleton.getType() == EntityType.WITHER_SKELETON
                && skeleton.level() instanceof ServerLevel level) {
            if (level.random.nextFloat() < WITHER_SKELETON_GHOST_CHANCE) {
                WitherGhost ghost = WITHER_GHOST.get().create(level);
                if (ghost != null) {
                    ghost.setPos(skeleton.getX(), skeleton.getY(), skeleton.getZ());
                    ghost.finalizeSpawn(level, level.getCurrentDifficultyAt(ghost.blockPosition()),
                            MobSpawnType.MOB_SUMMONED, null);
                    level.addFreshEntity(ghost);
                }
            }
            return;
        }
        if (!(event.getEntity() instanceof Berserker berserker) || berserker.level().isClientSide()) return;
        if (berserker instanceof Bedserker bedserker && bedserker.isDetonated()) return;
        ServerLevel level = (ServerLevel) berserker.level();
        DamageSource source = event.getSource();
        Entity direct = source.getDirectEntity();
        Entity causing = source.getEntity();
        Creeper creeper = findIgnitedCreeper(direct, causing);
        if (creeper != null) {
            awardPlayer(level, creeper.getPersistentData(), CREEPER_IGNITER_TAG, berserker,
                    "fellow_pressure");
        }
        PrimedTnt tnt = findPrimedTnt(direct, causing);
        if (tnt != null) {
            LivingEntity owner = tnt.getOwner();
            if (owner instanceof ServerPlayer player) {
                award(player, level, berserker, "explosion_against_explosion");
            } else {
                awardNearestPlayer(level, berserker, "explosion_against_explosion");
            }
        }
        berserkerSelfDestructActive = true;
        try {
            level.explode(null, berserker.getX(), berserker.getY(), berserker.getZ(), 2.0F, Level.ExplosionInteraction.MOB);
        } finally {
            berserkerSelfDestructActive = false;
        }
        // 伤害半径取 4.0：与威力 2.0 爆炸原本的生物波及范围一致，
        // 剥除爆炸伤害后外圈不至于从"有衰减伤害"直接变成零伤害。
        for (Entity entity : level.getEntitiesOfClass(Entity.class, berserker.getBoundingBox().inflate(4.0D))) {
            if (entity instanceof net.minecraft.world.entity.LivingEntity living && entity != berserker) {
                double distance = living.distanceTo(berserker);
                if (distance <= 4.0D) {
                    // 自爆固定 10 点伤害；凋灵骷髅阵营（名册标签 + 头颅 + 传令兵）减半为 5 点。
                    float damage = LegionAuraHandler.isFactionMember(living) ? 5.0F : 10.0F;
                    living.hurt(level.damageSources().explosion(null, berserker), damage);
                }
                if (distance <= 2.0D) {
                    living.addEffect(new MobEffectInstance(MobEffects.WITHER, 200), berserker);
                }
            }
        }
    }

    private static Creeper findIgnitedCreeper(Entity direct, Entity causing) {
        if (direct instanceof Creeper creeper && creeper.getPersistentData().hasUUID(CREEPER_IGNITER_TAG)) {
            return creeper;
        }
        if (causing instanceof Creeper creeper && creeper.getPersistentData().hasUUID(CREEPER_IGNITER_TAG)) {
            return creeper;
        }
        return null;
    }

    private static PrimedTnt findPrimedTnt(Entity direct, Entity causing) {
        if (direct instanceof PrimedTnt tnt) {
            return tnt;
        }
        if (causing instanceof PrimedTnt tnt) {
            return tnt;
        }
        return null;
    }

    private static void awardPlayer(ServerLevel level, net.minecraft.nbt.CompoundTag data, String key,
                                    Berserker berserker, String advancementPath) {
        if (!data.hasUUID(key)) {
            return;
        }
        var player = level.getPlayerByUUID(data.getUUID(key));
        if (player instanceof ServerPlayer serverPlayer) {
            award(serverPlayer, level, berserker, advancementPath);
        }
    }

    private static void awardNearestPlayer(ServerLevel level, Berserker berserker, String advancementPath) {
        ServerPlayer nearest = level.getEntitiesOfClass(ServerPlayer.class,
                        berserker.getBoundingBox().inflate(32.0D), player -> true).stream()
                .min((left, right) -> Double.compare(left.distanceToSqr(berserker), right.distanceToSqr(berserker)))
                .orElse(null);
        if (nearest != null) {
            award(nearest, level, berserker, advancementPath);
        }
    }

    private static void award(ServerPlayer player, ServerLevel level, Berserker berserker, String advancementPath) {
        // 同行压力挂在以爆制爆之后：未完成 TNT 成就时不发放苦力怕成就。
        if ("fellow_pressure".equals(advancementPath)
                && !hasCompleted(player, level, "explosion_against_explosion")) {
            return;
        }
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(MOD_ID, advancementPath);
        var holder = level.getServer().getAdvancements().get(id);
        if (holder != null) {
            player.getAdvancements().award(holder, "killed_berserker");
        }
    }

    private static boolean hasCompleted(ServerPlayer player, ServerLevel level, String advancementPath) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(MOD_ID, advancementPath);
        var holder = level.getServer().getAdvancements().get(id);
        return holder != null && player.getAdvancements().getOrStartProgress(holder).isDone();
    }
}
