package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.GeneratedMod;
import cn.blockforge.generated.netherarmy.GravityReversalState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 重力反转的服务端半边：物理取负 + 给客户端留一份可见的状态。
 *
 * <p><b>物理：</b>把带效果的实体"默认重力"取负。1.21.1 的 {@code Entity#getGravity()}
 * （NeoForge 从 {@code getDefaultGravity} 接出来、且对 {@code isNoGravity()} 恒返回 0）是所有
 * 重力消费点的唯一入口：{@code Entity#applyGravity} 拿它做 {@code -d0}，
 * {@code LivingEntity#travel} 也读同一个值，因此只改这一处，坠落方向就整体翻转，
 * 不必去逐个覆写 {@code travel}。方法本身是 final，无法在子类覆写，只能用 Mixin。
 * 钩子同时作用于客户端与服务端：效果实例随 {@code ClientboundUpdateMobEffectPacket}
 * 同步到玩家，本地玩家的客户端预测因此和服务端算的是同一套重力，不会来回拉扯。</p>
 *
 * <p><b>状态同步：</b>1.21.1 的服务端<b>不同步非玩家生物的效果</b>，客户端 {@code hasEffect}
 * 对怪恒为 false，渲染半边会因此一直判定"没被反转"（详见
 * {@link GeneratedMod#GRAVITY_REVERSED}）。所以这里在 {@code Entity#baseTick} 末尾补一手：
 * 每个 tick 把实体的附件对齐到真实的效果状态，由 NeoForge 自动广播给正在追踪它的玩家。
 * 挂在 {@code baseTick} 而不是"效果增加/移除"事件上，是因为它能一次覆盖所有路径
 * （添加、续时长、自然到期、{@code /effect clear}、其他模组施加），漏一条也不会让怪物
 * 永久倒立。这个钩子和灵魂火状态用的是同一个（{@code SoulFireEntityMixin}）。</p>
 *
 * <p><b>与 {@link LivingEntityGravityReversalMixin} 的分工：</b>这个类只负责"重力取负 + 按目标
 * 速度缩放"，也就是定住稳态速度；负重力攒速度的起步还得靠那边绕开原版 {@code aiStep} 的
 * 竖直速度死区，否则第一步的 0.0018 会被清零、速度永远起不来。两处缺一不可。</p>
 */
@Mixin(Entity.class)
public abstract class EntityGravityReversalMixin {

    /**
     * 原版飘浮 I 的稳态上浮速度（格/tick）。
     *
     * <p>{@code LivingEntity#travel} 非流体分支里，飘浮走的是
     * {@code d2 += (0.05 * (amplifier + 1) - vec35.y) * 0.2}，随后竖直分量乘固定阻尼 0.98。
     * 令 y 为稳态速度，{@code y = 0.98 * (y + (0.05 - y) * 0.2)}，解得
     * {@code y = 0.05 * 0.98 * 0.2 / (1 - 0.98 * 0.8) ≈ 0.04537}。</p>
     */
    private static final double LEVITATION_I_ASCENT =
            0.05D * 0.98D * 0.2D / (1.0D - 0.98D * 0.8D);

    /** 需求速度：重力反转的上浮稳态速度 = 飘浮 I 的二倍（≈ 0.09074 格/tick）。 */
    private static final double TARGET_ASCENT = 2.0D * LEVITATION_I_ASCENT;

    /**
     * 上浮速度系数：把"负重力"按目标稳态速度缩放。
     *
     * <p>重力反转那条路上，{@code travel} 把 {@code d2 -= getGravity()} 之后同样乘 0.98，
     * 于是稳态速度 {@code y = 0.98 * (y + g)}，解得 {@code y = 0.98 / 0.02 * g = 49 g}；
     * 故所需重力 {@code g = TARGET_ASCENT / 49}。{@code getGravity()} 返回的是
     * {@code Attributes.GRAVITY}（初值 0.08），这里换算成相对系数
     * {@code ≈ 0.02315}，对重力属性被改过的生物也保持一致的比例。</p>
     */
    private static final double ASCENT_SPEED_SCALE =
            TARGET_ASCENT / (0.98D / (1.0D - 0.98D) * 0.08D);

    @Inject(method = "getGravity", at = @At("RETURN"), cancellable = true)
    private void netherarmy$reverseGravity(CallbackInfoReturnable<Double> cir) {
        // Mixin 里 this 的静态类型是混入类本身，直接 instanceof 目标类的子类过不了编译，
        // 先擦成 Object 再判。
        if (((Object) this) instanceof LivingEntity living
                && living.hasEffect(GeneratedMod.GRAVITY_REVERSAL)) {
            cir.setReturnValue(-cir.getReturnValueD() * ASCENT_SPEED_SCALE);
        }
    }

    /** 服务端每 tick 把"是否反转"写进同步附件，供客户端渲染半边判读。 */
    @Inject(method = "baseTick", at = @At("TAIL"))
    private void netherarmy$syncGravityReversalState(CallbackInfo callback) {
        Entity self = (Entity) (Object) this;
        if (self.level().isClientSide()) {
            return;
        }
        if (self instanceof LivingEntity living) {
            GravityReversalState.syncFromEffect(living);
        }
    }
}
