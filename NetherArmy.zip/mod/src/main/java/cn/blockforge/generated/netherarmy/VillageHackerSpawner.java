package cn.blockforge.generated.netherarmy;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.util.RandomSource;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** 在已加载的主世界村庄中补充黑客，每个村庄同时最多一只。 */
public final class VillageHackerSpawner {
    private static final long RETRY_TICKS = 6000L;
    private static final Map<Long, Long> LAST_SPAWN = new HashMap<>();
    private static int timer;

    private VillageHackerSpawner() {
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (++timer < 100) return;
        timer = 0;
        ServerLevel level = event.getServer().getLevel(Level.OVERWORLD);
        if (level == null || !level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)) return;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            StructureStart village = level.structureManager().getStructureWithPieceAt(
                    player.blockPosition(), StructureTags.VILLAGE);
            if (village == null || !village.isValid()) continue;
            long key = village.getChunkPos().toLong();
            BoundingBox box = village.getBoundingBox();
            AABB area = new AABB(box.minX(), box.minY(), box.minZ(),
                    box.maxX() + 1.0D, box.maxY() + 1.0D, box.maxZ() + 1.0D);
            if (!level.getEntitiesOfClass(Hacker.class, area).isEmpty()) continue;
            long now = level.getGameTime();
            if (now - LAST_SPAWN.getOrDefault(key, Long.MIN_VALUE) < RETRY_TICKS) continue;
            BlockPos spawn = findSpawn(level, village, player.getRandom(), box);
            if (spawn == null) continue;
            Hacker hacker = GeneratedMod.HACKER.get().create(level);
            if (hacker == null) continue;
            hacker.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                    player.getRandom().nextFloat() * 360.0F, 0.0F);
            hacker.finalizeSpawn(level, level.getCurrentDifficultyAt(spawn), MobSpawnType.EVENT, null);
            hacker.setPersistenceRequired();
            level.addFreshEntity(hacker);
            LAST_SPAWN.put(key, now);
        }
    }

    private static BlockPos findSpawn(ServerLevel level, StructureStart village, RandomSource random, BoundingBox box) {
        for (int attempt = 0; attempt < 32; attempt++) {
            int x = box.minX() + random.nextInt(Math.max(1, box.getXSpan() + 1));
            int z = box.minZ() + random.nextInt(Math.max(1, box.getZSpan() + 1));
            BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    new BlockPos(x, 0, z));
            if (!box.isInside(surface)) continue;
            BlockPos below = surface.below();
            BlockState floor = level.getBlockState(below);
            if (!floor.blocksMotion() || !level.getBlockState(surface).getFluidState().isEmpty()
                    || !level.getBlockState(surface.above()).getFluidState().isEmpty()) continue;
            if (!level.getBlockState(surface).isAir() || !level.getBlockState(surface.above()).isAir()) continue;
            if (!level.noCollision(GeneratedMod.HACKER.get().getDimensions().makeBoundingBox(
                    surface.getX() + 0.5D, surface.getY(), surface.getZ() + 0.5D))) continue;
            return surface;
        }
        return null;
    }
}
