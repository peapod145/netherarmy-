package cn.blockforge.generated.netherarmy;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** 皇家长剑的攻击无视护甲，玩家和怪物近战共用这一入口。 */
public final class RoyalLongswordDamageHandler {
    private RoyalLongswordDamageHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled() || event.getAmount() <= 0.0F
                || event.getEntity().level().isClientSide()) {
            return;
        }

        DamageSource source = event.getSource();
        if (!(source.is(DamageTypes.PLAYER_ATTACK)
                || source.is(DamageTypes.MOB_ATTACK)
                || source.is(DamageTypes.MOB_ATTACK_NO_AGGRO))) {
            return;
        }
        if (!(source.getEntity() instanceof LivingEntity attacker)) {
            return;
        }

        ItemStack weapon = attacker.getMainHandItem();
        if (weapon.is(GeneratedMod.ROYAL_LONGSWORD.get())) {
            event.getContainer().addModifier(DamageContainer.Reduction.ARMOR,
                    (container, reduction) -> 0.0F);
        }
    }
}
