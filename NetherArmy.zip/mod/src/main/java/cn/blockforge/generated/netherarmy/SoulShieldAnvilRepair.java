package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.stats.Stats;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * 亡魂重盾 / 地煞战斧 / 炼狱晶四件套的炼狱晶材料铁砧修复规则。
 *
 * <p>炼狱晶碎片（左槽任意一件支持修复的装备 + 右槽碎片）：每枚固定恢复 10 点耐久，
 * 等级花费为 0（不消耗经验）；产物是左槽的完整复制，仅改写耐久，不触碰 REPAIR_COST
 * 组件，因此反复修复也不会涨价。</p>
 *
 * <p>炼狱晶锭（左槽受损装备 + 右槽锭）：消耗一枚立即恢复满耐久，等级花费按"同一件
 * 装备此前锭修复次数"结算——第一次 500 级，之后每修一次 +250 级。次数写在产物的
 * {@code CUSTOM_DATA#netherarmy_crystal_ingot_repairs}，随装备正常存档、转移；
 * 左槽物品在拿取前不会被预览改写，反复摆弄槽位也不会把次数刷上去。</p>
 *
 * <p>实现说明：原版 {@link net.minecraft.world.inventory.AnvilMenu#mayPickup} 带有
 * cost>0 的硬编码条件，0 消耗的产物会被锁死在输出槽里拿不出来，因此这里把铁砧交互
 * 整体接管到自己的 {@link SoulShieldAnvilMenu}（仅放行该状态）。而锭修复的 500+ 级
 * 花费没有"Too Expensive"上限问题：NeoForge 的 {@code CommonHooks#onAnvilChange}
 * 把事件 cost 直接写进同步的 cost DataSlot，并在事件产出有效结果时提前 return，
 * 跳过原版 createResult 尾部 {@code cost >= 40} 的清产物判定，mayPickup 本身只要求
 * {@code experienceLevel >= cost}。</p>
 */
public final class SoulShieldAnvilRepair {
    /** 每枚炼狱晶碎片恢复的耐久点数。 */
    public static final int REPAIR_PER_SHARD = 10;
    /** 使用炼狱晶锭恢复满耐久时，同一件装备第一次的等级花费。 */
    public static final int FULL_REPAIR_BASE_COST = 500;
    /** 同一件装备每多做一次锭修复追加的等级花费。 */
    public static final int FULL_REPAIR_COST_INCREMENT = 250;

    /** 物品 CUSTOM_DATA 中记录"此前已用过多少枚炼狱晶锭"的键。 */
    static final String INGET_REPAIR_COUNT_KEY = "netherarmy_crystal_ingot_repairs";

    private static final Component REPAIR_TITLE = Component.translatable("container.repair");

    private SoulShieldAnvilRepair() {
    }

    /** 支持炼狱晶碎片免经验修复、也支持炼狱晶锭付费满耐久修复的物品。 */
    private static boolean isCrystalRepairable(ItemStack stack) {
        return stack.is(GeneratedMod.SOUL_SHIELD.get())
                || stack.is(GeneratedMod.DISHA_BATTLE_AXE.get())
                || stack.is(GeneratedMod.ROYAL_LONGSWORD.get())
                || stack.is(GeneratedMod.NETHER_CRYSTAL_HELMET.get())
                || stack.is(GeneratedMod.NETHER_CRYSTAL_CHESTPLATE.get())
                || stack.is(GeneratedMod.NETHER_CRYSTAL_LEGGINGS.get())
                || stack.is(GeneratedMod.NETHER_CRYSTAL_BOOTS.get());
    }

    @SubscribeEvent
    public static void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack material = event.getRight();
        if (!isCrystalRepairable(left) || material.isEmpty()) {
            return;
        }
        // 玩家正在输入重命名时让位给原版逻辑（改名优先，与既有碎片规则保持一致）。
        if (event.getName() != null && !event.getName().isBlank()) {
            return;
        }
        if (material.is(GeneratedMod.NETHER_CRYSTAL_SHARD.get())) {
            applyShardRepair(event, left, material);
        } else if (material.is(GeneratedMod.NETHER_CRYSTAL_INGOT.get())) {
            applyIngotRepair(event, left);
        }
    }

    /** 碎片修复：每枚 +10 耐久、0 经验、不涨价；只吃掉真正需要的数量。 */
    private static void applyShardRepair(AnvilUpdateEvent event, ItemStack left, ItemStack shards) {
        int damage = left.getDamageValue();
        if (damage <= 0) {
            return;
        }
        int used = Math.min(shards.getCount(), (damage + REPAIR_PER_SHARD - 1) / REPAIR_PER_SHARD);
        ItemStack output = left.copy();
        output.setDamageValue(Math.max(0, damage - used * REPAIR_PER_SHARD));
        event.setOutput(output);
        event.setCost(0L);
        event.setMaterialCost(used);
    }

    /** 锭修复：1 枚锭立即回满，费用 500 + 250×该件历史锭修复次数；产物把次数 +1。 */
    private static void applyIngotRepair(AnvilUpdateEvent event, ItemStack left) {
        int damage = left.getDamageValue();
        if (damage <= 0) {
            // 满耐久还放锭：这套专属规则无事可做，也不让原版拿锭做 25% 的部分修复/涨修理费。
            event.setCanceled(true);
            return;
        }
        long previous = readIngotRepairCount(left);
        ItemStack output = left.copy();
        output.setDamageValue(0);
        CompoundTag custom = output.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        custom.putInt(INGET_REPAIR_COUNT_KEY, (int) Math.min(Integer.MAX_VALUE - 1L, previous + 1L));
        output.set(DataComponents.CUSTOM_DATA, CustomData.of(custom));
        event.setOutput(output);
        event.setCost(FULL_REPAIR_BASE_COST + (long) FULL_REPAIR_COST_INCREMENT * previous);
        event.setMaterialCost(1);
    }

    /** 读取该件装备历史锭修复次数；缺失或非 int 时按 0 处理。 */
    private static long readIngotRepairCount(ItemStack stack) {
        CustomData customData = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        CompoundTag tag = customData.copyTag();
        if (!tag.contains(INGET_REPAIR_COUNT_KEY, CompoundTag.TAG_INT)) {
            return 0L;
        }
        return Math.max(0, tag.getInt(INGET_REPAIR_COUNT_KEY));
    }

    @SubscribeEvent
    public static void onRightClickAnvil(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        if (level.isClientSide() || event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        BlockPos pos = event.getPos();
        if (!level.getBlockState(pos).is(BlockTags.ANVIL)) {
            return;
        }
        Player player = event.getEntity();
        if (player.isSpectator()) {
            return;
        }
        // 复刻原版 ServerPlayerGameMode#useItemOn 的潜行判定：这种点击原版本来就不会开界面，不要插手。
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        boolean hasHeld = !main.isEmpty() || !off.isEmpty();
        boolean skipBlockUse = player.isSecondaryUseActive() && hasHeld
                && !(main.doesSneakBypassUse(level, pos, player) && off.doesSneakBypassUse(level, pos, player));
        if (skipBlockUse) {
            return;
        }
        event.setCanceled(true);
        player.openMenu(new SimpleMenuProvider(
                (windowId, inventory, user) -> new SoulShieldAnvilMenu(windowId, inventory,
                        ContainerLevelAccess.create(level, pos)), REPAIR_TITLE), pos);
        player.awardStat(Stats.INTERACT_WITH_ANVIL);
    }
}
