package cn.blockforge.generated.netherarmy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.UUID;

/**
 * 运兵车的隐形判定盒（车头一具、车尾一具）：整车长 9.94 格，而 Java 实体判定箱只能是
 * 正方形（3.7×4.4 已顶到下界要塞走廊的宽度上限），一条 AABB 罩不住前后两头——上一轮
 * 把模型前移 2 格让判定箱罩住后半截之后，探出约 5.1 格的车头就变成了"打不着、瞄不上、
 * F3 里没有判定线"的空白区。本类把缺失的前、后两截补成<b>真实体</b>：
 *
 * <ul>
 *   <li><b>攻击判定</b>：十字准星拾取、近战射线、弹道命中、爆炸索敌、F3 判定线走的全是
 *       {@code Entity#getBoundingBox()}，所以只有把车头做成有盒子的实体才可能被"打到"。
 *       命中本盒即等价命中运兵车：{@link #hurt} 原额转发 {@link NetherCarrier#hurt}，
 *       镐类 ×5 无视护甲、受击黑烟爆发、10% 受击召唤等规则全部走本尊一条代码路径。</li>
 *   <li><b>跟随定位</b>：本实体以<b>乘客</b>身份挂在运兵车上，位置每 tick 由
 *       {@link NetherCarrier#positionRider} 按车头向量现算（服务端与客户端都跑，
 *       转向时判定盒跟着转）。借原版乘客机制的另外两个红利：存档时随本尊嵌套保存、
 *       读档自动重新挂好；且 {@code canCollideWith} 天然跳过"同车乘客"，判定盒永远不会
 *       反过来卡住运兵车自己走路（当初抽搐的病根就是判定与移动打架，不能复发）。</li>
 *   <li><b>不挡道</b>：{@link #canBeCollidedWith()} 恒为 {@code false}——车头区不设实体
 *       碰撞。这是刻意的：正面撞击的 5 格弹道就是从鼻尖盒里穿出去的，判定盒一旦实体化
 *       会把被撞玩家半路拦下；而"站进车头"本来就会被 {@link NetherCarrier} 的接触伤害
 *       （2 点/tick）与撞击击退立刻请出去，不需要一堵看不见的墙。</li>
 * </ul>
 *
 * <p>本类不是 {@code Mob} 也不是 {@code LivingEntity}：没有 AI、不能被索敌、不掉落、
 * 不吃摔落/燃烧，军团阵营与精神控制那套 {@code instanceof Mob} 的过滤器都天然跳过它。
 * 渲染端注册的是空渲染器，画面上一切仍由运兵车自己的模型呈现，本盒只存在"判定"。</p>
 */
public class CarrierHitbox extends Entity {

    public static final int KIND_NOSE = 0;
    public static final int KIND_REAR = 1;

    /**
     * 车头盒：3.6 宽 × 3.2 高 × 5.2 长。长 5.2 = 从主判定箱前缘（锚点前 1.85）
     * 一直盖到车鼻末端（约 +6.97）还多 0.08；高 3.2 取前机舱罩 + 撞角顶板的高度，
     * 玩家平视挥剑的射线（眼高 ~1.6）稳稳落在盒内。
     */
    static final EntityDimensions NOSE_DIMENSIONS = EntityDimensions.scalable(3.6F, 3.2F);
    /** 车尾盒：3.6 宽 × 4.4 高 × 1.6 长，贴住主判定箱后缘，罩住探出的后货台。 */
    static final EntityDimensions REAR_DIMENSIONS = EntityDimensions.scalable(3.6F, 4.4F);

    /** 车头盒中心在锚点前方的距离（格）：1.85（主箱半深）+ 5.2/2。 */
    static final double NOSE_CENTER_AHEAD = 4.45D;
    /** 车尾盒中心在锚点后方的距离（格）：1.85 + 1.6/2。 */
    static final double REAR_CENTER_BEHIND = 2.65D;

    /** 与本尊失联（区块切换等）后的宽限，超过就自我清除，避免游离的隐形判定盒。 */
    private static final int ORPHAN_GRACE_TICKS = 60;

    private static final EntityDataAccessor<Byte> DATA_KIND =
            SynchedEntityData.defineId(CarrierHitbox.class, EntityDataSerializers.BYTE);

    private UUID owner;
    private int orphanTicks;

    public CarrierHitbox(EntityType<? extends CarrierHitbox> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
        this.setSilent(true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_KIND, (byte) KIND_NOSE);
    }

    /** 生成侧调用：绑定本尊与盒种（先写数据再入世界，保证加入包/同步包带上正确形态）。 */
    void setup(NetherCarrier carrier, int kind) {
        this.owner = carrier.getUUID();
        this.entityData.set(DATA_KIND, (byte) kind);
        this.setPos(this.getX(), this.getY(), this.getZ());
    }

    int getKind() {
        return this.entityData.get(DATA_KIND);
    }

    /** 盒种对应的锚距：正值=车头方向，负值=车尾方向（沿 {@link NetherCarrier} 车头向量）。 */
    double anchorOffset() {
        return this.getKind() == KIND_NOSE ? NOSE_CENTER_AHEAD : -REAR_CENTER_BEHIND;
    }

    private EntityDimensions kindDimensions() {
        return this.getKind() == KIND_NOSE ? NOSE_DIMENSIONS : REAR_DIMENSIONS;
    }

    /** 同一种实体装两种尺寸：类型级 sized() 只是兜底，真正盒子按盒种现算。 */
    @Override
    protected AABB makeBoundingBox() {
        return this.kindDimensions().makeBoundingBox(this.position());
    }

    /** 读档/挂接都会触发 refreshDimensions，把它也钉在盒种尺寸上（父类按类型尺寸算）。 */
    @Override
    public void refreshDimensions() {
        this.setBoundingBox(this.makeBoundingBox());
    }

    /** 运兵车本尊：优先取载具指针，失联时按 UUID 找回（区块重载竞态宽限期内用）。 */
    NetherCarrier carrier() {
        if (this.getVehicle() instanceof NetherCarrier carrier) {
            return carrier;
        }
        if (this.owner == null || !(this.level() instanceof ServerLevel server)) {
            return null;
        }
        return server.getEntity(this.owner) instanceof NetherCarrier carrier ? carrier : null;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            return;
        }
        NetherCarrier carrier = this.carrier();
        if (carrier == null) {
            if (++this.orphanTicks > ORPHAN_GRACE_TICKS) {
                this.discard();
            }
            return;
        }
        this.orphanTicks = 0;
        if (!carrier.isAlive()) {
            // 本尊死亡动画期间判定盒就该退场；死亡爆炸等残余伤害在 hurt 里另有自伤闸门。
            this.discard();
            return;
        }
        if (this.getVehicle() == null) {
            this.startRiding(carrier, true);
            this.refreshDimensions();
        }
    }

    /** 命中本盒 = 命中本尊：全额原样转发，所有伤害规则（镐 ×5、无视护甲、爆发烟）不旁落。 */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide()) {
            return false;
        }
        NetherCarrier carrier = this.carrier();
        if (carrier == null || !carrier.isAlive()) {
            return false;
        }
        // 本尊自己的接触伤害/死亡爆炸永远不该绕进自家判定盒再打回本尊。
        if (source.getEntity() == carrier || source.getDirectEntity() == carrier) {
            return false;
        }
        return carrier.hurt(source, amount);
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean canBeHitByProjectile() {
        return true;
    }

    /** 隐形、可打、但不挡道（理由见类注释"不挡道"条）。 */
    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    /** 不参与活塞推动之类的位移（本来每 tick 就被钉回锚位）。 */
    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(Entity entity) {
        // 本盒不推任何人，也不被谁推着走。
    }

    @Override
    public void push(double x, double y, double z) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(DATA_KIND, (byte) tag.getInt("CarrierHitboxKind"));
        if (tag.hasUUID("CarrierHitboxOwner")) {
            this.owner = tag.getUUID("CarrierHitboxOwner");
        }
        this.refreshDimensions();
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("CarrierHitboxKind", this.getKind());
        if (this.owner != null) {
            tag.putUUID("CarrierHitboxOwner", this.owner);
        }
    }

    /** 占位姿态接口：本盒永远是 STAND_UP 的方盒。 */
    @Override
    public Pose getPose() {
        return Pose.STANDING;
    }
}
