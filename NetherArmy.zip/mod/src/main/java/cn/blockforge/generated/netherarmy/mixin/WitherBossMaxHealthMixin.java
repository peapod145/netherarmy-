package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.world.entity.boss.wither.WitherBoss;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * 凋灵血量上限 300 → 600：改写 {@code WitherBoss#createAttributes} 里
 * {@code Attributes.MAX_HEALTH} 的属性底常量。
 *
 * <p>原版那一行是 {@code .add(Attributes.MAX_HEALTH, 300.0)}，方法体内
 * {@code 300.0d} 只出现这一次，用 {@link ModifyConstant} 精确命中。走 Mixin 而不是
 * 在服务端 tick 里 {@code setBaseValue} 覆写，是因为属性底需要<b>双侧</b>一致：
 * 客户端的凋灵护甲外观与二阶段光效由原版 {@code isPowered()}（血量 ≤ 上限一半）
 * 驱动，血量数据走实体同步、上限却读客户端本地的属性表；只改服务端的 600 会让
 * 客户端继续按 300 的上限算半血线（150），护甲外观比服务端的真实阶段晚一截。
 * 这里改的是构造属性表的静态工厂，客户端、服务端、{@code /summon}、方块召唤与
 * 下界反应堆等所有生成路径一次到位。</p>
 *
 * <p>二阶段阈值随上限自动平移：原版 {@code isPowered()} 与
 * {@code WitherEnhancementHandler#isPhaseTwo} 都是"血量 ≤ 上限的一半"的比例口径，
 * 上限 600 后半血线即 300，无需再动任何阶段判定。召唤动画的 1/3 起步也按新上限
 * 结算（600/3 = 200），动画回血节奏的补偿见
 * {@code WitherEnhancementHandler#topOffSpawnAnimation}。</p>
 */
@Mixin(WitherBoss.class)
public abstract class WitherBossMaxHealthMixin {
    /** 目标血量上限：原版 300 翻倍到 600。 */
    private static final double BOOSTED_MAX_HEALTH = 600.0D;

    @ModifyConstant(method = "createAttributes", constant = @Constant(doubleValue = 300.0D))
    private static double netherarmy$boostMaxHealthBase(double constant) {
        return BOOSTED_MAX_HEALTH;
    }
}
