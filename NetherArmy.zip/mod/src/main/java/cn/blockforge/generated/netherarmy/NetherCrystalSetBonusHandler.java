package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingHealEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * 炼狱晶套的运行时能力结算（全部服务端）。
 *
 * <p>四类逻辑：</p>
 * <ol>
 *   <li>单件伤害减免（{@link LivingIncomingDamageEvent}）：按佩戴部位对指定伤害类别
 *       乘 0.75。头盔管溺水（{@code is_drowning}）、窒息（{@code in_wall}，即卡在
 *       方块里的原版伤害类型）、弹射物（{@code is_projectile}）；胸甲管近战（直接
 *       伤害源是活体且不带弹射物标签）、爆炸（{@code is_explosion}）、魔法
 *       （{@code minecraft:magic} 与 {@code minecraft:indirect_magic}）；护腿管火焰
 *       （{@code is_fire}，含燃烧/岩浆/火球）、饥饿（{@code minecraft:starve}）、
 *       细雪冰冻（{@code is_freezing}）；靴子管摔落（{@code is_fall}）与鞘翅撞墙
 *       动能伤害（{@code minecraft:fly_into_wall}，1.21 起原版鞘翅高速撞墙专用
 *       伤害类型）。</li>
 *   <li>回血速度 +25%（{@link LivingHealEvent}）：佩戴胸甲时所有治疗量乘 1.25。
 *       原版自然回血（{@code Player#tick} 的 {@code heal(1)}）与再生效果都走
 *       {@code LivingEntity#heal}，治疗量放大 25% 与"回血速度 +25%"在稳态下等价。</li>
 *   <li>buff 时长缩放（{@link MobEffectEvent.Applicable}）：该事件在
 *       {@code addEffect} 合并进实体之前触发，拿到的就是即将入库的实例对象，
 *       通过 mixin 访问器直接改写 duration，对"新施加"和"刷新叠加"两条路径都生效。
 *       胸甲：有益效果 ×1.25；护腿：有害效果 ×0.75。无限时长（-1）与瞬时（0）不动。</li>
 *   <li>套装效果（{@link PlayerTickEvent.Post} + {@link EntityTickEvent.Post}）：
 *       ≥2 件生命上限 +10 与力量 I，≥3 件追加抗性提升 I、急迫 I、速度 I，≥4 件再
 *       +10 生命上限并把四个效果升到 II。生命上限走两条独立的 transient 属性修饰符
 *       （2 件档、4 件档各 +10，四件共 +20），效果走无限时长隐藏 MobEffectInstance；
 *       死亡重生后属性与效果都会重建，因此每 tick 按当前件数对账补齐，无需额外事件钩子。
 *       <b>玩家和怪物走同一套结算</b>：怪物（含地狱军团自生成怪、被发射器/拾取穿上这套的
 *       任意活体）穿戴时同样凑件数、同样吃减伤与套装加成；急迫只影响挖矿速度，
 *       所以只给玩家挂，怪物省掉这个无意义的效果实例。</li>
 * </ol>
 *
 * <p>前三类逻辑挂在 {@code LivingEntity} 维度的事件上，本来就对所有活体生效；
 * 属性类能力（护甲、韧性、击退抗性、氧气加成、游泳/移动速度、跳跃强度）由原版
 * {@code LivingEntity#collectEquipmentChanges} 每 tick 按装备槽应用物品属性修饰符，
 * 玩家与怪物共用这条路径，因此怪物穿上就直接生效。只有饥饿消耗 -25%（靴子）
 * 依赖玩家的疲劳度入口——怪物没有饥饿值，这条对怪物天然无意义。</p>
 */
public final class NetherCrystalSetBonusHandler {
    private NetherCrystalSetBonusHandler() {
    }

    private static ResourceLocation id(String name) {
        return ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, name);
    }

    /** 2 件档生命上限 +10。 */
    private static final ResourceLocation SET_MAX_HEALTH_TIER2 = id("nether_crystal_set_max_health_tier2");
    /** 4 件档生命上限再 +10（与 2 件档叠加，四件共 +20）。 */
    private static final ResourceLocation SET_MAX_HEALTH_TIER4 = id("nether_crystal_set_max_health_tier4");

    private static boolean isNetherCrystal(ItemStack stack) {
        return stack.getItem() instanceof NetherCrystalArmorItem;
    }

    private static int equippedPieces(LivingEntity entity) {
        int count = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (isNetherCrystal(entity.getItemBySlot(slot))) {
                count++;
            }
        }
        return count;
    }

    private static boolean wearing(LivingEntity entity, EquipmentSlot slot) {
        return isNetherCrystal(entity.getItemBySlot(slot));
    }

    // ------------------------------------------------------------------
    // 1. 单件伤害减免
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity entity = event.getEntity();
        DamageSource source = event.getSource();
        float amount = event.getAmount();
        boolean applied = false;

        if (wearing(entity, EquipmentSlot.HEAD)
                && (source.is(DamageTypeTags.IS_DROWNING)
                || source.is(DamageTypes.IN_WALL)
                || source.is(DamageTypeTags.IS_PROJECTILE))) {
            amount *= 0.75F;
            applied = true;
        }
        if (wearing(entity, EquipmentSlot.CHEST)
                && (isMeleeAttack(source)
                || source.is(DamageTypeTags.IS_EXPLOSION)
                || source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC))) {
            amount *= 0.75F;
            applied = true;
        }
        if (wearing(entity, EquipmentSlot.LEGS)
                && (source.is(DamageTypeTags.IS_FIRE)
                || source.is(DamageTypes.STARVE)
                || source.is(DamageTypeTags.IS_FREEZING))) {
            amount *= 0.75F;
            applied = true;
        }
        if (wearing(entity, EquipmentSlot.FEET)
                && (source.is(DamageTypeTags.IS_FALL)
                || source.is(DamageTypes.FLY_INTO_WALL))) {
            amount *= 0.75F;
            applied = true;
        }
        if (applied) {
            event.setAmount(amount);
        }
    }

    /**
     * 近战伤害判定：直接伤害源是活体实体且不属于弹射物。覆盖玩家攻击
     * （{@code player_attack}）、怪物近战（{@code mob_attack}）等所有"贴脸"来源；
     * 弓箭、三叉戟、火球等带 IS_PROJECTILE 标签的都不算近战。
     */
    private static boolean isMeleeAttack(DamageSource source) {
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            return false;
        }
        Entity direct = source.getDirectEntity();
        return direct instanceof LivingEntity;
    }

    // ------------------------------------------------------------------
    // 2. 胸甲：回血速度 +25%
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onLivingHeal(LivingHealEvent event) {
        if (wearing(event.getEntity(), EquipmentSlot.CHEST)) {
            event.setAmount(event.getAmount() * 1.25F);
        }
    }

    // ------------------------------------------------------------------
    // 3. 胸甲/护腿：buff 时长缩放
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onEffectApplicable(MobEffectEvent.Applicable event) {
        LivingEntity entity = event.getEntity();
        // 只在服务端缩放：客户端收到同步包后也会走 addEffect，若再乘一次会让
        // HUD 显示的剩余时长比真实值长（服务端才是权威时长）。
        if (entity.level().isClientSide()) {
            return;
        }
        MobEffectInstance instance = event.getEffectInstance();
        int duration = instance.getDuration();
        // 无限时长（-1）与瞬时效果（0）不参与缩放。
        if (duration <= 0) {
            return;
        }
        MobEffectCategory category = instance.getEffect().value().getCategory();
        cn.blockforge.generated.netherarmy.mixin.MobEffectInstanceDurationAccess access =
                (cn.blockforge.generated.netherarmy.mixin.MobEffectInstanceDurationAccess) instance;
        if (category == MobEffectCategory.BENEFICIAL && wearing(entity, EquipmentSlot.CHEST)) {
            access.netherarmy$setDuration(Math.max(1, duration * 5 / 4));
        } else if (category == MobEffectCategory.HARMFUL && wearing(entity, EquipmentSlot.LEGS)) {
            access.netherarmy$setDuration(Math.max(1, duration * 3 / 4));
        }
    }

    // ------------------------------------------------------------------
    // 4. 套装效果（玩家与怪物等所有活体实体通用）
    // ------------------------------------------------------------------

    /**
     * 玩家走 {@link PlayerTickEvent.Post}：{@code ServerPlayer} 不在
     * {@code ServerLevel} 的实体 tick 列表里，由 {@code PlayerList#tick} 直接 tick，
     * 收不到 {@link EntityTickEvent.Post}。
     */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        syncSetBonus(event.getEntity());
    }

    /** 玩家以外的全部活体实体：怪物、穿戴装备的动物、盔甲架等（含骑乘中的实体）。 */
    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity entity) || entity instanceof Player) {
            return;
        }
        syncSetBonus(entity);
    }

    private static void syncSetBonus(LivingEntity entity) {
        if (entity.level().isClientSide()) {
            return;
        }
        int pieces = equippedPieces(entity);
        // 没凑到 2 件、身上也没有我们挂过的套装加成时直接返回：这样满世界的普通怪物
        // 每 tick 只多花 4 次数组读 + 两次属性哈希查，不增加属性/效果遍历开销。
        if (pieces < 2 && !carriesSetBonus(entity)) {
            return;
        }
        syncMaxHealthModifier(entity, SET_MAX_HEALTH_TIER2, pieces >= 2);
        syncMaxHealthModifier(entity, SET_MAX_HEALTH_TIER4, pieces >= 4);

        // 力量：≥2 件 I，≥4 件 II。
        syncSetEffect(entity, MobEffects.DAMAGE_BOOST, tierAmplifier(pieces, 2, 4));
        // 抗性提升 / 速度：≥3 件 I，≥4 件 II。
        Integer lateTierAmp = tierAmplifier(pieces, 3, 4);
        syncSetEffect(entity, MobEffects.DAMAGE_RESISTANCE, lateTierAmp);
        syncSetEffect(entity, MobEffects.MOVEMENT_SPEED, lateTierAmp);
        // 急迫只作用于挖掘速度，怪物用不上，省掉一个空转的效果实例。
        if (entity instanceof Player) {
            syncSetEffect(entity, MobEffects.DIG_SPEED, lateTierAmp);
        }
    }

    /** 凑够 {@code tier1Pieces} 件给 I（amplifier 0），凑够 {@code tier2Pieces} 件给 II，否则 null。 */
    private static Integer tierAmplifier(int pieces, int tier1Pieces, int tier2Pieces) {
        if (pieces >= tier2Pieces) {
            return Integer.valueOf(1);
        }
        if (pieces >= tier1Pieces) {
            return Integer.valueOf(0);
        }
        return null;
    }

    /**
     * 这个实体身上是否还留着本套装挂过的加成（掉到 2 件以下时需要清理）。
     * 效果实例会随实体存进 NBT，属性修饰符是 transient 不会存，所以重载后可能出现
     * "只剩隐藏效果"的实体，两道都要查一遍才能彻底清干净。
     */
    private static boolean carriesSetBonus(LivingEntity entity) {
        AttributeInstance maxHealth = entity.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null && (maxHealth.getModifier(SET_MAX_HEALTH_TIER2) != null
                || maxHealth.getModifier(SET_MAX_HEALTH_TIER4) != null)) {
            return true;
        }
        if (entity.getActiveEffects().isEmpty()) {
            return false;
        }
        return isSetBonusEffect(entity.getEffect(MobEffects.DAMAGE_BOOST))
                || isSetBonusEffect(entity.getEffect(MobEffects.DAMAGE_RESISTANCE))
                || isSetBonusEffect(entity.getEffect(MobEffects.MOVEMENT_SPEED))
                || isSetBonusEffect(entity.getEffect(MobEffects.DIG_SPEED));
    }

    private static void syncMaxHealthModifier(LivingEntity entity, ResourceLocation modifierId, boolean wanted) {
        AttributeInstance instance = entity.getAttribute(Attributes.MAX_HEALTH);
        if (instance == null) {
            return;
        }
        boolean present = instance.getModifier(modifierId) != null;
        if (wanted && !present) {
            float healthBefore = entity.getHealth();
            float maxBefore = entity.getMaxHealth();
            instance.addTransientModifier(new AttributeModifier(modifierId, 10.0D,
                    AttributeModifier.Operation.ADD_VALUE));
            // 刚穿上就满血的对象（新刷出来、被发射器穿满一套的怪物尤其明显）把血量一起抬到
            // 新上限，否则它的血条会一直显示"缺 5 颗心"；已经受伤的对象不趁机白回血。
            if (entity.isAlive() && healthBefore >= maxBefore) {
                entity.setHealth(entity.getMaxHealth());
            }
        } else if (!wanted && present) {
            instance.removeModifier(modifierId);
            if (entity.getHealth() > entity.getMaxHealth()) {
                entity.setHealth(entity.getMaxHealth());
            }
        }
    }

    /**
     * 本套装挂的效果长什么样：无限时长 + 不显示图标不冒粒子。用它区分"我们的效果"和
     * 信标/药水等外部来源给的同名效果——外部来源的都是可见有限时长，不会被我们改写或移除
     * （否则药水增益会被刷成永久，或信标力量被套装掉件时顺手吞掉）。
     */
    private static boolean isSetBonusEffect(MobEffectInstance instance) {
        return instance != null && instance.getDuration() == MobEffectInstance.INFINITE_DURATION
                && !instance.isVisible();
    }

    /**
     * 对齐一个套装效果的有无与等级。隐藏（visible=false）：不刷 HUD 图标也不冒粒子，
     * 效果本身照常生效，说明全部写在物品提示里。
     */
    private static void syncSetEffect(LivingEntity entity, Holder<MobEffect> effect, Integer desiredAmp) {
        MobEffectInstance current = entity.getEffect(effect);
        if (current != null && !isSetBonusEffect(current)) {
            // 这个效果位被外部来源（信标、药水、怪物自身技能）占着，让位不动它。
            return;
        }
        if (desiredAmp == null) {
            if (current != null) {
                entity.removeEffect(effect);
            }
            return;
        }
        if (current != null && current.getAmplifier() == desiredAmp.intValue()) {
            return;
        }
        if (current != null) {
            // addEffect 的合并逻辑只升不降，掉档时必须先移除再挂新等级。
            entity.removeEffect(effect);
        }
        entity.addEffect(new MobEffectInstance(effect, MobEffectInstance.INFINITE_DURATION,
                desiredAmp.intValue(), false, false));
    }
}
