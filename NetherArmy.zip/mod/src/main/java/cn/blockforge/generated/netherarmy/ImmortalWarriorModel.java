package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 不死武士模型：直接由用户提供的 immortal_warrior-6.bbmodel 生成。
 *
 * <p>所有骨骼枢轴使用原版凋灵骷髅/SkeletonModel 坐标；上传文件中的方块、
 * 护甲几何和逐面 UV 原样发射，躯干旧导出偏移只在生成阶段归零。</p>
 */
public final class ImmortalWarriorModel extends SkeletonModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "immortal_warrior"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 64;
    private final ModelPart root;

    private static final float[] HEAD = {
        4.0F, -8.0F, -4.0F, -4.0F, -8.0F, -4.0F, -4.0F, 0.0F, -4.0F, 4.0F,
        0.0F, -4.0F, 8.0F, 8.0F, 16.0F, 16.0F, 0.0F, 0.0F, -1.0F, -4.0F,
        -8.0F, 4.0F, 4.0F, -8.0F, 4.0F, 4.0F, 0.0F, 4.0F, -4.0F, 0.0F,
        4.0F, 24.0F, 8.0F, 32.0F, 16.0F, 0.0F, 0.0F, 1.0F, 4.0F, -8.0F,
        4.0F, 4.0F, -8.0F, -4.0F, 4.0F, 0.0F, -4.0F, 4.0F, 0.0F, 4.0F,
        0.0F, 8.0F, 8.0F, 16.0F, 1.0F, 0.0F, 0.0F, -4.0F, -8.0F, -4.0F,
        -4.0F, -8.0F, 4.0F, -4.0F, 0.0F, 4.0F, -4.0F, 0.0F, -4.0F, 16.0F,
        8.0F, 24.0F, 16.0F, -1.0F, 0.0F, 0.0F, -4.0F, -8.0F, -4.0F, 4.0F,
        -8.0F, -4.0F, 4.0F, -8.0F, 4.0F, -4.0F, -8.0F, 4.0F, 16.0F, 8.0F,
        8.0F, 0.0F, 0.0F, -1.0F, 0.0F, -4.0F, 0.0F, 4.0F, 4.0F, 0.0F,
        4.0F, 4.0F, 0.0F, -4.0F, -4.0F, 0.0F, -4.0F, 24.0F, 0.0F, 16.0F,
        8.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] HEADWEAR = {
        4.0F, -8.5F, -4.0F, -4.0F, -8.5F, -4.0F, -4.0F, -6.5F, -4.0F, 4.0F,
        -6.5F, -4.0F, 40.0F, 8.0F, 48.0F, 10.0F, 0.0F, 0.0F, -1.0F, -4.0F,
        -8.5F, 4.0F, 4.0F, -8.5F, 4.0F, 4.0F, -6.5F, 4.0F, -4.0F, -6.5F,
        4.0F, 56.0F, 8.0F, 64.0F, 10.0F, 0.0F, 0.0F, 1.0F, 4.0F, -8.5F,
        4.0F, 4.0F, -8.5F, -4.0F, 4.0F, -6.5F, -4.0F, 4.0F, -6.5F, 4.0F,
        32.0F, 8.0F, 40.0F, 10.0F, 1.0F, 0.0F, 0.0F, -4.0F, -8.5F, -4.0F,
        -4.0F, -8.5F, 4.0F, -4.0F, -6.5F, 4.0F, -4.0F, -6.5F, -4.0F, 48.0F,
        8.0F, 56.0F, 10.0F, -1.0F, 0.0F, 0.0F, -4.0F, -8.5F, -4.0F, 4.0F,
        -8.5F, -4.0F, 4.0F, -8.5F, 4.0F, -4.0F, -8.5F, 4.0F, 48.0F, 8.0F,
        40.0F, 0.0F, 0.0F, -1.0F, 0.0F, -4.0F, -6.5F, 4.0F, 4.0F, -6.5F,
        4.0F, 4.0F, -6.5F, -4.0F, -4.0F, -6.5F, -4.0F, 56.0F, 0.0F, 48.0F,
        8.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] BODY = {
        4.0F, 0.0F, -2.0F, -4.0F, 0.0F, -2.0F, -4.0F, 12.0F, -2.0F, 4.0F,
        12.0F, -2.0F, 20.0F, 20.0F, 28.0F, 32.0F, 0.0F, 0.0F, -1.0F, -4.0F,
        0.0F, 2.0F, 4.0F, 0.0F, 2.0F, 4.0F, 12.0F, 2.0F, -4.0F, 12.0F,
        2.0F, 32.0F, 20.0F, 40.0F, 32.0F, 0.0F, 0.0F, 1.0F, 4.0F, 0.0F,
        2.0F, 4.0F, 0.0F, -2.0F, 4.0F, 12.0F, -2.0F, 4.0F, 12.0F, 2.0F,
        16.0F, 20.0F, 20.0F, 32.0F, 1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F,
        -4.0F, 0.0F, 2.0F, -4.0F, 12.0F, 2.0F, -4.0F, 12.0F, -2.0F, 28.0F,
        20.0F, 32.0F, 32.0F, -1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F, 4.0F,
        0.0F, -2.0F, 4.0F, 0.0F, 2.0F, -4.0F, 0.0F, 2.0F, 28.0F, 20.0F,
        20.0F, 16.0F, 0.0F, -1.0F, 0.0F, -4.0F, 12.0F, 2.0F, 4.0F, 12.0F,
        2.0F, 4.0F, 12.0F, -2.0F, -4.0F, 12.0F, -2.0F, 36.0F, 16.0F, 28.0F,
        20.0F, 0.0F, 1.0F, 0.0F, 4.0F, 9.0F, -2.0F, -4.0F, 9.0F, -2.0F,
        -4.0F, 13.0F, -2.0F, 4.0F, 13.0F, -2.0F, 42.0F, 42.0F, 50.0F, 46.0F,
        0.0F, 0.0F, -1.0F, -4.0F, 9.0F, 2.0F, 4.0F, 9.0F, 2.0F, 4.0F,
        13.0F, 2.0F, -4.0F, 13.0F, 2.0F, 54.0F, 42.0F, 62.0F, 46.0F, 0.0F,
        0.0F, 1.0F, 4.0F, 9.0F, 2.0F, 4.0F, 9.0F, -2.0F, 4.0F, 13.0F,
        -2.0F, 4.0F, 13.0F, 2.0F, 38.0F, 42.0F, 42.0F, 46.0F, 1.0F, 0.0F,
        0.0F, -4.0F, 9.0F, -2.0F, -4.0F, 9.0F, 2.0F, -4.0F, 13.0F, 2.0F,
        -4.0F, 13.0F, -2.0F, 50.0F, 42.0F, 54.0F, 46.0F, -1.0F, 0.0F, 0.0F,
        -4.0F, 9.0F, -2.0F, 4.0F, 9.0F, -2.0F, 4.0F, 9.0F, 2.0F, -4.0F,
        9.0F, 2.0F, 50.0F, 42.0F, 42.0F, 38.0F, 0.0F, -1.0F, 0.0F, -4.0F,
        13.0F, 2.0F, 4.0F, 13.0F, 2.0F, 4.0F, 13.0F, -2.0F, -4.0F, 13.0F,
        -2.0F, 58.0F, 38.0F, 50.0F, 42.0F, 0.0F, 1.0F, 0.0F, 4.0F, 0.0F,
        -2.0F, -4.0F, 0.0F, -2.0F, -4.0F, 5.0F, -2.0F, 4.0F, 5.0F, -2.0F,
        20.0F, 48.0F, 28.0F, 53.0F, 0.0F, 0.0F, -1.0F, -4.0F, 0.0F, 2.0F,
        4.0F, 0.0F, 2.0F, 4.0F, 5.0F, 2.0F, -4.0F, 5.0F, 2.0F, 32.0F,
        48.0F, 40.0F, 53.0F, 0.0F, 0.0F, 1.0F, 4.0F, 0.0F, 2.0F, 4.0F,
        0.0F, -2.0F, 4.0F, 5.0F, -2.0F, 4.0F, 5.0F, 2.0F, 16.0F, 48.0F,
        20.0F, 53.0F, 1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F, -4.0F, 0.0F,
        2.0F, -4.0F, 5.0F, 2.0F, -4.0F, 5.0F, -2.0F, 28.0F, 48.0F, 32.0F,
        53.0F, -1.0F, 0.0F, 0.0F, -4.0F, 0.0F, -2.0F, 4.0F, 0.0F, -2.0F,
        4.0F, 0.0F, 2.0F, -4.0F, 0.0F, 2.0F, 28.0F, 48.0F, 20.0F, 44.0F,
        0.0F, -1.0F, 0.0F, -4.0F, 5.0F, 2.0F, 4.0F, 5.0F, 2.0F, 4.0F,
        5.0F, -2.0F, -4.0F, 5.0F, -2.0F, 36.0F, 44.0F, 28.0F, 48.0F, 0.0F,
        1.0F, 0.0F, 3.0F, 4.0F, -2.0F, -3.0F, 4.0F, -2.0F, -3.0F, 7.0F,
        -2.0F, 3.0F, 7.0F, -2.0F, 21.0F, 60.0F, 27.0F, 63.0F, 0.0F, 0.0F,
        -1.0F, -3.0F, 4.0F, 2.0F, 3.0F, 4.0F, 2.0F, 3.0F, 7.0F, 2.0F,
        -3.0F, 7.0F, 2.0F, 31.0F, 60.0F, 37.0F, 63.0F, 0.0F, 0.0F, 1.0F,
        3.0F, 4.0F, 2.0F, 3.0F, 4.0F, -2.0F, 3.0F, 7.0F, -2.0F, 3.0F,
        7.0F, 2.0F, 17.0F, 60.0F, 21.0F, 63.0F, 1.0F, 0.0F, 0.0F, -3.0F,
        4.0F, -2.0F, -3.0F, 4.0F, 2.0F, -3.0F, 7.0F, 2.0F, -3.0F, 7.0F,
        -2.0F, 27.0F, 60.0F, 31.0F, 63.0F, -1.0F, 0.0F, 0.0F, -3.0F, 4.0F,
        -2.0F, 3.0F, 4.0F, -2.0F, 3.0F, 4.0F, 2.0F, -3.0F, 4.0F, 2.0F,
        27.0F, 60.0F, 21.0F, 56.0F, 0.0F, -1.0F, 0.0F, -3.0F, 7.0F, 2.0F,
        3.0F, 7.0F, 2.0F, 3.0F, 7.0F, -2.0F, -3.0F, 7.0F, -2.0F, 33.0F,
        56.0F, 27.0F, 60.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_ARM = {
        1.0F, -2.0F, -1.0F, -1.0F, -2.0F, -1.0F, -1.0F, 10.0F, -1.0F, 1.0F,
        10.0F, -1.0F, 44.0F, 18.0F, 42.0F, 30.0F, 0.0F, 0.0F, -1.0F, -1.0F,
        -2.0F, 1.0F, 1.0F, -2.0F, 1.0F, 1.0F, 10.0F, 1.0F, -1.0F, 10.0F,
        1.0F, 48.0F, 18.0F, 46.0F, 30.0F, 0.0F, 0.0F, 1.0F, 1.0F, -2.0F,
        1.0F, 1.0F, -2.0F, -1.0F, 1.0F, 10.0F, -1.0F, 1.0F, 10.0F, 1.0F,
        46.0F, 18.0F, 44.0F, 30.0F, 1.0F, 0.0F, 0.0F, -1.0F, -2.0F, -1.0F,
        -1.0F, -2.0F, 1.0F, -1.0F, 10.0F, 1.0F, -1.0F, 10.0F, -1.0F, 42.0F,
        18.0F, 40.0F, 30.0F, -1.0F, 0.0F, 0.0F, -1.0F, -2.0F, -1.0F, 1.0F,
        -2.0F, -1.0F, 1.0F, -2.0F, 1.0F, -1.0F, -2.0F, 1.0F, 42.0F, 18.0F,
        44.0F, 16.0F, 0.0F, -1.0F, 0.0F, -1.0F, 10.0F, 1.0F, 1.0F, 10.0F,
        1.0F, 1.0F, 10.0F, -1.0F, -1.0F, 10.0F, -1.0F, 44.0F, 16.0F, 46.0F,
        18.0F, 0.0F, 1.0F, 0.0F, -1.0F, 2.5F, -1.0F, -1.0F, 4.5F, -1.0F,
        1.0F, 4.5F, -1.0F, 1.0F, 2.5F, -1.0F, 26.0F, 36.0F, 24.0F, 38.0F,
        0.0F, 0.0F, -1.0F, -1.0F, 4.5F, 1.0F, -1.0F, 2.5F, 1.0F, 1.0F,
        2.5F, 1.0F, 1.0F, 4.5F, 1.0F, 30.0F, 36.0F, 28.0F, 38.0F, 0.0F,
        0.0F, 1.0F, -1.0F, 2.5F, 1.0F, -1.0F, 2.5F, -1.0F, 1.0F, 2.5F,
        -1.0F, 1.0F, 2.5F, 1.0F, 28.0F, 36.0F, 26.0F, 38.0F, 0.0F, -1.0F,
        0.0F, -1.0F, 4.5F, -1.0F, -1.0F, 4.5F, 1.0F, 1.0F, 4.5F, 1.0F,
        1.0F, 4.5F, -1.0F, 24.0F, 36.0F, 22.0F, 38.0F, 0.0F, 1.0F, 0.0F,
        -1.0F, 4.5F, -1.0F, -1.0F, 2.5F, -1.0F, -1.0F, 2.5F, 1.0F, -1.0F,
        4.5F, 1.0F, 24.0F, 36.0F, 26.0F, 34.0F, -1.0F, 0.0F, 0.0F, 1.0F,
        4.5F, 1.0F, 1.0F, 2.5F, 1.0F, 1.0F, 2.5F, -1.0F, 1.0F, 4.5F,
        -1.0F, 26.0F, 34.0F, 28.0F, 36.0F, 1.0F, 0.0F, 0.0F, -0.2F, 2.0F,
        -1.5F, -1.2F, 2.0F, -1.5F, -1.2F, 5.0F, -1.5F, -0.2F, 5.0F, -1.5F,
        18.0F, 36.0F, 17.0F, 39.0F, 0.0F, 0.0F, -1.0F, -1.2F, 2.0F, 1.5F,
        -0.2F, 2.0F, 1.5F, -0.2F, 5.0F, 1.5F, -1.2F, 5.0F, 1.5F, 22.0F,
        36.0F, 21.0F, 39.0F, 0.0F, 0.0F, 1.0F, -0.2F, 2.0F, 1.5F, -0.2F,
        2.0F, -1.5F, -0.2F, 5.0F, -1.5F, -0.2F, 5.0F, 1.5F, 21.0F, 36.0F,
        18.0F, 39.0F, 1.0F, 0.0F, 0.0F, -1.2F, 2.0F, -1.5F, -1.2F, 2.0F,
        1.5F, -1.2F, 5.0F, 1.5F, -1.2F, 5.0F, -1.5F, 17.0F, 36.0F, 14.0F,
        39.0F, -1.0F, 0.0F, 0.0F, -1.2F, 2.0F, -1.5F, -0.2F, 2.0F, -1.5F,
        -0.2F, 2.0F, 1.5F, -1.2F, 2.0F, 1.5F, 17.0F, 36.0F, 18.0F, 33.0F,
        0.0F, -1.0F, 0.0F, -1.2F, 5.0F, 1.5F, -0.2F, 5.0F, 1.5F, -0.2F,
        5.0F, -1.5F, -1.2F, 5.0F, -1.5F, 18.0F, 33.0F, 19.0F, 36.0F, 0.0F,
        1.0F, 0.0F, 1.5F, -3.0F, -1.5F, -1.5F, -3.0F, -1.5F, -1.5F, 0.0F,
        -1.5F, 1.5F, 0.0F, -1.5F, 6.0F, 36.0F, 3.0F, 39.0F, 0.0F, 0.0F,
        -1.0F, -1.5F, -3.0F, 1.5F, 1.5F, -3.0F, 1.5F, 1.5F, 0.0F, 1.5F,
        -1.5F, 0.0F, 1.5F, 12.0F, 36.0F, 9.0F, 39.0F, 0.0F, 0.0F, 1.0F,
        1.5F, -3.0F, 1.5F, 1.5F, -3.0F, -1.5F, 1.5F, 0.0F, -1.5F, 1.5F,
        0.0F, 1.5F, 9.0F, 36.0F, 6.0F, 39.0F, 1.0F, 0.0F, 0.0F, -1.5F,
        -3.0F, -1.5F, -1.5F, -3.0F, 1.5F, -1.5F, 0.0F, 1.5F, -1.5F, 0.0F,
        -1.5F, 3.0F, 36.0F, 0.0F, 39.0F, -1.0F, 0.0F, 0.0F, -1.5F, -3.0F,
        -1.5F, 1.5F, -3.0F, -1.5F, 1.5F, -3.0F, 1.5F, -1.5F, -3.0F, 1.5F,
        3.0F, 36.0F, 6.0F, 33.0F, 0.0F, -1.0F, 0.0F, -1.5F, 0.0F, 1.5F,
        1.5F, 0.0F, 1.5F, 1.5F, 0.0F, -1.5F, -1.5F, 0.0F, -1.5F, 6.0F,
        33.0F, 9.0F, 36.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_ARM = {
        1.0F, -2.0F, -1.0F, -1.0F, -2.0F, -1.0F, -1.0F, 10.0F, -1.0F, 1.0F,
        10.0F, -1.0F, 42.0F, 18.0F, 44.0F, 30.0F, 0.0F, 0.0F, -1.0F, -1.0F,
        -2.0F, 1.0F, 1.0F, -2.0F, 1.0F, 1.0F, 10.0F, 1.0F, -1.0F, 10.0F,
        1.0F, 46.0F, 18.0F, 48.0F, 30.0F, 0.0F, 0.0F, 1.0F, 1.0F, -2.0F,
        1.0F, 1.0F, -2.0F, -1.0F, 1.0F, 10.0F, -1.0F, 1.0F, 10.0F, 1.0F,
        40.0F, 18.0F, 42.0F, 30.0F, 1.0F, 0.0F, 0.0F, -1.0F, -2.0F, -1.0F,
        -1.0F, -2.0F, 1.0F, -1.0F, 10.0F, 1.0F, -1.0F, 10.0F, -1.0F, 44.0F,
        18.0F, 46.0F, 30.0F, -1.0F, 0.0F, 0.0F, -1.0F, -2.0F, -1.0F, 1.0F,
        -2.0F, -1.0F, 1.0F, -2.0F, 1.0F, -1.0F, -2.0F, 1.0F, 44.0F, 18.0F,
        42.0F, 16.0F, 0.0F, -1.0F, 0.0F, -1.0F, 10.0F, 1.0F, 1.0F, 10.0F,
        1.0F, 1.0F, 10.0F, -1.0F, -1.0F, 10.0F, -1.0F, 46.0F, 16.0F, 44.0F,
        18.0F, 0.0F, 1.0F, 0.0F, -1.5F, -3.0F, 1.5F, 1.5F, -3.0F, 1.5F,
        1.5F, 0.0F, 1.5F, -1.5F, 0.0F, 1.5F, 6.0F, 36.0F, 3.0F, 39.0F,
        0.0F, 0.0F, 1.0F, 1.5F, -3.0F, -1.5F, -1.5F, -3.0F, -1.5F, -1.5F,
        0.0F, -1.5F, 1.5F, 0.0F, -1.5F, 12.0F, 36.0F, 9.0F, 39.0F, 0.0F,
        0.0F, -1.0F, -1.5F, -3.0F, -1.5F, -1.5F, -3.0F, 1.5F, -1.5F, 0.0F,
        1.5F, -1.5F, 0.0F, -1.5F, 9.0F, 36.0F, 6.0F, 39.0F, -1.0F, 0.0F,
        0.0F, 1.5F, -3.0F, 1.5F, 1.5F, -3.0F, -1.5F, 1.5F, 0.0F, -1.5F,
        1.5F, 0.0F, 1.5F, 3.0F, 36.0F, 0.0F, 39.0F, 1.0F, 0.0F, 0.0F,
        1.5F, -3.0F, 1.5F, -1.5F, -3.0F, 1.5F, -1.5F, -3.0F, -1.5F, 1.5F,
        -3.0F, -1.5F, 3.0F, 36.0F, 6.0F, 33.0F, 0.0F, -1.0F, 0.0F, 1.5F,
        0.0F, -1.5F, -1.5F, 0.0F, -1.5F, -1.5F, 0.0F, 1.5F, 1.5F, 0.0F,
        1.5F, 6.0F, 33.0F, 9.0F, 36.0F, 0.0F, 1.0F, 0.0F, -1.0F, 2.5F,
        -1.0F, -1.0F, 4.5F, -1.0F, 1.0F, 4.5F, -1.0F, 1.0F, 2.5F, -1.0F,
        26.0F, 36.0F, 24.0F, 38.0F, 0.0F, 0.0F, -1.0F, -1.0F, 4.5F, 1.0F,
        -1.0F, 2.5F, 1.0F, 1.0F, 2.5F, 1.0F, 1.0F, 4.5F, 1.0F, 30.0F,
        36.0F, 28.0F, 38.0F, 0.0F, 0.0F, 1.0F, -1.0F, 2.5F, 1.0F, -1.0F,
        2.5F, -1.0F, 1.0F, 2.5F, -1.0F, 1.0F, 2.5F, 1.0F, 28.0F, 36.0F,
        26.0F, 38.0F, 0.0F, -1.0F, 0.0F, -1.0F, 4.5F, -1.0F, -1.0F, 4.5F,
        1.0F, 1.0F, 4.5F, 1.0F, 1.0F, 4.5F, -1.0F, 24.0F, 36.0F, 22.0F,
        38.0F, 0.0F, 1.0F, 0.0F, -1.0F, 4.5F, -1.0F, -1.0F, 2.5F, -1.0F,
        -1.0F, 2.5F, 1.0F, -1.0F, 4.5F, 1.0F, 24.0F, 36.0F, 26.0F, 34.0F,
        -1.0F, 0.0F, 0.0F, 1.0F, 4.5F, 1.0F, 1.0F, 2.5F, 1.0F, 1.0F,
        2.5F, -1.0F, 1.0F, 4.5F, -1.0F, 26.0F, 34.0F, 28.0F, 36.0F, 1.0F,
        0.0F, 0.0F, 0.2F, 2.0F, 1.5F, 1.2F, 2.0F, 1.5F, 1.2F, 5.0F,
        1.5F, 0.2F, 5.0F, 1.5F, 18.0F, 36.0F, 17.0F, 39.0F, 0.0F, 0.0F,
        1.0F, 1.2F, 2.0F, -1.5F, 0.2F, 2.0F, -1.5F, 0.2F, 5.0F, -1.5F,
        1.2F, 5.0F, -1.5F, 22.0F, 36.0F, 21.0F, 39.0F, 0.0F, 0.0F, -1.0F,
        0.2F, 2.0F, -1.5F, 0.2F, 2.0F, 1.5F, 0.2F, 5.0F, 1.5F, 0.2F,
        5.0F, -1.5F, 21.0F, 36.0F, 18.0F, 39.0F, -1.0F, 0.0F, 0.0F, 1.2F,
        2.0F, 1.5F, 1.2F, 2.0F, -1.5F, 1.2F, 5.0F, -1.5F, 1.2F, 5.0F,
        1.5F, 17.0F, 36.0F, 14.0F, 39.0F, 1.0F, 0.0F, 0.0F, 1.2F, 2.0F,
        1.5F, 0.2F, 2.0F, 1.5F, 0.2F, 2.0F, -1.5F, 1.2F, 2.0F, -1.5F,
        17.0F, 36.0F, 18.0F, 33.0F, 0.0F, -1.0F, 0.0F, 1.2F, 5.0F, -1.5F,
        0.2F, 5.0F, -1.5F, 0.2F, 5.0F, 1.5F, 1.2F, 5.0F, 1.5F, 18.0F,
        33.0F, 19.0F, 36.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] RIGHT_LEG = {
        0.9F, 0.0F, -1.0F, -1.1F, 0.0F, -1.0F, -1.1F, 12.0F, -1.0F, 0.9F,
        12.0F, -1.0F, 4.0F, 18.0F, 2.0F, 30.0F, 0.0F, 0.0F, -1.0F, -1.1F,
        0.0F, 1.0F, 0.9F, 0.0F, 1.0F, 0.9F, 12.0F, 1.0F, -1.1F, 12.0F,
        1.0F, 8.0F, 18.0F, 6.0F, 30.0F, 0.0F, 0.0F, 1.0F, 0.9F, 0.0F,
        1.0F, 0.9F, 0.0F, -1.0F, 0.9F, 12.0F, -1.0F, 0.9F, 12.0F, 1.0F,
        6.0F, 18.0F, 4.0F, 30.0F, 1.0F, 0.0F, 0.0F, -1.1F, 0.0F, -1.0F,
        -1.1F, 0.0F, 1.0F, -1.1F, 12.0F, 1.0F, -1.1F, 12.0F, -1.0F, 2.0F,
        18.0F, 0.0F, 30.0F, -1.0F, 0.0F, 0.0F, -1.1F, 0.0F, -1.0F, 0.9F,
        0.0F, -1.0F, 0.9F, 0.0F, 1.0F, -1.1F, 0.0F, 1.0F, 2.0F, 18.0F,
        4.0F, 16.0F, 0.0F, -1.0F, 0.0F, -1.1F, 12.0F, 1.0F, 0.9F, 12.0F,
        1.0F, 0.9F, 12.0F, -1.0F, -1.1F, 12.0F, -1.0F, 4.0F, 16.0F, 6.0F,
        18.0F, 0.0F, 1.0F, 0.0F, -1.1F, 6.0F, 1.0F, -1.1F, 4.0F, 1.0F,
        0.9F, 4.0F, 1.0F, 0.9F, 6.0F, 1.0F, 26.0F, 36.0F, 24.0F, 38.0F,
        0.0F, 0.0F, 1.0F, -1.1F, 4.0F, -1.0F, -1.1F, 6.0F, -1.0F, 0.9F,
        6.0F, -1.0F, 0.9F, 4.0F, -1.0F, 30.0F, 36.0F, 28.0F, 38.0F, 0.0F,
        0.0F, -1.0F, -1.1F, 6.0F, -1.0F, -1.1F, 6.0F, 1.0F, 0.9F, 6.0F,
        1.0F, 0.9F, 6.0F, -1.0F, 28.0F, 36.0F, 26.0F, 38.0F, 0.0F, 1.0F,
        0.0F, -1.1F, 4.0F, 1.0F, -1.1F, 4.0F, -1.0F, 0.9F, 4.0F, -1.0F,
        0.9F, 4.0F, 1.0F, 24.0F, 36.0F, 22.0F, 38.0F, 0.0F, -1.0F, 0.0F,
        -1.1F, 4.0F, 1.0F, -1.1F, 6.0F, 1.0F, -1.1F, 6.0F, -1.0F, -1.1F,
        4.0F, -1.0F, 24.0F, 36.0F, 26.0F, 34.0F, -1.0F, 0.0F, 0.0F, 0.9F,
        4.0F, -1.0F, 0.9F, 6.0F, -1.0F, 0.9F, 6.0F, 1.0F, 0.9F, 4.0F,
        1.0F, 26.0F, 34.0F, 28.0F, 36.0F, 1.0F, 0.0F, 0.0F, 0.9F, 10.0F,
        -1.0F, -1.1F, 10.0F, -1.0F, -1.1F, 12.0F, -1.0F, 0.9F, 12.0F, -1.0F,
        25.0F, 61.0F, 27.0F, 63.0F, 0.0F, 0.0F, -1.0F, -1.1F, 10.0F, 1.0F,
        0.9F, 10.0F, 1.0F, 0.9F, 12.0F, 1.0F, -1.1F, 12.0F, 1.0F, 29.0F,
        61.0F, 31.0F, 63.0F, 0.0F, 0.0F, 1.0F, 0.9F, 10.0F, 1.0F, 0.9F,
        10.0F, -1.0F, 0.9F, 12.0F, -1.0F, 0.9F, 12.0F, 1.0F, 23.0F, 61.0F,
        25.0F, 63.0F, 1.0F, 0.0F, 0.0F, -1.1F, 10.0F, -1.0F, -1.1F, 10.0F,
        1.0F, -1.1F, 12.0F, 1.0F, -1.1F, 12.0F, -1.0F, 27.0F, 61.0F, 29.0F,
        63.0F, -1.0F, 0.0F, 0.0F, -1.1F, 10.0F, -1.0F, 0.9F, 10.0F, -1.0F,
        0.9F, 10.0F, 1.0F, -1.1F, 10.0F, 1.0F, 27.0F, 61.0F, 25.0F, 59.0F,
        0.0F, -1.0F, 0.0F, -1.1F, 12.0F, 1.0F, 0.9F, 12.0F, 1.0F, 0.9F,
        12.0F, -1.0F, -1.1F, 12.0F, -1.0F, 29.0F, 59.0F, 27.0F, 61.0F, 0.0F,
        1.0F, 0.0F, -1.75F, 3.5F, -2.15F, -1.75F, 3.5F, -1.15F, -1.75F, 6.5F,
        -1.15F, -1.75F, 6.5F, -2.15F, 18.0F, 36.0F, 17.0F, 39.0F, -1.0F, 0.0F,
        0.0F, 1.25F, 3.5F, -1.15F, 1.25F, 3.5F, -2.15F, 1.25F, 6.5F, -2.15F,
        1.25F, 6.5F, -1.15F, 22.0F, 36.0F, 21.0F, 39.0F, 1.0F, 0.0F, 0.0F,
        1.25F, 3.5F, -2.15F, -1.75F, 3.5F, -2.15F, -1.75F, 6.5F, -2.15F, 1.25F,
        6.5F, -2.15F, 21.0F, 36.0F, 18.0F, 39.0F, 0.0F, 0.0F, -1.0F, -1.75F,
        3.5F, -1.15F, 1.25F, 3.5F, -1.15F, 1.25F, 6.5F, -1.15F, -1.75F, 6.5F,
        -1.15F, 17.0F, 36.0F, 14.0F, 39.0F, 0.0F, 0.0F, 1.0F, -1.75F, 3.5F,
        -1.15F, -1.75F, 3.5F, -2.15F, 1.25F, 3.5F, -2.15F, 1.25F, 3.5F, -1.15F,
        17.0F, 36.0F, 18.0F, 33.0F, 0.0F, -1.0F, 0.0F, 1.25F, 6.5F, -1.15F,
        1.25F, 6.5F, -2.15F, -1.75F, 6.5F, -2.15F, -1.75F, 6.5F, -1.15F, 18.0F,
        33.0F, 19.0F, 36.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] LEFT_LEG = {
        1.1F, 0.0F, -1.0F, -0.9F, 0.0F, -1.0F, -0.9F, 12.0F, -1.0F, 1.1F,
        12.0F, -1.0F, 2.0F, 18.0F, 4.0F, 30.0F, 0.0F, 0.0F, -1.0F, -0.9F,
        0.0F, 1.0F, 1.1F, 0.0F, 1.0F, 1.1F, 12.0F, 1.0F, -0.9F, 12.0F,
        1.0F, 6.0F, 18.0F, 8.0F, 30.0F, 0.0F, 0.0F, 1.0F, 1.1F, 0.0F,
        1.0F, 1.1F, 0.0F, -1.0F, 1.1F, 12.0F, -1.0F, 1.1F, 12.0F, 1.0F,
        0.0F, 18.0F, 2.0F, 30.0F, 1.0F, 0.0F, 0.0F, -0.9F, 0.0F, -1.0F,
        -0.9F, 0.0F, 1.0F, -0.9F, 12.0F, 1.0F, -0.9F, 12.0F, -1.0F, 4.0F,
        18.0F, 6.0F, 30.0F, -1.0F, 0.0F, 0.0F, -0.9F, 0.0F, -1.0F, 1.1F,
        0.0F, -1.0F, 1.1F, 0.0F, 1.0F, -0.9F, 0.0F, 1.0F, 4.0F, 18.0F,
        2.0F, 16.0F, 0.0F, -1.0F, 0.0F, -0.9F, 12.0F, 1.0F, 1.1F, 12.0F,
        1.0F, 1.1F, 12.0F, -1.0F, -0.9F, 12.0F, -1.0F, 6.0F, 16.0F, 4.0F,
        18.0F, 0.0F, 1.0F, 0.0F, 1.1F, 10.0F, -1.0F, -0.9F, 10.0F, -1.0F,
        -0.9F, 12.0F, -1.0F, 1.1F, 12.0F, -1.0F, 26.0F, 61.0F, 28.0F, 63.0F,
        0.0F, 0.0F, -1.0F, -0.9F, 10.0F, 1.0F, 1.1F, 10.0F, 1.0F, 1.1F,
        12.0F, 1.0F, -0.9F, 12.0F, 1.0F, 30.0F, 61.0F, 32.0F, 63.0F, 0.0F,
        0.0F, 1.0F, 1.1F, 10.0F, 1.0F, 1.1F, 10.0F, -1.0F, 1.1F, 12.0F,
        -1.0F, 1.1F, 12.0F, 1.0F, 24.0F, 61.0F, 26.0F, 63.0F, 1.0F, 0.0F,
        0.0F, -0.9F, 10.0F, -1.0F, -0.9F, 10.0F, 1.0F, -0.9F, 12.0F, 1.0F,
        -0.9F, 12.0F, -1.0F, 28.0F, 61.0F, 30.0F, 63.0F, -1.0F, 0.0F, 0.0F,
        -0.9F, 10.0F, -1.0F, 1.1F, 10.0F, -1.0F, 1.1F, 10.0F, 1.0F, -0.9F,
        10.0F, 1.0F, 28.0F, 61.0F, 26.0F, 59.0F, 0.0F, -1.0F, 0.0F, -0.9F,
        12.0F, 1.0F, 1.1F, 12.0F, 1.0F, 1.1F, 12.0F, -1.0F, -0.9F, 12.0F,
        -1.0F, 30.0F, 59.0F, 28.0F, 61.0F, 0.0F, 1.0F, 0.0F, -0.9F, 6.0F,
        1.0F, -0.9F, 4.0F, 1.0F, 1.1F, 4.0F, 1.0F, 1.1F, 6.0F, 1.0F,
        26.0F, 36.0F, 24.0F, 38.0F, 0.0F, 0.0F, 1.0F, -0.9F, 4.0F, -1.0F,
        -0.9F, 6.0F, -1.0F, 1.1F, 6.0F, -1.0F, 1.1F, 4.0F, -1.0F, 30.0F,
        36.0F, 28.0F, 38.0F, 0.0F, 0.0F, -1.0F, -0.9F, 6.0F, -1.0F, -0.9F,
        6.0F, 1.0F, 1.1F, 6.0F, 1.0F, 1.1F, 6.0F, -1.0F, 28.0F, 36.0F,
        26.0F, 38.0F, 0.0F, 1.0F, 0.0F, -0.9F, 4.0F, 1.0F, -0.9F, 4.0F,
        -1.0F, 1.1F, 4.0F, -1.0F, 1.1F, 4.0F, 1.0F, 24.0F, 36.0F, 22.0F,
        38.0F, 0.0F, -1.0F, 0.0F, -0.9F, 4.0F, 1.0F, -0.9F, 6.0F, 1.0F,
        -0.9F, 6.0F, -1.0F, -0.9F, 4.0F, -1.0F, 24.0F, 36.0F, 26.0F, 34.0F,
        -1.0F, 0.0F, 0.0F, 1.1F, 4.0F, -1.0F, 1.1F, 6.0F, -1.0F, 1.1F,
        6.0F, 1.0F, 1.1F, 4.0F, 1.0F, 26.0F, 34.0F, 28.0F, 36.0F, 1.0F,
        0.0F, 0.0F, -1.25F, 3.5F, -2.15F, -1.25F, 3.5F, -1.15F, -1.25F, 6.5F,
        -1.15F, -1.25F, 6.5F, -2.15F, 18.0F, 36.0F, 17.0F, 39.0F, -1.0F, 0.0F,
        0.0F, 1.75F, 3.5F, -1.15F, 1.75F, 3.5F, -2.15F, 1.75F, 6.5F, -2.15F,
        1.75F, 6.5F, -1.15F, 22.0F, 36.0F, 21.0F, 39.0F, 1.0F, 0.0F, 0.0F,
        1.75F, 3.5F, -2.15F, -1.25F, 3.5F, -2.15F, -1.25F, 6.5F, -2.15F, 1.75F,
        6.5F, -2.15F, 21.0F, 36.0F, 18.0F, 39.0F, 0.0F, 0.0F, -1.0F, -1.25F,
        3.5F, -1.15F, 1.75F, 3.5F, -1.15F, 1.75F, 6.5F, -1.15F, -1.25F, 6.5F,
        -1.15F, 17.0F, 36.0F, 14.0F, 39.0F, 0.0F, 0.0F, 1.0F, -1.25F, 3.5F,
        -1.15F, -1.25F, 3.5F, -2.15F, 1.75F, 3.5F, -2.15F, 1.75F, 3.5F, -1.15F,
        17.0F, 36.0F, 18.0F, 33.0F, 0.0F, -1.0F, 0.0F, 1.75F, 6.5F, -1.15F,
        1.75F, 6.5F, -2.15F, -1.25F, 6.5F, -2.15F, -1.25F, 6.5F, -1.15F, 18.0F,
        33.0F, 19.0F, 36.0F, 0.0F, 1.0F, 0.0F
    };

    public ImmortalWarriorModel(ModelPart root) {
        super(root);
        this.root = root;
    }

    @Override
    public void setupAnim(net.minecraft.world.entity.Entity entity, float limbSwing,
                          float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.resetPose();
        this.body.resetPose();
        this.rightArm.resetPose();
        this.leftArm.resetPose();
        this.rightLeg.resetPose();
        this.leftLeg.resetPose();
        if (!(entity instanceof net.minecraft.world.entity.LivingEntity livingEntity)) {
            return;
        }
        super.setupAnim(livingEntity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (!(entity instanceof ImmortalWarrior warrior)) {
            return;
        }

        float partialTick = Mth.clamp(ageInTicks - warrior.tickCount, 0.0F, 1.0F);
        float progress = Mth.clamp(warrior.getDisintegrationProgress(partialTick), 0.0F, 1.0F);
        if (progress <= 0.0F) {
            return;
        }

        // fall_apart 的旋转/位移来自用户提供的动画文件。每个骨骼必须绕文件中的真实
        // origin 旋转，再换算回原版 ModelPart 枢轴；只改 xRot/yRot/zRot 会造成脱节错位。
        float headPositionProgress = Mth.clamp(progress / 0.91666F, 0.0F, 1.0F);
        // Bedrock 使用 Y 向上；Java 模型使用 Y 向下。对原动画做镜像换算：
        // rotation=(x,y,z) -> (-x,y,-z)，position=(x,y,z) -> (x,-y,z)，
        // 并把 Bedrock 左右骨骼映射到 Java 的 right/left 部件。
        applyFallApart(this.head, 0.0F, 0.0F, 0.0F,
                0.0F, 0.0F, 0.0F, progress, headPositionProgress,
                -105.0F, 360.0F, 0.0F, 0.0F, 20.0F, 0.0F);
        applyFallApart(this.body, 0.0F, 0.0F, 0.0F,
                0.0F, 6.25F, 0.0F, progress, progress,
                82.4634F, -3.7F, -378.0967F, -1.0F, 15.0F, -2.0F);
        applyFallApart(this.rightArm, -5.0F, 2.0F, 0.0F,
                -5.175F, 4.375F, 0.0F, progress, progress,
                432.6982F, -10.1592F, 112.4779F, -2.0F, 20.0F, 0.0F);
        applyFallApart(this.leftArm, 5.0F, 2.0F, 0.0F,
                5.0F, 2.0F, 0.0F, progress, progress,
                -80.5779F, 37.1248F, 354.2805F, 0.0F, 21.0F, 0.0F);
        applyFallApart(this.rightLeg, -1.9F, 12.0F, 0.0F,
                -2.0F, 12.0F, 0.0F, progress, progress,
                -85.4645F, 57.3425F, -13.7897F, -2.0F, 9.0F, 3.0F);
        applyFallApart(this.leftLeg, 1.9F, 12.0F, 0.0F,
                2.0F, 12.0F, 0.0F, progress, progress,
                72.5F, 32.5F, -360.0F, 2.0F, 9.54F, -10.0F);
    }

    private static void applyFallApart(ModelPart part, float baseX, float baseY, float baseZ,
                                       float pivotX, float pivotY, float pivotZ, float progress,
                                       float positionProgress, float xDeg, float yDeg, float zDeg,
                                       float dx, float dy, float dz) {
        float x = xDeg * Mth.DEG_TO_RAD * progress;
        float y = yDeg * Mth.DEG_TO_RAD * progress;
        float z = zDeg * Mth.DEG_TO_RAD * progress;
        float px = pivotX - baseX;
        float py = pivotY - baseY;
        float pz = pivotZ - baseZ;
        float sx = Mth.sin(x), cx = Mth.cos(x);
        float sy = Mth.sin(y), cy = Mth.cos(y);
        float sz = Mth.sin(z), cz = Mth.cos(z);
        // ModelPart 使用 rotationZYX；这里求 R·(pivot-base)，再用
        // base + pivot-base - R·(pivot-base) 补回真实骨骼枢轴，避免部件脱节。
        float rx = cy * cz * px + (cz * sy * sx - sz * cx) * py
                + (cz * sy * cx + sz * sx) * pz;
        float ry = cy * sz * px + (sz * sy * sx + cz * cx) * py
                + (sz * sy * cx - cz * sx) * pz;
        float rz = -sy * px + cy * sx * py + cy * cx * pz;
        part.x = baseX + (px - rx) + dx * positionProgress;
        part.y = baseY + (py - ry) + dy * positionProgress;
        part.z = baseZ + (pz - rz) + dz * positionProgress;
        part.xRot = x;
        part.yRot = y;
        part.zRot = z;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.head, HEAD,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        poseStack.pushPose();
        this.head.translateAndRotate(poseStack);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.head.getChild("headwear"), HEADWEAR,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        poseStack.popPose();
        ImmortalWarriorQuads.emit(poseStack, buffer, this.body, BODY,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.rightArm, RIGHT_ARM,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.leftArm, LEFT_ARM,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.rightLeg, RIGHT_LEG,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        ImmortalWarriorQuads.emit(poseStack, buffer, this.leftLeg, LEFT_LEG,
                TEX_WIDTH, TEX_HEIGHT, packedLight, packedOverlay, color);
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        head.addOrReplaceChild("headwear", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
