package cn.blockforge.generated.netherarmy;

import net.minecraft.Util;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.AdvancementEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * BAD APPLE 成就的"打开视频"链路。
 *
 * <p>进度达成事件（{@link AdvancementEvent.AdvancementEarnEvent}）只在服务端触发，
 * 而开浏览器是纯客户端动作，因此达成时给该玩家回发一条无数据载荷
 * {@link BadAppleUrlPayload}；客户端收到后经 {@code enqueueWork} 切回主线程，
 * 用原版同款通道 {@code Util.getPlatform().openUri} 打开视频页。</p>
 */
public final class BadAppleUrlSync {
    /** 达成 BAD APPLE 进度时自动打开的地址。 */
    public static final String BAD_APPLE_VIDEO_URL =
            "https://www.bilibili.com/video/BV1xx411c79H/?spm_id_from=333.337.search-card.all.click";

    private BadAppleUrlSync() {
    }

    /** 模组总线：注册 play-to-client 载荷处理器。 */
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(BadAppleUrlPayload.TYPE, BadAppleUrlPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(
                        () -> Util.getPlatform().openUri(BAD_APPLE_VIDEO_URL)));
    }

    /** 游戏总线（服务端侧）：玩家达成 BAD APPLE 进度时推送开屏载荷。 */
    @SubscribeEvent
    public static void onAdvancementEarned(AdvancementEvent.AdvancementEarnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ResourceLocation id = event.getAdvancement().id();
        if (!ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "bad_apple").equals(id)) {
            return;
        }
        PacketDistributor.sendToPlayer(player, new BadAppleUrlPayload());
    }
}
