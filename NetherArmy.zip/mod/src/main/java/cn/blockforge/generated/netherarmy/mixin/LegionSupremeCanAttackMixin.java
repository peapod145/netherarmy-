package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherFactionRoster;
import cn.blockforge.generated.netherarmy.WitherFactionSupremeHostility;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 军团仇恨总闸（一）：{@code LivingEntity#canAttack} 由 {@link WitherFactionSupremeHostility}
 * 说了算。
 *
 * <p>HEAD 注入 + {@code setReturnValue} 会取消这个方法上后续所有注入与原版实现，
 * 因此第三方模组给自家怪加的"无敌阶段／不可被看作敌人／亡灵同盟"都盖不住军团的判断，
 * 而 {@code TargetingConditions}、{@code HurtByTargetGoal}、{@code NearestAttackableTargetGoal}
 * 这些原版通道又都从这里过，改一处就等于改了全部。</p>
 *
 * <p>只对阵营成员生效：非军团实体保持原版语义，别模组的怪该怎么打还怎么打。</p>
 *
 * <p>不使用任何 {@code @Shadow} 字段——影子字段只在本类声明里找得到，
 * {@code TargetGoal#mob} 那类父类字段在实机 NeoForge 上会直接
 * {@code InvalidMixinException} 崩掉启动（本模组踩过这个坑），这里统一用
 * {@code (LivingEntity)(Object) this} 取值。</p>
 */
@Mixin(LivingEntity.class)
public abstract class LegionSupremeCanAttackMixin {

    @Inject(method = "canAttack(Lnet/minecraft/world/entity/LivingEntity;)Z", at = @At("HEAD"), cancellable = true)
    private void netherarmy$legionIsSupreme(LivingEntity target, CallbackInfoReturnable<Boolean> callback) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!WitherFactionRoster.isMember(self)) {
            return;
        }
        callback.setReturnValue(WitherFactionSupremeHostility.canLegionAttack(self, target));
    }
}
