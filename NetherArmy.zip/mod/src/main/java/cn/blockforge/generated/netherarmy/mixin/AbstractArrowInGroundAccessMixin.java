package cn.blockforge.generated.netherarmy.mixin;

import net.minecraft.world.entity.projectile.AbstractArrow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * 放开原版 {@code AbstractArrow#inGround}（插地标记）的读取。
 *
 * <p>该字段是 protected 且没有任何公开 getter：箭矢（含三叉戟）命中方块后，
 * {@code onHitBlock} 会把它置 true，并把 {@code getDeltaMovement()} 改写成
 * "命中点相对方块原点的偏移"作插地姿态渲染提示——一个永久非零的假速度。
 * 抛射物闪避要剔除这种"钉在地上的箭"，只看速度或跨 tick 位移都做不到即时判定
 * （位移核验对新出现的来袭箭天然要晚 1～2 次观测，近距离直射会被漏掉），
 * 而 {@code inGround} 是原版自己维护的权威状态，当 tick 即可判定。</p>
 *
 * <p>这里用访问器混入（interface mixin + {@code @Accessor}）由 Mixin 在
 * {@code AbstractArrow} 上生成实现，调用方把实例强转本接口即可读取。</p>
 */
@Mixin(AbstractArrow.class)
public interface AbstractArrowInGroundAccessMixin {

    /** 原版 {@code AbstractArrow#inGround}：箭矢插进方块期间为 true。 */
    @Accessor("inGround")
    boolean netherarmy$isInGround();
}
