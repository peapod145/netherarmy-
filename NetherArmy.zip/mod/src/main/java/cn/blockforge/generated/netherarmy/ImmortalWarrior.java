package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 不死武士：死亡时由不死武士残骸接管解体过程。 */
public class ImmortalWarrior extends WitherSkeleton {
    public static final int FALL_APART_TICKS = 10;
    public static final int DISINTEGRATED_HOLD_TICKS = 100;
    public static final int RECOVER_TICKS = 10;
    public static final int WITHER_TICKS = 200;
    private static final double WITHER_SKELETON_SPEED = 0.25D;

    protected static final EntityDataAccessor<Integer> DATA_WARRIOR_STATE =
            SynchedEntityData.defineId(ImmortalWarrior.class, EntityDataSerializers.INT);
    protected static final EntityDataAccessor<Integer> DATA_STATE_TICKS =
            SynchedEntityData.defineId(ImmortalWarrior.class, EntityDataSerializers.INT);

    /** 0=正常，1=解体进行中，2=解体末帧停留，3=复原倒放。由残骸实体使用。 */
    protected int warriorState;
    protected int stateTicks;
    protected float lockedYRot;
    protected float lockedYHeadRot;
    private boolean hadTarget;

    public ImmortalWarrior(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        this.xpReward = 0;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_WARRIOR_STATE, 0);
        builder.define(DATA_STATE_TICKS, 0);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, WITHER_SKELETON_SPEED)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.FOLLOW_RANGE, 25.0D);
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.ROYAL_LONGSWORD.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                         DifficultyInstance difficulty) {
        // 附魔由 finalizeSpawn 统一按 10% 概率处理，避免原版凋灵骷髅再次覆盖武器。
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        net.minecraft.world.entity.MobSpawnType spawnType,
                                        SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.setLeftHanded(false);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.ROYAL_LONGSWORD.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        if (this.getRandom().nextFloat() < 0.10F && level instanceof ServerLevelAccessor serverAccessor
                && serverAccessor.getLevel() instanceof ServerLevel serverLevel) {
            addRandomSwordEnchantments(serverLevel, this.getRandom());
        }
        this.reassessWeaponGoal();
        return result;
    }

    private void addRandomSwordEnchantments(ServerLevel level, RandomSource random) {
        ItemStack sword = this.getMainHandItem();
        HolderLookup.RegistryLookup<Enchantment> registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = new ArrayList<>();
        for (String id : List.of("sharpness", "smite", "bane_of_arthropods", "knockback", "fire_aspect",
                "looting", "sweeping_edge", "unbreaking", "mending")) {
            ResourceKey<Enchantment> key = ResourceKey.create(Registries.ENCHANTMENT,
                    ResourceLocation.withDefaultNamespace(id));
            Holder.Reference<Enchantment> enchantment = registry.get(key)
                    .map(found -> (Holder.Reference<Enchantment>) found).orElse(null);
            if (enchantment != null && enchantment.value().canEnchant(sword)) {
                candidates.add(enchantment);
            }
        }
        Collections.shuffle(candidates, new java.util.Random(random.nextLong()));
        List<Holder.Reference<Enchantment>> selected = new ArrayList<>();
        int count = 1 + random.nextInt(Math.min(3, Math.max(1, candidates.size())));
        for (Holder.Reference<Enchantment> candidate : candidates) {
            if (selected.stream().allMatch(existing -> Enchantment.areCompatible(candidate, existing))) {
                selected.add(candidate);
                sword.enchant(candidate, Math.min(1 + random.nextInt(2), candidate.value().getMaxLevel()));
                if (selected.size() >= count) {
                    break;
                }
            }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!super.doHurtTarget(target)) {
            return false;
        }
        if (target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, WITHER_TICKS, 1), this);
        }
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive()) {
            if (!hadTarget) {
                this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1), this);
                hadTarget = true;
            }
        } else {
            hadTarget = false;
        }
    }

    /** 正常不死武士不播放死亡动画，而是在原地生成一个残骸实体。 */
    @Override
    public void die(DamageSource source) {
        if (!transformsIntoRemainsOnDeath()) {
            super.die(source);
            return;
        }
        if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
            ImmortalWarriorRemains remains = GeneratedMod.IMMORTAL_WARRIOR_REMAINS.get().create(serverLevel);
            if (remains != null) {
                remains.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), this.getXRot());
                remains.setYHeadRot(this.getYHeadRot());
                remains.setYBodyRot(this.getYRot());
                remains.lockedYRot = this.getYRot();
                remains.lockedYHeadRot = this.getYHeadRot();
                remains.startDisintegration();
                remains.setItemSlot(EquipmentSlot.MAINHAND, this.getMainHandItem().copy());
                remains.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                serverLevel.addFreshEntity(remains);
            }
        }
        this.discard();
    }

    protected boolean transformsIntoRemainsOnDeath() {
        return true;
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    @Override
    public boolean shouldDropExperience() {
        return false;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        // 正常不死武士的死亡由 die() 转换为残骸，因此不会产生任何掉落物。
    }

    public boolean isDisintegrating() {
        return this.level().isClientSide ? getWarriorState() != 0 : warriorState != 0;
    }

    protected void setWarriorState(int state, int ticks) {
        this.warriorState = state;
        this.stateTicks = ticks;
        this.entityData.set(DATA_WARRIOR_STATE, state);
        this.entityData.set(DATA_STATE_TICKS, ticks);
    }

    public void startDisintegration() {
        // 状态在加入世界前已同步；使用恰好 10 tick，避免首帧多停一 tick。
        setWarriorState(1, FALL_APART_TICKS);
    }

    public int getWarriorState() {
        return this.level().isClientSide ? this.entityData.get(DATA_WARRIOR_STATE) : warriorState;
    }

    /** 客户端模型使用 0→1 的解体进度；复原阶段按 1→0 倒放。 */
    public float getDisintegrationProgress(float partialTick) {
        int state = getWarriorState();
        int ticks = this.level().isClientSide ? this.entityData.get(DATA_STATE_TICKS) : stateTicks;
        float clampedPartialTick = Math.max(0.0F, Math.min(1.0F, partialTick));
        if (state == 0) {
            return 0.0F;
        }
        if (state == 1) {
            return Math.max(0.0F, Math.min(1.0F,
                    1.0F - (ticks - clampedPartialTick) / FALL_APART_TICKS));
        }
        if (state == 2) {
            return 1.0F;
        }
        return Math.max(0.0F, Math.min(1.0F,
                (ticks - clampedPartialTick) / RECOVER_TICKS));
    }

    // 免疫凋零效果由 WitherFactionWitherImmunityMixin 按阵营统一判定，本类不再单独覆盖
    // canBeAffected（不朽战士与其残躯都在 #minecraft:wither_skeletons 名册里）。
}
