package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.sensing.Sensor;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/** 让指定的原版守卫生物与整个凋灵骷髅阵营保持敌对。 */
public final class WitherFactionHostilityHandler {
    private static final TagKey<EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));
    private static final TagKey<EntityType<?>> WITHER_FRIENDS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_friends"));

    private WitherFactionHostilityHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (!(event.getEntity() instanceof SnowGolem) && !(event.getEntity() instanceof IronGolem)) {
            return;
        }
        Mob mob = (Mob) event.getEntity();
        if (hasFactionTargetGoal(mob)) {
            return;
        }
        mob.targetSelector.addGoal(3, new WitherFactionTargetGoal(mob));
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof AbstractPiglin piglin)
                || !(piglin instanceof Piglin || piglin instanceof PiglinBrute)
                || !piglin.isAdult()
                || piglin.level().isClientSide()
                || piglin.tickCount % 20 != 0) {
            return;
        }

        Brain<?> brain = piglin.getBrain();
        if (brain.hasMemoryValue(MemoryModuleType.NEAREST_VISIBLE_NEMESIS)) {
            return;
        }
        brain.getMemory(MemoryModuleType.NEAREST_VISIBLE_LIVING_ENTITIES)
                .ifPresent(visible -> visible.find(candidate -> candidate instanceof Mob
                                && candidate.isAlive()
                                && isWitherFaction(candidate))
                        .findFirst()
                        .ifPresent(nemesis -> angerAt(piglin, nemesis)));
    }

    /** 凋灵骷髅阵营由两个原版标签取并集，并包含凋灵本体。 */
    public static boolean isWitherFaction(LivingEntity entity) {
        return entity instanceof WitherBoss
                || entity.getType().is(WITHER_SKELETONS)
                || entity.getType().is(WITHER_FRIENDS);
    }

    private static boolean hasFactionTargetGoal(Mob mob) {
        return mob.targetSelector.getAvailableGoals().stream()
                .map(WrappedGoal::getGoal)
                .anyMatch(WitherFactionTargetGoal.class::isInstance);
    }

    private static void angerAt(AbstractPiglin piglin, LivingEntity target) {
        if (!(target instanceof Mob nemesis)
                || !Sensor.isEntityAttackableIgnoringLineOfSight(piglin, nemesis)) {
            return;
        }
        Brain<?> brain = piglin.getBrain();
        brain.eraseMemory(MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);
        brain.setMemoryWithExpiry(MemoryModuleType.ANGRY_AT, nemesis.getUUID(), 600L);
        brain.setMemory(MemoryModuleType.NEAREST_VISIBLE_NEMESIS, nemesis);
    }

    private static final class WitherFactionTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
        private WitherFactionTargetGoal(Mob mob) {
            super(mob, LivingEntity.class, 10, true, false, WitherFactionHostilityHandler::isWitherFaction);
        }
    }
}
