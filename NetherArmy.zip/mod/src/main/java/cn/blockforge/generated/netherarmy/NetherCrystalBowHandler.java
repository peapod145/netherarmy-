package cn.blockforge.generated.netherarmy;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.player.ArrowLooseEvent;

/**
 * 炼狱晶弓的三条服务端规则：
 *
 * <ol>
 *   <li><b>拉弓速度 2 倍</b>：原版把蓄力刻数换算成力道的
 *       {@code BowItem.getPowerForTime(charge)} 是静态方法、不可覆盖，
 *       {@code releaseUsing} 里唯一能改的就是 {@code EventHooks.onArrowLoose}
 *       （本事件）返回的 charge。翻倍后 10 刻到满档。</li>
 *   <li><b>命中挂 10 秒虚弱 / 缓慢 / 饥饿 / 易伤</b>：在箭命中实体前一刻
 *       （{@code ProjectileImpactEvent} 就在 {@code hitTargetOrDeflectSelf} 之前派发）
 *       判断"这支箭是不是本弓射出来的"——{@link AbstractArrow#getWeaponItem()} 记录着
 *       发射时手里的武器，因此对普通箭、药箭、光谱箭一律适用，也不用往箭上写数据。
 *       效果来源取箭的 {@code getEffectSource()}（正常情况就是射手）。</li>
 *   <li><b>火矢附魔 → 灵魂火矢</b>：箭在生成时被
 *       {@link NetherCrystalBowItem#createProjectile} 打上灵魂火标记；
 *       命中时这里把"点燃 5 秒"换成 {@link SoulFireBurn#ignite}——目标进入灵魂火状态，
 *       燃烧伤害翻倍（{@code SoulFireDamageHandler}）、火焰覆盖层同样是蓝焰。</li>
 * </ol>
 *
 * <p>只对本模组的弓生效：其他物品的 charge 原样放回，其他箭的命中不处理。</p>
 */
public final class NetherCrystalBowHandler {
    /** 拉弓速度倍率：charge 翻倍即 10 刻拉满。 */
    private static final int CHARGE_MULTIPLIER = 2;

    /** 命中效果的持续刻数：200 刻 = 10 秒。 */
    public static final int HIT_EFFECT_DURATION_TICKS = 200;

    /** 命中效果的等级（0 = I 级）。 */
    private static final int HIT_EFFECT_AMPLIFIER = 0;

    /** 灵魂火矢点燃目标的秒数：与原版火矢的 5 秒一致，变的只是"哪种火"。 */
    public static final float SOUL_FIRE_HIT_SECONDS = 5.0F;

    /** 灵魂火矢命中时的蓝焰粒子数量。 */
    private static final int SOUL_FIRE_HIT_PARTICLES = 12;

    private NetherCrystalBowHandler() {
    }

    @SubscribeEvent
    public static void onArrowLoose(ArrowLooseEvent event) {
        if (!event.getBow().is(GeneratedMod.NETHER_CRYSTAL_BOW.get())) {
            return;
        }
        event.setCharge(event.getCharge() * CHARGE_MULTIPLIER);
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getProjectile() instanceof AbstractArrow arrow) || arrow.level().isClientSide()) {
            return;
        }
        ItemStack weapon = arrow.getWeaponItem();
        if (weapon == null || weapon.isEmpty() || !weapon.is(GeneratedMod.NETHER_CRYSTAL_BOW.get())) {
            return;
        }
        // 火矢附魔的箭带着灵魂火标记：命中处先炸一簇蓝焰，属于纯视觉提示，不影响判定。
        boolean soulFireArrow = SoulFireBurn.isSoulFlame(arrow);
        if (soulFireArrow && arrow.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    arrow.getX(), arrow.getY(), arrow.getZ(), SOUL_FIRE_HIT_PARTICLES,
                    0.25D, 0.25D, 0.25D, 0.02D);
        }
        if (!(event.getRayTraceResult() instanceof EntityHitResult entityHit)
                || !(entityHit.getEntity() instanceof LivingEntity target)) {
            return;
        }
        Entity source = arrow.getEffectSource();
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,
                HIT_EFFECT_DURATION_TICKS, HIT_EFFECT_AMPLIFIER), source);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                HIT_EFFECT_DURATION_TICKS, HIT_EFFECT_AMPLIFIER), source);
        target.addEffect(new MobEffectInstance(MobEffects.HUNGER,
                HIT_EFFECT_DURATION_TICKS, HIT_EFFECT_AMPLIFIER), source);
        target.addEffect(new MobEffectInstance(GeneratedMod.VULNERABILITY,
                HIT_EFFECT_DURATION_TICKS, HIT_EFFECT_AMPLIFIER), source);
        if (soulFireArrow) {
            // 灵魂火替代原版"橙色火"：燃烧伤害翻倍，火焰覆盖层取 soul_fire 动画帧。
            SoulFireBurn.ignite(target, SOUL_FIRE_HIT_SECONDS);
        }
    }
}
