package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;

/**
 * 下界戍城的刷怪黑名单：戍城范围内不再自然刷出猪灵、猪灵蛮兵和僵尸猪灵。
 *
 * <p>戍城在 {@code spawn_overrides} 里没有自定义刷怪表（{@code {}}），整座建筑吃的是
 * 所在群系的刷怪规则；而 {@code spawn_overrides} 本身也只覆盖结构部件的包围盒，
 * 部件之间的庭院与缝隙照样按群系刷怪。所以和 {@link FortressSpawnBlacklistHandler}
 * 一样，统一在最终刷怪位置检查处拦截，整座戍城（含外围空地）都按同一条规则处理。</p>
 *
 * <p>判定走 {@code #netherarmy:counts_as_nether_garrison} 标签（目前只收
 * {@code netherarmy:nether_garrison}），因此不必写死结构 id：以后给戍城加变体、
 * 或者让别的模组的结构"算作戍城"，往标签里加一条即可。</p>
 *
 * <p>只拦自然刷怪这一类路径（自然 / 区块生成 / 结构 / 增援 / 刷怪笼 / 巡逻等），
 * 刷怪蛋和 {@code /summon} 仍然照常可用——那是玩家主动放的，不算"刷新"。</p>
 */
public final class GarrisonSpawnBlacklistHandler {
    public static final TagKey<Structure> GARRISON_STRUCTURES = TagKey.create(
            Registries.STRUCTURE,
            ResourceLocation.fromNamespaceAndPath("netherarmy", "counts_as_nether_garrison"));

    private GarrisonSpawnBlacklistHandler() {
    }

    /** 判断位置是否落在标签所列的任一戍城结构的整体包围盒内。 */
    public static boolean insideGarrison(ServerLevelAccessor level, BlockPos pos) {
        if (level.getLevel().dimension() != Level.NETHER) {
            return false;
        }

        Registry<Structure> structures = level.registryAccess()
                .registryOrThrow(Registries.STRUCTURE);
        for (Holder<Structure> holder : structures.getOrCreateTag(GARRISON_STRUCTURES)) {
            if (level.getLevel().structureManager()
                    .getStructureAt(pos, holder.value()).isValid()) {
                return true;
            }
        }
        return false;
    }

    @SubscribeEvent
    public static void onSpawnPlacementCheck(MobSpawnEvent.SpawnPlacementCheck event) {
        EntityType<?> type = event.getEntityType();
        if (type != EntityType.PIGLIN
                && type != EntityType.PIGLIN_BRUTE
                && type != EntityType.ZOMBIFIED_PIGLIN) {
            return;
        }

        MobSpawnType spawnType = event.getSpawnType();
        // 刷怪蛋、命令召唤是玩家主动行为，保留。
        if (spawnType == MobSpawnType.SPAWN_EGG || spawnType == MobSpawnType.COMMAND) {
            return;
        }

        if (insideGarrison(event.getLevel(), event.getPos())) {
            event.setResult(MobSpawnEvent.SpawnPlacementCheck.Result.FAIL);
        }
    }
}
