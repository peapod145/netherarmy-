package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** 格尔多末日状态的网络同步。 */
public final class GeardleSync {
    private GeardleSync() {
    }

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(GeardleStatePayload.TYPE, GeardleStatePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(
                        () -> GeardleHandler.CLIENT_APOCALYPSE = payload.active()));
        registrar.playToClient(GeardleConfirmationPayload.TYPE, GeardleConfirmationPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(
                        () -> GeardleHandler.CLIENT_PENDING_GEARDLE_HAND = payload.hand()));
        registrar.playToServer(GeardleConfirmationResponsePayload.TYPE,
                GeardleConfirmationResponsePayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> {
                    if (!(context.player() instanceof ServerPlayer player)
                            || payload.hand() < 0 || payload.hand() > 1) {
                        return;
                    }
                    InteractionHand hand = payload.hand() == 0
                            ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
                    ItemStack stack = player.getItemInHand(hand);
                    if (!stack.is(GeneratedMod.GEARDLE.get())) {
                        return;
                    }
                    if (payload.confirmed()) {
                        stack.shrink(1);
                        GeardleHandler.activate(player);
                    }
                }));
    }

    public static void sendState(ServerPlayer player, boolean active) {
        PacketDistributor.sendToPlayer(player, new GeardleStatePayload(active));
    }
}
