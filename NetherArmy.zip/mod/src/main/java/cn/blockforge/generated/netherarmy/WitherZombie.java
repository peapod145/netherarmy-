package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * 尸鬼（witherzombie）：凋灵骷髅阵营的亡灵生物，僵尸的直接子类。
 *
 * <p>直接继承 {@link Zombie}，僵尸那套"生成携带防具/武器、概率捡起物品、小型变种、
 * 穿戴装备、召集同伴"的管线全部原样复用，只在差异点上覆写：</p>
 * <ul>
 *   <li>血量 25（初版 40 下调后的削弱值）、护甲 5；移速 0.23、攻击 3 点、索敌 35——</li>
 *   <li>移速/攻击/索敌与僵尸完全一致，血量与护甲按本模组的强度定位单独标定；</li>
 *   <li>近战命中附加凋零 10s（凋灵骷髅同款）与中毒 5s；免疫凋零效果（阵营性质）；</li>
 *   <li>破门固有能力（{@link WitherZombieBreakDoorGoal}）：和平以外任何难度都砸门，
 *       木门用时为僵尸的 1/3（80 tick ≈ 4 秒），铁门以僵尸破门同速（240 tick ≈ 12 秒）
 *       敲碎；受 mobGriefing 与原版破坏方块权限约束。而且是<b>主动</b>破拆：目标躲在
 *       闭合铁门另一侧、寻路又绕不过去时，尸鬼会自己认出那扇门、走到门前、顶住门砸开
 *       （原版式破门只在"位移被挡住"那一刻发动，而闭合铁门对寻路不可通行，路径铺到
 *       门前就算走完，尸鬼站在门前不动，所以那套判定对铁门永远起不来）；</li>
 *   <li>免疫火焰（EntityType 构造器 {@code fireImmune}），不再被阳光点燃；</li>
 *   <li>岩浆游泳：不覆写 {@code canStandOnFluid}，{@code LivingEntity#travel} 的岩浆分支
 *       天然给出游泳物理；炽足兽同款浮力把它顶在岩浆面附近，寻路对岩浆/火焰代价清零，
 *       入岩浆时置 swimming 标志以播放溺尸式划水姿态（见 {@link #updateSwimming()}）；</li>
 *   <li>主动攻击僵尸/溺尸/尸壳/僵尸村民（{@code Zombie.class} 目标选择器，排除同类）、
 *       村民与僵尸村民（僵尸基类 {@code AbstractVillager}）、铁傀儡（僵尸基类）、
 *       猪灵与猪灵蛮兵（{@code AbstractPiglin}，凋灵骷髅同款）；猪灵侧的敌意见
 *       {@link WitherFactionHostilityHandler}，铁傀儡侧由阵营锁定自动成立；</li>
 *   <li>击杀僵尸系/村民时将其感染为尸鬼：{@code convertTo(type, true)} 原样保留
 *       全部装备、掉落概率、幼年状态与自定义名，不重掷生成装备（见 {@link #killedEntity}）；</li>
 *   <li>尸鬼骑士：原版"小僵尸 5% 概率骑鸡"这条分支在本实体上换成骑衰翼，概率与判定顺序
 *       逐字对齐原版（见 {@link #finalizeSpawn} 与 {@link #tryMountWitherphantom}）；</li>
 *   <li>召集同伴：原版 {@code Zombie#hurt} 写死召唤普通僵尸，这里把召唤者类型换成
 *       尸鬼本体逐行复刻（50 次随机取点、HARD 难度、同一条充值衰减），并临时清零
 *       增援属性阻断原版分支，避免混召普通僵尸；</li>
 *   <li>经验 15 点（僵尸 5 点的三倍，幼年 ×2.5 加成沿用僵尸基类）；掉落见
 *       {@code data/netherarmy/loot_table/entities/witherzombie.json}；</li>
 *   <li>自然生成：下界全部群系（权重逐群系取"该群系主要怪物二倍"，僵尸猪灵所在群系
 *       即其两倍），排除基岩层高度带与基岩地板，允许脚下/身体为岩浆（岩浆海）；
 *       <b>下界要塞全包围盒内一律不刷</b>（含呼援），见
 *       {@link #checkWitherZombieSpawnRules}；</li>
 *   <li>阵营：实体类型登记在 {@code minecraft:wither_skeletons}；{@code wither_friends}
 *       与 {@code undead}/{@code inverted_healing_and_harm}/{@code ignores_poison_and_regen}
 *      /{@code sensitive_to_smite} 等亡灵标签都嵌套了这份阵营名册，所以后续新怪只要进
 *       {@code wither_skeletons} 一处，阵营与亡灵判定（含免疫凋零，见
 *       {@code WitherFactionWitherImmunityMixin}）自动全套生效。</li>
 * </ul>
 */
public class WitherZombie extends Zombie {
    /** 近战附加的凋零时长（凋灵骷髅同款，10 秒）。 */
    private static final int WITHER_EFFECT_TICKS = 200;
    /** 近战附加的中毒时长（5 秒）。 */
    private static final int POISON_EFFECT_TICKS = 100;
    /** 岩浆游泳推进力：沿用鱼类的速度衰减模型，但让尸鬼的僵尸移速属性真正生效。 */
    private static final float LAVA_SWIM_RELATIVE_FORCE = 0.02F;
    /** 鱼类同款速度阻尼，避免岩浆内水平速度被原版 0.5 倍阻尼拖死。 */
    private static final double LAVA_SWIM_DAMPING = 0.9D;

    /** 与原版 Zombie 共用的增援充值修饰符 ID（语义完全一致，可直接复用命名空间）。 */
    private static final ResourceLocation REINFORCEMENT_CALLER_CHARGE_ID =
            ResourceLocation.withDefaultNamespace("reinforcement_caller_charge");
    private static final AttributeModifier REINFORCEMENT_CALLEE_CHARGE = new AttributeModifier(
            ResourceLocation.withDefaultNamespace("reinforcement_callee_charge"),
            -0.05F, AttributeModifier.Operation.ADD_VALUE);

    /** 幼年判定箱：成年判定箱的 0.5 倍、眼高 0.93（与小僵尸同款换算，惰性初始化）。 */
    private static EntityDimensions babyDimensions;

    public WitherZombie(EntityType<? extends WitherZombie> entityType, Level level) {
        super(entityType, level);
        // 经验值为僵尸（Monster 基类 5 点）的三倍。
        this.xpReward = 15;
        // 岩浆与火焰对寻路完全通畅（炽足兽同款三件套）。
        this.setPathfindingMalus(PathType.LAVA, 0.0F);
        this.setPathfindingMalus(PathType.DANGER_FIRE, 0.0F);
        this.setPathfindingMalus(PathType.DAMAGE_FIRE, 0.0F);
        // 破门固有能力：让寻路把闭合木门视作可通行（DOOR_WOOD_CLOSED →
        // WALKABLE_DOOR），原版 DoorInteractGoal 的路径扫描也以该标志为闸门。
        // 原版僵尸靠 setCanBreakDoors 随机打开此标志，尸鬼在构造期即常开。
        if (this.getNavigation() instanceof GroundPathNavigation groundNavigation) {
            groundNavigation.setCanOpenDoors(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                // 削弱：血量由初版 40 下调到 25（护甲与其余属性保持不变）。
                .add(Attributes.MAX_HEALTH, 25.0)
                .add(Attributes.ARMOR, 5.0);
    }

    @Override
    protected void addBehaviourGoals() {
        super.addBehaviourGoals();
        // 尸鬼破门：与原版僵尸的"10% 概率 + 仅 HARD"挂 Goal 不同，此目标无条件常驻
        // （和平除外），木门 80 tick（僵尸的 1/3 用时），铁门 240 tick（僵尸同款用时）。
        // 优先级 1 且占 MOVE/LOOK：目标躲在闭合铁门另一侧、寻路绕不过去时，
        // 由它把导航抢过来——先走到门前再砸，而不是等位移被挡住才想起来砸门。
        this.goalSelector.addGoal(1, new WitherZombieBreakDoorGoal(this));
        // 僵尸基类已含 Player / AbstractVillager（村民+僵尸村民）/ IronGolem / Turtle 索敌。
        // 主动攻击一切僵尸系（僵尸/溺尸/尸壳/僵尸村民），排除尸鬼同类。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(
                this, Zombie.class, true, target -> !(target instanceof WitherZombie)));
        // 凋灵骷髅同款：主动攻击猪灵系（猪灵/猪灵蛮兵）。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractPiglin.class, true));
    }

    // ---------------------------------------------------------------- 破门

    /**
     * 拒收原版的 {@code BreakDoorGoal}：它写死"仅 HARD 有效 + 只认木门"，且靠生成期
     * 掷骰（区域难度 × 10%）才挂上。尸鬼的破门由 {@link WitherZombieBreakDoorGoal}
     * 全量接管，这里让基类的注册/移除逻辑（setCanBreakDoors 等所有入口）整体空转。
     */
    @Override
    protected boolean supportsBreakDoorGoal() {
        return false;
    }

    /**
     * 尸鬼恒可破门。基类字段版只在 HARD 掷骰成功后为真，这里覆写成常量真，
     * 让 {@code MoveThroughVillageGoal} 为尸鬼规划穿门路径（它建路径前会临时把
     * 导航的 canOpenDoors 切到本方法的返回值）。
     */
    @Override
    public boolean canBreakDoors() {
        return true;
    }

    // ---------------------------------------------------------------- 近战与阵营

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        if (!super.doHurtTarget(target)) {
            return false;
        }
        if (target instanceof LivingEntity livingEntity) {
            livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, WITHER_EFFECT_TICKS), this);
            livingEntity.addEffect(new MobEffectInstance(MobEffects.POISON, POISON_EFFECT_TICKS), this);
        }
        return true;
    }

    // 凋灵骷髅同款的"免疫凋零效果"不再写在本地：阵营成员的效果免疫已由
    // WitherFactionWitherImmunityMixin（LivingEntity#canBeAffected）按
    // #minecraft:wither_skeletons 名册统一判定。

    /** 免疫火焰的下界亡灵：不在阳光下自燃。 */
    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    /** 不会像僵尸那样在水里溺成溺尸。 */
    @Override
    protected boolean convertsInWater() {
        return false;
    }

    // ---------------------------------------------------------------- 感染

    /**
     * 击杀僵尸/溺尸/尸壳/僵尸村民/村民时将其感染为尸鬼。
     *
     * <p>走 {@code convertTo(type, true)}：位置、朝向、幼年状态、自定义名、全部装备槽
     * 与掉落概率原样继承（与僵尸溺成溺尸同一条原版管线）；刻意不调用 finalizeSpawn，
     * 避免重掷生成装备覆盖"保留原先的装备"。村民分支在僵尸基类把村民变成僵尸村民
     * 之前拦截——尸鬼的受害者直接成为尸鬼。</p>
     */
    @Override
    public boolean killedEntity(ServerLevel level, LivingEntity victim) {
        if (isInfectable(victim) && infect(level, (net.minecraft.world.entity.Mob) victim, this.isSilent()) != null) {
            return false;
        }
        return super.killedEntity(level, victim);
    }

    /** 可被感染成尸鬼的受害者：僵尸/溺尸/尸壳/僵尸村民/村民，且不是尸鬼同类。 */
    public static boolean isInfectable(LivingEntity victim) {
        // Zombie 分支覆盖僵尸/溺尸/尸壳/僵尸村民（ZombieVillager 直接继承 Zombie），
        // AbstractVillager 分支覆盖村民。尸鬼本身排除，避免同类自感染。
        return victim instanceof net.minecraft.world.entity.Mob
                && !(victim instanceof WitherZombie)
                && (victim instanceof Zombie || victim instanceof AbstractVillager);
    }

    /**
     * 把受害者当场感染成尸鬼（供本类 {@code killedEntity} 与凋灵骷髅阵营击杀处理器共用）。
     *
     * <p>走 {@code convertTo(type, true)}：位置、朝向、幼年状态、自定义名、全部装备槽与
     * 掉落概率原样继承，新尸鬼由实体类型新建（满血），原受害者立即 discard——因此调用方
     * 返回 false 时原版不会再为它掉一次战利品。转换失败（返回 null）时调用方应走原逻辑。</p>
     */
    public static WitherZombie infect(ServerLevel level, net.minecraft.world.entity.Mob victim, boolean silent) {
        if (!isInfectable(victim)) {
            return null;
        }
        WitherZombie converted = victim.convertTo(GeneratedMod.WITHER_ZOMBIE.get(), true);
        if (converted == null) {
            return null;
        }
        converted.handleAttributes(
                level.getCurrentDifficultyAt(converted.blockPosition()).getSpecialMultiplier());
        if (!silent) {
            level.levelEvent(null, 1026, converted.blockPosition(), 0);
        }
        return converted;
    }

    // ---------------------------------------------------------------- 召集同伴

    @Override
    public boolean hurt(DamageSource source, float amount) {
        AttributeInstance reinforcements = this.getAttribute(Attributes.SPAWN_REINFORCEMENTS_CHANCE);
        double savedBase = reinforcements != null ? reinforcements.getBaseValue() : 0.0D;
        if (reinforcements != null) {
            // 临时清零：原版 Zombie#hurt 的增援分支写死召唤普通僵尸，这里由
            // callWitherZombieReinforcements 以同参数召唤尸鬼同类（见其注释）。
            reinforcements.setBaseValue(0.0D);
        }
        boolean flag;
        try {
            flag = super.hurt(source, amount);
        } finally {
            if (reinforcements != null) {
                reinforcements.setBaseValue(savedBase);
            }
        }
        if (flag) {
            this.callWitherZombieReinforcements(source);
        }
        return flag;
    }

    /**
     * 原版 {@code Zombie#hurt} 增援逻辑的逐行复刻，唯一差异是召唤实体类型换成尸鬼：
     * HARD 难度、随机数对照 {@code SPAWN_REINFORCEMENTS_CHANCE}、{@code doMobSpawning}
     * 游戏规则、50 次 7..40 格随机取点、生成规则/无遮挡/无玩家 7 格内/不含液体的终检、
     * 召唤者充值 -0.05、被召者 -0.05，全部保持一致。
     */
    private void callWitherZombieReinforcements(DamageSource source) {
        if (!(this.level() instanceof ServerLevel serverlevel)) {
            return;
        }
        LivingEntity livingentity = this.getTarget();
        if (livingentity == null && source.getEntity() instanceof LivingEntity) {
            livingentity = (LivingEntity) source.getEntity();
        }
        if (livingentity == null
                || this.level().getDifficulty() != Difficulty.HARD
                || (double) this.random.nextFloat() >= this.getAttributeValue(Attributes.SPAWN_REINFORCEMENTS_CHANCE)
                || !this.level().getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)) {
            return;
        }
        int i = Mth.floor(this.getX());
        int j = Mth.floor(this.getY());
        int k = Mth.floor(this.getZ());
        WitherZombie zombie = new WitherZombie(GeneratedMod.WITHER_ZOMBIE.get(), this.level());
        for (int l = 0; l < 50; l++) {
            int i1 = i + Mth.nextInt(this.random, 7, 40) * Mth.nextInt(this.random, -1, 1);
            int j1 = j + Mth.nextInt(this.random, 7, 40) * Mth.nextInt(this.random, -1, 1);
            int k1 = k + Mth.nextInt(this.random, 7, 40) * Mth.nextInt(this.random, -1, 1);
            BlockPos blockpos = new BlockPos(i1, j1, k1);
            EntityType<?> entitytype = zombie.getType();
            if (SpawnPlacements.isSpawnPositionOk(entitytype, this.level(), blockpos)
                    && SpawnPlacements.checkSpawnRules(entitytype, serverlevel,
                        MobSpawnType.REINFORCEMENT, blockpos, this.level().random)) {
                zombie.setPos((double) i1, (double) j1, (double) k1);
                if (!this.level().hasNearbyAlivePlayer((double) i1, (double) j1, (double) k1, 7.0D)
                        && this.level().isUnobstructed(zombie)
                        && this.level().noCollision(zombie)
                        && !this.level().containsAnyLiquid(zombie.getBoundingBox())) {
                    zombie.setTarget(livingentity);
                    zombie.finalizeSpawn(serverlevel,
                            this.level().getCurrentDifficultyAt(zombie.blockPosition()),
                            MobSpawnType.REINFORCEMENT, null);
                    serverlevel.addFreshEntityWithPassengers(zombie);
                    AttributeInstance attributeinstance =
                            this.getAttribute(Attributes.SPAWN_REINFORCEMENTS_CHANCE);
                    AttributeModifier attributemodifier =
                            attributeinstance.getModifier(REINFORCEMENT_CALLER_CHARGE_ID);
                    double d0 = attributemodifier != null ? attributemodifier.amount() : 0.0D;
                    attributeinstance.removeModifier(REINFORCEMENT_CALLER_CHARGE_ID);
                    attributeinstance.addPermanentModifier(new AttributeModifier(
                            REINFORCEMENT_CALLER_CHARGE_ID, d0 - 0.05D,
                            AttributeModifier.Operation.ADD_VALUE));
                    zombie.getAttribute(Attributes.SPAWN_REINFORCEMENTS_CHANCE)
                            .addPermanentModifier(REINFORCEMENT_CALLEE_CHARGE);
                    break;
                }
            }
        }
    }

    // ---------------------------------------------------------------- 岩浆游泳

    @Override
    public void tick() {
        super.tick();
        this.floatInLava();
    }

    /**
     * 鱼类式浮力：只修正垂直速度，不再缩放整个速度向量，避免把水平游泳速度每 tick
     * 再砍半。尸鬼仍会停留在岩浆面附近，接触稳定液面后按原版流体碰撞处理。
     */
    private void floatInLava() {
        if (!this.isInLava()) {
            return;
        }

        CollisionContext collisioncontext = CollisionContext.of(this);
        if (collisioncontext.isAbove(LiquidBlock.STABLE_SHAPE, this.blockPosition(), true)
                && !this.level().getFluidState(this.blockPosition().above()).is(FluidTags.LAVA)) {
            this.setOnGround(true);
            return;
        }

        Vec3 movement = this.getDeltaMovement();
        double vertical = Mth.clamp(movement.y * 0.5D + 0.05D, -0.08D, 0.08D);
        this.setDeltaMovement(movement.x, vertical, movement.z);
    }

    /**
     * 岩浆内采用鱼类的推进/阻尼曲线。原版 LivingEntity 岩浆分支会把速度乘以 0.5，
     * 再叠加上方浮力后尸鬼几乎无法追击；这里使用鱼类的 0.9 阻尼，让僵尸的移速属性
     * 通过 {@code zza} 参与推进，同时保留碰撞时的上跃处理。
     */
    @Override
    public void travel(net.minecraft.world.phys.Vec3 travelInput) {
        FluidState fluidstate = this.level().getFluidState(this.blockPosition());
        if (!this.isControlledByLocalInstance()
                || !this.isInLava()
                || !this.isAffectedByFluids()
                || this.canStandOnFluid(fluidstate)) {
            super.travel(travelInput);
            return;
        }

        double startY = this.getY();
        this.moveRelative(LAVA_SWIM_RELATIVE_FORCE, travelInput);
        this.move(MoverType.SELF, this.getDeltaMovement());

        Vec3 movement = this.getDeltaMovement().scale(LAVA_SWIM_DAMPING);
        if (this.getTarget() == null) {
            movement = movement.add(0.0D, -0.003D, 0.0D);
        }
        this.setDeltaMovement(movement);

        if (this.horizontalCollision
                && this.isFree(movement.x, movement.y + 0.6D - this.getY() + startY, movement.z)) {
            this.setDeltaMovement(movement.x, 0.3D, movement.z);
        }
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        this.checkInsideBlocks();
        if (this.isInLava()) {
            this.resetFallDistance();
        } else {
            super.checkFallDamage(y, onGround, state, pos);
        }
    }

    /** 身体进入岩浆即置游泳标志（同步到客户端），驱动溺尸式划水姿态。 */
    @Override
    public void updateSwimming() {
        if (!this.level().isClientSide) {
            this.setSwimming(this.isInLava());
        }
    }

    @Override
    public boolean isVisuallySwimming() {
        return this.isSwimming();
    }

    @Override
    public boolean isPushedByFluid() {
        return !this.isSwimming();
    }

    // ---------------------------------------------------------------- 幼年变种

    /** 幼年判定箱与小僵尸同款换算（0.5 倍、眼高 0.93），惰性基于本实体类型计算。 */
    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        if (this.isBaby()) {
            if (babyDimensions == null) {
                babyDimensions = this.getType().getDimensions()
                        .scale(0.5F).withEyeHeight(0.93F);
            }
            return babyDimensions;
        }
        return super.getDefaultDimensions(pose);
    }

    // ---------------------------------------------------------------- 尸鬼骑士

    /** 幼年尸鬼骑上衰翼的概率，与原版鸡骑士那条判定逐字对齐（5%）。 */
    private static final float WITHERPHANTOM_MOUNT_CHANCE = 0.05F;

    /**
     * 把原版的"小僵尸骑鸡"换成"小尸鬼骑衰翼"。
     *
     * <p>原版的鸡骑士判定内联写在 {@code Zombie#finalizeSpawn} 里，没有可覆写的钩子，
     * 只能从它的开关入手：那条分支要求组数据 {@code ZombieGroupData.canSpawnJockey} 为真，
     * 所以这里把组数据重写成 {@code (isBaby, false)}——幼年判定仍走原版同一条
     * {@code Zombie#getSpawnAsBabyOdds}（5%），只是不让它去挂鸡；随后由
     * {@link #tryMountWitherphantom} 用同一个 5% 概率挂上衰翼。幼年率与骑士率都和原版持平。</p>
     *
     * <p>组数据由外部传入时（刷怪组、转化等）也一并改写：只要 {@code canSpawnJockey} 为真就
     * 换成 false 的等价实例，保证尸鬼永远不会骑到鸡身上。</p>
     */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData spawnGroupData) {
        SpawnGroupData groupData;
        if (spawnGroupData instanceof Zombie.ZombieGroupData provided) {
            groupData = provided.canSpawnJockey
                    ? new Zombie.ZombieGroupData(provided.isBaby, false)
                    : provided;
        } else if (spawnGroupData == null) {
            groupData = new Zombie.ZombieGroupData(Zombie.getSpawnAsBabyOdds(level.getRandom()), false);
        } else {
            groupData = spawnGroupData;
        }
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 原版只给幼年个体挂坐骑（isBaby 为真时才走那条 5% 判定），这里保持一致。
        if (groupData instanceof Zombie.ZombieGroupData data && data.isBaby) {
            tryMountWitherphantom(level, difficulty);
        }
        return result;
    }

    /**
     * 挂一只衰翼当坐骑，动作顺序照抄原版对鸡做的事：同点落位 → 以 {@code JOCKEY} 归因做
     * {@code finalizeSpawn} → 乘骑 → 入世界；差别只在坐骑换成衰翼，并且要求持久化——
     * 幻翼没有"骑士鸡"这种免消失标记，不置持久化的话它中途被刷掉，小尸鬼就被丢在半空。
     */
    private void tryMountWitherphantom(ServerLevelAccessor level, DifficultyInstance difficulty) {
        if (level.getRandom().nextFloat() >= WITHERPHANTOM_MOUNT_CHANCE) {
            return;
        }
        Witherphantom mount = GeneratedMod.WITHERPHANTOM.get().create(level.getLevel());
        if (mount == null) {
            return;
        }
        mount.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), 0.0F);
        mount.finalizeSpawn(level, difficulty, MobSpawnType.JOCKEY, null);
        mount.setPersistenceRequired();
        if (!this.startRiding(mount)) {
            // 乘骑失败（例如已经骑在别的东西上）：坐骑不入世界，避免留下没人骑的衰翼。
            return;
        }
        level.getLevel().addFreshEntity(mount);
    }

    // ---------------------------------------------------------------- 自然生成

    /**
     * 下界自然生成规则（配合 NO_RESTRICTIONS 放置类型自行完成原版地板校验）：
     *
     * <ul>
     *   <li>和平难度不刷；刷怪蛋/刷怪笼/凋灵召唤等非自然路径直接放行；</li>
     *   <li><b>下界要塞黑名单</b>：落点位于 {@code #netherarmy:counts_as_nether_fortress}
     *       标签所列的任一有效要塞整体包围盒内一律不刷，覆盖原版要塞、
     *       {@code netherarmy:fortress}、{@code netherarmy:small_fortress}，
     *       以及 {@code #netherarmy:large_fortress} 收录的大型要塞。
     *       原版要塞的 {@code spawn_overrides}（monster，PIECE 包围盒）只顶替
     *       结构部件包围盒内的生物群系刷怪表，院落、桥缘等部件之外的空地照旧
     *       按群系表走——尸鬼在恶地权重高达 200，要塞内因此随处可见；
     *       {@code neoforge:remove_spawns} 删不到生物群系表，只能在这条规则
     *       函数里一票否决。HARD 难度呼援与生成期预刷走同一函数，一并拦下；</li>
     *   <li>基岩层排除：高度带 y≤4 与 y≥122（下界顶底板床岩及其噪声带），且地板
     *       本身不得是基岩；</li>
     *   <li>地板允许实心方块或岩浆（岩浆海）；生成格与头顶格允许空气或岩浆——
     *       岩浆分支的 isValidSpawn 恒失败（岩浆发光 15），原版 ON_GROUND 不可用，
     *       与衰翼的注册同理；</li>
     *   <li>主刷怪循环原有的 noCollision 终检保持不变。</li>
     * </ul>
     */
    public static boolean checkWitherZombieSpawnRules(EntityType<WitherZombie> entityType,
                                                      ServerLevelAccessor level, MobSpawnType spawnType,
                                                      BlockPos pos, RandomSource random) {
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        if (insideNetherFortress(level, pos)) {
            return false;
        }
        boolean natural = spawnType == MobSpawnType.NATURAL || spawnType == MobSpawnType.CHUNK_GENERATION;
        if (!natural) {
            return true;
        }
        int y = pos.getY();
        if (y <= 4 || y >= 122) {
            return false;
        }
        BlockPos below = pos.below();
        BlockState floor = level.getBlockState(below);
        if (floor.is(Blocks.BEDROCK)) {
            return false;
        }
        boolean floorOk = floor.is(Blocks.LAVA) || floor.isSolidRender(level, below);
        return floorOk && isAirOrLavaCell(level, pos) && isAirOrLavaCell(level, pos.above());
    }

    /**
     * 落点是否位于任一已生成下界要塞的整体包围盒内（含部件包围盒之外的院落空地）。
     * 判定与原版 {@code NaturalSpawner#isInNetherFortressBounds} 的结构测试同源
     * （{@code StructureManager#getStructureAt} 的起始包围盒检查），但不要求脚下
     * 是下界砖——正是要把"要塞观感范围内"的所有刷新缝隙全部堵上。
     */
    private static boolean insideNetherFortress(ServerLevelAccessor level, BlockPos pos) {
        return FortressSpawnBlacklistHandler.insideFortress(level, pos);
    }

    /** 该格能否作为身体占位：无完整碰撞、非信号源、流体只允许岩浆、不在禁止刷怪方块内。 */
    private static boolean isAirOrLavaCell(BlockGetter level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.isCollisionShapeFullBlock(level, pos)) {
            return false;
        }
        if (state.isSignalSource()) {
            return false;
        }
        FluidState fluid = state.getFluidState();
        return (fluid.isEmpty() || fluid.is(FluidTags.LAVA))
                && !state.is(BlockTags.PREVENT_MOB_SPAWNING_INSIDE);
    }
}
