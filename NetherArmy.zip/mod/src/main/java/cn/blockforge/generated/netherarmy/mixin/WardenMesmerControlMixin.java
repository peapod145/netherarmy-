package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MesmerizerControl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.AngerLevel;
import net.minecraft.world.entity.monster.warden.Warden;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 反逆者心控对监守者的强制覆盖。
 *
 * <p>监守者的索敌不走 {@code Mob.setTarget}，而是 Brain 的 {@code ATTACK_TARGET} 记忆，
 * 并且整套战斗链都以"愤怒值"为前提：</p>
 * <ul>
 *   <li>{@code Warden#increaseAngerAt} 是声音（振动）、接触、受击共用的愤怒入口——
 *       玩家制造动静即累计愤怒，跨过阈值还会直接抹掉 {@code ATTACK_TARGET}，
 *       等 {@code SetRoarTarget → ROAR → setAttackTarget} 转一圈后，仇恨就换成了声源；</li>
 *   <li>{@code FIGHT} 活动里的 {@code StopAttackingIfTargetInvalid} 谓词要求
 *       {@code getAngerLevel().isAngry()} 为真，否则每刻清除目标——被控监守者若愤怒
 *       归零，外部强行写入的 {@code ATTACK_TARGET} 会在下一个 Brain tick 里被抹掉。</li>
 * </ul>
 *
 * <p>因此这里做三件事：被控期间愤怒不再因声音/接触/受击累积（彻底掐断"仇恨随声源走"
 * 的源头）；被控期间 {@code getAngerLevel} 恒报 ANGRY，让 {@code FIGHT} 活动保住
 * {@code MesmerizerControlHandler} 每刻同步的反逆者目标；被控期间 {@code Warden#hurt}
 * 里"无目标时顺手记恨攻击者"的分支不再执行，索敌完全交由反逆者接管。</p>
 *
 * <p>残余嫌疑人由 {@code MesmerizerControlHandler} 每刻用公开的
 * {@code getEntityAngryAt()/clearAnger()} 排空，防止旧仇恨经咆哮链复活。</p>
 */
@Mixin(Warden.class)
public abstract class WardenMesmerControlMixin {

    @Inject(method = "increaseAngerAt(Lnet/minecraft/world/entity/Entity;IZ)V", at = @At("HEAD"), cancellable = true)
    private void netherarmy$blockVibrationAnger(Entity source, int amount, boolean playListeningSound, CallbackInfo callback) {
        if (MesmerizerControl.isControlled((LivingEntity) (Object) this)) {
            callback.cancel();
        }
    }

    @Inject(method = "getAngerLevel", at = @At("HEAD"), cancellable = true)
    private void netherarmy$forcedAngryWhileControlled(CallbackInfoReturnable<AngerLevel> callback) {
        if (MesmerizerControl.isControlled((LivingEntity) (Object) this)) {
            callback.setReturnValue(AngerLevel.ANGRY);
        }
    }

    @Redirect(method = "hurt(Lnet/minecraft/world/damagesource/DamageSource;F)Z",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/warden/Warden;setAttackTarget(Lnet/minecraft/world/entity/LivingEntity;)V"))
    private void netherarmy$blockHurtRetarget(Warden warden, LivingEntity attacker) {
        if (!MesmerizerControl.isControlled(warden)) {
            warden.setAttackTarget(attacker);
        }
    }
}
