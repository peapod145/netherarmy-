package cn.blockforge.generated.netherarmy;

/**
 * {@code AbstractFurnaceBlockEntity} 的鸭子接口，由
 * {@link cn.blockforge.generated.netherarmy.mixin.CrystalShardSmeltingSpeedMixin}
 * 合并进原版熔炉方块实体。
 *
 * <p>用途是让静态的 {@code serverTick} 注入点能够跨类读写熔炉的包级私有计时字段，
 * 并查询"当前这一炉烧的是不是炼狱晶碎片"：
 * <ul>
 *   <li>{@link #netherarmy$isCrystalShardFuel()} —— 点火那一刻记下的燃料标记；</li>
 *   <li>{@link #netherarmy$cookingProgress()} / {@link #netherarmy$setCookingProgress(int)}
 *       —— 当前烧炼进度（原版每 tick +1）；</li>
 *   <li>{@link #netherarmy$cookingTotalTime()} —— 本次烧炼的总时长；</li>
 *   <li>{@link #netherarmy$litTime()} —— 剩余燃烧时间（>0 即处于点燃状态）。</li>
 * </ul>
 */
public interface CrystalShardFuelAccess {
    /** 当前正在燃烧的燃料是否为炼狱晶碎片。 */
    boolean netherarmy$isCrystalShardFuel();

    /** 当前烧炼进度（tick）。 */
    int netherarmy$cookingProgress();

    /** 改写当前烧炼进度（tick）。 */
    void netherarmy$setCookingProgress(int progress);

    /** 当前这一炉的烧炼总时长（tick）。 */
    int netherarmy$cookingTotalTime();

    /** 剩余燃烧时间（tick）。 */
    int netherarmy$litTime();
}
