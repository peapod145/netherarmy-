package cn.blockforge.generated.netherarmy;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileItem;
import net.minecraft.world.level.Level;

/** 可手掷、也可由发射器发射的圣光炸弹。 */
public final class HolyBombItem extends Item implements ProjectileItem {
    private static final int COOLDOWN_TICKS = 2 * 20;
    private static final float THROW_SPEED = 1.5F;
    private static final float THROW_INACCURACY = 1.0F;

    public HolyBombItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide()) {
            HolyBomb bomb = new HolyBomb(player, level, player.getViewVector(1.0F));
            bomb.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F,
                    THROW_SPEED, THROW_INACCURACY);
            level.addFreshEntity(bomb);
            // 与原版雪球完全一致：由服务端向附近客户端广播投掷音效，避免客户端侧
            // 直接调用 playSound 时没有对应的服务端声音事件。
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.SNOWBALL_THROW, SoundSource.NEUTRAL, 0.5F,
                    0.4F / (level.getRandom().nextFloat() * 0.4F + 0.8F));
        }
        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        player.awardStat(Stats.ITEM_USED.get(this));
        stack.consume(1, player);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public Projectile asProjectile(Level level, net.minecraft.core.Position position,
                                   ItemStack stack, net.minecraft.core.Direction direction) {
        HolyBomb bomb = new HolyBomb(level, position.x(), position.y(), position.z());
        bomb.setItem(stack);
        this.shoot(bomb, direction.getStepX(), direction.getStepY(), direction.getStepZ(),
                THROW_SPEED, THROW_INACCURACY);
        return bomb;
    }
}
