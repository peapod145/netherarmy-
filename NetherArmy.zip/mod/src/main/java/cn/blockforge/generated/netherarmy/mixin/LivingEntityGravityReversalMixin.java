package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.GeneratedMod;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 重力反转的"起浮打火"：绕开原版 {@code aiStep} 的竖直速度死区。
 *
 * <p><b>为什么需要这个补丁：</b>{@code LivingEntity#aiStep} 一进门就取一次
 * {@code getDeltaMovement()}，把三个分量里绝对值小于 {@link LivingEntity#MIN_MOVEMENT_DISTANCE}
 * （0.003）的<b>直接抹成 0</b>，这段代码排在 {@code travel} 之前。重力反转是靠"负重力"逐 tick
 * 累计竖直速度的（{@code v ← 0.98 · (v + g)}），把 g 压到"飘浮二倍"对应的量级后
 * （系数见 {@link EntityGravityReversalMixin}，{@code g ≈ 0.00185}），
 * 第一步只能得到 {@code g · 0.98 ≈ 0.0018}——落在死区里，下一 tick 又被抹平，
 * 于是速度永远爬不到稳态，实体纹丝不动。现象就是"模型翻过来了，但浮不起来"。</p>
 *
 * <p><b>做法：</b>只在死区那一档上补一手。竖直速度只要还在 {@code ±MIN_MOVEMENT_DISTANCE}
 * 之内，就先垫一个刚越过死区的小值，让之后的重力累计能正常爬到 49g
 * （= 飘浮 I 稳态速度的二倍）。跳跃、击退、爆炸这些真正的大速度不在死区里，一个字节都不碰；
 * 流体与鞘翅分支走原版自己的算法，也不干预。</p>
 *
 * <p>钩子挂在 {@code travel} 而不是 {@code aiStep}：死区清零就在同一个
 * {@code aiStep} 里、{@code travel} 调用之前，挂 {@code aiStep} 的 HEAD 会被那次清零覆盖，
 * 挂 {@code travel} 的 HEAD 才落在清零之后。</p>
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityGravityReversalMixin {

    /**
     * 打火值：两倍死区，保证 {@code travel} 末尾乘 0.98 之后仍稳稳高于
     * {@link LivingEntity#MIN_MOVEMENT_DISTANCE}，下一 tick 不会被再抹掉。
     */
    private static final double BOOTSTRAP_ASCENT = 2.0D * LivingEntity.MIN_MOVEMENT_DISTANCE;

    @Inject(method = "travel", at = @At("HEAD"))
    private void netherarmy$bootstrapReversedAscent(Vec3 input, CallbackInfo callback) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!self.hasEffect(GeneratedMod.GRAVITY_REVERSAL)) {
            return;
        }
        // 三种走原版另一套竖直算法的情形不插手：水中、岩浆中、鞘翅滑翔。
        if (self.isInWater() || self.isInLava() || self.isFallFlying()) {
            return;
        }
        // 本来就没有重力的实体（getGravity 恒 0）反转后也没有上浮力，别用打火伪造出假上浮。
        if (self.isNoGravity()) {
            return;
        }
        Vec3 motion = self.getDeltaMovement();
        if (Math.abs(motion.y) < LivingEntity.MIN_MOVEMENT_DISTANCE) {
            self.setDeltaMovement(motion.x, BOOTSTRAP_ASCENT, motion.z);
        }
    }
}
