package cn.blockforge.generated.netherarmy;

/**
 * 军团光环载体：由 {@code LegionAuraMobMixin} 混入 {@link net.minecraft.world.entity.Mob}。
 *
 * <p>光环标记用原版同步实体数据（synched entity data）承载，服务端写、客户端读，
 * 天然跟随实体进出追踪范围，无需任何额外网络包；客户端渲染层（脚下光环贴图）与
 * 服务端结算（{@link LegionAuraHandler} 的属性/回血、
 * {@code LegionAuraMeleeCooldownMixin} 的攻速）读的是同一个标志。</p>
 */
public interface ILegionAuraCarrier {
    boolean netherarmy$hasLegionAura();

    void netherarmy$setLegionAura(boolean value);
}
