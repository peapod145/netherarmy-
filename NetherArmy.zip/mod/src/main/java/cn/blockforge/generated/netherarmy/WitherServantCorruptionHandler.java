package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.GameRules;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/**
 * 凋零腐蚀催生：非凋灵骷髅阵营的生物每被凋零 buff 的持续伤害扣一次血，
 * 就有 5% 概率在身边凝出一只对它怀有专属仇恨的凋灵仆役。玩家同样算数。
 *
 * <p>判定挂在 {@link LivingDamageEvent.Post} 而不是 Incoming/Pre：只有真正掉了血的
 * 那一次才掷骰，被护盾完全格挡、被吸收盾吃光、无敌帧免疫的伤害都不算数
 * （{@code getNewDamage()} 就是这次实际损失的血量，结算完的余血 ≤ 0 也不催生——
 * 猎物当场没了，仆役生出来只会发呆）。</p>
 *
 * <p>阵营口径取 {@link MesmerizerControl#isWitherSkeletonFaction}（阵营名册标签 +
 * 凋灵骷髅基类 + 凋灵 + 无头骑士头颅）。凋灵骷髅阵营成员本来就免疫凋零 buff，
 * 这一条主要拦"其它模组硬塞进来的凋零伤害"——自己人不刷自己人。</p>
 *
 * <p>落点照尸鬼增援那套"随机采样 + 找结实地面"处理：在受害者水平 ±4 格、竖直
 * -1~+1 格的范围内随机采样，再向下找最多 3 格结实地面，要求脚下与头顶无液体、
 * 无实体碰撞；受害者悬空（飞行生物、鞘翅）或泡在水里时找不到落脚面，就贴着它
 * 本体生成，由重力自己落位。生成后由 {@link WitherServant#becomeHostileTo}
 * 把受害者钉成这只仆役的唯一猎物。</p>
 *
 * <p>难度为和平、或世界规则关闭 {@code doMobSpawning} 时不催生（与尸鬼增援、
 * 巡逻队、陷阱刷新同一条门槛）。一次伤害事件只掷一次骰，因此一次最多催生一只。</p>
 */
public final class WitherServantCorruptionHandler {
    /** 每次凋零 buff 掉血的催生概率。 */
    private static final float SPAWN_CHANCE = 0.05F;
    /** 找落脚面的采样次数。 */
    private static final int SPAWN_ATTEMPTS = 24;
    /** 水平散布半径（格）。 */
    private static final int HORIZONTAL_RANGE = 4;
    /** 从候选点向下找地面的最大深度（格）。 */
    private static final int VERTICAL_DROP = 3;

    private WitherServantCorruptionHandler() {
    }

    @SubscribeEvent
    public static void onLivingDamaged(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !(victim.level() instanceof ServerLevel level)) {
            return;
        }
        if (!event.getSource().is(DamageTypes.WITHER)) {
            return;
        }
        if (!victim.isAlive() || victim.isRemoved() || event.getNewDamage() <= 0.0F) {
            return;
        }
        if (MesmerizerControl.isWitherSkeletonFaction(victim)) {
            return;
        }
        if (level.getDifficulty() == Difficulty.PEACEFUL
                || !level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)) {
            return;
        }
        if (level.getRandom().nextFloat() >= SPAWN_CHANCE) {
            return;
        }
        spawn(level, victim);
    }

    private static void spawn(ServerLevel level, LivingEntity victim) {
        WitherServant servant = GeneratedMod.WITHER_SERVANT.get().create(level);
        if (servant == null || !placeNear(level, servant, victim)) {
            return;
        }
        servant.finalizeSpawn(level, level.getCurrentDifficultyAt(servant.blockPosition()),
                MobSpawnType.TRIGGERED, null);
        servant.becomeHostileTo(victim);
        level.addFreshEntityWithPassengers(servant);
    }

    /** 找一个能站的地面点；全找不到就退回"贴着受害者生成"。 */
    private static boolean placeNear(ServerLevel level, WitherServant servant, LivingEntity victim) {
        RandomSource random = level.getRandom();
        BlockPos origin = victim.blockPosition();
        for (int attempt = 0; attempt < SPAWN_ATTEMPTS; attempt++) {
            int dx = random.nextInt(HORIZONTAL_RANGE * 2 + 1) - HORIZONTAL_RANGE;
            int dz = random.nextInt(HORIZONTAL_RANGE * 2 + 1) - HORIZONTAL_RANGE;
            int dy = random.nextInt(3) - 1;
            for (int drop = 0; drop <= VERTICAL_DROP; drop++) {
                BlockPos floor = origin.offset(dx, dy - drop, dz);
                if (!level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) {
                    continue;
                }
                BlockPos feet = floor.above();
                if (!level.getFluidState(feet).isEmpty()
                        || !level.getFluidState(feet.above()).isEmpty()) {
                    break;
                }
                if (tryPlace(level, servant, feet, random)) {
                    return true;
                }
                break;
            }
        }
        return tryPlace(level, servant, origin, random)
                || tryPlace(level, servant, origin.above(), random);
    }

    private static boolean tryPlace(ServerLevel level, WitherServant servant, BlockPos feet,
                                    RandomSource random) {
        servant.moveTo(feet.getX() + 0.5D, feet.getY(), feet.getZ() + 0.5D,
                random.nextFloat() * 360.0F, 0.0F);
        return level.noCollision(servant) && level.isUnobstructed(servant);
    }
}
