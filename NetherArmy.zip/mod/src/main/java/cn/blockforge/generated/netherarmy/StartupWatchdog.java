package cn.blockforge.generated.netherarmy;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 启动看门狗（仅客户端启动）：模组 client setup 完成后拉起一条守护线程，
 * 在 75 / 150 / 300 秒三个检查点各看一眼"游戏是否已经进入主界面（或任何界面）"，
 * 还没进去就把<b>全 JVM 线程堆栈</b>写到游戏目录
 * {@code logs/netherarmy-stuck-<秒数>s.txt}。
 *
 * <p>存在的意义：卡在加载画面时，光看进度条百分比无法定位卡死点——线程堆栈能。
 * 拿到这份 dump，第一行主线程（Render thread）的栈顶帧就是此刻卡住的代码；
 * 如果主线程在等某个 CompletableFuture，被等的工作线程在干什么也一并写在里面。</p>
 *
 * <p>安全性：本类只在 {@code FMLClientSetupEvent} 里被 {@link #start()}，
 * 对 {@code net.minecraft.client.Minecraft} 的引用只发生在检查点方法体内，
 * 专用服务端永远不会加载这些客户端类；线程是 daemon，任何异常都被吞掉，
 * 最坏情况等于这个功能不存在，不会影响游戏。</p>
 */
public final class StartupWatchdog {
    /** 检查点（秒）：到点仍未进界面就写一份堆栈 dump。 */
    private static final long[] CHECKPOINT_SECONDS = {75L, 150L, 300L};

    private static volatile boolean started;

    private StartupWatchdog() {
    }

    /** 由客户端 setup 调用；幂等。 */
    public static void start() {
        if (started) {
            return;
        }
        started = true;
        Thread thread = new Thread(StartupWatchdog::watch, "netherarmy-startup-watchdog");
        thread.setDaemon(true);
        thread.start();
    }

    private static void watch() {
        long beginMillis = System.currentTimeMillis();
        try {
            for (long checkpoint : CHECKPOINT_SECONDS) {
                long sleepMillis = checkpoint * 1000L - (System.currentTimeMillis() - beginMillis);
                if (sleepMillis > 0) {
                    Thread.sleep(sleepMillis);
                }
                if (gameHasReachedUi()) {
                    return;
                }
                writeDump(checkpoint);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable ignored) {
            // 看门狗自身绝不允许影响游戏。
        }
    }

    /** 主界面/弹窗/已进世界——任意一个出现即说明启动流程已经走过去了。 */
    private static boolean gameHasReachedUi() {
        try {
            net.minecraft.client.Minecraft minecraft = net.minecraft.client.Minecraft.getInstance();
            return minecraft == null || minecraft.screen != null || minecraft.level != null;
        } catch (Throwable t) {
            // 客户端类还没就绪（拿不到实例）时保守视为"仍在加载"。
            return false;
        }
    }

    private static void writeDump(long checkpointSeconds) {
        try {
            File logsDir = new File("logs");
            if (!logsDir.isDirectory() && !logsDir.mkdirs()) {
                logsDir = new File(".");
            }
            File out = new File(logsDir, "netherarmy-stuck-" + checkpointSeconds + "s.txt");
            StringBuilder text = new StringBuilder();
            text.append("netherarmy startup watchdog: game still has no UI after ")
                    .append(checkpointSeconds).append("s\n");
            text.append("time: ").append(new java.util.Date()).append('\n');
            text.append("java: ").append(System.getProperty("java.vendor", "?"))
                    .append(' ').append(System.getProperty("java.version", "?")).append('\n');
            text.append("os:   ").append(System.getProperty("os.name", "?"))
                    .append(' ').append(System.getProperty("os.version", "?")).append('\n');
            text.append("mod:  ").append(GeneratedMod.LOGGER.getName())
                    .append(" (watchdog started at client setup)\n\n");
            appendUiState(text);
            text.append("\n=== thread dump ===\n");
            List<Map.Entry<Thread, StackTraceElement[]>> entries =
                    new ArrayList<>(Thread.getAllStackTraces().entrySet());
            entries.sort(Comparator.comparing(e -> e.getKey().getName()));
            for (Map.Entry<Thread, StackTraceElement[]> entry : entries) {
                Thread t = entry.getKey();
                text.append('\n').append('"').append(t.getName())
                        .append("\" id=").append(t.getId())
                        .append(" state=").append(t.getState())
                        .append(t.isDaemon() ? " daemon" : "").append('\n');
                for (StackTraceElement frame : entry.getValue()) {
                    text.append("    at ").append(frame).append('\n');
                }
            }
            Files.writeString(out.toPath(), text.toString(), StandardCharsets.UTF_8);
            GeneratedMod.LOGGER.warn("[netherarmy] still loading after {}s - thread dump written to {}",
                    checkpointSeconds, out.getPath());
        } catch (Throwable ignored) {
            // 写不出来就算了。
        }
    }

    /** 反射读客户端界面状态（读不到就略过，绝不抛）。 */
    private static void appendUiState(StringBuilder text) {
        try {
            net.minecraft.client.Minecraft minecraft = net.minecraft.client.Minecraft.getInstance();
            if (minecraft == null) {
                return;
            }
            text.append("\n=== game state ===\n")
                    .append("screen : ").append(nameOf(minecraft.screen)).append('\n')
                    .append("level  : ").append(minecraft.level == null ? "null" : "present").append('\n');
        } catch (Throwable ignored) {
        }
    }

    private static String nameOf(Object object) {
        return object == null ? "null" : object.getClass().getName();
    }
}
