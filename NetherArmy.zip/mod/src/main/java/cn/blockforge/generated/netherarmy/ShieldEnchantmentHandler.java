package cn.blockforge.generated.netherarmy;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * 盾牌附魔：护主、重塑、立体防御与钝击缓冲，并处理亡魂重盾的格挡效果与被斧头缴械的冷却。
 *
 * <p>护主／重塑／立体防御对<b>任何活体</b>生效（玩家与怪物 alike，无头骑士副手的护主盾靠这条通道挡伤）：
 * 判定全部挂在 {@link LivingIncomingDamageEvent}／{@link LivingShieldBlockEvent} 上，
 * 手上那面带附魔的盾牌是唯一的门槛，不再要求实体必须是玩家。
 * 唯一的差别是"举盾"这个动作只有玩家会做，所以立体防御对怪物按常驻格挡处理
 * （见 {@link #findActiveShield}）。
 * 缴械分两条通道：正在举盾的玩家走原版格挡链（{@code isDamageSourceBlocked} →
 * {@link LivingShieldBlockEvent} → {@code disableShield()}）；而<b>护主玩家即使没举盾也会被缴械</b>——
 * 护主把伤害在 {@link LivingIncomingDamageEvent} 就吞掉了，原版的 {@code isBlocking()} 前提
 * 在"未举盾"时根本不成立、整条格挡链不可达，所以在护主分支里手动复刻 {@code disableShield()}
 * 的三件事（写冷却、停用水品、广播 30 号破盾事件）并套用同一套冷却规则。
 * 怪物仍然不会被缴械：{@code getCooldowns()} 与 {@code disableShield()} 都是 {@link Player} 的成员，
 * 原版的敲落盾牌那步（{@code Player#blockUsingShield} 的 {@code disableShield()}）也只有玩家有
 * （{@code LivingEntity#blockUsingShield} 只会敲退攻击者）。</p>
 *
 * <p>护主通道的耐久损耗沿用护主自己的规则（每击扣原始伤害向上取整），但当攻击者是斧类且持盾者
 * 因此被缴械时，损耗同样并入下方战斧特例。</p>
 *
 * <p>地煞战斧的缴械特例（斧类固有判定 {@code IItemExtension#canDisableShield} 默认
 * {@code this instanceof AxeItem}，本斧继承 {@code AxeItem} 故天然能缴械，这里只改结算）：
 * 缴械冷却 ×2（普通盾牌 100 → 200 刻 = 10 秒），并且被敲落这一击的盾牌耐久损耗
 * = 这一击的斧伤害 ×2（满蓄力 18 点伤害 → 扣 36 点），原版的 {@code 1 + floor(格挡伤害)}
 * 损耗在这条通道上被替换掉，避免与 ×2 的定死数值叠出不成比例的数。</p>
 */
public final class ShieldEnchantmentHandler {
    /** 普通盾牌被斧头缴械后的冷却（刻）：原版 Player#disableShield 里写死的 100。 */
    private static final int SHIELD_DISARM_COOLDOWN = 100;
    /** 亡魂重盾被斧头缴械后的冷却（刻）：普通盾牌的一半，即 50 刻（2.5 秒）。 */
    private static final int SOUL_SHIELD_DISARM_COOLDOWN = SHIELD_DISARM_COOLDOWN / 2;
    /** 地煞战斧的缴械冷却倍率：正常斧类武器（100 刻）的两倍。 */
    private static final int DISHA_DISARM_COOLDOWN_MULTIPLIER = 2;
    /** 地煞战斧缴械时的盾牌耐久损耗倍率：损耗 = 这一击的斧伤害 × 2。 */
    private static final double DISHA_SHIELD_WEAR_MULTIPLIER = 2.0D;
    /** 钝击缓冲的最高等级，每级把缴械冷却缩短 15%（5 级即 75%）。 */
    private static final int MAX_BLUNT_BUFFER_LEVEL = 5;
    private static final double BLUNT_BUFFER_REDUCTION_PER_LEVEL = 0.15D;

    /** 本刻刚被斧头缴械、需要在刻末覆写冷却的盾牌；在刻末统一处理。 */
    private static final Map<UUID, PendingDisarm> PENDING_DISARM = new ConcurrentHashMap<>();

    private ShieldEnchantmentHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide() || event.getAmount() <= 0.0F
                || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }

        Holder<Enchantment> protector = enchantment(entity, GeneratedMod.PROTECTOR);
        ShieldInHand protectorShield = findShield(entity, protector);
        if (protectorShield != null) {
            ItemStack stack = protectorShield.stack();
            DamageSource source = event.getSource();
            applySoulShieldWither(entity, stack, source);
            boolean axeDisarm = canDisableShieldBy(source);
            boolean dishaDisarm = axeDisarm && attackerHoldsDisha(source);
            // amount 就是"这一击的原始伤害"（护甲前、含蓄力倍率），与格挡通道 getOriginalDamage() 同口径。
            int wear = dishaDisarm ? dishaShieldWear(event.getAmount())
                    : Math.max(1, (int) Math.ceil(event.getAmount()));
            damageShield(entity, protectorShield, wear);
            if (axeDisarm && entity instanceof Player player) {
                // 未举盾也缴械：复刻 disableShield()（写冷却 + 停用 + 破盾反馈），规则与格挡通道一致。
                applyProtectorDisarm(player, stack, dishaDisarm);
            }
            event.setCanceled(true);
            return;
        }

        Holder<Enchantment> threeDimensionalDefense = enchantment(entity, GeneratedMod.THREE_DIMENSIONAL_DEFENSE);
        ShieldInHand defenseShield = findActiveShield(entity, threeDimensionalDefense);
        if (defenseShield != null && event.getSource().getDirectEntity() != entity
                && !event.getSource().is(DamageTypeTags.BYPASSES_SHIELD)) {
            applySoulShieldWither(entity, defenseShield.stack(), event.getSource());
            damageShield(entity, defenseShield, Math.max(1, (int) Math.ceil(event.getAmount())));
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onShieldBlock(LivingShieldBlockEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()
                || event.getDamageSource().is(DamageTypeTags.BYPASSES_SHIELD)) {
            return;
        }

        ItemStack used = entity.getUseItem();
        if (!isShield(used)) {
            return;
        }

        Holder<Enchantment> threeDimensionalDefense = enchantment(entity, GeneratedMod.THREE_DIMENSIONAL_DEFENSE);
        Holder<Enchantment> remodel = enchantment(entity, GeneratedMod.REMODEL);
        boolean allAngle = EnchantmentHelper.getItemEnchantmentLevel(threeDimensionalDefense, used) > 0;
        boolean hasRemodel = EnchantmentHelper.getItemEnchantmentLevel(remodel, used) > 0;
        // 缴械这一步只在"格挡真的成立"时才会发生：原版 getOriginalBlock() 为真，
        // 或者立体防御把这一击补成格挡（setBlocked(true) 后同样会走 blockUsingShield）。
        boolean blocked = event.getOriginalBlock() || allAngle;
        boolean dishaDisarm = blocked && isDishaDisarm(entity, event.getDamageSource());
        if (blocked) {
            applySoulShieldWither(entity, used, event.getDamageSource());
            queueShieldDisarm(entity, used, event.getDamageSource(), dishaDisarm);
        }
        if (dishaDisarm && !entity.hasInfiniteMaterials()) {
            // 缴械这一击的盾牌损耗按"斧伤害 ×2"由我们自己扣，原版的 1+floor(格挡伤害) 让位。
            event.setShieldDamage(0.0F);
            damageShield(entity, new ShieldInHand(activeHand(entity), used),
                    dishaShieldWear(event.getDamageContainer().getOriginalDamage()));
            if (entity.getItemInHand(activeHand(entity)) != used) {
                // 盾牌已被这次损耗敲碎摘手，后面不再对同一个 stack 结算第二次。
                return;
            }
        }
        if (!allAngle && !hasRemodel) {
            return;
        }
        if (!event.getOriginalBlock() && !allAngle) {
            return;
        }

        if (allAngle) {
            event.setBlocked(true);
            event.setBlockedDamage(event.getDamageContainer().getOriginalDamage());
        }

        float shieldDamage = event.getBlockedDamage();
        if (shieldDamage <= 0.0F) {
            event.setShieldDamage(0.0F);
            return;
        }

        event.setShieldDamage(0.0F);
        damageShield(entity, new ShieldInHand(activeHand(entity), used), Math.max(1, (int) Math.ceil(shieldDamage)));
    }

    /**
     * 刻末收尾：原版的缴械冷却此时已经写进玩家的冷却表，这里把冷却改成本来就该有的长度。
     * 与原版同刻写入、同刻覆写，所以重盾的冷却恰好是普通盾牌的一半（50 刻），
     * 地煞战斧敲落的再翻成两倍（普通盾牌 200 刻 = 10 秒），
     * 带钝击缓冲的盾牌再按等级缩短 15% × 等级，客户端也会收到覆写后的同步包。
     */
    @SubscribeEvent
    public static void onServerTickEnd(ServerTickEvent.Post event) {
        if (PENDING_DISARM.isEmpty()) {
            return;
        }
        for (PendingDisarm pending : PENDING_DISARM.values()) {
            Player player = pending.player();
            Item item = pending.shield().getItem();
            // 只有真正被缴械才会出现该冷却；举着盾时不可能已在冷却中，故这条冷却必然来自本刻的缴械。
            if (!player.getCooldowns().isOnCooldown(item)) {
                continue;
            }
            player.getCooldowns().addCooldown(item, disarmCooldown(pending));
        }
        PENDING_DISARM.clear();
    }

    /** 按钝击缓冲等级折算缴械冷却：每级 -15%，至少保留 1 刻。 */
    private static int disarmCooldown(PendingDisarm pending) {
        return reduceWithBluntBuffer(pending.baseCooldown(), pending.bluntBufferLevel());
    }

    /** 钝击缓冲的通用减免：两条缴械通道（格挡链覆写、护主手动复刻）共用同一份规则。 */
    private static int reduceWithBluntBuffer(int baseCooldown, int bluntBufferLevel) {
        int level = Math.min(bluntBufferLevel, MAX_BLUNT_BUFFER_LEVEL);
        if (level <= 0) {
            return baseCooldown;
        }
        double factor = Math.max(0.0D, 1.0D - BLUNT_BUFFER_REDUCTION_PER_LEVEL * level);
        return Math.max(1, (int) Math.round(baseCooldown * factor));
    }

    /**
     * 登记一次可能发生的斧盾缴械。原版 {@code Player#disableShield()} 的 100 刻冷却是写死的、
     * 也没有对应事件，只能在它写入后（见 {@link #onServerTickEnd}）覆写。
     * 只有需要改动冷却的盾牌才登记：亡魂重盾（减半）、带钝击缓冲的盾牌（按等级减免）、
     * 被地煞战斧敲落的盾牌（×2，即普通盾牌 200 刻 = 10 秒）。
     *
     * <p>这条通道只对玩家存在：冷却表与 {@code disableShield()} 都是 {@link Player} 的成员，
     * 怪物既不会被斧头敲落盾牌，也没有可覆写的冷却。</p>
     */
    private static void queueShieldDisarm(LivingEntity entity, ItemStack shield, DamageSource source,
                                          boolean dishaDisarm) {
        if (!(entity instanceof Player player) || !isShield(shield) || !canDisableShieldBy(source)) {
            return;
        }
        boolean soulShield = shield.is(GeneratedMod.SOUL_SHIELD.get());
        int bluntBufferLevel = enchantmentLevel(player, shield, GeneratedMod.BLUNT_BUFFER);
        if (!soulShield && !dishaDisarm && bluntBufferLevel <= 0) {
            return;
        }
        int baseCooldown = soulShield ? SOUL_SHIELD_DISARM_COOLDOWN : SHIELD_DISARM_COOLDOWN;
        if (dishaDisarm) {
            // 倍率作用在这面盾本该有的基础冷却上：普通盾牌 100→200，亡魂重盾 50→100。
            baseCooldown *= DISHA_DISARM_COOLDOWN_MULTIPLIER;
        }
        PENDING_DISARM.put(player.getUUID(),
                new PendingDisarm(player, shield, baseCooldown, bluntBufferLevel));
    }

    /**
     * 这次近战命中是否会由地煞战斧把玩家的盾牌敲落。
     * 与原版缴械链一致（非弹射物、活体近战直接命中、主手武器 {@code canDisableShield}），
     * 再把武器收紧到"就是地煞战斧"：冷却表与 {@code disableShield()} 只有玩家有，
     * 所以防守方也必须是玩家。
     */
    private static boolean isDishaDisarm(LivingEntity defender, DamageSource source) {
        if (!(defender instanceof Player) || !canDisableShieldBy(source)) {
            return false;
        }
        return attackerHoldsDisha(source);
    }

    /** 能缴械盾牌的近战攻击者（{@code canDisableShield} 已含"主手持斧类武器"）手里是否就是地煞战斧。 */
    private static boolean attackerHoldsDisha(DamageSource source) {
        return source.getDirectEntity() instanceof LivingEntity attacker
                && attacker.getMainHandItem().is(GeneratedMod.DISHA_BATTLE_AXE.get());
    }

    /** 地煞战斧敲落盾牌这一击的盾牌耐久损耗：这一击的斧伤害 × 2（伤害 18 → 36 点）。 */
    private static int dishaShieldWear(double attackDamage) {
        return Math.max(1, (int) Math.ceil(DISHA_SHIELD_WEAR_MULTIPLIER * attackDamage));
    }

    /**
     * 护主通道的手动缴械：原版的 {@code isDamageSourceBlocked} 要求 {@code isBlocking()}，
     * 未举盾时整条格挡→{@code disableShield()} 链不可达，这里复刻它的三件事——
     * 给盾牌物品写冷却（{@code ServerItemCooldowns} 会自动发 {@code ClientboundCooldownPacket} 同步）、
     * 停用水品（正在举盾的玩家被敲落）、广播 30 号实体事件（客户端放破盾音效）。
     * 冷却规则与格挡通道完全一致：亡魂重盾 50 刻、普通盾牌 100 刻，
     * 被地煞战斧敲落再 ×2，带钝击缓冲的最后按等级减免。
     */
    private static void applyProtectorDisarm(Player player, ItemStack shield, boolean dishaDisarm) {
        int baseCooldown = shield.is(GeneratedMod.SOUL_SHIELD.get())
                ? SOUL_SHIELD_DISARM_COOLDOWN
                : SHIELD_DISARM_COOLDOWN;
        if (dishaDisarm) {
            baseCooldown *= DISHA_DISARM_COOLDOWN_MULTIPLIER;
        }
        int cooldown = reduceWithBluntBuffer(baseCooldown,
                enchantmentLevel(player, shield, GeneratedMod.BLUNT_BUFFER));
        // 覆写语义与原版 disableShield() 一致（addCooldown 无条件替换同物品的冷却），
        // ServerItemCooldowns 会同步把 ClientboundCooldownPacket 发给客户端。
        player.getCooldowns().addCooldown(shield.getItem(), cooldown);
        player.stopUsingItem();
        player.level().broadcastEntityEvent(player, (byte) 30);
    }

    /** 复刻原版的缴械判定：非弹射物、由活体近战直接命中，且攻击者手上的武器能敲落盾牌。 */
    private static boolean canDisableShieldBy(DamageSource source) {
        return !source.is(DamageTypeTags.IS_PROJECTILE)
                && source.getDirectEntity() instanceof LivingEntity attacker
                && attacker.canDisableShield();
    }

    /**
     * 亡魂重盾的附赠效果：挡下攻击就给攻击者挂凋灵（200 刻 = 10 秒，凋零 I）。
     * 防守方可以是任何活体——护主／立体防御分支本就不问实体类型，所以怪物装备
     * "亡魂重盾＋护主（或立体防御）"时同样会反挂凋零；但<b>不带这两枚附魔的"裸"重盾
     * 装在怪物身上不会生效</b>：怪物没有 {@code isBlocking()}，格挡事件永远不会为它触发。
     */
    private static void applySoulShieldWither(LivingEntity defender, ItemStack shield, DamageSource source) {
        if (!shield.is(GeneratedMod.SOUL_SHIELD.get())) {
            return;
        }
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity livingAttacker && attacker != defender) {
            livingAttacker.addEffect(new MobEffectInstance(MobEffects.WITHER, 200, 0), defender);
        }
    }

    private static void damageShield(LivingEntity entity, ShieldInHand shield, int amount) {
        ItemStack stack = shield.stack();
        int available = stack.getMaxDamage() - stack.getDamageValue();
        if (available <= 0 || amount >= available) {
            reshapeOrBreak(entity, shield);
            return;
        }
        stack.setDamageValue(stack.getDamageValue() + amount);
    }

    /**
     * 盾牌该碎的时候：带重塑就 repair/降级，没重塑就把它从持盾者手上摘掉。
     * 玩家与怪物走同一段代码——{@code setItemInHand} 是 {@link LivingEntity} 的成员。
     */
    private static void reshapeOrBreak(LivingEntity entity, ShieldInHand shield) {
        ItemStack stack = shield.stack();
        int reshapeLevel = enchantmentLevel(entity, stack, GeneratedMod.REMODEL);
        if (reshapeLevel <= 0) {
            entity.setItemInHand(shield.hand(), ItemStack.EMPTY);
            return;
        }

        stack.setDamageValue(0);
        if (reshapeLevel == 1) {
            EnchantmentHelper.setEnchantments(stack, ItemEnchantments.EMPTY);
            return;
        }

        ItemEnchantments.Mutable reduced = new ItemEnchantments.Mutable(stack.getEnchantments());
        for (Holder<Enchantment> holder : reduced.keySet().toArray(Holder[]::new)) {
            int level = reduced.getLevel(holder);
            if (level <= 1) {
                reduced.removeIf(candidate -> candidate.equals(holder));
            } else {
                reduced.set(holder, level - 1);
            }
        }
        EnchantmentHelper.setEnchantments(stack, reduced.toImmutable());
    }

    /** 任一手持有 {@code required} 附魔的盾牌即返回它（护主不问角度、不问是否举盾，故两只手都查）。 */
    private static ShieldInHand findShield(LivingEntity entity, Holder<Enchantment> required) {
        InteractionHand active = activeHand(entity);
        ItemStack activeStack = entity.getItemInHand(active);
        if (isShieldWith(activeStack, required)) {
            return new ShieldInHand(active, activeStack);
        }
        InteractionHand other = active == InteractionHand.MAIN_HAND
                ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack otherStack = entity.getItemInHand(other);
        if (isShieldWith(otherStack, required)) {
            return new ShieldInHand(other, otherStack);
        }
        return null;
    }

    /**
     * 立体防御需要"正在举盾"：玩家得真的按住右键（{@code isUsingItem()}），
     * 而原版的举盾动作只有玩家会做——怪物永远不会 {@code startUsingItem} 一面盾牌。
     * 所以对怪物来说这枚附魔等价于常驻格挡，任一手持盾即算举盾。
     */
    private static ShieldInHand findActiveShield(LivingEntity entity, Holder<Enchantment> required) {
        if (!(entity instanceof Player)) {
            return findShield(entity, required);
        }
        if (!entity.isUsingItem()) {
            return null;
        }
        InteractionHand active = activeHand(entity);
        ItemStack stack = entity.getItemInHand(active);
        return isShieldWith(stack, required) ? new ShieldInHand(active, stack) : null;
    }

    private static boolean isShieldWith(ItemStack stack, Holder<Enchantment> required) {
        return isShield(stack) && EnchantmentHelper.getItemEnchantmentLevel(required, stack) > 0;
    }

    private static boolean isShield(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() instanceof net.minecraft.world.item.ShieldItem
                && stack.isDamageableItem();
    }

    private static InteractionHand activeHand(LivingEntity entity) {
        ItemStack use = entity.getUseItem();
        if (!use.isEmpty() && use == entity.getItemInHand(InteractionHand.OFF_HAND)) {
            return InteractionHand.OFF_HAND;
        }
        return InteractionHand.MAIN_HAND;
    }

    private static int enchantmentLevel(LivingEntity entity, ItemStack stack, ResourceKey<Enchantment> key) {
        return EnchantmentHelper.getItemEnchantmentLevel(enchantment(entity, key), stack);
    }

    private static Holder<Enchantment> enchantment(LivingEntity entity, ResourceKey<Enchantment> key) {
        return entity.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(key);
    }

    private record ShieldInHand(InteractionHand hand, ItemStack stack) {
    }

    /** 一次待覆写的缴械：玩家、被缴械的盾牌、盾牌的基础冷却与钝击缓冲等级。 */
    private record PendingDisarm(Player player, ItemStack shield, int baseCooldown, int bluntBufferLevel) {
    }
}
