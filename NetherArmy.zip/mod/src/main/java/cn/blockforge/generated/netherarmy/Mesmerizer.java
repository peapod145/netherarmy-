package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;

/**
 * 反逆者：手持控制器，以凋零骷髅的敌对目标规则发射心灵控制光球。
 *
 * <h3>军团视野</h3>
 * <p>反逆者是凋灵骷髅阵营的"眼"。三条规则共同生效，前两条在
 * {@link LegionVisionHandler}（可见性事件）里结算，第三条在本类里：</p>
 * <ul>
 *   <li>落在它索敌圈内的隐身敌人，对整个凋灵骷髅阵营都不再隐身。</li>
 *   <li>玩家戴怪物头颅不会缩短它的索敌范围。</li>
 *   <li>它能借用自己心控生物的视线：本体隔墙看不到、但某个受控生物看得见时，
 *       照样把那个目标立为己方目标（{@link #seesThroughControlledMob}、
 *       {@link MesmerizerSharedVisionTargetGoal}）。</li>
 * </ul>
 */
public class Mesmerizer extends WitherSkeleton {
    /** 索敌（视线感知与近战判定共用）半径；下界传令兵与之对齐，见 {@link NetherCourier#createAttributes()}。 */
    public static final double MESMERIZER_FOLLOW_RANGE = 32.0D;
    private static final float MESMERIZER_ATTACK_RANGE = 30.0F;
    private static final int ORB_INTERVAL = 140;
    private static final int ATTACK_POSE_TICKS = 12;
    private static final float RETREAT_DISTANCE = 10.0F;
    private static final int PATH_RECALCULATION_INTERVAL = 8;
    /**
     * 借眼范围：只有在这个半径内、且仍受自己心控的生物才充当反逆者的眼睛。
     * 受控生物本来就跟着军团走（{@link CourierFollowGoal} 的 30 格），64 格留足绕路余量。
     */
    private static final double SHARED_VISION_HOST_RANGE = 64.0D;
    /** 受控生物名单的重扫间隔（tick）：心控关系随时可能因死亡/卸载/戴冠而失效，靠重扫收敛。 */
    private static final int SHARED_VISION_REFRESH_TICKS = 8;
    /** 借眼索敌的重扫间隔（tick），与原版 {@code NearestAttackableTargetGoal} 的 10 tick 同量级。 */
    private static final int SHARED_VISION_SEARCH_INTERVAL = 10;
    private static final String ORB_CHARGE_TICKS = "generated_mod_mesmerizer_orb_charge_ticks";
    private static final String ORB_CHARGED = "generated_mod_mesmerizer_orb_charged";
    private int attackPoseTicks;
    private int orbChargeTicks;
    private boolean orbCharged;
    /** 当前正受本反逆者心控的生物（纯内存快照，服务端每 {@value #SHARED_VISION_REFRESH_TICKS} tick 重取）。 */
    private final List<LivingEntity> controlledMobs = new ArrayList<>();
    private int sharedVisionRefreshCountdown;

    public Mesmerizer(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        this.setLeftHanded(false);
        this.xpReward = 8;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.attackPoseTicks > 0 && --this.attackPoseTicks == 0) {
            this.setAggressive(false);
        }
        if (!this.level().isClientSide() && this.isAlive()) {
            // 借眼的“眼睛名单”：心控关系是每刻可变的（戴冠解除、死亡、区块卸载），
            // 所以不常驻引用，只留一份 8 tick 一换的快照供视线判定用。
            if (--this.sharedVisionRefreshCountdown <= 0) {
                this.sharedVisionRefreshCountdown = SHARED_VISION_REFRESH_TICKS;
                this.refreshControlledMobs();
            }
        }
        if (!this.level().isClientSide() && this.isAlive() && !this.orbCharged) {
            if (++this.orbChargeTicks >= ORB_INTERVAL) {
                this.orbChargeTicks = 0;
                this.orbCharged = true;
            }
        }
    }

    /** 本反逆者当前还在心控、且处在借眼距离内的生物快照（服务端）。 */
    public List<LivingEntity> getControlledMobs() {
        return this.controlledMobs;
    }

    /**
     * 反逆者能否"借用"受控生物的视线看到 {@code target}。
     *
     * <p>判定的是受控生物那侧的真实射线（{@code LivingEntity#hasLineOfSight}），与本体的
     * {@code Sensing} 无关：本体被墙挡住、而傀儡站在敌人那一边时，这里返回 {@code true}。</p>
     */
    public boolean seesThroughControlledMob(Entity target) {
        if (this.level().isClientSide() || target == null || target == this || !this.hasControllableEyes()) {
            return false;
        }
        for (LivingEntity eye : this.controlledMobs) {
            if (eye != target && eye.isAlive() && eye.level() == this.level()
                    && MesmerizerControl.isControlledBy(eye, this)
                    && eye.hasLineOfSight(target)) {
                return true;
            }
        }
        return false;
    }

    /** 至少有一个活着、同维度、仍受本反逆者心控的生物可以充当眼睛。 */
    public boolean hasControllableEyes() {
        for (LivingEntity eye : this.controlledMobs) {
            if (eye.isAlive() && eye.level() == this.level() && MesmerizerControl.isControlledBy(eye, this)) {
                return true;
            }
        }
        return false;
    }

    private void refreshControlledMobs() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        AABB box = this.getBoundingBox().inflate(SHARED_VISION_HOST_RANGE);
        this.controlledMobs.removeIf(eye -> !eye.isAlive() || eye.level() != level
                || !MesmerizerControl.isControlledBy(eye, this)
                || eye.distanceToSqr(this) > SHARED_VISION_HOST_RANGE * SHARED_VISION_HOST_RANGE);
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity != this && MesmerizerControl.isControlledBy(entity, this))) {
            if (!this.controlledMobs.contains(candidate)) {
                this.controlledMobs.add(candidate);
            }
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractSkeleton.createAttributes()
                .add(Attributes.FOLLOW_RANGE, MESMERIZER_FOLLOW_RANGE);
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.removeAllGoals(goal -> isGoalType(goal, MeleeAttackGoal.class)
                || isGoalType(goal, net.minecraft.world.entity.ai.goal.RangedBowAttackGoal.class));
        this.targetSelector.removeAllGoals(goal -> true);
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Piglin.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        this.targetSelector.addGoal(5, new NearestAttackableTargetGoal<>(this, PiglinBrute.class, 10, true, false,
                target -> MesmerizerControl.canAttack(this, target)));
        // 借眼索敌垫在最后：本体自己能看见的目标全部交给上面 2~5 条常规规则，
        // 只有在"本体被挡住、而某个受控生物看得见"时才由它接管。
        this.targetSelector.addGoal(6, new MesmerizerSharedVisionTargetGoal(this));
        this.goalSelector.addGoal(2, new MesmerizerRangedAttackGoal(this));
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        if (this.level().isClientSide() || !this.orbCharged || !MesmerizerControl.canAttack(this, target)) {
            return;
        }
        MesmerizerOrb orb = new MesmerizerOrb(this, this.level());
        Vec3 direction = target.getEyePosition().subtract(this.getEyePosition());
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        orb.setPos(this.getEyePosition().add(direction.scale(0.5D)));
        orb.shoot(direction.x, direction.y, direction.z, 1.2F, 0.0F);
        this.setAggressive(true);
        this.attackPoseTicks = ATTACK_POSE_TICKS;
        this.swing(InteractionHand.MAIN_HAND, true);
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 0.8F, 1.1F);
        this.level().addFreshEntity(orb);
        this.orbCharged = false;
        this.orbChargeTicks = 0;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(ORB_CHARGE_TICKS, this.orbChargeTicks);
        tag.putBoolean(ORB_CHARGED, this.orbCharged);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.orbChargeTicks = Math.max(0, Math.min(ORB_INTERVAL - 1, tag.getInt(ORB_CHARGE_TICKS)));
        this.orbCharged = tag.getBoolean(ORB_CHARGED);
        if (this.orbCharged) {
            this.orbChargeTicks = 0;
        }
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.MESMERIZER_CROWN.get()));
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.MESMERIZER_CONTROLLER.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    protected void populateDefaultEquipmentEnchantments(ServerLevelAccessor level, RandomSource random,
                                                         DifficultyInstance difficulty) {
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         net.minecraft.world.entity.MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.setLeftHanded(false);
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.MESMERIZER_CROWN.get()));
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.MESMERIZER_CONTROLLER.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setCanPickUpLoot(false);
        return result;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        return stack.is(GeneratedMod.MESMERIZER_CONTROLLER.get());
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return false;
    }

    @Override
    public void reassessWeaponGoal() {
    }

    /**
     * 借眼索敌：本体视线被挡住、但它心控的某个生物看得见敌人时，照样把敌人立为目标。
     *
     * <p>挂在 targetSelector 最后一级（6）：反逆者自己看得见的目标全部由上面 2~5 条
     * 常规规则处理，本 goal 只补"隔墙"这一种情况；并且只在当前没有目标时抢一次
     * （{@code getTarget() != null} 直接放弃），避免和高级 goal 来回换目标。</p>
     *
     * <p>范围仍然按反逆者自己的 {@code FOLLOW_RANGE}（32 格）算，不以受控生物为中心扩展：
     * 借来的是"眼睛"，不是射程——否则一个躲在 200 格外的傀儡能把反逆者拽着跨维度跑路，
     * 而光球只有 1.2 格/tick 的飞行速度。发现目标后由
     * {@link MesmerizerRangedAttackGoal} 负责把本体带到能直视的位置再开球。</p>
     */
    private static final class MesmerizerSharedVisionTargetGoal extends Goal {
        private final Mesmerizer mesmerizer;
        private LivingEntity candidate;
        private int cooldown;

        private MesmerizerSharedVisionTargetGoal(Mesmerizer mesmerizer) {
            this.mesmerizer = mesmerizer;
            this.setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            LivingEntity current = this.mesmerizer.getTarget();
            if (current != null && (current.isRemoved() || !current.isAlive())) {
                // 尸体不清目标的话，反逆者会一直盯着一具躺平的对象，借眼也就永远轮不到。
                this.mesmerizer.setTarget(null);
                current = null;
            }
            if (current != null && current != this.candidate) {
                return false;
            }
            if (this.candidate != null && this.isValid(this.candidate)) {
                return true;
            }
            if (--this.cooldown > 0) {
                return false;
            }
            this.cooldown = SHARED_VISION_SEARCH_INTERVAL;
            this.candidate = this.findBorrowedTarget();
            return this.candidate != null;
        }

        @Override
        public void start() {
            if (this.candidate != null) {
                this.mesmerizer.setTarget(this.candidate);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return this.candidate != null && this.isValid(this.candidate)
                    && this.mesmerizer.getTarget() == this.candidate;
        }

        @Override
        public void stop() {
            this.candidate = null;
        }

        private LivingEntity findBorrowedTarget() {
            if (!(this.mesmerizer.level() instanceof ServerLevel level)
                    || !this.mesmerizer.hasControllableEyes()) {
                return null;
            }
            double range = followRange();
            AABB box = this.mesmerizer.getBoundingBox().inflate(range);
            LivingEntity nearest = null;
            double nearestDistance = Double.MAX_VALUE;
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box,
                    this::isBorrowedSightCandidate)) {
                double distance = entity.distanceToSqr(this.mesmerizer);
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearest = entity;
                }
            }
            return nearest;
        }

        private boolean isBorrowedSightCandidate(LivingEntity entity) {
            if (entity == this.mesmerizer || !entity.isAlive() || entity.level() != this.mesmerizer.level()) {
                return false;
            }
            // 敌对名单与常规索敌保持一致：玩家、铁傀儡、猪灵与猪灵蛮兵。
            if (!(entity instanceof Player || entity instanceof IronGolem || entity instanceof AbstractPiglin)) {
                return false;
            }
            if (entity instanceof Player player && player.isSpectator()) {
                return false;
            }
            if (!MesmerizerControl.canAttack(this.mesmerizer, entity)) {
                return false;
            }
            // 本体看得见就交给 2~5 条常规规则，本 goal 只管"本体看不见、傀儡看得见"。
            return !this.mesmerizer.getSensing().hasLineOfSight(entity)
                    && this.mesmerizer.seesThroughControlledMob(entity);
        }

        private boolean isValid(LivingEntity target) {
            return target.isAlive() && target.level() == this.mesmerizer.level()
                    && MesmerizerControl.canAttack(this.mesmerizer, target)
                    && target.distanceToSqr(this.mesmerizer) <= followRange() * followRange()
                    && (this.mesmerizer.getSensing().hasLineOfSight(target)
                    || this.mesmerizer.seesThroughControlledMob(target));
        }

        private double followRange() {
            double range = this.mesmerizer.getAttributeValue(Attributes.FOLLOW_RANGE);
            return range > 0.0D ? range : MESMERIZER_FOLLOW_RANGE;
        }
    }

    private static final class MesmerizerRangedAttackGoal extends Goal {
        private final Mesmerizer mesmerizer;
        private LivingEntity target;
        private int strafingTime;
        private boolean strafingClockwise;

        private MesmerizerRangedAttackGoal(Mesmerizer mesmerizer) {
            this.mesmerizer = mesmerizer;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity candidate = this.mesmerizer.getTarget();
            if (candidate == null || !candidate.isAlive()) {
                return false;
            }
            this.target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive()
                    && this.mesmerizer.getTarget() == this.target;
        }

        @Override
        public void start() {
            this.strafingTime = -1;
            this.strafingClockwise = this.mesmerizer.getRandom().nextBoolean();
        }

        @Override
        public void stop() {
            this.target = null;
            this.strafingTime = -1;
            this.mesmerizer.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity currentTarget = this.mesmerizer.getTarget();
            if (currentTarget == null || !currentTarget.isAlive()) {
                return;
            }
            this.target = currentTarget;
            double distanceSqr = this.mesmerizer.distanceToSqr(currentTarget);
            // 本体视线是"站桩开球"与"贴身拉开"的硬条件：光球是实体弹，隔墙打出去只会糊在墙上。
            // 借来的视线（MesmerizerSharedVisionTargetGoal 负责索敌）在这里的作用是让反逆者
            // 不要对着看不见的目标乱退位——一律靠过去，走到自己也能看见为止。
            boolean canSee = this.mesmerizer.getSensing().hasLineOfSight(currentTarget);

            this.mesmerizer.getLookControl().setLookAt(currentTarget, 30.0F, 30.0F);
            if (canSee && distanceSqr < RETREAT_DISTANCE * RETREAT_DISTANCE) {
                this.strafeBackward(currentTarget);
            } else if (canSee && distanceSqr <= MESMERIZER_ATTACK_RANGE * MESMERIZER_ATTACK_RANGE) {
                this.strafingTime = -1;
                this.mesmerizer.getNavigation().stop();
                this.mesmerizer.stopInPlace();
            } else {
                // 超出射程，或者本体这侧没有视线（只有受控生物看得见、或纯粹被墙挡住）：继续靠近。
                this.strafingTime = -1;
                this.mesmerizer.getNavigation().moveTo(currentTarget, 1.0D);
            }

            if (this.mesmerizer.orbCharged && canSee
                    && distanceSqr <= MESMERIZER_ATTACK_RANGE * MESMERIZER_ATTACK_RANGE) {
                this.mesmerizer.performRangedAttack(currentTarget, 1.0F);
            }
        }

        private void strafeBackward(LivingEntity target) {
            if (this.strafingTime-- <= 0) {
                this.strafingClockwise = this.mesmerizer.getRandom().nextBoolean();
                this.strafingTime = 4 + this.mesmerizer.getRandom().nextInt(7);
            }

            // 不再把“负前进量”交给当前实体朝向解释。LookControl 与 MoveControl
            // 的更新顺序可能让实体朝向滞后一 tick，导致骷髅式游走偶尔向目标靠近。
            // 直接用目标到反逆者的水平向量计算背离方向，保证每次下发的移动
            // 都有明确的远离分量，同时保留左右随机横移。
            Vec3 away = this.mesmerizer.position().subtract(target.position());
            away = new Vec3(away.x, 0.0D, away.z);
            if (away.lengthSqr() < 1.0E-6D) {
                away = new Vec3(0.0D, 0.0D, 1.0D);
            } else {
                away = away.normalize();
            }
            Vec3 side = new Vec3(-away.z, 0.0D, away.x);
            Vec3 retreat = away.scale(0.625D).add(side.scale(this.strafingClockwise ? 0.5D : -0.5D));
            retreat = retreat.normalize();

            this.mesmerizer.getNavigation().stop();
            this.mesmerizer.getMoveControl().setWantedPosition(
                    this.mesmerizer.getX() + retreat.x,
                    this.mesmerizer.getY(),
                    this.mesmerizer.getZ() + retreat.z,
                    1.0D);
            this.mesmerizer.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }
    }

    private static boolean isGoalType(net.minecraft.world.entity.ai.goal.Goal goal,
                                      Class<? extends net.minecraft.world.entity.ai.goal.Goal> type) {
        return type.isInstance(goal)
                || goal instanceof WrappedGoal wrapped && type.isInstance(wrapped.getGoal());
    }
}
