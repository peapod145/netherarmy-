package cn.blockforge.generated.netherarmy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.projectile.Projectile;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 猎手系列成就的服务端判定与授予，共七枚：
 *
 * <ul>
 *   <li>【箭皆虚发】：下界猎手躲开玩家射出的抛射物累计 100 发。躲避动作发生时由
 *       {@link NetherHunter} 的闪避 Goal 回调计数；若该发抛射物最终仍击中了猎手，
 *       说明这一发并没有"躲开"，在 {@link LivingIncomingDamageEvent} 里回退计数。
 *       计数与"是否已计过"分别存进玩家与抛射物的 PersistentData，天然跨重载持久，
 *       同一发抛射物被多名猎手（或多个 tick 反复）判为威胁也只计一次。</li>
 *   <li>【谁才是猎手？】：玩家用自身发射的抛射物补刀下界猎手，且击杀时与猎手相距
 *       10 格以上。</li>
 *   <li>【借刀杀人】：下界猎手被恶魂（含其火球）杀死，授予现场距猎手最近、
 *       且已完成【箭皆虚发】的玩家。</li>
 *   <li>【空战王牌】：鞘翅滑翔中用抛射物杀死衰翼。</li>
 *   <li>【狩猎之神】：失明状态下用抛射物杀死衰翼或下界猎手。</li>
 *   <li>【天空即为战争】：鞘翅滑翔中用近战攻击杀死衰翼。</li>
 *   <li>【驱狼吞虎】：正对玩家保持仇恨目标（{@code getTarget() 为玩家}）的僵尸猪灵
 *       被尸鬼打出伤害，即授予该玩家。</li>
 * </ul>
 *
 * <p>成就链的先后要求在 JSON 的 parent 之外，这里再用 {@link #hasCompleted} 显式把关
 * （与 {@code GeneratedMod#award} 对同行压力的处理同一套路）：父成就未完成时，
 * 本次判定的条件直接跳过，不缓存补发。</p>
 */
public final class HunterHuntAdvancementHandler {

    /** 玩家 PersistentData：已被下界猎手躲开的玩家抛射物发数。 */
    private static final String DODGE_COUNT_KEY = "netherarmy_hunter_dodged_shots";
    /** 抛射物 PersistentData：这一发已被计入躲避数。 */
    private static final String PROJECTILE_COUNTED_KEY = "netherarmy_dodge_counted";
    /** 抛射物 PersistentData：这一发已经命中过猎手（躲避失败，不再计也不再回退）。 */
    private static final String PROJECTILE_STRUCK_KEY = "netherarmy_dodge_struck";

    private static final int DODGE_TARGET = 100;
    private static final double SNIPER_DISTANCE = 10.0D;
    private static final double GHAST_KILL_RADIUS = 32.0D;

    private HunterHuntAdvancementHandler() {
    }

    // ------------------------------------------------------------------
    // 【箭皆虚发】躲避计数（由 NetherHunter.ProjectileDodgeGoal 回调）
    // ------------------------------------------------------------------

    /**
     * 猎手把某一发抛射物判为来袭威胁并开始闪避时调用。只有玩家发射的抛射物计入，
     * 同一发只计一次（抛射物身上的计数标记负责去重）。
     */
    public static void onProjectileDodged(Projectile projectile) {
        if (!(projectile.getOwner() instanceof ServerPlayer player)) {
            return;
        }
        CompoundTag projectileTag = projectile.getPersistentData();
        if (projectileTag.getInt(PROJECTILE_COUNTED_KEY) != 0
                || projectileTag.getInt(PROJECTILE_STRUCK_KEY) != 0) {
            return;
        }
        projectileTag.putInt(PROJECTILE_COUNTED_KEY, 1);
        CompoundTag playerData = player.getPersistentData();
        int count = playerData.getInt(DODGE_COUNT_KEY) + 1;
        playerData.putInt(DODGE_COUNT_KEY, count);
        if (count >= DODGE_TARGET) {
            award(player, "every_arrow_misses", "dodged_100_projectiles", null);
        }
    }

    /**
     * 已被计入躲避数的抛射物真的打在了猎手身上：这一发没能"躲开"，回退计数。
     * 标记先落盘再回退，保证同一发无论后续如何纠缠都至多回退一次。
     */
    private static void onProjectileStruckHunter(Projectile projectile) {
        CompoundTag projectileTag = projectile.getPersistentData();
        if (projectileTag.getInt(PROJECTILE_COUNTED_KEY) == 0
                || projectileTag.getInt(PROJECTILE_STRUCK_KEY) != 0) {
            return;
        }
        projectileTag.putInt(PROJECTILE_COUNTED_KEY, 0);
        projectileTag.putInt(PROJECTILE_STRUCK_KEY, 1);
        if (projectile.getOwner() instanceof ServerPlayer player) {
            CompoundTag playerData = player.getPersistentData();
            playerData.putInt(DODGE_COUNT_KEY, Math.max(0, playerData.getInt(DODGE_COUNT_KEY) - 1));
        }
    }

    // ------------------------------------------------------------------
    // 事件入口
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        Entity victim = event.getEntity();
        DamageSource source = event.getSource();
        if (victim instanceof NetherHunter && source.getDirectEntity() instanceof Projectile projectile) {
            onProjectileStruckHunter(projectile);
            return;
        }
        // 驱狼吞虎：尸鬼打伤一只正把玩家锁为仇恨目标的僵尸猪灵。
        if (victim instanceof ZombifiedPiglin piglin
                && source.getEntity() instanceof Husk
                && piglin.getTarget() instanceof ServerPlayer player) {
            award(player, "drive_wolf_devour_tiger", "husk_attacked_enraged_piglin", null);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        DamageSource source = event.getSource();
        if (event.getEntity() instanceof NetherHunter hunter) {
            onHunterDeath(level, hunter, source);
        } else if (event.getEntity() instanceof Witherphantom) {
            onPhantomDeath(source);
        }
    }

    private static void onHunterDeath(ServerLevel level, NetherHunter hunter, DamageSource source) {
        // 借刀杀人：最后一击归于恶魂（火球的 owner 即恶魂本体）。
        if (source.getEntity() instanceof Ghast) {
            ServerPlayer nearest = null;
            double bestDistance = Double.MAX_VALUE;
            for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class,
                    hunter.getBoundingBox().inflate(GHAST_KILL_RADIUS))) {
                if (!hasCompleted(player, "every_arrow_misses")) {
                    continue;
                }
                double distance = player.distanceToSqr(hunter);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    nearest = player;
                }
            }
            if (nearest != null) {
                award(nearest, "kill_by_borrowed_knife", "ghast_killed_hunter", "every_arrow_misses");
            }
            return;
        }
        // 远程击杀判定：direct 是抛射物、owner 是该玩家。
        if (source.getEntity() instanceof ServerPlayer player
                && source.getDirectEntity() instanceof Projectile) {
            // 谁才是猎手？：补刀瞬间与猎手相距 10 格以外。
            if (player.distanceTo(hunter) > SNIPER_DISTANCE) {
                award(player, "who_is_the_hunter", "ranged_kill_beyond_10_blocks", "every_arrow_misses");
            }
            // 狩猎之神：失明状态下远程猎杀。
            if (player.hasEffect(MobEffects.BLINDNESS)) {
                award(player, "god_of_the_hunt", "blinded_ranged_hunt", "who_is_the_hunter");
            }
        }
    }

    private static void onPhantomDeath(DamageSource source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (source.getDirectEntity() instanceof Projectile) {
            // 空战王牌：鞘翅滑翔中远程击杀衰翼。
            if (player.isFallFlying()) {
                award(player, "flying_ace", "gliding_ranged_phantom_kill", "who_is_the_hunter");
            }
            // 狩猎之神：失明状态下远程猎杀衰翼。
            if (player.hasEffect(MobEffects.BLINDNESS)) {
                award(player, "god_of_the_hunt", "blinded_ranged_hunt", "who_is_the_hunter");
            }
        } else if (source.getDirectEntity() == player && player.isFallFlying()) {
            // 天空即为战争：鞘翅滑翔中近战击杀衰翼。
            award(player, "the_sky_is_war", "gliding_melee_phantom_kill", null);
        }
    }

    // ------------------------------------------------------------------
    // 授予工具（与 GeneratedMod / MesmerizerControlHandler 同一套路）
    // ------------------------------------------------------------------

    private static void award(ServerPlayer player, String path, String criterion, String requiredParent) {
        if (requiredParent != null && !hasCompleted(player, requiredParent)) {
            return;
        }
        var holder = player.server.getAdvancements().get(
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, path));
        if (holder != null) {
            player.getAdvancements().award(holder, criterion);
        }
    }

    private static boolean hasCompleted(ServerPlayer player, String path) {
        var holder = player.server.getAdvancements().get(
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, path));
        return holder != null && player.getAdvancements().getOrStartProgress(holder).isDone();
    }
}
