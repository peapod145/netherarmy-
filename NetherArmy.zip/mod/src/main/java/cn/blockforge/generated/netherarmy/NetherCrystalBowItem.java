package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * 炼狱晶弓。物品本身的行为：
 *
 * <ul>
 *   <li><b>耐久 3000、可附魔、掉落物不灭</b>：注册处的 {@code durability(3000)} /
 *       {@code fireResistant} / {@code rarity(EPIC)}，加上物品标签
 *       {@code #minecraft:enchantable/bow} 与 {@code #minecraft:enchantable/durability}
 *       （附魔台能出力量、冲击、火矢、无限、耐久、经验修补这一整套）。</li>
 *   <li><b>箭矢 2 倍速</b>：{@code BowItem.releaseUsing} 把 {@code f * 3.0F} 当初速交给
 *       {@code ProjectileWeaponItem#shoot}，最后落在 {@code shootProjectile} 的 velocity
 *       参数上；这里原样重写父类那一行，只把 velocity 乘 2，散布角（多重射击）与
 *       准头（inaccuracy）保持父类行为。</li>
 *   <li><b>拉弓 2 倍速</b>：{@code getPowerForTime} 是静态方法不可覆盖，
 *       {@code releaseUsing} 里唯一能改的是 {@code ArrowLooseEvent} 的 charge，
 *       见 {@link NetherCrystalBowHandler#onArrowLoose}（10 刻拉满）。</li>
 *   <li><b>命中挂 10 秒虚弱 / 缓慢 / 饥饿 / 易伤</b>：见
 *       {@link NetherCrystalBowHandler#onProjectileImpact}。刻意不往箭的 ItemStack 里
 *       塞效果：那会让捡回来的箭不再和普通箭堆叠、而且换把普通弓射也还带着效果。</li>
 *   <li><b>火矢附魔 → 灵魂火矢</b>：见 {@link #createProjectile}。</li>
 *   <li><b>可修复</b>：铁砧材料为炼狱晶碎片与炼狱晶锭，见 {@link #isValidRepairItem}。</li>
 * </ul>
 */
public final class NetherCrystalBowItem extends BowItem {
    /** 箭矢初速倍率（原版满蓄力 3.0 → 本弓 6.0）。 */
    public static final float ARROW_SPEED_MULTIPLIER = 2.0F;

    /**
     * 火矢附魔在本弓上换成的灵魂火矢，箭矢自身点燃的刻数。
     * 取 100 刻 = 5 秒，与原版火矢（{@code Enchantments.FLAME} 的 {@code ignite} 100 刻）
     * 完全一致，改的只是"烧的是哪种火"。
     */
    public static final int SOUL_FIRE_ARROW_TICKS = 100;

    public NetherCrystalBowItem(Properties properties) {
        super(properties);
    }

    /**
     * 把出膛初速翻倍。
     *
     * <p>父类实现是
     * {@code projectile.shootFromRotation(shooter, shooter.getXRot(), shooter.getYRot() + angle, 0.0F, velocity, inaccuracy)}，
     * 这里只把 velocity 乘 2。</p>
     */
    @Override
    protected void shootProjectile(LivingEntity shooter, Projectile projectile, int index, float velocity,
                                   float inaccuracy, float angle, LivingEntity target) {
        projectile.shootFromRotation(shooter, shooter.getXRot(), shooter.getYRot() + angle, 0.0F,
                velocity * ARROW_SPEED_MULTIPLIER, inaccuracy);
    }

    /**
     * 带火矢附魔时把箭改成"灵魂火矢"。
     *
     * <p>1.21.1 的火矢是 {@code Enchantments.FLAME} 上的
     * {@code PROJECTILE_SPAWNED} → {@code Ignite(100)} 效果：箭在 {@code AbstractArrow}
     * 构造器里被点着 100 刻，命中时 {@code onHitEntity} 再把目标点燃 5 秒。</p>
     *
     * <p>{@code createProjectile} 是唯一"既知道弓附了什么魔、又拿着箭本体"的位置：
     * 构造之后立刻打上灵魂火标记，于是箭在飞行途中被换成蓝焰包裹层，命中时由
     * {@link NetherCrystalBowHandler#onProjectileImpact} 给目标挂灵魂火
     * （{@link SoulFireBurn#ignite}，燃烧伤害翻倍，见 {@code SoulFireDamageHandler}）。</p>
     */
    @Override
    protected Projectile createProjectile(Level level, LivingEntity shooter, ItemStack weapon, ItemStack ammo,
                                          boolean isCrit) {
        Projectile projectile = super.createProjectile(level, shooter, weapon, ammo, isCrit);
        if (projectile instanceof AbstractArrow arrow && hasFlame(level, weapon)) {
            // 原版火矢已经点着了，这里补灵魂火标记；顺手保证点燃刻数与灵魂火矢一致。
            arrow.setRemainingFireTicks(SOUL_FIRE_ARROW_TICKS);
            SoulFireBurn.setSoulFlame(arrow, true);
        }
        return projectile;
    }

    /**
     * 这把弓是否带火矢附魔（等级 &gt; 0 即可，原版火矢只有 I 级）。
     *
     * <p>{@code Enchantments.FLAME} 是 {@code ResourceKey<Enchantment>}，而
     * {@code EnchantmentHelper#getItemEnchantmentLevel} 要 {@code Holder<Enchantment>}，
     * 所以先经注册表查一次。</p>
     */
    public static boolean hasFlame(Level level, ItemStack weapon) {
        return !weapon.isEmpty() && EnchantmentHelper.getItemEnchantmentLevel(
                level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.FLAME),
                weapon) > 0;
    }

    /**
     * 铁砧修复材料：炼狱晶碎片与炼狱晶锭，与炼狱晶套装同一套材料。
     *
     * <p>弓继承的是 {@code BowItem}，不在 {@code TieredItem}/{@code ArmorItem} 那条
     * "材料自带修复材料"的链路上，{@code Item#isValidRepairItem} 默认返回 false，
     * 所以这里显式认两种材料；{@code AnvilMenu} 判定二手槽时走的就是这个方法。</p>
     */
    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(GeneratedMod.NETHER_CRYSTAL_SHARD.get())
                || repairCandidate.is(GeneratedMod.NETHER_CRYSTAL_INGOT.get())
                || super.isValidRepairItem(stack, repairCandidate);
    }

    /**
     * 掉落物免疫爆炸：{@code ItemEntity#hurt} 扣血前先问 {@code ItemStack#canBeHurtBy}，
     * 这里把 {@code IS_EXPLOSION} 挡掉。火焰/岩浆免疫由注册处的 {@code fireResistant} 组件负责。
     */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }

    /** 提示框：深红色单行，只写命中附带的效果。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.nether_crystal_bow.tooltip")
                .withStyle(ChatFormatting.DARK_RED));
    }
}
