package cn.blockforge.generated.netherarmy;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;

/**
 * 无头强袭骑士的马：基础代码照抄无头骑士的马（编组同步、近战推进、可上鞍可穿马铠），
 * 强袭规格：
 * <ul>
 *   <li>血量 40、自带 4 点护甲、行走移速与无头骑士的马一致（0.345）；</li>
 *   <li>近战伤害为无头骑士的马的 1.5 倍（3.0 → 4.5）；</li>
 *   <li>免疫击退与一切负面效果，免疫摔落伤害；</li>
 *   <li>发现敌人后进入奔跑姿态（仅驱动下面的越障跳跃，不再额外提速，
 *       移速始终与无头骑士的马相同）；</li>
 *   <li>奔跑中探测前方 3 格内的障碍，能跳则跳；跳不过去时寻路会像正常生物
 *       一样自行改道（导航每 tick 重建路径，绕障是路径系统的天然行为）；</li>
 *   <li>近战命中时打出与下界军团旗帜完全相同的范围凋零波与黑烟，
 *       并附带强袭凋零叠加（30 秒凋零 II 起步，可叠至十级）；</li>
 *   <li>必定携带马鞍与炼狱晶锁链马铠；死亡必掉马鞍，1% 概率掉落马铠。</li>
 * </ul>
 */
public class BlitzDullhanHorse extends DullhanHorse {
    private static final double BLITZ_MAX_HEALTH = 40.0D;
    /** 行走移速：与无头骑士的马一致（0.345）。 */
    private static final double BLITZ_WALK_SPEED = 0.345D;
    private static final double BLITZ_BASE_ARMOR = 4.0D;
    /** 近战伤害：无头骑士的马（3.0）的 1.5 倍。 */
    private static final double BLITZ_ATTACK_DAMAGE = 4.5D;
    /** 障碍探测：正前方 3 格内、高于自动上台阶沿的方块起跳。 */
    private static final double OBSTACLE_REACH = 3.0D;
    private static final double OBSTACLE_SAMPLE_STEP = 0.5D;
    private static final int JUMP_COOLDOWN_TICKS = 10;
    /** 马铠掉率：1%。 */
    private static final float BARDING_DROP_CHANCE = 0.01F;
    /** 历史清理：旧版奔跑 ×2 提速曾以常驻修饰符写入存档，需在旧存档的马上移除一次。 */
    private static final ResourceLocation LEGACY_GALLOP_ID = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "blitz_horse_gallop");

    private boolean galloping;
    private boolean legacyGallopCleaned;
    private int jumpCooldown;

    public BlitzDullhanHorse(EntityType<? extends BlitzDullhanHorse> type, Level level) {
        super(type, level);
        this.repinBlitzStats();
    }

    private void repinBlitzStats() {
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(BLITZ_MAX_HEALTH);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BLITZ_WALK_SPEED);
        this.getAttribute(Attributes.ARMOR).setBaseValue(BLITZ_BASE_ARMOR);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(BLITZ_ATTACK_DAMAGE);
        this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return DullhanHorse.createAttributes()
                .add(Attributes.MAX_HEALTH, BLITZ_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, BLITZ_WALK_SPEED)
                .add(Attributes.ARMOR, BLITZ_BASE_ARMOR)
                .add(Attributes.ATTACK_DAMAGE, BLITZ_ATTACK_DAMAGE)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void randomizeAttributes(RandomSource random) {
        super.randomizeAttributes(random);
        // SkeletonHorse 生成时随机血量/速度，父类又钉成无头骑士规格，最后由强袭覆盖。
        this.repinBlitzStats();
        this.setHealth(this.getMaxHealth());
    }

    /** 免疫一切负面效果。 */
    @Override
    public boolean canBeAffected(MobEffectInstance instance) {
        if (instance.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
            return false;
        }
        return super.canBeAffected(instance);
    }

    /** 免疫摔落伤害。 */
    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    /** 近战命中：强袭凋零叠加 + 与军团旗帜同款的范围凋零波与黑烟。 */
    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            BlitzDullhanBody.applyBlitzWither(living);
            if (this.level() instanceof ServerLevel serverLevel) {
                NetherArmyFlagWitherAoeHandler.triggerBlitzMountImpact(serverLevel, this, living);
            }
        }
        return hurt;
    }

    /** 必带马鞍与炼狱晶锁链马铠；马铠零默认掉率（1% 特判见掉落钩子）。 */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        if (groupData == null) {
            this.equipSaddle(new ItemStack(Items.SADDLE), null);
            this.setBodyArmorItem(new ItemStack(GeneratedMod.NETHER_CRYSTAL_HORSE_ARMOR.get()));
        }
        this.setDropChance(EquipmentSlot.BODY, 0.0F);
        return result;
    }

    /** 死亡必掉马鞍；炼狱晶锁链马铠 1% 概率掉落。 */
    @Override
    protected void rollSaddleDrop() {
        // 不销鞍槽：马鞍就在马物品栏第 0 格，父类 AbstractHorse 无条件掉落整个物品栏，马鞍因此必掉。
    }

    /**
     * 马铠 1% 掉落。注意马铠实际存放在 BODY 装备槽（{@code Mob#bodyArmorItem}）而非马物品栏，
     * {@code AbstractHorse#dropEquipment} 只遍历物品栏、扫不到它；原版掉率链路
     * （{@code Mob#dropCustomDeathLoot}）又因 BODY 掉率被钉 0 而直接跳过。
     * 因此 1% 命中时必须在这里手动掉出，两种结果最后都清空格子。
     */
    @Override
    protected void rollBodyArmorDrop() {
        ItemStack barding = this.getItemBySlot(EquipmentSlot.BODY);
        if (!barding.isEmpty() && this.random.nextFloat() < BARDING_DROP_CHANCE) {
            this.spawnAtLocation(barding);
        }
        this.setBodyArmorItem(ItemStack.EMPTY);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            return;
        }
        this.updateGallop();
        if (this.jumpCooldown > 0) {
            this.jumpCooldown--;
        }
        if (this.galloping) {
            this.tryLeapOverObstacle();
        }
    }

    /** 发现敌人 → 进入奔跑姿态（仅驱动越障跳跃，不加任何移速）；丢失目标 → 回落。 */
    private void updateGallop() {
        LivingEntity target = this.getTarget();
        this.galloping = target != null && target.isAlive();
        if (!this.legacyGallopCleaned) {
            this.legacyGallopCleaned = true;
            AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                speed.removeModifier(LEGACY_GALLOP_ID);
            }
        }
    }

    /**
     * 奔跑中探测正前方 3 格：命中"高于自动上台阶沿、上方两格净空"的障碍就起跳。
     * 起跳力度取马匹跳跃强度属性（炼狱晶锁链马铠的 +25% 跳跃加成在此生效）。
     * 跳不过去不做额外处理——导航每 tick 重建路径，绕道改向是寻路的天然行为。
     */
    private void tryLeapOverObstacle() {
        if (!this.onGround() || this.jumpCooldown > 0) {
            return;
        }
        Vec3 look = this.getLookAngle();
        double horizontal = Math.hypot(look.x, look.z);
        if (horizontal < 1.0E-3D) {
            return;
        }
        double ux = look.x / horizontal;
        double uz = look.z / horizontal;
        Level level = this.level();
        for (double t = 1.5D; t <= OBSTACLE_REACH; t += OBSTACLE_SAMPLE_STEP) {
            double x = this.getX() + ux * t;
            double z = this.getZ() + uz * t;
            BlockPos feetPos = BlockPos.containing(x, this.getY() + 0.05D, z);
            BlockState state = level.getBlockState(feetPos);
            if (state.isAir() || !state.blocksMotion()) {
                continue;
            }
            // 一级台阶自动步频就能跨过，不值得起跳。
            double obstacleTop = feetPos.getY() + 1.0D;
            if (obstacleTop - this.getY() <= this.maxUpStep() + 0.05F) {
                continue;
            }
            // 头顶要有两格净空，跳了也卡进方块里的坑不跳。
            if (!level.getBlockState(feetPos.above()).isAir()
                    || !level.getBlockState(feetPos.above(2)).isAir()) {
                continue;
            }
            double jumpPower = this.getAttributeValue(Attributes.JUMP_STRENGTH);
            Vec3 motion = this.getDeltaMovement();
            this.setDeltaMovement(motion.x, Math.max(motion.y, jumpPower * 0.75D), motion.z);
            this.hasImpulse = true;
            this.jumpCooldown = JUMP_COOLDOWN_TICKS;
            return;
        }
    }
}
