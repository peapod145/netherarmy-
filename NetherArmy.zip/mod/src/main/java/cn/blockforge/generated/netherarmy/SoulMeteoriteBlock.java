package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 灵魂陨石落地后留下的方块：数值与原版黑曜石完全一致
 * （{@code Properties.ofFullCopy(Blocks.OBSIDIAN)}，抗爆 1200、硬度 50），
 * 挖掘等级同样是黑曜石档——方块标签 {@code minecraft:needs_diamond_tool}
 * 里加了 {@code netherarmy:soul_meteorite}，只有钻石/下界合金镐算"正确工具"，
 * 可正常挖掘并掉落自身（见 {@code loot_table/blocks/soul_meteorite.json}）。
 *
 * <p>站上去的活物获得易伤——只在<b>还没有</b>易伤时施加一次，避免逐刻刷新把等级
 * 一路顶到 V。持续期间不刷新，掉光后若还站在上面会立刻重新挂上，等效于"接触期间
 * 一直有易伤"。<b>对一切活物生效，不分阵营</b>：玩家、凋灵骷髅阵营的友军、别的阵营的怪
 * 都一样，另有一条每 5 刻的兜底扫描（见 {@link SoulMeteoriteContactHandler}）。
 * 持续时间 {@value #CONTACT_EFFECT_TICKS} 刻（10 秒），与陨石落地冲击
 * 的 20 秒区分开：踩方块是"蹭一下"，被砸中才是完整时长。两者都已按
 * {@link WitherArchmage#EFFECT_DURATION_MULTIPLIER} 翻倍。</p>
 *
 * <h2>为什么必须用 {@code stepOn} 而不是 {@code entityInside}</h2>
 * <p>{@link #entityInside} 只在实体的碰撞盒<b>真正插进方块体积</b>时触发。这是满块
 * 实心方块，站在顶上时脚底恰好落在方块上表面：包围盒 minY == 方块 maxY，AABB 的
 * {@code intersects} 判的是严格小于，所以<b>永远不满足</b>，站在上面时
 * {@code entityInside} 一次都不会被调用——"接触获得易伤"就是这样失效的。</p>
 *
 * <p>原版岩浆块用的是 {@code Block#stepOn}：{@code Entity#move} 在
 * {@code onGround()} 为真时每刻调用它，踩住不动也会持续触发，正是"接触方块"的
 * 正确钩子。{@code move} 客户端同样会跑，所以这里必须挡 {@code level.isClientSide}，
 * 否则效果会在客户端空放一遍。</p>
 *
 * <p>两个钩子都保留：{@code stepOn} 负责站在顶面，{@code entityInside} 负责实体
 * 碰撞盒真的陷进方块里的情形（例如落点正好压在小体型实体身上）。</p>
 *
 * <h2>挖错工具就炸</h2>
 * <p>挖掘等级（{@code needs_diamond_tool}）和工具类型任一不符——徒手、木/石/铁镐、
 * 斧、铲、剑，甚至空手硬抠——方块照样会被挖掉，但 {@link #playerDestroy} 会在原坐标
 * 补一发威力 {@value #WRONG_TOOL_EXPLOSION_POWER} 的 {@code TNT} 式爆炸（破坏方块、
 * 不点火，与爆炸等效）。判定直接用 {@link ItemStack#isCorrectToolForDrops}：它同时涵盖
 * 工具类型（镐才行）与等级（钻石/下界合金才行）。</p>
 *
 * <p>顺序很关键：先 {@code super.playerDestroy} 扔出掉落物，再起爆——掉落物就落在爆心，
 * 靠 {@link SoulMeteoriteItem} 的火焰/爆炸双免疫活下来。创造模式挖掉不炸：创造模式
 * 随手一点就碎、工具栏也常年不是镐，真炸起来只会拆家。</p>
 */
public class SoulMeteoriteBlock extends Block {
    /** 接触方块给的易伤时长：5 秒，按魔导师的施法倍率翻倍后 10 秒。 */
    public static final int CONTACT_EFFECT_TICKS =
            100 * WitherArchmage.EFFECT_DURATION_MULTIPLIER;
    /** 挖错工具时触发的爆炸威力：与原版 TNT 同值。 */
    public static final float WRONG_TOOL_EXPLOSION_POWER = 4.0F;

    public SoulMeteoriteBlock(Properties properties) {
        super(properties);
    }

    /**
     * 玩家挖掉方块：工具不对就原地炸一发 TNT。
     *
     * <p>先 {@code super} 生成掉落物、再起爆，掉落物因此正好位于爆心（见类注释）。</p>
     */
    @Override
    public void playerDestroy(Level level, Player player, BlockPos pos, BlockState state,
                              BlockEntity blockEntity, ItemStack tool) {
        super.playerDestroy(level, player, pos, state, blockEntity, tool);
        if (level.isClientSide || player.isCreative() || tool.isCorrectToolForDrops(state)) {
            return;
        }
        level.explode(player, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                WRONG_TOOL_EXPLOSION_POWER, Level.ExplosionInteraction.TNT);
    }

    /** 踩在顶面：每刻都会走到这里。 */
    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        super.stepOn(level, pos, state, entity);
        applyContactVulnerability(level, entity);
    }

    /** 碰撞盒插进方块体积的情形。 */
    @Override
    protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        applyContactVulnerability(level, entity);
    }

    /**
     * 接触结算：服务端给还没有易伤的活物挂一次。
     *
     * <p>对<b>一切活物</b>生效，不按阵营过滤：玩家、凋灵骷髅阵营的友军、别的阵营的怪
     * 踩上来都一样。除了下面两个方块钩子，{@link SoulMeteoriteContactHandler} 还会每
     * {@value SoulMeteoriteContactHandler#SCAN_INTERVAL_TICKS} 刻扫一次所有活物脚下的方块，
     * 兜住"钩子没跑到"的情形。</p>
     */
    public static void applyContactVulnerability(Level level, Entity entity) {
        if (level.isClientSide || !(entity instanceof LivingEntity living) || !living.isAlive()) {
            return;
        }
        if (living.getEffect(GeneratedMod.VULNERABILITY) != null) {
            return;
        }
        living.addEffect(new MobEffectInstance(GeneratedMod.VULNERABILITY, CONTACT_EFFECT_TICKS, 0,
                false, false, true));
        WitherArchmage.spawnVulnerabilityParticles(level, living);
    }
}
