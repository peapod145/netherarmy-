package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** 黑客本体层与衣服层共用的姿态。数值按 hacker.bbmodel 的坐标换算。 */
final class HackerPose {
    private HackerPose() {
    }

    static void apply(ModelPart root, Hacker entity, float limbSwing, float limbSwingAmount,
                      float ageInTicks, float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);

        ModelPart head = root.getChild("head");
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;

        // bbmodel 两臂 rotation=[60, -7.5, 0] / [60, 7.5, 0]，
        // 在工程统一的 Java 换算中 X、Y 旋转都取反。
        float rightTap = 0.0F;
        float leftTap = 0.0F;
        if (entity.isUsingComputer()) {
            float time = entity.computerAnimationTime(ageInTicks);
            rightTap = tap(time, true);
            leftTap = tap(time, false);
        }

        ModelPart rightArm = root.getChild("right_arm");
        ModelPart leftArm = root.getChild("left_arm");
        rightArm.xRot = (-60.0F - rightTap) * Mth.DEG_TO_RAD;
        rightArm.yRot = 7.5F * Mth.DEG_TO_RAD;
        leftArm.xRot = (-60.0F - leftTap) * Mth.DEG_TO_RAD;
        leftArm.yRot = -7.5F * Mth.DEG_TO_RAD;

        if (!entity.isUsingComputer() && limbSwingAmount > 0.01F) {
            // bbmodel walk：right_leg -25→25，left_leg 25→-25；X 旋转取反后为此结果。
            float swing = Mth.cos(limbSwing * 0.6662F) * 25.0F
                    * Mth.clamp(limbSwingAmount * 3.0F, 0.0F, 1.0F);
            root.getChild("right_leg").xRot = swing * Mth.DEG_TO_RAD;
            root.getChild("left_leg").xRot = -swing * Mth.DEG_TO_RAD;
        }
    }

    /** use_computer 的线性关键帧三角波；右手与左手相差 0.25 秒。 */
    private static float tap(float time, boolean rightArm) {
        if (time < 0.0F) {
            return 0.0F;
        }
        float phase = time - (rightArm ? 0.25F : 0.0F);
        if (phase < 0.0F) {
            return 0.0F;
        }
        phase %= 0.5F;
        return phase < 0.25F
                ? 12.5F * phase * 4.0F
                : 12.5F * (0.5F - phase) * 4.0F;
    }
}
