package cn.blockforge.generated.netherarmy;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/** 强化原版信标：无需提交矿物，按底座层数提供全部原版增益。 */
public final class BeaconEnhancementHandler {
    private static final int MAX_BEACON_LEVEL = 3;
    private static final int EFFECT_RADIUS = 100;
    private static final int EFFECT_DURATION = 40;
    private static final int EFFECT_TICK_INTERVAL = 20;

    private static final Set<net.minecraft.core.Holder<MobEffect>> BEACON_EFFECTS = Set.of(
            MobEffects.MOVEMENT_SPEED,
            MobEffects.DIG_SPEED,
            MobEffects.DAMAGE_RESISTANCE,
            MobEffects.JUMP,
            MobEffects.DAMAGE_BOOST,
            MobEffects.REGENERATION);

    private static final Map<net.minecraft.server.level.ServerLevel, Set<BlockPos>> LOADED_BEACONS =
            Collections.synchronizedMap(new java.util.WeakHashMap<>());

    private BeaconEnhancementHandler() {
    }

    @SubscribeEvent
    public static void onRightClickBeacon(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getLevel().getBlockState(event.getPos()).is(Blocks.BEACON)) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (!(event.getChunk() instanceof LevelChunk chunk)
                || !(chunk.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) {
            return;
        }
        Set<BlockPos> beacons = LOADED_BEACONS.computeIfAbsent(level,
                ignored -> new HashSet<>());
        for (var entry : chunk.getBlockEntities().entrySet()) {
            if (entry.getValue() instanceof BeaconBlockEntity) {
                beacons.add(entry.getKey().immutable());
            }
        }
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (!(event.getChunk() instanceof LevelChunk chunk)
                || !(chunk.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) {
            return;
        }
        Set<BlockPos> beacons = LOADED_BEACONS.get(level);
        if (beacons == null) {
            return;
        }
        for (var entry : chunk.getBlockEntities().entrySet()) {
            if (entry.getValue() instanceof BeaconBlockEntity) {
                beacons.remove(entry.getKey());
            }
        }
    }

    @SubscribeEvent
    public static void onBeaconPlaced(BlockEvent.EntityPlaceEvent event) {
        if (event.isCanceled() || !event.getPlacedBlock().is(Blocks.BEACON)
                || !(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) {
            return;
        }
        registerBeacon(level, event.getPos());
    }

    @SubscribeEvent
    public static void onBeaconBroken(BlockEvent.BreakEvent event) {
        if (event.isCanceled() || !event.getState().is(Blocks.BEACON)
                || !(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) {
            return;
        }
        Set<BlockPos> beacons = LOADED_BEACONS.get(level);
        if (beacons != null) {
            beacons.remove(event.getPos());
        }
    }

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)
                || level.getGameTime() % EFFECT_TICK_INTERVAL != 0) {
            return;
        }
        Set<BlockPos> beacons = LOADED_BEACONS.get(level);
        if (beacons == null || beacons.isEmpty()) {
            return;
        }

        Iterator<BlockPos> iterator = beacons.iterator();
        while (iterator.hasNext()) {
            BlockPos pos = iterator.next();
            if (!(level.getBlockEntity(pos) instanceof BeaconBlockEntity beacon)
                    || beacon.isRemoved() || !level.getBlockState(pos).is(Blocks.BEACON)) {
                iterator.remove();
                continue;
            }
            int levelCount = getBeaconLevel(level, pos);
            if (levelCount > 0) {
                applyBeaconEffects(level, pos, levelCount);
            }
        }
    }

    private static void registerBeacon(net.minecraft.server.level.ServerLevel level, BlockPos pos) {
        LOADED_BEACONS.computeIfAbsent(level,
                ignored -> new HashSet<>()).add(pos.immutable());
    }

    private static int getBeaconLevel(Level level, BlockPos beaconPos) {
        int levelCount = 0;
        BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
        for (int layer = 1; layer <= MAX_BEACON_LEVEL; layer++) {
            int y = beaconPos.getY() - layer;
            int radius = layer;
            boolean validLayer = true;
            for (int x = beaconPos.getX() - radius; x <= beaconPos.getX() + radius && validLayer; x++) {
                for (int z = beaconPos.getZ() - radius; z <= beaconPos.getZ() + radius; z++) {
                    mutablePos.set(x, y, z);
                    if (!level.getBlockState(mutablePos).is(BlockTags.BEACON_BASE_BLOCKS)) {
                        validLayer = false;
                        break;
                    }
                }
            }
            if (!validLayer) {
                break;
            }
            levelCount = layer;
        }
        return levelCount;
    }

    private static void applyBeaconEffects(net.minecraft.server.level.ServerLevel level, BlockPos beaconPos,
                                           int levelCount) {
        double centerX = beaconPos.getX() + 0.5D;
        double centerY = beaconPos.getY() + 0.5D;
        double centerZ = beaconPos.getZ() + 0.5D;
        AABB area = new AABB(centerX - EFFECT_RADIUS, centerY - EFFECT_RADIUS, centerZ - EFFECT_RADIUS,
                centerX + EFFECT_RADIUS, centerY + EFFECT_RADIUS, centerZ + EFFECT_RADIUS);
        int amplifier = levelCount * 2 - 1;
        for (Player player : level.getEntitiesOfClass(Player.class, area)) {
            for (net.minecraft.core.Holder<MobEffect> effect : BEACON_EFFECTS) {
                player.addEffect(new MobEffectInstance(effect, EFFECT_DURATION, amplifier, true, true, true));
            }
        }
    }
}
