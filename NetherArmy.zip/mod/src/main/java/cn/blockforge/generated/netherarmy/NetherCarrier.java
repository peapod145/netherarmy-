package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.BodyRotationControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Nullable;

/**
 * 下界运兵车（Nether Carrier）。
 *
 * <h2>面板</h2>
 * <ul>
 *   <li>血量 200、自带 100 点护甲。</li>
 *   <li>凋灵骷髅阵营：继承 {@link WitherSkeleton}，亡灵判定、猪灵互仇、免疫凋零
 *       全部白捡；同时挂进 {@code minecraft:wither_skeletons} 等阵营标签，
 *       所以友军伤害、军团光环、旗帜范围凋零波都会把它当自己人。</li>
 *   <li>索敌 {@value #FOLLOW_RANGE_BLOCKS} 格（{@code FOLLOW_RANGE}）：仇恨表登记玩家、猪灵、
 *       铁傀儡三条主动索敌 + 受击反击，阵营成员永不入表。铁傀儡这条来自原版
 *       {@code AbstractSkeleton#registerGoals}，本类不调 super 时显式补回（见
 *       {@link #registerGoals}）。仇恨总闸在 {@link #setTarget}：凋灵骷髅阵营成员与
 *       创造/旁观模式玩家<b>从任何路径都进不了仇恨表</b>——主动索敌、受击反击、
 *       外部注入一律在此改写为空，"无论如何都不会索敌创造模式玩家"由此成立。</li>
 *   <li>最大移速与狂战士完全同款（{@code MOVEMENT_SPEED = 0.375}），从静止拉到满速
 *       需要 2 秒（{@value #ACCEL_TICKS} tick 线性加速），松手后 0.5 秒内收住；
 *       血量低于 {@value #LOW_HEALTH_SMOKE} / {@value #CRITICAL_HEALTH_SMOKE} 时最大移速
 *       分别降至凋灵骷髅同款（{@value #WITHER_SKELETON_MAX_SPEED}）与其 75%
 *       （{@value #CRITICAL_HEALTH_MAX_SPEED}），见 {@link #updateLowHealthMaxSpeed}。</li>
 *   <li>经验 {@value #XP_REWARD}：凋灵骷髅基准（{@value #WITHER_SKELETON_BASE_XP}）的
 *       {@value #XP_MULTIPLIER} 倍；本车不携带任何装备，{@code Mob#getBaseExperienceReward}
 *       的装备随机加成无从叠加，击杀实得经验恒为该值。掉落见
 *       {@code netherarmy:entities/nether_carrier} 掉落表。</li>
 * </ul>
 *
 * <h2>接触伤害与撞击（无冷却的接触判定）</h2>
 * <p>参照史莱姆的 {@code tickEnemies}：每 tick 取鼻尖判定盒里的活物，凡是在盒内的
 * 目标每 tick 吃 {@value #CONTACT_DAMAGE_PER_TICK} 点<b>固定接触伤害</b>——与速度无关、
 * 与正侧面无关，静止贴住也照掉（约 40 点/秒）。伤害走 {@code mobAttack} 来源，
 * 护甲、保护、盾牌格挡照常参与结算；凋灵骷髅阵营成员完全豁免。原版
 * {@code LivingEntity#hurt} 自带 20 tick 无敌帧（且低伤会被上一击压制），要每 tick
 * 结算必须在 {@code hurt} 前后手动清 {@code invulnerableTime}。</p>
 * <p>在接触伤害之上，每个目标每 {@value #RE_HIT_INTERVAL} tick 至多"新进入"接触集一次，
 * 额外结算一发随速度放大的<b>撞击</b>（大伤害 + 大击退 + 缴械）。全程没有攻击冷却、
 * 没有挥手动画。</p>
 * <p>撞击的伤害与击退都是相对速度的一次函数：</p>
 * <pre>
 *   ratio  = clamp(相对接近速度 / 满速基准, 0, 2)
 *   正面伤害 = 50 × ratio         正面击退 = 5 格 × ratio
 *   侧面伤害 = 50 × 25% × ratio   侧面击退 = 5 格 × 25% × ratio
 * </pre>
 * <p>"满速基准"取本车实测的最高水平速度（服务端在拉满加速系数时记录），因此
 * "达到最大移速撞静止目标 = 50 点 / 5 格"这条标定在任何地形、任何速度修正下都成立，
 * 不依赖原版摩擦公式的具体形式。相对速度按目标在车头方向上的速度分量做减法，
 * 迎面跑来的目标会吃到超过 50 点的伤害（上限 2 倍，防止被爆炸/弹射物甩出的极端速度放大）。</p>
 * <p>正侧面判据：目标相对车体的连线在车头方向上的投影长度 ≥ 侧向偏移长度即为正面，
 * 否则算侧面。贴着车身擦过时侧向距离必然小于纵向，判定符合直觉。</p>
 * <p>击退<b>不</b>走 {@code knockback()}，而是把目标的水平速度直接钉成标定值：原版
 * {@code hurt} 自带 0.4 击退，叠加进来会让"5 格"变成 6~7 格。换算系数
 * {@value #KNOCKBACK_BLOCKS_TO_VELOCITY} 格/tick 每格来自"腾空段 ≈ 4.2·v0 + 落地滑行
 * ≈ 0.75·v0"的阻尼积分，即 1.0 格/tick 初速约滑行 5 格。</p>
 *
 * <h2>缴械盾牌</h2>
 * <p>{@link #canDisableShield()} 恒为 true：目标举盾格挡时，原版
 * {@code LivingEntity#hurt → blockUsingShield → Player#disableShield} 链路会自动给盾
 * 上 10 秒冷却并播放破盾动画（这一击的伤害被盾吃掉，但人照样被撞飞）。此外本车还会
 * 把盾从手上打落成一个 1.5 秒内捡不起来的掉落物——{@link ShieldItem} 的子类都算，
 * 所以亡魂重盾同样会被缴。</p>
 *
 * <h2>镐类弱点（无视护甲 ×5）</h2>
 * <p>需求：镐类工具能够<b>无视这 100 点护甲</b>，并对其造成 <b>5 倍伤害</b>。
 * 实现钉在 {@link #getDamageAfterArmorAbsorb} 这条原版唯一护甲段上：命中者主手持
 * 镐（{@code minecraft:pickaxes} 标签或 {@link PickaxeItem} 子类）时，该段不再走
 * CombatRules 减伤，而是把进入护甲段的全额伤害直接乘 5 送出——玩家普通一击的
 * 5 倍，且完全不参与 80% 护甲减免。抗性效果、{@code LivingIncomingDamageEvent}
 * 等其他伤害修正仍按原版顺序正常叠加；弹射物、爆炸等非"手持镐近战命中"不受影响，
 * 走正常护甲。详见 {@link #getDamageAfterArmorAbsorb} 的推导注释。</p>
 *
 * <h2>受击表现：不闪红，改喷黑烟</h2>
 * <p>需求：受击时<b>不再变红</b>，改为一瞬间车头冒出大量黑烟；血量低于
 * {@value #LOW_HEALTH_SMOKE} 后全身各部位持续冒浓黑烟并每秒吃
 * {@value #SMOKE_VOID_DAMAGE_LOW} 点虚空伤害，血量低于 {@value #CRITICAL_HEALTH_SMOKE}
 * 后每秒 {@value #SMOKE_VOID_DAMAGE_HIGH} 点；与此同时最大移速在这两条阈值上分别降到
 * 凋灵骷髅同款（{@value #WITHER_SKELETON_MAX_SPEED}）与其 75%
 * （{@value #CRITICAL_HEALTH_MAX_SPEED}）。红闪在渲染器侧掐断（1.21.1 的受击红是
 * {@code LivingEntityRenderer#getOverlayCoords} 直接读 {@code hurtTime} 字段，与
 * {@code isHurt()} 无关，所以渲染前把字段清零是唯一干净的封法，见
 * {@code GeneratedModClient.NetherCarrierRenderer}）；黑烟与虚空伤害全在服务端结算
 * （{@link #hurt} 的爆发烟、{@link #tickDamageSmoke} 的持续烟与每秒掉血），
 * 粒子用 {@code ServerLevel#sendParticles} 广播。虚空伤害走 {@code out_of_world}
 * 伤害类型：按定义无视这 100 点护甲，1~2 点足额入账。</p>
 *
 * <h2>受击召唤与死亡爆炸</h2>
 * <p>每次真正掉血后 10% 概率在<b>自身所在位置</b>召唤一只凋灵骷髅/狂战士/下界猎手/
 * 反逆者，并把本车的仇恨原样交给它。死亡时在原地来一发 TNT 当量（威力 4、留火、
 * 破坏方块）的爆炸，并随机吐出 3~5 只同款乘员；<b>此外必定再留下一名下界传令兵</b>
 * （{@link #summonGuaranteedCourier}，与 3~5 只随机乘员叠加、互不占用随机数）。
 * 爆炸走自定义 {@link FactionSafeCalculator}，阵营成员（含这名传令兵）既不掉血也不被
 * 冲击波推开。</p>
 *
 * <h2>运动时碾压方块</h2>
 * <p>加速系数过 {@value #BREAK_MIN_RAMP} 后，每 tick 把鼻尖盒里硬度<b>小于</b>钻石矿
 * （3.0F）的方块铲掉，每 tick 上限 {@value #BREAK_BUDGET_PER_TICK} 块；硬度 -1
 * （基岩、屏障）与流体不动。</p>
 *
 * <h2>判定箱与模型的折中</h2>
 * <p>整车（含车轮撞角）长 9.94 格、宽 3.75 格、高 4.44 格，而 Java 的实体判定箱只能是
 * <b>正方形</b>底面（{@code EntityType.Builder#sized} 只给一个 width），所以取
 * 3.7×4.4：宽度贴着车身（4.1 以上就挤不进 4 格宽的走廊，寻路会大面积失败）。正方形
 * 装不下 9.94 的长度，两头必须取舍——这里把整车模型沿车头方向<b>前移 2 格</b>
 * （{@link NetherCarrierModel} 的 frame 枢轴），让判定箱罩住车体后 3/4：后舱、
 * 后轮组、车尾全部有实体碰撞，车尾仅探出约 1.1 格（此前前后各探出 3.1 格，
 * "后半部分大片没有碰撞"即由此而来）。前移让出的车头一段约 5.1 格，撞击与破方块
 * 仍用"本体判定盒沿车头前伸 {@value #NOSE_REACH} 格"的鼻尖盒结算——玩家看到的是车头
 * 撞上来，判定上也确实是车头撞上来；正面被探出的车头碾到时，撞击会把速度钉成
 * 击退值弹开（{@link #ramInto}），不会出现"卡在看不见的车头上"。
 * 侧向则始终由本体判定箱负责。</p>
 *
 * <h2>车头/车尾的补位判定盒</h2>
 * <p>一条正方形判定箱罩不住 9.94 格的车身：探出的前 5.1 格与后 1.1 格此前"打不着、
 * 瞄不上、F3 里没有判定线"。现在这两截各挂一具隐形的 {@link CarrierHitbox} 子判定盒：
 * 以乘客身份挂在车上、每 tick 按车头向量钉位（转向时跟着转，存档随本尊嵌套保存），
 * 命中子盒即原额转发 {@link #hurt}——镐 ×5、受击黑烟、受击召唤全部走本尊一条路径。
 * 子盒刻意<b>不设实体碰撞</b>：正面撞击的 5 格弹道就是从车头穿出去的，实体化的鼻尖
 * 会把被撞玩家半路拦下；贴脸站进车头本来也会被接触伤害与击退立刻请出去。</p>
 *
 * <h2>转向：船式（静止不能转、运动中每 tick 左右各 15°）</h2>
 * <p>需求：静止时无法转向，只有在运动时可以向左或右偏转 15°，并且按船的转向那样
 * 平滑。服务端整车<b>只有一个地方</b>会写车身朝向——{@code MoveControl#tick} 的 MOVE_TO
 * 分支（{@code mob.setYRot(rotlerp(mob.getYRot(), 信箱方向, 90.0F))}，STRAFE 分支根本不碰
 * {@code yRot}），而冲锋（{@link CarrierChargeGoal}）与游走（{@code PathNavigation}）两条
 * 通道最后都汇到这一行。于是接管点就选在这条分支的 {@code rotlerp} 上
 * （原版就是 {@code protected}）：{@link CarrierSteeringControl} 把转角请求交给
 * {@link #steerTowards}，速度、跳跃、{@code isWalkable} 一行不动。</p>
 * <p>{@link #steerTowards} 的做法与 {@code Boat} 同构：{@code Boat} 用
 * {@code deltaRotation} 累加打舵量、把<b>转向率</b>而不是目标角写进朝向、再每 tick
 * {@code deltaRotation *= invFriction}（水中 0.9）收敛。本车对应
 * {@link #TURN_INPUT_PER_TICK}（每 tick 1.8° 打舵）、{@link #MAX_STEER_DEGREES_PER_TICK}
 * （±15°/tick 的帽，替代原版 90°）、{@link #decayTurnRate}（每 tick ×0.9 泄舵，且在
 * 没有转向请求的 tick 也照做，所以残余转向率不会攒着等下一拍突然甩出去）。
 * 效果：起转约 0.35 秒到 9°/tick、0.9 秒才满舵，转 90° 约 0.6 秒、掉头约 0.9 秒，
 * 停转同样是斜线收尾。推进侧不改，{@code LivingEntity#travel} 每 tick 用<b>新</b>朝向
 * 旋前进量，所以车是"边转边走"划弧线，不会先拧头再直着冲，也不会侧滑。</p>
 * <p>两条保护：{@link #canSteer} 以"上一 tick 的真实地面位移"为唯一运动判据——拉着油门
 * 却一步没动不算"在运动"，所以停着的车不会原地掉头；唯一的例外是连续
 * {@value #WEDGE_STEER_TICKS} tick 满载推进仍被完全楔住（顶在
 * {@link #BREAK_HARDNESS_LIMIT} 铲不动的基岩/黑曜石这类方块上），此时放行转向让它掉头
 * 脱困，因为"静止禁转"是需求，"永远顶墙"不是；转过头保护把本 tick 的转角夹在剩余需求角
 * 以内，配合 15°/tick 的帽把"目标一挪、车身左右甩"的摇摆彻底按住
 * （{@link CarrierChargeGoal} 里记录的那代抖动病根同源）。</p>
 * <p>模型侧不需要任何改动：整车骨架跟的就是车身朝向（渲染读 {@code yBodyRot}，
 * 本类已把它钉成 {@code yRot}，见 {@link CarrierBodyControl}；模型也从不读头向，
 * {@link NetherCarrierModel#setupAnim} 里根本没有 {@code netHeadYaw}），
 * 两具子判定盒由 {@link #positionRider} 每 tick 按 {@link #forward()} 重钉，
 * 因此车头/车尾的判定自动跟着这条弧线走。</p>
 * <p>还有一层容易漏掉的：渲染读的是 {@code yBodyRot} 而不是 {@code yRot}，而原版
 * {@code BodyRotationControl} 在停车时会把车身跟着头向拧——{@link CarrierHitbox}
 * 不是 {@code Mob}，停车分支的"乘客闸门"过不去，于是 {@code LookAtPlayerGoal} 一掰头
 * 整车就会原地转向。本类用 {@link #createBodyControl} 换成
 * {@link CarrierBodyControl}：车身恒等于 {@code yRot}，头向只被收拢、不再驱动车身。</p>
 *
 * <h2>动画</h2>
 * <p>只有移动时播放：本类按带符号的地面位移累计轮相 {@link #getRollProgress()}，
 * 模型侧只读这个值（静止时相位不推进，所有部件停在初始姿态），详见
 * {@link NetherCarrierModel#setupAnim}。</p>
 */
public class NetherCarrier extends WitherSkeleton {
    /** 与狂战士同款的 {@code MOVEMENT_SPEED} 属性值。 */
    public static final double MAX_SPEED_ATTRIBUTE = 0.375D;
    /**
     * 索敌范围（格）：写进 {@code FOLLOW_RANGE}，需求规定 50 格。
     *
     * <p>{@code NearestAttackableTargetGoal#findTarget} 每 {@code randomInterval} tick
     * 用 {@code getTargetSearchArea(mob.getAttributeValue(FOLLOW_RANGE))} 以自身为中心取
     * AABB 扫描敌人，所以这一个属性就是"锁敌半径"；{@code TargetGoal} 的追击与
     * {@code PathNavigation} 的寻路上限同样读它。整车长 9.94 格，原版凋灵骷髅的 16 格
     * 连车身都盖不住，先前的 32 格也给不出冲锋余量，因此按需求拉到 50 格。</p>
     */
    public static final double FOLLOW_RANGE_BLOCKS = 50.0D;
    /**
     * 满速基准的初值（格/tick）：按原版积分现算，不等实测收敛。
     *
     * <p>冲锋走 {@code MoveControl 信箱(MOVE_TO) → LivingEntity#travel}：每 tick 把
     * 信箱钉在敌人实时坐标上，不经寻路（摇摆根因与取舍见 {@link CarrierChargeGoal}）；
     * 游走仍由 {@code PathNavigation} 发点。本常量只是撞击标定
     * 的初值参考：实测满速（{@link #updateTopSpeedReference}）会不断把它向上修正，
     * "最大移速撞击 = 50 点"按修正后的实测值结算，与具体通道无关。</p>
     */
    public static final double FALLBACK_TOP_SPEED =
            0.25D * MAX_SPEED_ATTRIBUTE * (0.6D * 0.91D) / (1.0D - 0.6D * 0.91D);
    /** 静止 → 满速：2 秒。 */
    public static final int ACCEL_TICKS = 40;
    /** 松手 → 停住：0.5 秒（需求只规定了加速时间，减速取 1/4 让操作不发肉）。 */
    public static final int DECEL_TICKS = 10;

    // ---------------------------------------------------------------- 转向（船式，需求）

    /**
     * 需求：运动中每 tick 允许的最大偏转角——左右各 15°。原版 {@code MoveControl} 的
     * MOVE_TO 分支把帽硬编码成 90°/tick（一拍就能把 9.94 格长的车身拧四分之一圈），
     * 由 {@link CarrierSteeringControl} 换成本值。参照量：原版船按住一个方向的稳态
     * 转向率约 9~10°/tick，本值与之同量级；配合下面的打舵量与衰减，转 90°
     * 约 12 tick（0.6 秒）、原地掉头 180° 约 18 tick（0.9 秒）。
     */
    public static final float MAX_STEER_DEGREES_PER_TICK = 15.0F;
    /**
     * 转向率衰减，逐字照抄原版船：{@code Boat#floatBoat} 每 tick
     * {@code deltaRotation *= invFriction}（水中 {@code invFriction = 0.9F}）。
     * 起转与停转的渐变全在这一维上。
     */
    public static final float TURN_RATE_DECAY = 0.9F;
    /**
     * 每 tick 递给转向率的打舵量（度）。与 {@link #TURN_RATE_DECAY} 配成
     * {@code 1.8 / (1 − 0.9) = 18} 的理论稳态，正好被 15°/tick 的帽夹住：
     * 第 7 tick 才到 9°/tick、第 18 tick（0.9 秒）才触帽，不会出现"第一帧就满舵"。
     */
    public static final float TURN_INPUT_PER_TICK = 1.8F;
    /** 转角需求小于该值（度）视为"已对准"：不再打舵，让转向率自然收尾（不回正、不抖）。 */
    public static final float TURN_DEADBAND_DEGREES = 0.5F;
    /** "在运动"的地面位移下限（格/tick）：满速实测约 0.11 格/tick，这里取约 3%。 */
    public static final double MIN_STEER_GROUND_SPEED = 0.003D;
    /** 油门拉到该值以上却一步没动 = 推进被方块完全吃掉（楔住）。 */
    public static final float WEDGE_STEER_RAMP = 0.5F;
    /** 连续楔住这么多 tick 后放行转向，让车能掉头脱困——需求"静止不能转"的唯一例外。 */
    public static final int WEDGE_STEER_TICKS = 10;

    /** 满速正面撞击静止目标：50 点伤害。 */
    public static final float FRONT_RAM_DAMAGE = 50.0F;
    /** 满速正面撞击静止目标：击退 5 格。 */
    public static final double FRONT_RAM_KNOCKBACK_BLOCKS = 5.0D;
    /** 侧面撞击 = 正面的 25%。 */
    public static final float SIDE_RAM_RATIO = 0.25F;
    /** 相对速度折算上限：迎面高速目标最快按 2 倍满速结算。 */
    public static final double MAX_SPEED_RATIO = 2.0D;
    /** 撞击初速度（格/tick）= 期望滑行距离 × 该系数，见类注释的阻尼积分推导。 */
    public static final double KNOCKBACK_BLOCKS_TO_VELOCITY = 0.2D;
    /** 鼻尖判定盒在本体判定箱之外再前伸的距离（格）。整车模型前移 2 格后，车头探出约 5.12 格。 */
    public static final double NOSE_REACH = 5.1D;
    /**
     * 可视车体中点在实体锚点<b>前方</b>的距离（格）。模型整体沿车头前移 2 格
     * （{@link NetherCarrierModel} 的 frame 枢轴 {@code z=-32}）让判定箱罩住后半截车身，
     * 因此正/侧面撞击的几何基准不能再取 {@code position()}，得沿车头补这 2 格，
     * 否则贴着侧面擦过会被误判成正面。
     */
    public static final double MODEL_CENTER_AHEAD = 2.0D;
    /** 同一目标的最短再撞间隔（tick）——只约束随速度放大的撞击，不约束接触伤害。 */
    public static final int RE_HIT_INTERVAL = 20;
    /** 起步阶段（低于该相对速度系数）不结算撞击（接触伤害仍然每 tick 生效）。 */
    public static final double MIN_RAM_RATIO = 0.05D;
    /** 固定接触伤害：每 tick 2 点，与速度无关（含静止贴住）。 */
    public static final float CONTACT_DAMAGE_PER_TICK = 2.0F;

    /** 破方块硬度上限：钻石矿硬度 3.0F，"小于"才撞得碎（-1 = 不可破坏）。 */
    public static final float BREAK_HARDNESS_LIMIT = 3.0F;
    /** 每 tick 最多铲掉的方块数：防止一帧拆穿一整条隧道。 */
    public static final int BREAK_BUDGET_PER_TICK = 6;
    /** 加速系数低于这个值时不拆房（慢速蠕行、贴脸挪位不算冲击）。 */
    public static final float BREAK_MIN_RAMP = 0.2F;

    /**
     * 原版凋灵骷髅的经验基准：{@code Monster} 构造器把 {@code xpReward} 钉成 5，
     * {@code WitherSkeleton} 自己没有覆盖它，所以"凋灵骷髅的经验值"就是 5。
     */
    public static final int WITHER_SKELETON_BASE_XP = 5;
    /** 需求倍率：运兵车经验 = 凋灵骷髅的 10 倍。 */
    public static final int XP_MULTIPLIER = 10;
    /** 写进 {@code Mob#xpReward} 的经验基准（5 × 10 = 50）。 */
    public static final int XP_REWARD = WITHER_SKELETON_BASE_XP * XP_MULTIPLIER;

    /** 受击召唤概率（百分比）。 */
    public static final int SUMMON_ON_HURT_CHANCE = 10;

    // ---------------------------------------------------------------- 受损黑烟与虚空自毁（需求）

    /** 受击瞬间车头烟柱的锚点：沿车头到鼻尖盒末段（引擎舱位置，格）。 */
    public static final double NOSE_SMOKE_AHEAD = 4.2D;
    /** 车头烟柱锚点高度（格，约在车头盖板上方）。 */
    public static final double NOSE_SMOKE_HEIGHT = 3.0D;
    /** 受击一瞬间在车头撒出的大烟雾粒子数（"大量黑烟"）。 */
    public static final int HURT_SMOKE_BURST = 44;
    /** 受击爆发里叠一层细烟（原版 {@code smoke}）的粒子数，让烟团更黑更实。 */
    public static final int HURT_SMOKE_PUFF = 16;
    /** 血量低于该值（需求 50）：全身持续冒浓黑烟，且每秒吃 {@value #SMOKE_VOID_DAMAGE_LOW} 点虚空伤害。 */
    public static final float LOW_HEALTH_SMOKE = 50.0F;
    /** 血量低于该值（需求 20）：每秒虚空伤害升到 {@value #SMOKE_VOID_DAMAGE_HIGH} 点。 */
    public static final float CRITICAL_HEALTH_SMOKE = 20.0F;
    /** 低血量段的每秒虚空伤害（1 点）。 */
    public static final float SMOKE_VOID_DAMAGE_LOW = 1.0F;
    /** 濒危段的每秒虚空伤害（2 点）。 */
    public static final float SMOKE_VOID_DAMAGE_HIGH = 2.0F;
    /** 虚空伤害节拍：20 tick 一发。 */
    public static final int SMOKE_VOID_INTERVAL_TICKS = 20;
    /**
     * 持续烟的密度（加浓后的口径）：低血量段每孔位每 tick 抛 {@value} 个大烟雾，
     * 濒危段抛 {@link #VENT_SMOKE_LARGE_HIGH} 个；再叠 {@link #VENT_SMOKE_FINE_LOW} /
     * {@link #VENT_SMOKE_FINE_HIGH} 个细烟打底（低血量段隔 tick 撒，濒危段每 tick）。
     */
    public static final int VENT_SMOKE_LARGE_LOW = 2;
    /** 濒危段每孔位每 tick 的大烟雾数（低血量段的 2 倍、原单缕口径的 4 倍）。 */
    public static final int VENT_SMOKE_LARGE_HIGH = 4;
    /** 低血量段每孔位每细烟 tick 的细烟数。 */
    public static final int VENT_SMOKE_FINE_LOW = 1;
    /** 濒危段每孔位每 tick 的细烟数。 */
    public static final int VENT_SMOKE_FINE_HIGH = 2;
    /** 闷喷节拍：每隔 {@value}（低血量段）/ {@link #BELCH_PERIOD_HIGH}（濒危段）tick 发作一次。 */
    public static final int BELCH_PERIOD_LOW = 12;
    /** 濒危段闷喷节拍。 */
    public static final int BELCH_PERIOD_HIGH = 6;
    /** 单次闷喷随机点名的孔位数（共 6 孔）。 */
    public static final int BELCH_VENTS = 3;
    /** 单次闷喷每个被点名孔位抛出的大/细烟数（大半径炸开，形成脉动的浓烟团）。 */
    public static final int BELCH_LARGE = 10;
    public static final int BELCH_FINE = 4;
    /**
     * 凋灵骷髅的 {@code MOVEMENT_SPEED} 属性底（0.2，来自原版
     * {@code AbstractSkeleton#createAttributes}，凋灵骷髅原样继承未覆盖）——
     * 低血量限速的基准。
     */
    public static final double WITHER_SKELETON_MAX_SPEED = 0.2D;
    /** 血量低于 {@value #LOW_HEALTH_SMOKE}（需求）：最大移速降为凋灵骷髅同款。 */
    public static final double LOW_HEALTH_MAX_SPEED = WITHER_SKELETON_MAX_SPEED;
    /** 血量低于 {@value #CRITICAL_HEALTH_SMOKE}（需求）：最大移速再降到凋灵骷髅的 75%。 */
    public static final double CRITICAL_HEALTH_MAX_SPEED = WITHER_SKELETON_MAX_SPEED * 0.75D;

    /**
     * 持续烟的排放点，写在本车锚点系里：{@code {沿车头距离, 侧向偏移, 高度}}。
     * 车头 4.2 格、车体中段 1.8 格（可视车体中心，见 {@link #MODEL_CENTER_AHEAD}）、
     * 车尾 -0.8 格三排各取左右两个孔位，高矮错落，覆盖"各个部位"。
     */
    private static final double[][] SMOKE_VENTS = {
            {4.2D, -1.1D, 3.0D}, {4.2D, 1.1D, 3.0D},
            {1.8D, -1.6D, 2.6D}, {1.8D, 1.6D, 2.6D},
            {-0.8D, -1.2D, 2.2D}, {-0.8D, 1.2D, 2.2D},
    };
    /**
     * 镐类弱点倍率（需求）：主手持镐命中时伤害无视护甲并按该倍率放大，
     * 见 {@link #getDamageAfterArmorAbsorb}。
     */
    public static final float PICKAXE_DAMAGE_MULTIPLIER = 5.0F;
    /** 死亡爆炸：TNT 同量威力，且留火。 */
    public static final float DEATH_EXPLOSION_POWER = 4.0F;
    public static final int DEATH_CREW_MIN = 3;
    public static final int DEATH_CREW_MAX = 5;

    /** 移动音效：矿车声降调。0.55 ≈ 低 15 个半音。 */
    public static final float ROLL_SOUND_PITCH = 0.55F;
    public static final float ROLL_SOUND_VOLUME = 0.9F;

    /** 一轮滚动对应的行程，见 {@link NetherCarrierModel#ROLL_CYCLE_BLOCKS}。 */
    private static final double ROLL_CYCLE = NetherCarrierModel.ROLL_CYCLE_BLOCKS;

    /** 加速系数 0..1（服务端推进，见 {@link #travel}）。 */
    private float speedRamp;
    /**
     * 船式转向率（度/tick，带符号，正值=向右拧）：{@link #steerTowards} 累加、
     * {@link #tick} 每 tick 衰减，与原版船 {@code Boat#deltaRotation} 是同一个量。
     * 不入 NBT（船也没存它），重载后从 0 起转。
     */
    private float turnRate;
    /** 上一 tick 的真实地面位移模长（格/tick），由 {@link #updateRollProgress} 写入，转向闸门读它。 */
    private double groundSpeed;
    /** 拉了油门却连续零位移的 tick 数（防楔死，见 {@link #canSteer()}）。 */
    private int wedgedTicks;

    /** 满速实测基准（格/tick）。 */
    private double topSpeed = FALLBACK_TOP_SPEED;
    /** 轮相（圈）。 */
    private double rollProgress;
    /**
     * 活塞杆位移闸门 0..1：本 tick 有地面位移就升满、静止就平滑回落。模型侧读它
     * （{@link NetherCarrierModel#setupAnim}），于是停车时两根连杆收回绑定姿态，
     * 不会冻在行程中间或按作者动画 t=0 的 {@code [-16,0,0]} 偏出一整格。
     */
    private float pumpBlend;
    private double lastX;
    private double lastZ;
    private boolean rollAnchorReady;
    private boolean deathHandled;
    /** 低血量段每 tick 推进的虚空伤害节拍（0..{@value #SMOKE_VOID_INTERVAL_TICKS}）。 */
    private int voidDamageTick;
    /** 低血量段每 tick 推进的烟节拍（细烟隔 tick、闷喷按周期取模用），离开低血量段归零。 */
    private int smokeTick;
    /** 置位期间表示正在结算自己的虚空 tick：不再触发"受击黑烟"与受击召唤。 */
    private boolean applyingVoidDamage;

    /** 史莱姆式接触集：上一 tick 鼻尖盒里的实体。 */
    private final Set<UUID> ramContacts = new HashSet<>();
    /** 再撞间隔表：UUID → 上次结算 tick。 */
    private final Map<UUID, Long> ramTimestamps = new HashMap<>();

    public NetherCarrier(EntityType<? extends WitherSkeleton> type, Level level) {
        super(type, level);
        // 凋灵骷髅基准 5 的 10 倍 = 50。xpReward 由 Monster 构造器钉成 5（父类链上
        // WitherSkeleton 自己不碰它），本构造器在其之后覆盖；该字段不入 NBT，所以
        // 刷怪蛋、指令、结构刷怪、存档重载都固定走这一条，值不会被别处改写。
        // Mob#getBaseExperienceReward 会按"可掉落的装备件数"再各加 1~3 点，本车
        // populateDefaultEquipmentSlots 为空、finalizeSpawn 又把三个栏位清空，一件不掉，
        // 因此实得经验恒等于这个基准值。
        this.xpReward = XP_REWARD;
        // 转向改道：原版 MoveControl 的 MOVE_TO 分支每 tick 允许硬拧 90°，本车换成
        // 船式（静止禁转 + 每 tick 最多 15° + 转向率逐 tick 衰减）。只换"转角怎么算"，
        // 速度、跳跃、isWalkable 判定全留在父类实现里，见 CarrierSteeringControl。
        // 在 super 之后替换字段是原版做法（Parrot/Blaze 等就这么换 moveControl），
        // 而 CarrierChargeGoal 只在 tick() 里取 getMoveControl()，构造期没人引用它。
        this.moveControl = new CarrierSteeringControl(this);
    }

    /**
     * 工厂方法：{@code Mob} 构造器里调一次、结果写进 {@code private final} 字段，
     * 所以必须在这里覆盖，否则原版 {@code BodyRotationControl} 会在停车时把车身
     * 跟着头向拧（{@code LookAtPlayerGoal} 一掰头，整车原地转向）。详见
     * {@link CarrierBodyControl}。
     */
    @Override
    protected BodyRotationControl createBodyControl() {
        return new CarrierBodyControl(this);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.ARMOR, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, MAX_SPEED_ATTRIBUTE)
                // 索敌 50 格（需求）：车体 9.94 格长，范围太小连冲锋助跑都盖不住。
                .add(Attributes.FOLLOW_RANGE, FOLLOW_RANGE_BLOCKS)
                // 满载的运兵车不该被一剑挑飞、更不能把冲锋线打断。
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    public int getArmorValue() {
        // 需求是"自带 100 点护甲"，但 1.21.1 的 ARMOR 属性是 RangedAttribute(0, 30)，
        // AttributeInstance#calculateValue 末尾会 sanitizeValue 把 100 压回 30，光靠属性
        // 写不进去。LivingEntity#getDamageAfterArmorAbsorb 把护甲送进 CombatRules 时读的
        // 正是本方法（虚调用），所以在这里钉成 100：按 1.21.1 公式
        // clamp(armor - damage/(2 + toughness/4), armor×0.2, 20)/25，armor=100 时下界已经
        // 是 20，等于对任意单次伤害都稳定吃满 80% 减伤（30 点护甲在高伤一击下会被穿透）。
        return 100;
    }

    /**
     * 镐类弱点（需求：无视护甲、5 倍伤害）：主手持镐的近战命中不进 CombatRules
     * 减伤，而是把进入护甲段的全额伤害直接乘 {@value #PICKAXE_DAMAGE_MULTIPLIER}。
     *
     * <p>为什么覆盖这一条就够：1.21.1 NeoForge 的
     * {@code LivingEntity#actuallyHurt} 里护甲段唯一的落账方式是
     * {@code Reduction.ARMOR = getNewDamage() - getDamageAfterArmorAbsorb(…)}，
     * 随后 {@code newDamage -= 该值}。也就是说<b>最终伤害恒等于本方法的返回值</b>
     * （返回 {@code amount} 为全额穿透、返回 {@code amount×5} 即"无视护甲再 ×5"，
     * 差值记成负的 ARMOR reduction 只是账面）。输入侧也选得干净：本方法拿到的
     * {@code amount} 是容器当前值，难度缩放、{@code LivingIncomingDamageEvent}、
     * 盾牌格挡都已在它之前结算完毕；输出之后只剩
     * {@code getDamageAfterMagicAbsorb}——需求只说无视护甲，抗性效果照常参与。
     * 原版护甲耐久磨损 {@code hurtArmor} 随减伤一起跳过，本车不穿装备
     * （{@link #populateDefaultEquipmentSlots} 为空），无副作用。</p>
     */
    @Override
    protected float getDamageAfterArmorAbsorb(DamageSource source, float amount) {
        if (isPickaxeStrike(source)) {
            return amount * PICKAXE_DAMAGE_MULTIPLIER;
        }
        return super.getDamageAfterArmorAbsorb(source, amount);
    }

    /**
     * "持镐近战命中本车"判定。武器取 {@code DamageSource#getWeaponItem()}——原版
     * 语义即伤害来源<b>直接实体</b>的主手物品（玩家近战时就是玩家自己），与原版
     * 武器伤害、死亡消息读的是同一把武器；弹射物的直接实体是箭，主手恒为空，
     * 天然被排除。判据两层：原版 {@code minecraft:pickaxes} 标签（覆盖所有原版
     * 镐和大多按惯例进标签的模组镐）为主，{@link PickaxeItem} 实例判定兜底
     * 未进标签的自制镐。
     */
    private static boolean isPickaxeStrike(DamageSource source) {
        ItemStack weapon = source.getWeaponItem();
        if (weapon == null || weapon.isEmpty()) {
            return false;
        }
        return weapon.is(ItemTags.PICKAXES) || weapon.getItem() instanceof PickaxeItem;
    }

    @Override
    protected void registerGoals() {
        // 刻意不调 super.registerGoals()：父类那套骷髅行为（避日、怕狼、远程/近战、
        // 海龟仇恨）对一辆运兵车没有意义，只保留漂浮、冲锋、游走，以及凋灵骷髅阵营
        // 该有的"仇恨猪灵 + 仇恨玩家 + 仇恨铁傀儡"。
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new CarrierChargeGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // 猪灵：阵营外，全量索敌（谓词只是提前挡掉，真正封死在 setTarget 总闸）。
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, AbstractPiglin.class, true,
                candidate -> !LegionAuraHandler.isFactionMember(candidate)));
        // 玩家：排除凋灵骷髅阵营成员与创造/旁观模式玩家（需求"无论如何都不索敌创造玩家"）。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Player.class, true,
                candidate -> !LegionAuraHandler.isFactionMember(candidate) && !isCreativePlayer(candidate)));
        // 铁傀儡：原版这条来自 AbstractSkeleton#registerGoals 的 targetSelector 3
        // （NearestAttackableTargetGoal<>(this, IronGolem.class, true)），上面不调 super
        // 时把它一起丢了，所以车只会撞玩家和猪灵。这里显式补回来，索敌半径同样走
        // FOLLOW_RANGE（50 格）；阵营成员（凋灵骷髅系、传令兵、无头头颅）不锁，
        // 被反逆者心控的傀儡另有 MesmerizerControlHandler#onChangeTarget 全局拦截。
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, IronGolem.class, true,
                candidate -> !LegionAuraHandler.isFactionMember(candidate)));
    }

    @Override
    public void reassessWeaponGoal() {
        // 父类会按主手物品挂上近战/弓箭目标；运兵车的唯一攻击手段是撞击。
    }

    /** 创造模式玩家判定（需求：无论如何都不索敌创造玩家）。旁观模式一并排除。 */
    private static boolean isCreativePlayer(LivingEntity entity) {
        return entity instanceof Player player
                && (player.isCreative() || player.isSpectator());
    }

    /**
     * 强制锁定仇恨：任何写入目标的路径（主动索敌、受击反击、外部注入）都在此收口——
     * 目标若是凋灵骷髅阵营成员或创造/旁观模式玩家，一律改写成"无目标"。
     *
     * <p>这是"无论怎样都不索敌创造玩家 / 不打自己人"的总闸：{@code targetSelector} 的
     * {@code NearestAttackableTargetGoal} 每刻找到候选后走的正是 {@code setTarget}，
     * {@code HurtByTargetGoal} 的反击仇恨也走这里，所以单点覆盖即可封死所有入口，
     * 无需在每条 goal 上重复设防（goal 侧的谓词只是省一次无效搜索的优化，见
     * {@link #registerGoals}）。</p>
     */
    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target != null
                && (LegionAuraHandler.isFactionMember(target) || isCreativePlayer(target))) {
            target = null;
        }
        super.setTarget(target);
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        // 不发任何装备：有武器就会有挥砍判定，与"只能撞击"的设定冲突。
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        // 原版凋灵骷髅会发石剑/弓、55% 概率允许捡装备、万圣节还会扣个南瓜，
        // 这里一律清空并关掉捡拾，任何生成路径（刷怪蛋、指令、结构）都走这一条。
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        this.setCanPickUpLoot(false);
        return result;
    }

    // ---------------------------------------------------------------- 加速与轮相

    @Override
    public void travel(Vec3 input) {
        if (!this.level().isClientSide && this.isControlledByLocalInstance() && !this.isPassenger()) {
            boolean driving = input.horizontalDistanceSqr() > 1.0E-6D;
            this.speedRamp = Mth.clamp(
                    this.speedRamp + (driving ? 1.0F / ACCEL_TICKS : -1.0F / DECEL_TICKS), 0.0F, 1.0F);
            // 只缩放水平输入：竖直分量（上浮/下潜）保持原样，系数为 0 时等价于站住不动，
            // 于是"从静止到满速 2 秒"就落在这条线性系数上，与原版摩擦无关。
            super.travel(new Vec3(input.x * this.speedRamp, input.y, input.z * this.speedRamp));
            return;
        }
        super.travel(input);
    }

    /** 当前加速系数 0..1（客户端不跑 AI，恒为 1，仅用于"是否在动"的表现判断）。 */
    public float getSpeedRamp() {
        return this.level().isClientSide ? 1.0F : this.speedRamp;
    }

    /** 满速基准（格/tick）：撞击伤害的 1.0 系数。 */
    public double getTopSpeedReference() {
        return this.topSpeed;
    }

    /**
     * 轮相（单位：圈）。由本类按带符号的地面位移累计，静止时不推进——模型侧读它来转
     * 车轮与活塞杆，于是"只有移动时才播放动画"，且车速越快轮子转得越快。
     */
    public double getRollProgress() {
        return this.rollProgress;
    }

    @Override
    public void tick() {
        super.tick();
        this.updateRollProgress();
        if (!this.level().isClientSide && this.isAlive()) {
            this.decayTurnRate();
            this.updateTopSpeedReference();
            this.tickRam();
            this.smashBlocks();
            this.updateLowHealthMaxSpeed();
            this.tickDamageSmoke();
            this.ensureHitboxes();
        }
    }

    /** 两侧都跑：客户端用自己的位移（已插值）算出同样的轮相。 */
    private void updateRollProgress() {
        if (!this.rollAnchorReady) {
            this.rollAnchorReady = true;
            this.lastX = this.getX();
            this.lastZ = this.getZ();
            return;
        }
        Vec3 forward = this.forward();
        double dx = Mth.clamp(this.getX() - this.lastX, -8.0D, 8.0D);
        double dz = Mth.clamp(this.getZ() - this.lastZ, -8.0D, 8.0D);
        this.lastX = this.getX();
        this.lastZ = this.getZ();
        // 真实地面位移模长：转向闸门（是否在运动）唯一的判据，见 canSteer()。
        this.groundSpeed = Math.sqrt(dx * dx + dz * dz);
        // 投影到车头方向：被撞退、卡住回弹时轮子反向转，静止时不推进。
        double along = dx * forward.x + dz * forward.z;
        if (along != 0.0D) {
            this.rollProgress = (this.rollProgress + along / ROLL_CYCLE) % 1.0D;
        }
        // 活塞闸门：有位移升满、静止半秒内收回，两侧独立算出同样的值（无需同步）。
        this.pumpBlend = Mth.clamp(this.pumpBlend + (along != 0.0D ? 0.1F : -0.08F), 0.0F, 1.0F);
    }

    /** 活塞杆位移闸门（0=收回绑定姿态，1=走完整条关键帧轨），供模型侧读取。 */
    public float getPumpBlend() {
        return this.pumpBlend;
    }

    /** 拉满系数且踩在地上时，记录实测最高水平速度，作为撞击标定的分母。 */
    private void updateTopSpeedReference() {
        // 撞墙、下坡滑落带来的瞬时速度不算"满速"，只认平地上稳定跑出来的值。
        if (this.speedRamp >= 0.999F && this.onGround() && !this.horizontalCollision) {
            double speed = this.getDeltaMovement().horizontalDistance();
            if (speed > this.topSpeed) {
                this.topSpeed = speed;
            }
        }
    }

    // ---------------------------------------------------------------- 转向（船式，需求）

    /**
     * 本 tick 的车身朝向怎么变：把"转角请求"当成<b>打舵</b>而不是瞬拧，逐字照抄船的
     * 那套（{@code Boat#controlBoat} 用 {@code deltaRotation} 累加、{@code Boat#floatBoat}
     * 每 tick 让转向率自乘衰减），由 {@link CarrierSteeringControl#rotlerp} 在原版
     * MOVE_TO 分支的位置调用（每 tick 至多一次）。
     *
     * <ol>
     *   <li><b>静止禁转</b>（需求）：{@link #canSteer()} 为 false 就原样交回当前朝向——
     *       停着的车既不拧车身，也不积累转向率；</li>
     *   <li><b>每 tick 左右各 15° 封顶</b>（需求）：打舵量只有 {@value #TURN_INPUT_PER_TICK}°/tick，
     *       累加后再夹到 ±{@value #MAX_STEER_DEGREES_PER_TICK}°/tick，于是转速是
     *       "斜线拉起来"的（约 0.35 秒到 9°/tick、约 0.9 秒触帽），原版那一拍 90° 的
     *       甩头从此没有了；</li>
     *   <li><b>平缓收尾</b>：需求角小于 {@value #TURN_DEADBAND_DEGREES}° 视为已对准，
     *       不再打舵，剩下的转向率在 {@link #decayTurnRate()} 里按 {@value #TURN_RATE_DECAY}
     *       自乘淡出（船的水摩擦同款），停转也是一条斜线而不是急刹；</li>
     *   <li><b>转过头保护</b>：本 tick 实际转角不超过剩余需求角，被削掉的量不留成储备。
     *       目标在正前方微调时不会来回甩——早期"车身摇摆"的病根之一就是转角无记忆、
     *       每拍跟着信箱硬拧，这里给了记忆也给了上限，两头都堵住。</li>
     * </ol>
     *
     * <p>推进侧一行未改：{@code MOVE_TO} 分支照旧 {@code setSpeed}，而
     * {@code LivingEntity#travel} 每 tick 用<b>新</b>朝向把前进量旋进世界坐标，
     * 所以整车是"边转边走"划出弧线，不会先把头拧到位再直着撞出去，也不会侧滑——
     * 这正是船的手感。判定盒乘客由 {@link #positionRider} 每 tick 按 {@link #forward()}
     * 重钉，车头/车尾的隐形判定盒因此自动跟上这条弧线。</p>
     *
     * @param currentYaw 本 tick 开始时的车身朝向（度）
     * @param wantedYaw  信箱方向的绝对朝向（度），冲锋时是敌人实时坐标、游走时是路径节点
     * @return 要写进 {@code yRot} 的新朝向
     */
    public float steerTowards(float currentYaw, float wantedYaw) {
        if (!this.canSteer()) {
            return currentYaw;
        }
        float error = Mth.wrapDegrees(wantedYaw - currentYaw);
        if (Math.abs(error) <= TURN_DEADBAND_DEGREES) {
            // 已经对准：不打舵，让残余转向率在每 tick 的衰减里自己收干净。
            return currentYaw;
        }
        if (this.turnRate * error < 0.0F) {
            // 旧方向的舵还没泄完、需求已经换边：先掐掉反向储备，
            // 不能拿"转过头保护"去反向拧——那等于朝错误方向多走一步。
            this.turnRate = 0.0F;
        }
        this.turnRate = Mth.clamp(this.turnRate + Math.signum(error) * TURN_INPUT_PER_TICK,
                -MAX_STEER_DEGREES_PER_TICK, MAX_STEER_DEGREES_PER_TICK);
        this.turnRate = Mth.clamp(this.turnRate, -Math.abs(error), Math.abs(error));
        return currentYaw + this.turnRate;
    }

    /** 每 tick 一次的泄舵：转向率自乘 {@value #TURN_RATE_DECAY}，与原版船同式。 */
    private void decayTurnRate() {
        this.turnRate *= TURN_RATE_DECAY;
        if (Math.abs(this.turnRate) < 1.0E-3F) {
            this.turnRate = 0.0F;
        }
    }

    /**
     * 转向闸门（需求"静止时无法转向，只有在运动时可以转"）：判据取<b>上一 tick 的真实
     * 地面位移</b>（{@link #updateRollProgress} 记的 {@link #groundSpeed}），而不是油门——
     * 停着的车哪怕 AI 正在发前进指令也不给原地掉头，一旦轮子真的滚起来就开转，
     * 于是"起步即转"的观感和船一致。车身被撞退的滑行不算（{@code KNOCKBACK_RESISTANCE}
     * 恒为 1.0，本来也滑不出 0.003 格/tick）。
     *
     * <p>唯一例外是<b>被方块楔死</b>：油门已拉到一半以上、却连续
     * {@value #WEDGE_STEER_TICKS} tick 一步没动（碰上基岩/黑曜石这类
     * {@link #BREAK_HARDNESS_LIMIT} 铲不动的方块），此时推进已被完全吃掉，放行转向让它
     * 能掉头脱困；否则它会一辈子顶在墙上——静止禁转是本需求要的效果，原地楔死不是。</p>
     */
    private boolean canSteer() {
        if (this.groundSpeed > MIN_STEER_GROUND_SPEED) {
            this.wedgedTicks = 0;
            return true;
        }
        if (this.speedRamp > WEDGE_STEER_RAMP) {
            this.wedgedTicks++;
            return this.wedgedTicks >= WEDGE_STEER_TICKS;
        }
        this.wedgedTicks = 0;
        return false;
    }

    /** 当前转向率（度/tick，正值向右）。只给调试/渲染侧读，逻辑不参与判定。 */
    public float getTurnRate() {
        return this.turnRate;
    }

    // ---------------------------------------------------------------- 撞击

    /** 车头朝向的单位向量。用 {@code getYRot()}：模型与判定都跟着车身转。 */
    private Vec3 forward() {
        float rad = this.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(rad), 0.0D, Mth.cos(rad));
    }

    /** 鼻尖判定盒：本体判定盒沿车头前伸 {@value #NOSE_REACH} 格。 */
    private AABB noseBox() {
        Vec3 forward = this.forward();
        return this.getBoundingBox().expandTowards(forward.x * NOSE_REACH, 0.0D, forward.z * NOSE_REACH);
    }

    // ---------------------------------------------------------------- 车头/车尾补位判定盒

    /**
     * 保证两具隐形子判定盒（{@link CarrierHitbox}）挂在车上：探出主判定箱的车头
     * （约 5.1 格）与车尾（约 1.1 格）各一具。挂的是原版乘客机制：位置由
     * {@link #positionRider} 每 tick 现钉（两侧都跑，转向自动跟）、存档随本尊
     * 嵌套保存、{@code canCollideWith} 天然跳过同车乘客——判定盒永远不会反过来
     * 卡住运兵车走路（抽搐的病根不得复发）。丢盒（被清除/区块竞态）后下一 tick
     * 自愈补挂。
     */
    private void ensureHitboxes() {
        boolean hasNose = false;
        boolean hasRear = false;
        for (Entity rider : this.getPassengers()) {
            if (rider instanceof CarrierHitbox box) {
                if (box.getKind() == CarrierHitbox.KIND_NOSE) {
                    hasNose = true;
                } else {
                    hasRear = true;
                }
            }
        }
        if (!hasNose) {
            this.spawnHitbox(CarrierHitbox.KIND_NOSE);
        }
        if (!hasRear) {
            this.spawnHitbox(CarrierHitbox.KIND_REAR);
        }
    }

    private void spawnHitbox(int kind) {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        CarrierHitbox box = GeneratedMod.NETHER_CARRIER_HITBOX.get().create(level);
        if (box == null) {
            return;
        }
        // 先定形态再定位：锚距按盒种取，入世界第一帧就落在正确位置（无闪现/漂移包）。
        box.setup(this, kind);
        Vec3 forward = this.forward();
        double ahead = box.anchorOffset();
        box.setPos(this.getX() + forward.x * ahead, this.getY(), this.getZ() + forward.z * ahead);
        box.refreshDimensions();
        level.addFreshEntity(box);
        box.startRiding(this, true);
    }

    /**
     * 子判定盒钉位：沿 {@link #forward()} 平推到各自的锚距，脚底贴本尊脚底
     * （车头盒 0→3.2 格、车尾盒 0→4.4 格，正好罩住可见车体）。其余乘客走原版
     * 默认逻辑——将来若真有乘员爬上车顶，也互不干扰。
     */
    @Override
    protected void positionRider(Entity rider, Entity.MoveFunction moveFunc) {
        if (rider instanceof CarrierHitbox box) {
            Vec3 forward = this.forward();
            double ahead = box.anchorOffset();
            moveFunc.accept(box, this.getX() + forward.x * ahead, this.getY(), this.getZ() + forward.z * ahead);
            box.setYRot(this.getYRot());
            return;
        }
        super.positionRider(rider, moveFunc);
    }

    /**
     * 鼻尖盒里的每个目标每 tick 吃一次固定接触伤害；"新进入接触集"的目标额外结算
     * 一发随速度放大的撞击（伤害、击退、缴械）。阵营成员直接排除。
     */
    private void tickRam() {
        long now = this.level().getGameTime();
        List<LivingEntity> hits = this.level().getEntitiesOfClass(LivingEntity.class, this.noseBox(),
                candidate -> candidate != this && candidate.isAlive()
                        && !LegionAuraHandler.isFactionMember(candidate)
                        && !isCreativePlayer(candidate));
        Set<UUID> current = new HashSet<>(Math.max(4, hits.size() * 2));
        for (LivingEntity hit : hits) {
            UUID id = hit.getUUID();
            current.add(id);
            this.applyContactDamage(hit);
            if (this.ramContacts.contains(id)) {
                continue;
            }
            Long last = this.ramTimestamps.get(id);
            if (last != null && now - last < RE_HIT_INTERVAL) {
                continue;
            }
            this.ramTimestamps.put(id, now);
            this.ramInto(hit);
        }
        this.ramContacts.clear();
        this.ramContacts.addAll(current);
        if (this.ramTimestamps.size() > 64) {
            this.ramTimestamps.values().removeIf(at -> now - at > 200L);
        }
    }

    /**
     * 每 tick 2 点接触伤害。与速度无关：静止贴住、刚起步、被墙挤住都照掉。
     *
     * <p>原版 {@code LivingEntity#hurt} 把 {@code invulnerableTime} 设成 20，且低伤会被
     * 上一击压制（{@code lastHurt} 门槛），所以必须在 hurt 前后都清零，否则 2 点/tick
     * 会被无敌帧吞掉，看起来像"每秒才掉一次血"。</p>
     * <p>{@code mobAttack} 自带 0.4 击退；接触伤害不能把目标弹开，否则静止贴脸时
     * 下一 tick 已经不在判定盒里，2 点/tick 就变成了"碰一下弹开再碰一下"。
     * 速度型撞击的击退仍由 {@link #ramInto} 在同 tick 稍后写入。</p>
     */
    private void applyContactDamage(LivingEntity target) {
        Vec3 motion = target.getDeltaMovement();
        target.invulnerableTime = 0;
        target.hurt(this.damageSources().mobAttack(this), CONTACT_DAMAGE_PER_TICK);
        target.invulnerableTime = 0;
        target.setDeltaMovement(motion);
        target.hurtMarked = true;
    }

    /** 对一个目标结算一次撞击：伤害、击退、缴械。 */
    private void ramInto(LivingEntity target) {
        Vec3 forward = this.forward();
        // 几何基准取可视车体中点（模型前移 2 格，见 {@link #MODEL_CENTER_AHEAD}），
        // 否则中后段的侧擦会被判成正面（along 从锚点算起恒偏大）。
        Vec3 offset = target.position().subtract(
                this.getX() + forward.x * MODEL_CENTER_AHEAD,
                this.getY(),
                this.getZ() + forward.z * MODEL_CENTER_AHEAD);
        double along = offset.x * forward.x + offset.z * forward.z;
        // 侧向偏移 = 连线在"垂直于车头"方向上的投影长度。
        double lateral = Math.abs(-offset.x * forward.z + offset.z * forward.x);
        boolean frontal = Math.abs(along) >= lateral;

        Vec3 targetVelocity = target.getDeltaMovement();
        double closing = this.getDeltaMovement().horizontalDistance()
                - (targetVelocity.x * forward.x + targetVelocity.z * forward.z);
        double ratio = Mth.clamp(closing / Math.max(this.topSpeed, 1.0E-3D), 0.0D, MAX_SPEED_RATIO);
        if (ratio < MIN_RAM_RATIO) {
            // 几乎没速度（刚起步、被墙挤住）：不结算这次"撞击"（大伤害与击退），
            // 固定接触伤害已经在 applyContactDamage 里先行结算过了。
            return;
        }

        float damage = (frontal ? FRONT_RAM_DAMAGE : FRONT_RAM_DAMAGE * SIDE_RAM_RATIO) * (float) ratio;
        // 举盾格挡时这里可能是 false（这一击的伤害被盾吃掉），但缴械与击退照样执行。
        target.hurt(this.damageSources().mobAttack(this), damage);

        Vec3 push = new Vec3(offset.x, 0.0D, offset.z);
        push = push.lengthSqr() < 1.0E-4D ? forward : push.normalize();
        double blocks = frontal ? FRONT_RAM_KNOCKBACK_BLOCKS : FRONT_RAM_KNOCKBACK_BLOCKS * SIDE_RAM_RATIO;
        double velocity = blocks * ratio * KNOCKBACK_BLOCKS_TO_VELOCITY;
        Vec3 current = target.getDeltaMovement();
        target.setDeltaMovement(push.x * velocity,
                Math.min(0.4D, current.y + velocity * 0.35D), push.z * velocity);
        // hurtMarked 让 ServerEntity 把新速度回灌客户端（原版 knockback 走的也是这条路）。
        target.hurtMarked = true;

        this.disarmShield(target);
    }

    /** 撞击缴械：把盾从手上打落；玩家额外吃原版 10 秒破盾冷却与动画。 */
    private void disarmShield(LivingEntity target) {
        EquipmentSlot slot = null;
        if (target.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem) {
            slot = EquipmentSlot.OFFHAND;
        } else if (target.getItemBySlot(EquipmentSlot.MAINHAND).getItem() instanceof ShieldItem) {
            slot = EquipmentSlot.MAINHAND;
        }
        if (slot == null) {
            return;
        }
        if (target instanceof Player player) {
            player.disableShield();
        }
        ItemStack stolen = target.getItemBySlot(slot).copy();
        target.setItemSlot(slot, ItemStack.EMPTY);
        ItemEntity dropped = target.spawnAtLocation(stolen, 0.0F);
        if (dropped != null) {
            // 1.5 秒内捡不回来：给玩家"盾被创飞了"的体感，又不至于永久缴械。
            dropped.setPickUpDelay(30);
        }
        target.playSound(SoundEvents.SHIELD_BREAK, 1.0F, 0.8F);
    }

    @Override
    public boolean canDisableShield() {
        return true;
    }

    // ---------------------------------------------------------------- 破方块

    /** 运动中铲掉鼻尖盒里硬度低于钻石矿的方块。 */
    private void smashBlocks() {
        if (this.speedRamp < BREAK_MIN_RAMP) {
            return;
        }
        if (!net.neoforged.neoforge.event.EventHooks.canEntityGrief(this.level(), this)) {
            return;
        }
        AABB box = this.noseBox();
        Level level = this.level();
        int budget = BREAK_BUDGET_PER_TICK;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int x = Mth.floor(box.minX); x <= Mth.floor(box.maxX) && budget > 0; x++) {
            for (int y = Mth.floor(box.minY); y <= Mth.floor(box.maxY) && budget > 0; y++) {
                for (int z = Mth.floor(box.minZ); z <= Mth.floor(box.maxZ) && budget > 0; z++) {
                    cursor.set(x, y, z);
                    BlockState state = level.getBlockState(cursor);
                    if (state.isAir()) {
                        continue;
                    }
                    float hardness = state.getDestroySpeed(level, cursor);
                    if (hardness < 0.0F || hardness >= BREAK_HARDNESS_LIMIT) {
                        continue;
                    }
                    if (level.destroyBlock(cursor, true, this)) {
                        budget--;
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- 召唤与死亡

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean damaged = super.hurt(source, amount);
        if (damaged && !this.level().isClientSide && !this.applyingVoidDamage) {
            // 需求：受击不再闪红（红闪在渲染器侧掐断，见 GeneratedModClient），
            // 改为的一瞬间在车头撒一大团黑烟。自己每秒结算的虚空 tick 不算"受击"：
            // 低血量段本来就在全身持续冒烟，再叠一发爆发只会让节律糊成一团，
            // 也不该让自毁伤害白嫖 10% 受击召唤。
            this.emitNoseSmokeBurst();
            if (this.random.nextInt(100) < SUMMON_ON_HURT_CHANCE) {
                this.summonCrew(1, source.getEntity() instanceof LivingEntity threat ? threat : this.getTarget());
            }
        }
        return damaged;
    }

    // ---------------------------------------------------------------- 受损黑烟与虚空自毁

    /**
     * 低血量限速（需求）：血量低于 {@value #LOW_HEALTH_SMOKE} 时把 {@code MOVEMENT_SPEED}
     * 属性底从满速 {@value #MAX_SPEED_ATTRIBUTE} 降到凋灵骷髅同款的
     * {@value #WITHER_SKELETON_MAX_SPEED}，再跌破 {@value #CRITICAL_HEALTH_SMOKE}
     * 降到其 75%（{@value #CRITICAL_HEALTH_MAX_SPEED}）；血量回到阈值上方则恢复满速底。
     *
     * <p>为什么只动属性底就能全局封顶：两条移动通道都是每 tick 现读该属性——冲锋走
     * {@code MoveControl#tick} 的 MOVE_TO 分支（{@code speedModifier ×
     * getAttributeValue(MOVEMENT_SPEED)}，见 {@link CarrierChargeGoal}），游走由
     * {@code PathNavigation} 把路径节点写进同一条信箱；{@link #travel} 的
     * {@code speedRamp} 只是在这个上限之上再乘一个 0..1 的线性系数。所以属性底就是
     * 整车最大移速的唯一封顶，不需要逐个目标打补丁，冲锋/游走/翻障碍自动同步降速。</p>
     *
     * <p>只覆写底值、不碰修饰符：军团光环的 +25% 乘区与传令兵速度下限
     * （{@link LegionAuraHandler}）照旧叠加在降过的底值上，被光环加持的伤车与同款
     * 加持的凋灵骷髅移速依然一致，符合"与凋灵骷髅相同"的同条件口径。光环每隔若干
     * tick 回 1 点血，"回上阈值再掉下去"真实存在，每 tick 的重算同时负责升与降；
     * 值没变就不写属性，避免逐 tick 标脏。{@link #topSpeed} 实测基准只升不降，撞击
     * 伤害按"实际闭合速度 ÷ 满速基准"取比例，被限速的车撞得慢、伤害自然缩水，
     * 无需额外处理。</p>
     */
    private void updateLowHealthMaxSpeed() {
        float health = this.getHealth();
        double target = health < CRITICAL_HEALTH_SMOKE ? CRITICAL_HEALTH_MAX_SPEED
                : health < LOW_HEALTH_SMOKE ? LOW_HEALTH_MAX_SPEED
                : MAX_SPEED_ATTRIBUTE;
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && speed.getBaseValue() != target) {
            speed.setBaseValue(target);
        }
    }

    /**
     * 低血量段的"带伤行驶"结算（需求）：血量低于 {@value #LOW_HEALTH_SMOKE} 时每个 tick
     * 在 {@link #SMOKE_VENTS} 的全部孔位撒 {@value #VENT_SMOKE_LARGE_LOW} 个大烟雾
     * （{@code large_smoke}，黑灰色），濒危段（低于 {@value #CRITICAL_HEALTH_SMOKE}）
     * 升到 {@value #VENT_SMOKE_LARGE_HIGH} 个；同时隔 tick（濒危段每 tick）叠一层
     * {@code smoke} 细烟打底，并按 {@value #BELCH_PERIOD_LOW}/{@value #BELCH_PERIOD_HIGH}
     * tick 的周期随机点名 {@link #BELCH_VENTS} 个孔位闷喷一大团——烟柱因此有脉动的
     * 节奏，而不是均匀的一缕薄纱（需求补充：烟雾要更明显、更多）。
     * 并每 {@value #SMOKE_VOID_INTERVAL_TICKS} tick 吃一发虚空伤害——
     * {@value #SMOKE_VOID_DAMAGE_LOW} 点，血量再跌破 {@value #CRITICAL_HEALTH_SMOKE}
     * 升到 {@value #SMOKE_VOID_DAMAGE_HIGH} 点。
     *
     * <p>伤害走 {@code DamageSources#fellOutOfWorld()}（原版 {@code out_of_world}：
     * 虚空伤害按定义绕过护甲与格挡冷却，否则这 1~2 点会被 100 护甲砍到 0.2~0.4 点，
     * "每秒 1 点"就不成立）。伤害在 {@link #hurt} 里被 {@link #applyingVoidDamage}
     * 闸门标记，不再触发受击爆发烟与受击召唤。血量回到阈值以上时节拍归零，
     * 不会攒出一发双倍伤害。</p>
     *
     * <p>加量的代价只落在粒子数上：每个孔位每类烟仍各是一发
     * {@code sendParticles}（count 参数变大，包数不变），且该重载本身只广播给
     * 32 格内的玩家——远处看着烧车的玩家不会被无谓的包淹没。</p>
     */
    private void tickDamageSmoke() {
        if (this.getHealth() >= LOW_HEALTH_SMOKE) {
            this.voidDamageTick = 0;
            this.smokeTick = 0;
            return;
        }
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        boolean critical = this.getHealth() < CRITICAL_HEALTH_SMOKE;
        this.smokeTick++;
        Vec3 forward = this.forward();
        Vec3 right = new Vec3(-forward.z, 0.0D, forward.x);
        // 主烟柱：每孔位每 tick 一大股（低血量段 2 粒、濒危段 4 粒）。散布与上行
        // 速度都比原来的单缕口径放大一档，柱体明显变粗。
        int largePerVent = critical ? VENT_SMOKE_LARGE_HIGH : VENT_SMOKE_LARGE_LOW;
        // 细烟打底：细粒子塞进大烟雾的缝隙里，整根柱子看起来是"一坨黑"而不是散点。
        boolean fineTick = critical || (this.smokeTick & 1) == 0;
        int finePerVent = critical ? VENT_SMOKE_FINE_HIGH : VENT_SMOKE_FINE_LOW;
        for (double[] vent : SMOKE_VENTS) {
            Vec3 pos = this.ventWorldPos(forward, right, vent);
            level.sendParticles(ParticleTypes.LARGE_SMOKE,
                    pos.x, pos.y, pos.z, largePerVent, 0.45D, 0.3D, 0.45D, 0.025D);
            if (fineTick) {
                level.sendParticles(ParticleTypes.SMOKE,
                        pos.x, pos.y + 0.25D, pos.z, finePerVent, 0.3D, 0.25D, 0.3D, 0.045D);
            }
        }
        // 周期性闷喷：随机点名几个孔位，大半径炸开一团浓烟（濒危段节拍更短）。
        int belchPeriod = critical ? BELCH_PERIOD_HIGH : BELCH_PERIOD_LOW;
        if (this.smokeTick % belchPeriod == 0) {
            for (int i = 0; i < BELCH_VENTS; i++) {
                double[] vent = SMOKE_VENTS[this.random.nextInt(SMOKE_VENTS.length)];
                Vec3 pos = this.ventWorldPos(forward, right, vent);
                level.sendParticles(ParticleTypes.LARGE_SMOKE,
                        pos.x, pos.y, pos.z, BELCH_LARGE, 0.7D, 0.5D, 0.7D, 0.05D);
                level.sendParticles(ParticleTypes.SMOKE,
                        pos.x, pos.y + 0.3D, pos.z, BELCH_FINE, 0.5D, 0.4D, 0.5D, 0.07D);
            }
        }
        if (++this.voidDamageTick >= SMOKE_VOID_INTERVAL_TICKS) {
            this.voidDamageTick = 0;
            float damage = this.getHealth() < CRITICAL_HEALTH_SMOKE
                    ? SMOKE_VOID_DAMAGE_HIGH : SMOKE_VOID_DAMAGE_LOW;
            // 原版 hurt 的压制门是 `invulnerableTime > 10 && 伤害 <= lastHurt 就整击吞掉`：
            // 交战中途这一发 1~2 点很容易被上一刀顶掉，导致"每秒 1 点"变成"每秒看运气"。
            // 清零只为放行自己这一发；hurt 收尾照常把无敌帧设回 20，对外来的伤害节律无额外影响。
            this.invulnerableTime = 0;
            this.applyingVoidDamage = true;
            try {
                this.hurt(this.damageSources().fellOutOfWorld(), damage);
            } finally {
                this.applyingVoidDamage = false;
            }
        }
    }

    /** 把锚点系里的孔位 {@code {沿车头距离, 侧向偏移, 高度}} 换算成世界坐标。 */
    private Vec3 ventWorldPos(Vec3 forward, Vec3 right, double[] vent) {
        return new Vec3(
                this.getX() + forward.x * vent[0] + right.x * vent[1],
                this.getY() + vent[2],
                this.getZ() + forward.z * vent[0] + right.z * vent[1]);
    }

    /**
     * 受击一瞬间的车头黑烟爆发（服务端撒粒子，{@code sendParticles} 自动广播给附近玩家）。
     * 加浓口径：{@value #HURT_SMOKE_BURST} 个大烟雾（原来 24）炸开在更宽的散布里，
     * 再叠 {@value #HURT_SMOKE_PUFF} 个细烟垫在团芯，一瞬的烟团既要大也要黑。
     */
    private void emitNoseSmokeBurst() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        Vec3 forward = this.forward();
        double x = this.getX() + forward.x * NOSE_SMOKE_AHEAD;
        double y = this.getY() + NOSE_SMOKE_HEIGHT;
        double z = this.getZ() + forward.z * NOSE_SMOKE_AHEAD;
        level.sendParticles(ParticleTypes.LARGE_SMOKE,
                x, y, z, HURT_SMOKE_BURST, 0.9D, 0.5D, 0.9D, 0.055D);
        level.sendParticles(ParticleTypes.SMOKE,
                x, y + 0.3D, z, HURT_SMOKE_PUFF, 0.65D, 0.35D, 0.65D, 0.035D);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level().isClientSide || this.deathHandled) {
            return;
        }
        this.deathHandled = true;
        // TNT 当量：威力 4、留火、按 TNT 规则破坏方块（默认粒子 + GENERIC_EXPLODE 音效）；
        // 阵营成员由自定义计算器豁免。
        this.level().explode(this, null, new FactionSafeCalculator(), this.getX(), this.getY(), this.getZ(),
                DEATH_EXPLOSION_POWER, true, Level.ExplosionInteraction.TNT);
        this.summonCrew(DEATH_CREW_MIN + this.random.nextInt(DEATH_CREW_MAX - DEATH_CREW_MIN + 1),
                this.getTarget());
        // 需求：死亡时"必定"留下一名下界传令兵，与上面 3~5 只随机乘员互不影响、叠加结算。
        // 传令兵是凋灵骷髅阵营成员（{@link LegionAuraHandler#isFactionMember} 为 true），
        // 已被 FactionSafeCalculator 豁免，不会被这发爆炸炸死。
        this.summonGuaranteedCourier(this.getTarget());
    }

    /**
     * 死亡必留：在自身位置召唤一名下界传令兵，仇恨与本车保持一致。
     *
     * <p>刻意独立于 {@link #summonCrew} 的随机 4 选一——那条是"随机乘员"，本方法是
     * "固定传令兵"，两者在 {@link #die} 里各调各的，随机数互不占用，因此既不改变
     * 3~5 只的既有分布，也保证传令兵恒为 1 只。</p>
     */
    private void summonGuaranteedCourier(LivingEntity aggro) {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        NetherCourier courier = GeneratedMod.NETHER_COURIER.get().create(level);
        if (courier == null) {
            return;
        }
        courier.setPos(this.getX(), this.getY(), this.getZ());
        courier.setYRot(this.getRandom().nextFloat() * 360.0F);
        courier.finalizeSpawn(level, level.getCurrentDifficultyAt(courier.blockPosition()),
                MobSpawnType.MOB_SUMMONED, null);
        courier.setPersistenceRequired();
        if (isShareableAggro(aggro)) {
            courier.setTarget(aggro);
        }
        level.addFreshEntity(courier);
    }

    /**
     * 在自身位置召唤 {@code count} 只乘员，仇恨与本车保持一致。
     *
     * @param aggro 共享的仇恨目标，可为空（此时乘员按自己的索敌规则行动）
     */
    private void summonCrew(int count, LivingEntity aggro) {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        for (int i = 0; i < count; i++) {
            Entity crew = switch (this.random.nextInt(4)) {
                case 0 -> EntityType.WITHER_SKELETON.create(level);
                case 1 -> GeneratedMod.BERSERKER.get().create(level);
                case 2 -> GeneratedMod.NETHER_HUNTER.get().create(level);
                default -> GeneratedMod.MESMERIZER.get().create(level);
            };
            if (!(crew instanceof Mob mob)) {
                continue;
            }
            // 召唤位置就是运兵车所处的位置（可能与车体判定重叠，下一 tick 原版碰撞会推开）。
            mob.setPos(this.getX(), this.getY(), this.getZ());
            mob.setYRot(this.getRandom().nextFloat() * 360.0F);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()),
                    MobSpawnType.MOB_SUMMONED, null);
            mob.setPersistenceRequired();
            if (isShareableAggro(aggro)) {
                mob.setTarget(aggro);
            }
            level.addFreshEntity(mob);
        }
    }

    /**
     * 共享仇恨合法性判定：乘员/传令兵可以继承本车仇恨，但阵营成员与创造模式玩家除外
     * （需求：无论哪条路径都不该把这两类目标塞给下界军团）。
     */
    private boolean isShareableAggro(LivingEntity aggro) {
        return aggro != null && aggro != this && aggro.isAlive()
                && !LegionAuraHandler.isFactionMember(aggro)
                && !isCreativePlayer(aggro);
    }

    /** 爆炸豁免：凋灵骷髅阵营成员不掉血、也不被冲击波推开。 */
    private static final class FactionSafeCalculator extends ExplosionDamageCalculator {
        @Override
        public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
            return !LegionAuraHandler.isFactionMember(entity) && super.shouldDamageEntity(explosion, entity);
        }

        @Override
        public float getKnockbackMultiplier(Entity entity) {
            return LegionAuraHandler.isFactionMember(entity) ? 0.0F : super.getKnockbackMultiplier(entity);
        }
    }

    // ---------------------------------------------------------------- 音效与冲锋辅助

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        // 需求指定：受击音效同僵尸破门。
        return SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR;
    }

    @Override
    protected SoundEvent getDeathSound() {
        // 与受击同系列的"门被砸开"，把整段受击音效收束掉。
        return SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getStepSound() {
        // 需求指定：移动音效同矿车。
        return SoundEvents.MINECART_RIDING;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // 音调更低（0.55）＝矿车声压低，音量给足让"沉重的滚动"能听见。
        this.playSound(this.getStepSound(), ROLL_SOUND_VOLUME, ROLL_SOUND_PITCH);
    }

    /**
     * 渲染剔除用的包围盒：模型整体前移 2 格后，车头探出判定箱约 5.1 格、车尾约 1.1 格，
     * 按判定箱剔除会出现"镜头贴着车头时整车突然消失"，这里把盒子的水平范围按鼻尖长度
     * 补到模型实际尺寸（两头都补，对角线朝向时包络同样够用）。
     */
    @Override
    public AABB getBoundingBoxForCulling() {
        return super.getBoundingBoxForCulling().inflate(NOSE_REACH, 0.0D, NOSE_REACH);
    }

}