package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherFactionRoster;
import cn.blockforge.generated.netherarmy.WitherFactionSupremeHostility;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 军团仇恨总闸（三）：{@code Entity#isAlliedTo}。
 *
 * <p>{@code TargetingConditions} 的最后一道身份筛选。阵营成员只承认私有名册里的实体是自己人：
 * 别的模组用同盟、队伍、归属者（{@code getOwnerUUID}）之类机制把它的亡灵怪和军团"绑成一家"时，
 * 这份声明在军团这一侧不生效，索敌照样成立。</p>
 *
 * <p>只对"阵营成员自己开口判断"的调用生效：弹道问"这个受害者是不是发射者的自己人"这类
 * {@code this} 不是军团成员的调用完全不变，友伤豁免与原版行为不受影响。</p>
 */
@Mixin(Entity.class)
public abstract class LegionSupremeAllianceMixin {

    @Inject(method = "isAlliedTo(Lnet/minecraft/world/entity/Entity;)Z", at = @At("HEAD"), cancellable = true)
    private void netherarmy$legionDecidesAlliance(Entity other, CallbackInfoReturnable<Boolean> callback) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof LivingEntity attacker)) {
            return;
        }
        // 名册外的实体保持原版结论：先廉价排掉绝大多数调用。
        if (!WitherFactionRoster.isMember(attacker)) {
            return;
        }
        Boolean verdict = WitherFactionSupremeHostility.resolveAlliance(attacker, other instanceof LivingEntity otherLiving ? otherLiving : null);
        if (verdict != null) {
            callback.setReturnValue(verdict);
        }
    }
}
