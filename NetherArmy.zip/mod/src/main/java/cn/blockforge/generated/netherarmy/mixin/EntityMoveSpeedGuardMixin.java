package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.EntityMotionGuard;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 速度兜底的第二层：在 {@code Entity#move} 入口把这一 tick 的位移实参收进安全范围。
 *
 * <p><b>为什么还要这一层：</b>{@link EntityMotionGuard} 的
 * {@code EntityTickEvent.Pre} 只能收拾"上一 tick 留下来的"速度。有的模组是在自己的
 * {@code travel}/{@code tick} 里当场把速度算爆、紧接着同一次调用里就 {@code move}——
 * 这时候事件钩子早就过去了，崩服点却还是 {@code move} 里那个按位移撑开的碰撞盒。</p>
 *
 * <p><b>原版的坑：</b>{@code move} 会把 {@code getBoundingBox().expandTowards(位移)}
 * 交给 {@code EntitySectionStorage#forEachAccessibleNonEmptySection}，后者用
 * {@code SectionPos.asLong} 把盒子的 min/max 打包成 long 再取 {@code subSet}。
 * 打包只留了每轴 22 位（约 ±6700 万格），速度到了 10<sup>12</sup> 档就会回绕成
 * {@code start > end}，抛 {@code IllegalArgumentException} 崩服（实测崩在
 * {@code spore:inf_human} 上）。把位移在进 {@code move} 之前压回
 * {@link EntityMotionGuard#MAX_SPEED_PER_TICK} 格/tick，碰撞盒就永远是小盒子。</p>
 *
 * <p><b>只改实参，不改对象状态：</b>这里不动 {@code deltaMovement} 本身（那一层由
 * {@link EntityMotionGuard#onEntityTick} 负责），所以别的模组自己的"速度账本"不会被
 * 悄悄改写；就算它每 tick 都重新算出一个巨大的速度，也只会被逐次压成
 * "朝原方向、最多 64 格/tick 的位移"，不再崩服。</p>
 *
 * <p><b>require = 0：</b>这条注入是"锦上添花"的第二层，第一层（事件钩子）单独也能拦住
 * 绝大多数情况。万一将来版本把 {@code move} 改名或改签名，宁可退化成只有第一层、
 * 由 Mixin 打一行警告，也不要让整个 {@code Entity} 类转换失败把游戏崩在启动路上。</p>
 */
@Mixin(Entity.class)
public abstract class EntityMoveSpeedGuardMixin {

    /**
     * 只盯 {@code move} 里唯一的那一个 {@code Vec3} 实参（{@code MoverType} 之外），
     * 所以用类型匹配、不写死局部变量槽位：签名里再插什么参数也不会绑错。
     */
    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true, require = 0)
    private Vec3 netherarmy$clampMovementStep(Vec3 movement) {
        return EntityMotionGuard.guardMovementStep((Entity) (Object) this, movement);
    }
}
