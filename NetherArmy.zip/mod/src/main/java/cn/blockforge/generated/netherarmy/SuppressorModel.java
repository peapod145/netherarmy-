package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 反转士模型：几何与逐面 UV 按用户上传的 {@code Suppressor.bbmodel} 精确复刻
 * （64×64 贴图，32px 标准人形网格：头 8³、躯干 8×12×4、臂 2×12×2、腿 2×11×2）。
 *
 * <p>与原版凋灵骷髅的差别只在细节：本模型是"标准人形枢轴"（头/躯干 y=0、臂 ±5/y=2、
 * 腿 ±1.9/y=12），因此 {@code HumanoidModel#setupAnim} 每帧把枢轴钉回成年网格时
 * 恰好就是本模型自己的位置，无需像 {@link WitherServantModel} 那样再还原一次；
 * 渲染器里照常 {@code scale(1.2)} 把 32px 撑到 2.4 格，与凋灵骷髅判定箱齐平。</p>
 *
 * <p>两个 2×2×2 的靴套件挂在同一条腿上（同一个 {@link CubeListBuilder} 里追加面），
 * 四片 4×5×4 的裙甲按 bbmodel 的分组处理：两片无旋转的直接并进躯干，两片带
 * 180° Y 旋转的做成躯干的子部件（子部件的 {@code PartPose} 就是 Blockbench 的元素
 * 轴心 [1,10.5,0] / [-1,10.5,0] 换算到 Java 的 [1,13.5,0] / [-1,13.5,0]），
 * 这样旋转方向与 Blockbench 预览逐帧一致。</p>
 *
 * <p>头部的第二层（bbmodel {@code headwear}）走 Aulo {@code hat} 部件：与头同枢轴、
 * 同 8³ 几何，但每个面沿自身法线外推 0.5px——等价于原版的
 * {@code new CubeDeformation(0.5F)}，只是逐面做法可以同时保留 bbmodel 的逐面 UV。
 * 原因是 {@code CubeListBuilder} 没有"形变 + 指定可见面"的组合重载，若直接用
 * {@code addBox(..., CubeDeformation)} 就只能吃标准 box UV，而 bbmodel 的东西面
 * 与 Java 标准布局是互换的。</p>
 */
public class SuppressorModel extends HumanoidModel<Suppressor> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "suppressor"), "main");
    public static final ModelLayerLocation INNER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "suppressor"), "inner_armor");
    public static final ModelLayerLocation OUTER_ARMOR = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "suppressor"), "outer_armor");

    public SuppressorModel(ModelPart root) {
        super(root);
    }

    /**
     * 施法姿态：反转士起手后覆盖 {@link HumanoidModel} 的手臂摆动，改用原版唤魔者
     * {@code IllagerModel.SPELLCASTING} 那一套——双臂抬到肩上、指尖朝上（zRot ±135°），
     * 只留 {@code cos(ageInTicks * 0.6662F) * 0.25F} 的轻微颤动。数值逐项照抄
     * {@code net.minecraft.client.model.IllagerModel#setupAnim}，腿与头仍走父类逻辑，
     * 所以施法期间照样能走路/转头。
     *
     * <p>姿态放在 {@code super.setupAnim} 之后：父类已按行走、攻击挥臂、骑乘等算好手臂，
     * 这里只在"施法中"这一帧的最后盖掉，其余情况完全不动。护甲层用的是同款
     * {@link SuppressorModel} 实例，也会跟着抬臂。</p>
     */
    @Override
    public void setupAnim(Suppressor entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (entity.isCastingSpell()) {
            this.rightArm.x = -5.0F;
            this.rightArm.z = 0.0F;
            this.leftArm.x = 5.0F;
            this.leftArm.z = 0.0F;
            this.rightArm.xRot = Mth.cos(ageInTicks * 0.6662F) * 0.25F;
            this.leftArm.xRot = Mth.cos(ageInTicks * 0.6662F) * 0.25F;
            this.rightArm.zRot = (float) (Math.PI * 3.0 / 4.0);
            this.leftArm.zRot = (float) (-Math.PI * 3.0 / 4.0);
            this.rightArm.yRot = 0.0F;
            this.leftArm.yRot = 0.0F;
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // 头：bbmodel head（世界 y 24..32），枢轴在颈线（Java y=0）。
        root.addOrReplaceChild("head", faces(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F,
                        8, 8, 24, 8, 0, 8, 16, 8, 8, 0, 16, 0),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // headwear：第二层头（同几何外扩 0.5px，贴图 (32..64, 0..16)）。
        root.addOrReplaceChild("hat", facesDeformed(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, 0.5F,
                        40, 8, 56, 8, 32, 8, 48, 8, 40, 0, 48, 0),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // 躯干：bbmodel body（世界 y 12..24）＋两片无旋转的裙甲（世界 y 8..13）。
        CubeListBuilder bodyCubes = faces(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F,
                20, 20, 32, 20, 16, 20, 28, 20, 20, 16, 28, 16);
        // 裙甲 A：世界 x -4..0（bbmodel 8f85e458）。
        addFaces(bodyCubes, -4.0F, 11.0F, -2.0F, 4.0F, 5.0F, 4.0F,
                4, 36, 12, 36, 8, 36, 0, 36, 4, 32, 8, 32);
        // 裙甲 B：世界 x 0..4（bbmodel 1caa27db）。
        addFaces(bodyCubes, 0.0F, 11.0F, -2.0F, 4.0F, 5.0F, 4.0F,
                4, 36, 12, 36, 0, 36, 8, 36, 4, 32, 8, 32);
        PartDefinition body = root.addOrReplaceChild("body", bodyCubes, PartPose.offset(0.0F, 0.0F, 0.0F));
        // 裙甲 C：bbmodel 6d50ba88（世界 x -1..3、绕轴心 [1,10.5,0] 转 180°）。
        body.addOrReplaceChild("skirt_rot_a", faces(-2.0F, -2.5F, -2.0F, 4.0F, 5.0F, 4.0F,
                        4, 36, 12, 36, 0, 36, 8, 36, 4, 32, 8, 32),
                PartPose.offsetAndRotation(1.0F, 13.5F, 0.0F, 0.0F, (float) Math.PI, 0.0F));
        // 裙甲 D：bbmodel 27f4a430（世界 x -3..1、绕轴心 [-1,10.5,0] 转 180°）。
        body.addOrReplaceChild("skirt_rot_b", faces(-2.0F, -2.5F, -2.0F, 4.0F, 5.0F, 4.0F,
                        4, 36, 12, 36, 8, 36, 0, 36, 4, 32, 8, 32),
                PartPose.offsetAndRotation(-1.0F, 13.5F, 0.0F, 0.0F, (float) Math.PI, 0.0F));

        // 模型右臂（世界 -x 侧）：bbmodel left_arm。
        root.addOrReplaceChild("right_arm", faces(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        42, 20, 46, 20, 44, 20, 40, 20, 42, 18, 44, 18),
                PartPose.offset(-5.0F, 2.0F, 0.0F));

        // 模型左臂（世界 +x 侧）：bbmodel right_arm。
        root.addOrReplaceChild("left_arm", faces(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F,
                        42, 20, 46, 20, 40, 20, 44, 20, 42, 18, 44, 18),
                PartPose.offset(5.0F, 2.0F, 0.0F));

        // 模型右腿（世界 -x 侧）：bbmodel left_leg ＋脚踝靴套（贴图 v60..64）。
        CubeListBuilder rightLegCubes = faces(-1.1F, 1.0F, -1.0F, 2.0F, 11.0F, 2.0F,
                2, 18, 6, 18, 4, 18, 0, 18, 2, 16, 4, 16);
        addFaces(rightLegCubes, -1.1F, 10.0F, -1.0F, 2.0F, 2.0F, 2.0F,
                2, 62, 6, 62, 4, 62, 0, 62, 2, 60, 4, 60);
        root.addOrReplaceChild("right_leg", rightLegCubes, PartPose.offset(-1.9F, 12.0F, 0.0F));

        // 模型左腿（世界 +x 侧）：bbmodel right_leg ＋脚踝靴套。
        CubeListBuilder leftLegCubes = faces(-0.9F, 1.0F, -1.0F, 2.0F, 11.0F, 2.0F,
                2, 18, 6, 18, 0, 18, 4, 18, 2, 16, 4, 16);
        addFaces(leftLegCubes, -0.9F, 10.0F, -1.0F, 2.0F, 2.0F, 2.0F,
                2, 62, 6, 62, 0, 62, 4, 62, 2, 60, 4, 60);
        root.addOrReplaceChild("left_leg", leftLegCubes, PartPose.offset(1.9F, 12.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    /** 内甲层：与本体同枢轴、同尺寸，略膨胀以贴合拾来的护腿。 */
    public static LayerDefinition createInnerArmorLayer() {
        return createArmorLayer(new CubeDeformation(0.4F));
    }

    /** 外甲层：头盔/胸甲/靴子，膨胀略大于内甲。 */
    public static LayerDefinition createOuterArmorLayer() {
        return createArmorLayer(new CubeDeformation(0.8F));
    }

    /**
     * 穿戴护甲走原版 64×32 人形甲 UV（不是本模型贴图），所以用标准 texOffs 即可；
     * 部件枢轴必须与本体一致（头/躯干 0、臂 ±5/2、腿 ±1.9/12），否则盔甲会漂在半空。
     */
    private static LayerDefinition createArmorLayer(CubeDeformation deform) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, deform),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, deform),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                        .texOffs(40, 16).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F, deform),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create()
                        .texOffs(40, 16).mirror().addBox(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F, deform),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.1F, 1.0F, -1.0F, 2.0F, 11.0F, 2.0F, deform),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                        .texOffs(0, 16).mirror().addBox(-0.9F, 1.0F, -1.0F, 2.0F, 11.0F, 2.0F, deform),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    private static CubeListBuilder faces(float x, float y, float z, float w, float h, float d,
                                         int nU, int nV, int sU, int sV,
                                         int eU, int eV, int wU, int wV,
                                         int uU, int uV, int dU, int dV) {
        CubeListBuilder builder = CubeListBuilder.create();
        addFaces(builder, x, y, z, w, h, d, nU, nV, sU, sV, eU, eV, wU, wV, uU, uV, dU, dV);
        return builder;
    }

    /**
     * 带形变的六面（每面单独一个只露该面的立方体，沿各自法线外推 {@code deform}）。
     * 等价于原版 {@code CubeDeformation(deform)} 的几何，只是 UV 仍逐面指定。
     */
    private static CubeListBuilder facesDeformed(float x, float y, float z, float w, float h, float d,
                                                 float deform,
                                                 int nU, int nV, int sU, int sV,
                                                 int eU, int eV, int wU, int wV,
                                                 int uU, int uV, int dU, int dV) {
        CubeListBuilder builder = CubeListBuilder.create();
        int di = (int) d;
        int wi = (int) w;
        face(builder, Direction.NORTH, nU - di, nV - di, x, y, z - deform, w, h, d);
        face(builder, Direction.SOUTH, sU - 2 * di - wi, sV - di, x, y, z + deform, w, h, d);
        face(builder, Direction.WEST, wU, wV - di, x - deform, y, z, w, h, d);
        face(builder, Direction.EAST, eU - di - wi, eV - di, x + deform, y, z, w, h, d);
        face(builder, Direction.DOWN, uU - di, uV, x, y - deform, z, w, h, d);
        face(builder, Direction.UP, dU - di - wi, dV, x, y + deform, z, w, h, d);
        return builder;
    }

    private static void addFaces(CubeListBuilder builder, float x, float y, float z,
                                 float w, float h, float d,
                                 int nU, int nV, int sU, int sV,
                                 int eU, int eV, int wU, int wV,
                                 int uU, int uV, int dU, int dV) {
        int di = (int) d;
        int wi = (int) w;
        face(builder, Direction.NORTH, nU - di, nV - di, x, y, z, w, h, d);
        face(builder, Direction.SOUTH, sU - 2 * di - wi, sV - di, x, y, z, w, h, d);
        face(builder, Direction.WEST, wU, wV - di, x, y, z, w, h, d);
        face(builder, Direction.EAST, eU - di - wi, eV - di, x, y, z, w, h, d);
        face(builder, Direction.DOWN, uU - di, uV, x, y, z, w, h, d);
        face(builder, Direction.UP, dU - di - wi, dV, x, y, z, w, h, d);
    }

    /**
     * 把一个立方体的六个面分别摆到贴图上的指定矩形（与 {@link WitherZombieModel} 同款解法）。
     *
     * <p>注意原版 Cube 的面标签与视觉方向相反：模型空间 Y 轴向下，挂 {@code Direction.DOWN}
     * 标签的面（矩形 (U+d,V)）才是视觉顶面，{@code Direction.UP}（矩形 (U+d+w,V)）是视觉
     * 底面——原版 Steve 的头盖骨矩形 (8,0) 就挂在 DOWN 标签下。因此 bbmodel 的顶面要喂给
     * DOWN、底面喂给 UP。</p>
     *
     * @param x,y,z 立方体最小角（部件局部坐标）
     * @param w,h,d 立方体尺寸
     * @param nU,nV 北面矩形左上角；sU,sV 南面；eU,eV 东面；wU,wV 西面；
     *              uU,uV 顶面；dU,dV 底面（矩形宽高由立方体尺寸决定）
     */
    private static void face(CubeListBuilder builder, Direction dir, int texU, int texV,
                             float x, float y, float z, float w, float h, float d) {
        builder.texOffs(texU, texV).addBox(x, y, z, w, h, d, EnumSet.of(dir));
    }
}
