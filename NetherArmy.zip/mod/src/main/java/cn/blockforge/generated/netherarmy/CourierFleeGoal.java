package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * 传令兵的受击后撤：把 {@link NetherCourier#hurt} 里置好的后撤落点走完整。
 *
 * <p>优先级 1（父类最高的是游走 2、近战 4）：后撤期间 MOVE/JUMP 标志被本目标
 * 占住，近战目标（{@code MeleeAttackGoal}）因标志冲突、优先级又更高（数值更大）
 * 而启动不了——所以"后撤期间不反击"由标志占用保证，<b>不需要</b>牺牲仇恨。
 * 仇恨（{@code getTarget()}）与 {@code lastHurtByMob} 全程原样保留：退完最后
 * 一格、本目标释放标志的下一 tick，近战目标就拿着现成的仇恨立刻反打，
 * 不再等 {@code HurtByTargetGoal} 或索敌轮询重新锁定攻击者。</p>
 */
public final class CourierFleeGoal extends Goal {
    /** 到达落点的判定距离（格）。 */
    private static final double ARRIVE_DISTANCE = 0.6D;
    /** 后撤时的寻路速度倍率（相对移速属性，冲刺感）。 */
    private static final double FLEE_SPEED = 1.6D;

    private final NetherCourier courier;
    private int repathCooldown;

    public CourierFleeGoal(NetherCourier courier) {
        this.courier = courier;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        return this.courier.isFleeing();
    }

    @Override
    public boolean canContinueToUse() {
        if (!this.courier.isFleeing()) {
            return false;
        }
        Vec3 target = this.courier.getFleeTargetPos();
        if (target == null
                || this.courier.position().distanceTo(target) < ARRIVE_DISTANCE
                || this.courier.level().getGameTime() > this.courier.getFleeDeadline()) {
            this.courier.stopFleeing();
            return false;
        }
        return true;
    }

    @Override
    public void start() {
        this.repathCooldown = 0;
    }

    @Override
    public void tick() {
        if (this.repathCooldown-- > 0 && this.courier.getNavigation().isInProgress()) {
            return;
        }
        this.repathCooldown = 5;
        Vec3 target = this.courier.getFleeTargetPos();
        if (target != null) {
            this.courier.getNavigation().moveTo(target.x, target.y, target.z, FLEE_SPEED);
        }
    }
}
