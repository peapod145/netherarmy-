package cn.blockforge.generated.netherarmy;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

/**
 * 灵魂陨石方块对应的物品，即陨石的掉落物形态，免疫火焰与爆炸：
 * <ul>
 *   <li>火/岩浆：注册处带 {@code fireResistant} 组件，{@code ItemEntity#fireImmune()}
 *       读 {@code DataComponents.FIRE_RESISTANT} 后直接跳过着火与岩浆伤害；</li>
 *   <li>爆炸：{@code ItemEntity#hurt} 扣血前先问 {@code ItemStack#canBeHurtBy}，
 *       这里把 {@code IS_EXPLOSION} 挡掉（与炼狱晶锭 / 地煞战斧同款写法）。</li>
 * </ul>
 *
 * <p>这对组合是"挖错工具当场起爆"能成立的必要条件：{@link SoulMeteoriteBlock#playerDestroy}
 * 先走父类把掉落物扔出来，再在同一个坐标起爆——掉落物就躺在爆心，没有这两条免疫会被
 * 自己那次爆炸连掉落一起清掉。另外陨石爆炸落在灵魂火里，掉落物也不会被烧没。</p>
 */
public final class SoulMeteoriteItem extends BlockItem {
    public SoulMeteoriteItem(Block block, Item.Properties properties) {
        super(block, properties);
    }

    /** 掉落物不吃爆炸伤害（火烧由注册处的 fireResistant 组件负责）。 */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }
}
