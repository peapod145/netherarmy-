package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.CrystalShardFuelAccess;
import cn.blockforge.generated.netherarmy.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 炼狱晶碎片当燃料时，烧炼速度是正常速度的 3 倍（熔炉/高炉/烟熏炉一视同仁）。
 *
 * <p>火焰时长仍由 {@link cn.blockforge.generated.netherarmy.CrystalShardFuelHandler}
 * 给的 600 tick 决定，这里只改"每 tick 推进多少进度"：原版 {@code serverTick} 每 tick
 * 让 {@code cookingProgress} +1，本注入在方法开头先补 +2，并夹在
 * {@code cookingTotalTime - 1} 以内，随后原版那次 {@code ++} 正好命中
 * {@code cookingProgress == cookingTotalTime} 的完成判定，所以既不会漏产物，
 * 也不会因为跳过头而卡在进度条上。</p>
 *
 * <p>燃料身份只在点火那一刻可靠：原版在点燃前用待烧燃料调一次
 * {@code getBurnDuration(ItemStack)}，这里在它的 RETURN 处记下"是不是碎片"；
 * 燃料槽里剩几枚并不影响判定（点火会先 shrink 掉一枚）。标记同时写进方块实体
 * NBT，区块重载后仍能保持加速，而不是等下一枚碎片点火才恢复。</p>
 */
@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class CrystalShardSmeltingSpeedMixin implements CrystalShardFuelAccess {

    /** 每 tick 额外补的进度：2 + 原版 1 = 3 倍。 */
    private static final int NETHERARMY_EXTRA_PROGRESS = 2;

    /** 方块实体 NBT 里记录燃料标记的键。 */
    private static final String NETHERARMY_FUEL_KEY = "NetherArmyCrystalShardFuel";

    @Shadow
    int litTime;

    @Shadow
    int cookingProgress;

    @Shadow
    int cookingTotalTime;

    @Unique
    private boolean netherarmy$crystalShardFuel;

    @Override
    public boolean netherarmy$isCrystalShardFuel() {
        return this.netherarmy$crystalShardFuel;
    }

    @Override
    public int netherarmy$cookingProgress() {
        return this.cookingProgress;
    }

    @Override
    public void netherarmy$setCookingProgress(int progress) {
        this.cookingProgress = progress;
    }

    @Override
    public int netherarmy$cookingTotalTime() {
        return this.cookingTotalTime;
    }

    @Override
    public int netherarmy$litTime() {
        return this.litTime;
    }

    /** 点火前的燃料查询：记住这一炉烧的是不是炼狱晶碎片。 */
    @Inject(method = "getBurnDuration", at = @At("RETURN"))
    private void netherarmy$rememberFuel(ItemStack fuel, CallbackInfoReturnable<Integer> callback) {
        this.netherarmy$crystalShardFuel = fuel.is(GeneratedMod.NETHER_CRYSTAL_SHARD.get());
    }

    /** 每 tick 先补 2 点进度，配合原版的 +1 得到 3 倍烧炼速度。 */
    @Inject(method = "serverTick", at = @At("HEAD"))
    private static void netherarmy$smeltCrystalFuelFaster(Level level, BlockPos pos, BlockState state,
                                                          AbstractFurnaceBlockEntity furnace,
                                                          CallbackInfo callback) {
        CrystalShardFuelAccess access = (CrystalShardFuelAccess) (Object) furnace;
        if (!access.netherarmy$isCrystalShardFuel() || access.netherarmy$litTime() <= 0) {
            return;
        }
        int total = access.netherarmy$cookingTotalTime();
        int progress = access.netherarmy$cookingProgress();
        // 夹在 total-1 以内：随后原版的 ++ 正好命中 == total 的完成判定，不跳产物。
        int next = Math.min(progress + NETHERARMY_EXTRA_PROGRESS, total - 1);
        if (next > progress) {
            access.netherarmy$setCookingProgress(next);
        }
    }

    /** 把燃料标记随方块实体存档，避免区块卸载后加速丢失。 */
    @Inject(method = "saveAdditional", at = @At("TAIL"))
    private void netherarmy$saveFuelFlag(CompoundTag tag, HolderLookup.Provider registries, CallbackInfo callback) {
        if (this.netherarmy$crystalShardFuel) {
            tag.putBoolean(NETHERARMY_FUEL_KEY, true);
        }
    }

    /**
     * 读档时恢复燃料标记。原版 loadAdditional 也会用燃料槽内容调一次
     * {@code getBurnDuration}（可能把标记刷成错误值），所以这里在尾部以存档值为准。
     */
    @Inject(method = "loadAdditional", at = @At("TAIL"))
    private void netherarmy$loadFuelFlag(CompoundTag tag, HolderLookup.Provider registries, CallbackInfo callback) {
        this.netherarmy$crystalShardFuel = tag.getBoolean(NETHERARMY_FUEL_KEY);
    }
}
