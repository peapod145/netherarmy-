package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MachineryLegendCompat;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 器械传说箭类的额外保险：即使对方版本没有走自家
 * {@code RebellionLogic.canMachineProjectileHit}，也按本模组阵营规则碰撞。
 */
@Pseudo
@Mixin(targets = {
        "cn.blockforge.generated.machinerylegend.entity.MachineryArrow",
        "cn.blockforge.generated.machinerylegend.entity.ThrowingKnifeEntity"
})
public abstract class MachineryLegendRebellionProjectileMixin {
    @Inject(method = "canHitEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void netherarmy$allowMachineProjectileHit(
            Entity target, CallbackInfoReturnable<Boolean> callback) {
        Entity owner = ((AbstractArrow) (Object) this).getOwner();
        Boolean override = MachineryLegendCompat.machineProjectileOverride(owner, target);
        if (override != null) {
            callback.setReturnValue(override);
        }
    }
}
