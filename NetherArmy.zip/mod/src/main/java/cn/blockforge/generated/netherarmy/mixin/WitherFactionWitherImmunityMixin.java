package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MesmerizerControl;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 凋灵骷髅阵营的"免疫凋零效果"底层统一判定。
 *
 * <p>原版凋灵骷髅与凋灵本来就免疫凋零（各自的 {@code canBeAffected} 覆盖），但那是写在
 * 具体类里的：本模组的阵营生物只有继承 {@code WitherSkeleton} 的那一批（狂战士、床战士、
 * 下界猎手、无头骑士躯体、强袭躯体、运输兵、挑头者、御首者、不朽战士、怨灵）白捡到了这份
 * 免疫，而 {@code Hacker}（{@code PathfinderMob} 系）、{@code WitherZombie}（{@code Zombie}
 * 系）、{@code Witherphantom}（{@code Phantom} 系）、{@code ShadowApostle}（{@code Blaze}
 * 系）、{@code DullhanHorse}（{@code SkeletonHorse} 系）、{@code DullhanHead}（{@code Slime}
 * 系）都不在这条继承链上，只能各自再抄一遍 {@code canBeAffected}——既重复，又漏怪。</p>
 *
 * <p>这里把判定下沉到 {@code LivingEntity}：任何被
 * {@link MesmerizerControl#isWitherSkeletonFaction} 认作阵营成员的实体，凋零效果一律挂不上，
 * 效果来源不限（凋灵之首、凋灵玫瑰、军团旗帜、枯肉、盾牌附魔、强袭凋零、外部 mod）。
 * 后续新增凋灵骷髅阵营的怪，只要登记进
 * {@code data/minecraft/tags/entity_type/wither_skeletons.json}，这份免疫与
 * {@code #minecraft:undead} 等亡灵判定（那里的阵营标签嵌套见对应标签文件）都自动生效，
 * 不必再写一行代码。</p>
 *
 * <p>注入点选在 {@code canBeAffected} 而不是 {@code addEffect}：后者是
 * {@code final}（{@code addEffect(MobEffectInstance)}）且 {@code forceAddEffect} 会绕过它，
 * 前者才是原版所有效果施加路径共同收敛的闸门。子类的 {@code canBeAffected} 覆盖（强袭
 * 无头骑士三件套那条"免疫一切 HARMFUL 效果"）仍然优先执行，它们内部调用
 * {@code super.canBeAffected} 时照样经过本注入，两套规则叠加不冲突。</p>
 */
@Mixin(LivingEntity.class)
public abstract class WitherFactionWitherImmunityMixin {

    @Inject(method = "canBeAffected", at = @At("HEAD"), cancellable = true)
    private void netherarmy$factionIgnoresWitherEffect(MobEffectInstance effect,
                                                       CallbackInfoReturnable<Boolean> callback) {
        if (effect.is(MobEffects.WITHER)
                && MesmerizerControl.isWitherSkeletonFaction((LivingEntity) (Object) this)) {
            callback.setReturnValue(false);
        }
    }
}
