package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.NetherCrystalArmorItem;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 炼狱晶护腿：进食速度 +25%。
 *
 * <p>吃东西由 {@code LivingEntity#updateUsingItem} 每 tick 给
 * {@code useItemRemaining} 减 1，归零时服务端结算完成食用。在该方法末尾再补一次
 * 递减（仅服务端、仅带 FOOD 组件的物品、仅穿着炼狱晶护腿时），
 * 32 tick 的食物变成 25.6 tick 吃完，即 +25%。客户端动画不受影响，
 * 完成时刻始终以服务端同步为准。</p>
 *
 * <p>判定不限玩家：穿戴者换成任何活体实体（怪物、会自己进食的动物）都走同一条结算，
 * 保证"怪物穿这套也吃得到单件基础效果"。</p>
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityEatSpeedMixin {
    @Shadow
    protected int useItemRemaining;

    @Inject(method = "updateUsingItem", at = @At("TAIL"))
    private void netherarmy$crystalLeggingsFastEat(ItemStack stack, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide()) {
            return;
        }
        if (!(self.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof NetherCrystalArmorItem)) {
            return;
        }
        if (!stack.isEmpty() && stack.has(DataComponents.FOOD)) {
            this.useItemRemaining--;
        }
    }
}
