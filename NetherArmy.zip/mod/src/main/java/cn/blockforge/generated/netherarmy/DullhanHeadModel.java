package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/** 无头骑士头颅模型：固定的 8x8x8 像素骷髅头颅立方体。 */
public final class DullhanHeadModel extends EntityModel<DullhanHead> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "dullhan_head"), "main");

    private final ModelPart root;

    public DullhanHeadModel(ModelPart root) {
        this.root = root;
    }

    @Override
    public void setupAnim(DullhanHead entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // 头颅不使用史莱姆的挤压或尺寸动画，保持模型与固定碰撞箱一致。
    }

    @Override
    public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack poseStack,
                               com.mojang.blaze3d.vertex.VertexConsumer vertexConsumer,
                               int packedLight, int packedOverlay, int packedColor) {
        this.root.render(poseStack, vertexConsumer, packedLight, packedOverlay, packedColor);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // 模型脚点在实体原点；渲染器的 1.2 倍缩放后尺寸为 9.6 像素，即 0.6 格。
        root.addOrReplaceChild("skull", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, 16.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                net.minecraft.client.model.geom.PartPose.ZERO);
        return LayerDefinition.create(mesh, 24, 16);
    }
}
