package cn.blockforge.generated.netherarmy;

import java.util.List;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.armortrim.ArmorTrim;
import net.minecraft.world.item.armortrim.TrimMaterial;
import net.minecraft.world.item.armortrim.TrimPattern;
import net.minecraft.core.component.DataComponents;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * 凋灵骷髅阵营的"锻造模板盔甲"：阵营生物刷新时若自带防具，整件防具会被随机一种
 * 锻造模板（盔甲纹饰图案）+ 随机一种熔炼材料染上盔甲纹理。
 *
 * <p>阵营名册沿用模组既有的两个标签的并集：{@code #minecraft:wither_skeletons}
 * （原版凋灵骷髅 + 狂战士、下界猎手、无头骑士躯体与马、反逆者、衰翼、尸鬼、传令兵、
 * 运载者、御首者）与 {@code #minecraft:wither_friends}（额外的无头骑士头颅）。
 * 两个标签都收录的生物只处理一次。</p>
 *
 * <p>接线点选 {@link EntityJoinLevelEvent} 而不是 {@code FinalizeSpawnEvent}：
 * 原版的 {@code EventHooks#finalizeMobSpawn} 是在 {@code Mob#finalizeSpawn} 的<b>最后一行</b>
 * 触发的，而本模组的阵营生物几乎都在自己 {@code finalizeSpawn} 覆写的 {@code super} 调用
 * <b>之后</b>才摆放防具（{@link NetherHunter} 的皮革、{@link DullhanBody} 的金/铁、
 * {@link Berserker} 的金色三件、{@link GeneratedMod} 给原版凋灵骷髅补的金/铁套），
 * 在生成事件里读装备会读到一个空槽。实体真正加入世界的时刻则一定能读到完整的初始装备，
 * 且此时还没向客户端广播（分块监视在之后的 tick 才建立），改完的组件会随装备同步自然下发。</p>
 *
 * <p>一次性印记：{@link #APPLIED_TAG} 写在实体的持久化数据里（NeoForge 会随实体存档）。
 * 有了它，跨维度传送、被重新 {@code addFreshEntity} 等"二次进世界"不会把已经定型的纹理
 * 再重掷一次；分块加载时 {@link EntityJoinLevelEvent#loadedFromDisk()} 为真，直接跳过，
 * 读档的防具保持原样的纹理。</p>
 *
 * <p>只改自带防具、不改玩家后来塞进去的防具，正是"刷新时携带"的口径：印记在第一次进世界
 * 时就落定，之后捡起来穿上的装备不再被动过。</p>
 *
 * <p>参与判定的只有 {@link ArmorItem} 且槽位匹配的原版盔甲。模组自绘的两件
 * （{@code netherarmy:berserker_helmet}、{@code netherarmy:mesmerizer_crown}）会被跳过：
 * 它们的护甲模型由 {@code IClientItemExtensions} / 专用图层接管，渲染路径里不画纹饰层，
 * 强行挂纹饰只会得到工具提示里一行看不见的说明。马铠/狼铠属于 BODY 槽，同样不在处理范围。</p>
 *
 * <p>纹饰的图案与材料各随机一次、整只生物共用：同一只生物身上四件盔甲是同一套纹饰，
 * 视觉上是一套"军团制式"而不是四件拼凑；不同个体之间才会体现出随机差异。随机源用
 * {@code mob.getRandom()}</p>（与生物自带的装备随机同一条随机流，行为随世界种子可复现）。
 */
public final class WitherFactionArmorTrimHandler {
    /** 已处理印记：防止同一只生物被重复重掷纹饰（重新进世界、跨维度等）。 */
    private static final String APPLIED_TAG = "generated_mod_wither_faction_armor_trim";

    private static final TagKey<EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));
    private static final TagKey<EntityType<?>> WITHER_FRIENDS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_friends"));

    /** 参与纹饰的槽位：只有人形四件套会被 {@code HumanoidArmorLayer} 画出纹饰层。 */
    private static final EquipmentSlot[] TRIMMABLE_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private WitherFactionArmorTrimHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        // 读档而来的实体已经带着存档里的纹饰，重新加载不能改变它的外观。
        if (event.loadedFromDisk() || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getEntity() instanceof Mob mob) || !isWitherFaction(mob)) {
            return;
        }
        applyRandomTrim(level, mob);
    }

    /** 阵营判定：两个标签取并集（{@code wither_friends} 里多出的无头骑士头颅同样算阵营成员）。 */
    private static boolean isWitherFaction(Mob mob) {
        EntityType<?> type = mob.getType();
        return type.is(WITHER_SKELETONS) || type.is(WITHER_FRIENDS);
    }

    private static void applyRandomTrim(ServerLevel level, Mob mob) {
        CompoundTag data = mob.getPersistentData();
        if (data.getBoolean(APPLIED_TAG)) {
            return;
        }
        // 印记无条件落定：本次没穿防具，之后也不该再被重掷（"刷新时携带"只看这一刻）。
        data.putBoolean(APPLIED_TAG, true);

        List<ItemStack> armors = collectTrimableArmor(mob);
        if (armors.isEmpty()) {
            return;
        }

        RandomSource random = mob.getRandom();
        Holder<TrimPattern> pattern = randomPattern(level, random);
        Holder<TrimMaterial> material = randomMaterial(level, random);
        if (pattern == null || material == null) {
            // 注册表被数据包清空之类的极端情况：不动装备，保持原样。
            return;
        }
        ArmorTrim trim = new ArmorTrim(material, pattern);
        for (ItemStack stack : armors) {
            stack.set(DataComponents.TRIM, trim);
        }
    }

    /**
     * 收集本次刷新携带、且能被原版纹饰渲染接管的防具。
     *
     * <p>要求 {@code item.getClass() == ArmorItem.class}：原版的头盔/胸甲/护腿/靴子
     * 全部是直接 {@code new ArmorItem(...)} 的实例，走 {@code HumanoidArmorLayer} 的标准
     * 护甲模型，纹饰层会照常绘制；模组自定义的狂战士头盔与反逆者王冠是 {@code ArmorItem}
     * 的子类，护甲模型被 {@code IClientItemExtensions} 接管（王冠甚至是独立图层、并且渲染器
     * 把 {@code HumanoidArmorLayer} 整个移除了），画不出纹饰，故不参与。</p>
     *
     * <p>另外要求物品登记的槽位与当前槽位一致：原版生物偶尔会把非盔甲物品放进盔甲槽，
     * 而且只有槽位匹配的部件才会被对应那一层的护甲模型绘制。</p>
     */
    private static List<ItemStack> collectTrimableArmor(Mob mob) {
        List<ItemStack> armors = new java.util.ArrayList<>(TRIMMABLE_SLOTS.length);
        for (EquipmentSlot slot : TRIMMABLE_SLOTS) {
            ItemStack stack = mob.getItemBySlot(slot);
            if (stack.isEmpty() || stack.has(DataComponents.TRIM)) {
                // 已经带纹饰的（例如 /summon 显式给了成品盔甲）尊重原样，不覆盖。
                continue;
            }
            if (!(stack.getItem() instanceof ArmorItem armorItem)
                    || armorItem.getClass() != ArmorItem.class
                    || armorItem.getEquipmentSlot() != slot) {
                continue;
            }
            armors.add(stack);
        }
        return armors;
    }

    private static Holder<TrimPattern> randomPattern(ServerLevel level, RandomSource random) {
        List<Holder.Reference<TrimPattern>> pool = level.registryAccess()
                .lookupOrThrow(Registries.TRIM_PATTERN).listElements().toList();
        return pool.isEmpty() ? null : pool.get(random.nextInt(pool.size()));
    }

    private static Holder<TrimMaterial> randomMaterial(ServerLevel level, RandomSource random) {
        List<Holder.Reference<TrimMaterial>> pool = level.registryAccess()
                .lookupOrThrow(Registries.TRIM_MATERIAL).listElements().toList();
        return pool.isEmpty() ? null : pool.get(random.nextInt(pool.size()));
    }
}
