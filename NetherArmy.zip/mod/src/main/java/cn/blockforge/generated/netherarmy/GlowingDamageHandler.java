package cn.blockforge.generated.netherarmy;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** 发光状态的实体受到的伤害提高 50%。 */
public final class GlowingDamageHandler {
    private GlowingDamageHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled()
                || event.getEntity().level().isClientSide()
                || !event.getEntity().isCurrentlyGlowing()
                || event.getAmount() <= 0.0F) {
            return;
        }
        float amount = event.getAmount();
        // /kill 打的是 generic_kill，伤害量就是 Float.MAX_VALUE，乘 1.5 会溢出成 Infinity。
        // NeoForge 的伤害管线随后会把 Infinity 变成 NaN：generic_kill 在 bypasses_armor 里，
        // 护甲减伤原值返回，DamageContainer 记的减伤是 Infinity - Infinity = NaN，
        // newDamage 于是变 NaN，setHealth(血量 - NaN) 又被 Mth.clamp 原样放过（NaN 的比较
        // 全为假），实体血量停成 NaN —— 而 isDeadOrDying 只判断 <= 0，NaN 永远不满足，
        // 于是发光状态下 /kill 再也打不死。这里把结果封顶在 Float.MAX_VALUE：
        // 对任何致死伤害来说仍然是必死，但不会再溢出。
        float boosted = amount * 1.5F;
        event.setAmount(boosted < Float.MAX_VALUE ? boosted : Float.MAX_VALUE);
    }
}
