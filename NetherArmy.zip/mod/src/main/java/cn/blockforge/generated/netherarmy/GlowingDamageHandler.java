package cn.blockforge.generated.netherarmy;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** 发光状态的实体受到的伤害提高 50%。 */
public final class GlowingDamageHandler {
    private GlowingDamageHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.isCanceled()
                || event.getEntity().level().isClientSide()
                || !event.getEntity().isCurrentlyGlowing()
                || event.getAmount() <= 0.0F) {
            return;
        }
        // 乘 1.5 一律走 DamageGuard.scale：/kill 的 generic_kill 给的是 Float.MAX_VALUE，
        // 直接乘会溢出成 Infinity，NeoForge 的伤害管线再把它变成 NaN 写进血量
        // （Infinity - Infinity），而 isDeadOrDying 只判断 <= 0，于是这只怪再也打不死。
        // scale 用 double 中转并封顶在 Float.MAX_VALUE：对任何致死伤害仍然是必死，但不会溢出。
        event.setAmount(DamageGuard.scale(event.getAmount(), 1.5F));
    }
}
