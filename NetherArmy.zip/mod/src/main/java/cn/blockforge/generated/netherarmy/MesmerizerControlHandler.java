package cn.blockforge.generated.netherarmy;

import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundSetCarriedItemPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** 反逆者控制后的阵营、仇恨和玩家攻击限制。 */
public final class MesmerizerControlHandler {
    private MesmerizerControlHandler() {
    }

    private static final String REBELLION_LAVA_CACHE = "generated_mod_rebellion_lava";
    private static final String REBELLION_TARGET_CACHE = "generated_mod_rebellion_target";
    private static final String REBELLION_LOCKED_SLOT = "generated_mod_rebellion_locked_slot";
    private static final double REBELLION_AI_TARGET_RANGE = 32.0D;
    private static final int REBELLION_AI_SEARCH_INTERVAL = 5;
    private static final int REBELLION_AI_LAVA_HORIZONTAL_RANGE = 12;
    private static final int REBELLION_AI_LAVA_VERTICAL_RANGE = 8;
    private static final double REBELLION_AI_MOVE_SPEED = 0.1D;
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide()) {
            return;
        }
        awardCrownMastery(player);
        if (MesmerizerControl.isCrownProtected(player)) {
            player.removeEffect(GeneratedMod.REBELLION);
            clearRebellionControlState(player);
            return;
        }
        if (!player.hasEffect(GeneratedMod.REBELLION)) {
            clearRebellionControlState(player);
            return;
        }

        lockHotbarSlot(player);
        controlRebelliousPlayer(player);
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity target) || target.level().isClientSide()) {
            return;
        }
        if (target instanceof ServerPlayer player) {
            awardCrownMastery(player);
            if (MesmerizerControl.isCrownProtected(player)) {
                player.removeEffect(GeneratedMod.REBELLION);
            }
            if (player.hasEffect(GeneratedMod.REBELLION)) {
                spawnMesmerizedParticles((ServerLevel) player.level(), player);
            } else {
                clearRebellionControlState(player);
            }
            return;
        }
        if (target instanceof Player) {
            return;
        }
        if (MesmerizerControl.isCrownProtected(target)) {
            if (MesmerizerControl.isControlled(target)) {
                MesmerizerControl.releaseControl(target);
            }
            target.removeEffect(GeneratedMod.MESMERIZED);
            return;
        }
        MesmerizerControl.removeStaleControl(target);
        LivingEntity controller = MesmerizerControl.getController(target);
        if (target instanceof Mob mob && isBlueprintMachinery(mob)) {
            // 《机械传说》的蓝图器械走专用通道：见 keepMachineryHunting 的说明。
            if (controller != null) {
                target.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                        GeneratedMod.MESMERIZED, 10, 0, false, false, false));
                spawnMesmerizedParticles((ServerLevel) target.level(), target);
            } else {
                target.removeEffect(GeneratedMod.MESMERIZED);
            }
            keepMachineryHunting(mob, controller);
            return;
        }
        if (controller == null) {
            target.removeEffect(GeneratedMod.MESMERIZED);
            return;
        }
        target.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                GeneratedMod.MESMERIZED, 10, 0, false, false, false));
        spawnMesmerizedParticles((ServerLevel) target.level(), target);
        if (target instanceof Mob mob) {
            LivingEntity controllerTarget = controller instanceof Mob controllerMob ? controllerMob.getTarget() : null;
            if (controllerTarget != null && MesmerizerControl.canAttack(target, controllerTarget)) {
                setControlledMobTarget(mob, controllerTarget);
            } else {
                setControlledMobTarget(mob, null);
            }
            clearControlledMobHostility(mob, controller);
        }
    }

    /**
     * 将受控生物的目标同步到反逆者。
     *
     * <p>三类实现要分别对待：监守者与猪灵/猪灵蛮兵（1.21.1 起为 Brain AI）读取的都是
     * Brain 的 {@code ATTACK_TARGET} 记忆，{@code Mob} 的 target 字段对它们不可见；
     * 其中监守者必须走 {@code setAttackTarget}（它同时清咆哮目标并重置声波冷却），
     * 猪灵系则按原版 {@code PiglinAi.setAngerTarget} 的写法补上 {@code ANGRY_AT} 记忆——
     * 猪灵的 {@code StopAttackingIfTargetInvalid} 谓词要求当前攻击目标必须能被
     * {@code findNearestValidAttackTarget} 复现（愤怒记忆优先），只写 ATTACK_TARGET
     * 会在下一 Brain tick 被原版的校验行为抹掉；而猪灵"不打同类"的根因正是原版受击
     * 记恨入口 {@code PiglinAi/PiglinBruteAi.wasHurtBy} 会跳过猪灵类攻击者，愤怒记忆
     * 永远轮不到同类——由反逆者直接写入即可绕开这条物种豁免。其余goal-based生物写
     * 字段即可。</p>
     */
    private static void setControlledMobTarget(Mob mob, LivingEntity target) {
        if (mob instanceof Warden warden) {
            warden.setAttackTarget(target);
            drainWardenAnger(warden);
        } else if (mob instanceof AbstractPiglin) {
            Brain<?> brain = mob.getBrain();
            HackerCountermeasureHandler.eraseRegisteredMemory(mob, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);
            if (target != null) {
                brain.setMemoryWithExpiry(MemoryModuleType.ANGRY_AT, target.getUUID(), 600L);
                brain.setMemory(MemoryModuleType.ATTACK_TARGET, target);
            } else {
                HackerCountermeasureHandler.eraseRegisteredMemory(mob, MemoryModuleType.ANGRY_AT);
                HackerCountermeasureHandler.eraseRegisteredMemory(mob, MemoryModuleType.UNIVERSAL_ANGER);
                HackerCountermeasureHandler.eraseRegisteredMemory(mob, MemoryModuleType.ATTACK_TARGET);
            }
            mob.setTarget(target);
        } else {
            mob.setTarget(target);
        }
    }

    /**
     * 是否《机械传说》的蓝图器械：沿继承链找 {@code MachineryEntity}，类名匹配、
     * 不需要编译依赖；对方 mod 不在场时永远返回 false，原版行为零变化。
     * 包内共享给 {@link MachineryHostilityHandler} 的"阵营 → 器械"索敌目标判定。
     */
    static boolean isBlueprintMachinery(Mob mob) {
        return MachineryLegendCompat.isMachinery(mob);
    }

    /**
     * 蓝图器械（《机械传说》由蓝图生成、不能移动的实体）的索敌兼容通道。
     *
     * <p>器械完全没有 Goal AI：{@code MachineryEntity#tick} 每 5 tick 自己调一次
     * {@code findTarget()}，在 15 格里取"最近的合法敌人"。而它原版的合法口径
     * （{@code RebellionLogic#canMachineAttack}）是"敌对生物（Enemy）即可打、
     * 普通玩家不打"——反逆者本人恰好是 Enemy，通常还是炮塔 15 格里最近的一个。
     * 于是旧实现下两头堵死：器械每轮索敌都锁到反逆者，被本模组阵营门禁
     * （{@link #onChangeTarget}）拒绝并清空；被心控时旧同步逻辑又因"反逆者没有
     * 目标"每 tick 再清一遍。器械的目标永远立不起来，连原本在射程内的怪物也
     * 一并放弃——表现就是"控制了一个器械，它彻底傻掉，失去对周围生物的索敌"。</p>
     *
     * <p>现在器械走这条独立通道：不心控、不解放，只补不抢——</p>
     * <ul>
     *   <li>反逆者正压着一个器械原生口径也允许打的合法目标时，把军团目标交给它；</li>
     *   <li>其余情况一律保留器械自己锁定的目标，绝不清空；</li>
     *   <li>器械的索敌刚被阵营门禁吃掉（本 tick 末仍无目标）时，按原版口径
     *       （Enemy / 其自家反叛单位、15 格、有视线、再叠加本模组阵营规则）
     *       就近补一个合法目标，炮塔因此能继续打周围的怪物。</li>
     * </ul>
     */
    private static void keepMachineryHunting(Mob machine, LivingEntity controller) {
        if (controller instanceof Mob controllerMob) {
            LivingEntity legionTarget = controllerMob.getTarget();
            if (legionTarget != null) {
                if (isMachineryLegalTarget(machine, legionTarget)) {
                    if (machine.getTarget() != legionTarget) {
                        machine.setTarget(legionTarget);
                    }
                    return;
                }
                // 军团目标不是器械原生口径能打的（例如普通玩家）：不强塞，交给下面的兜底。
            }
        }
        // 器械自己的索敌刚被门禁吃掉时立刻补位，不必等下一次 5 tick 扫描：
        // 发射器下一 tick 读到的就是合法目标；目标还站着时不插手、不重置。
        if (machine.getTarget() != null) {
            return;
        }
        retargetMachinery(machine);
    }

    /** 按器械原版 15 格口径补一个本模组也允许打的最近敌人。 */
    private static void retargetMachinery(Mob machine) {
        if (!(machine.level() instanceof ServerLevel level)) {
            return;
        }
        AABB box = machine.getBoundingBox().inflate(MachineryLegendCompat.huntRange());
        LivingEntity nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, box,
                entity -> isMachineryLegalTarget(machine, entity))) {
            double distance = machine.distanceToSqr(candidate);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        if (nearest != null) {
            machine.setTarget(nearest);
        }
    }

    /**
     * 按《机械传说》原生口径判断"这台器械可以打谁"，再叠加本模组的阵营规则。
     *
     * <p>原版 {@code canMachineAttack}（攻击方非其自家反叛单位时）的判据是
     * {@code isRebel(target) XOR isEnemy(target)}：普通敌对生物能打，
     * 普通玩家不能打，被其反叛效果标记的单位也能打。这里复刻同一口径，
     * 保证补位目标不会越出器械本来的攻击名单；另外按"凋灵骷髅阵营与器械
     * 敌对"的要求，阵营成员一律进名单（{@code WitherBoss}、马匹这类不实现
     * {@code Enemy} 的成员原版口径轮不到它们）；最后用
     * {@link MesmerizerControl#canAttack} 挡掉受控生物与反逆者一侧的友军——
     * 被心控的器械正是靠这条拒绝回头打军团同袍的。</p>
     */
    private static boolean isMachineryLegalTarget(Mob machine, LivingEntity candidate) {
        return MachineryLegendCompat.isCompatibleMachineryTarget(machine, candidate)
                && machine.hasLineOfSight(candidate)
                && MesmerizerControl.canAttack(machine, candidate);
    }

    /** 排空被控监守者的残余仇恨与声源残留，防止旧嫌疑人经"咆哮→锁敌"链抢回索敌权。 */
    private static void drainWardenAnger(Warden warden) {
        Brain<Warden> brain = warden.getBrain();
        brain.eraseMemory(MemoryModuleType.DISTURBANCE_LOCATION);
        brain.eraseMemory(MemoryModuleType.ROAR_TARGET);
        for (int i = 0; i < 8; i++) {
            LivingEntity suspect = warden.getEntityAngryAt().orElse(null);
            if (suspect == null) {
                break;
            }
            warden.clearAnger(suspect);
        }
    }

    private static void clearControlledMobHostility(Mob mob, LivingEntity controller) {
        if (mob instanceof Warden warden) {
            warden.clearAnger(controller);
            if (warden.getTarget() == controller) {
                warden.setAttackTarget(null);
            }
            drainWardenAnger(warden);
        }
        if (mob instanceof IronGolem golem) {
            // 铁傀儡的原版 NearestAttackableTargetGoal 会直接写入持久怒气；
            // 受控后必须每 tick 清除对无头骑士部件及反逆者本人的敌意。
            LivingEntity target = golem.getTarget();
            if (target != null && !MesmerizerControl.canAttack(golem, target)) {
                golem.setTarget(null);
            }
            if (controller != null && golem.getPersistentAngerTarget() != null
                    && golem.getPersistentAngerTarget().equals(controller.getUUID())) {
                golem.setPersistentAngerTarget(null);
                golem.setRemainingPersistentAngerTime(0);
            }
            if (golem.getPersistentAngerTarget() != null
                    && golem.level() instanceof ServerLevel level) {
                Entity angerTarget = level.getEntity(golem.getPersistentAngerTarget());
                if (angerTarget instanceof DullhanHead
                        || (angerTarget instanceof LivingEntity living
                        && !MesmerizerControl.canAttack(golem, living))) {
                    golem.setPersistentAngerTarget(null);
                    golem.setRemainingPersistentAngerTime(0);
                }
            }
        }
    }

    private static void lockHotbarSlot(ServerPlayer player) {
        var data = player.getPersistentData();
        if (!data.contains(REBELLION_LOCKED_SLOT)) {
            data.putInt(REBELLION_LOCKED_SLOT, player.getInventory().selected);
        }

        int lockedSlot = Math.max(0, Math.min(8, data.getInt(REBELLION_LOCKED_SLOT)));
        if (player.getInventory().selected != lockedSlot) {
            player.getInventory().selected = lockedSlot;
            player.connection.send(new ClientboundSetCarriedItemPacket(lockedSlot));
        }
    }

    private static void clearRebellionControlState(ServerPlayer player) {
        var data = player.getPersistentData();
        data.remove(REBELLION_LAVA_CACHE);
        data.remove(REBELLION_TARGET_CACHE);
        data.remove(REBELLION_LOCKED_SLOT);
    }

    /**
     * 成就「我是自己的主人」：在反逆状态下把反逆者王冠戴到头上。
     *
     * <p>王冠一经戴上，下一个 tick 豁免逻辑就会清除反逆效果，"反逆中"与"戴冠"共存的
     * 窗口只有一刻；因此本判定必须抢在两个 tick 入口的清除动作之前执行，
     * 且两个入口都要有——事件先后顺序不做假设，先跑到的一方负责授予。</p>
     */
    private static void awardCrownMastery(ServerPlayer player) {
        if (!player.hasEffect(GeneratedMod.REBELLION) || !MesmerizerControl.isCrownProtected(player)) {
            return;
        }
        var advancement = player.server.getAdvancements()
                .get(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "i_am_my_own_master"));
        if (advancement != null) {
            player.getAdvancements().award(advancement, "wore_crown_in_rebellion");
        }
    }

    private static void stopPlayerMovement(ServerPlayer player) {
        Vec3 movement = player.getDeltaMovement();
        player.setDeltaMovement(0.0D, movement.y, 0.0D);
        player.setPlayerInput(0.0F, 0.0F, false, false);
        player.connection.teleport(player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
    }

    private static void controlRebelliousPlayer(ServerPlayer player) {
        if (player.isInLava()) {
            stopPlayerMovement(player);
            return;
        }

        var data = player.getPersistentData();
        if (player.tickCount % REBELLION_AI_SEARCH_INTERVAL == 0) {
            BlockPos lava = findNearestLava(player);
            if (lava == null) {
                data.remove(REBELLION_LAVA_CACHE);
            } else {
                data.putLong(REBELLION_LAVA_CACHE, lava.asLong());
            }

            LivingEntity target = findNearestAiTarget(player);
            if (target == null) {
                data.remove(REBELLION_TARGET_CACHE);
            } else {
                data.putUUID(REBELLION_TARGET_CACHE, target.getUUID());
            }
        }

        BlockPos lava = getCachedLava(player);
        if (lava != null) {
            movePlayerToward(player, lava.getCenter(), true);
            return;
        }

        LivingEntity target = getCachedAiTarget(player);
        if (target == null) {
            stopPlayerMovement(player);
            return;
        }

        movePlayerToward(player, new Vec3(target.getX(), target.getEyeY(), target.getZ()), false);
        double reach = 3.0D + target.getBbWidth() * 0.5D;
        if (player.distanceToSqr(target) <= reach * reach
                && player.hasLineOfSight(target)
                && player.getAttackStrengthScale(0.0F) >= 1.0F) {
            player.attack(target);
        }
    }

    private static BlockPos getCachedLava(ServerPlayer player) {
        var data = player.getPersistentData();
        if (!data.contains(REBELLION_LAVA_CACHE)) {
            return null;
        }
        BlockPos lava = BlockPos.of(data.getLong(REBELLION_LAVA_CACHE));
        if (!player.level().getFluidState(lava).is(FluidTags.LAVA)) {
            data.remove(REBELLION_LAVA_CACHE);
            return null;
        }
        return lava;
    }

    private static LivingEntity getCachedAiTarget(ServerPlayer player) {
        var data = player.getPersistentData();
        if (!data.hasUUID(REBELLION_TARGET_CACHE)) {
            return null;
        }
        Entity entity = player.serverLevel().getEntity(data.getUUID(REBELLION_TARGET_CACHE));
        if (!(entity instanceof Mob mob) || !isValidAiTarget(player, mob)) {
            data.remove(REBELLION_TARGET_CACHE);
            return null;
        }
        return mob;
    }

    private static void movePlayerToward(ServerPlayer player, Vec3 destination, boolean seekLava) {
        player.lookAt(EntityAnchorArgument.Anchor.EYES, destination);

        Vec3 horizontal = new Vec3(destination.x - player.getX(), 0.0D, destination.z - player.getZ());
        if (horizontal.lengthSqr() > 1.0E-6D) {
            Vec3 aiMovement = horizontal.normalize().scale(REBELLION_AI_MOVE_SPEED);
            player.move(MoverType.PLAYER, aiMovement);
        }

        boolean jump = player.onGround() && (seekLava || player.horizontalCollision);
        player.setPlayerInput(0.0F, 0.0F, jump, false);
        if (jump) {
            player.jumpFromGround();
        }
        player.setDeltaMovement(0.0D, player.getDeltaMovement().y, 0.0D);
        player.connection.teleport(player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
    }

    private static BlockPos findNearestLava(ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        BlockPos nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (int x = -REBELLION_AI_LAVA_HORIZONTAL_RANGE; x <= REBELLION_AI_LAVA_HORIZONTAL_RANGE; x++) {
            for (int y = -REBELLION_AI_LAVA_VERTICAL_RANGE; y <= REBELLION_AI_LAVA_VERTICAL_RANGE; y++) {
                for (int z = -REBELLION_AI_LAVA_HORIZONTAL_RANGE; z <= REBELLION_AI_LAVA_HORIZONTAL_RANGE; z++) {
                    BlockPos candidate = origin.offset(x, y, z);
                    if (!player.level().getFluidState(candidate).is(FluidTags.LAVA)) {
                        continue;
                    }
                    double distance = player.distanceToSqr(candidate.getCenter());
                    if (distance < nearestDistance) {
                        nearest = candidate;
                        nearestDistance = distance;
                    }
                }
            }
        }
        return nearest;
    }

    private static LivingEntity findNearestAiTarget(ServerPlayer player) {
        AABB searchBox = player.getBoundingBox().inflate(REBELLION_AI_TARGET_RANGE);
        return player.level().getEntities(player, searchBox, entity -> entity instanceof Mob mob
                        && isValidAiTarget(player, mob))
                .stream()
                .map(entity -> (LivingEntity) entity)
                .min((left, right) -> Double.compare(player.distanceToSqr(left), player.distanceToSqr(right)))
                .orElse(null);
    }

    private static boolean isValidAiTarget(ServerPlayer player, Mob target) {
        return target.isAlive()
                && !MesmerizerControl.isWitherSkeletonFaction(target)
                && !MesmerizerControl.isControlled(target)
                && MesmerizerControl.canAttack(player, target);
    }

    private static void spawnMesmerizedParticles(ServerLevel level, LivingEntity entity) {
        if (entity.tickCount % 2 != 0) {
            return;
        }
        int purple = 0x8A2BE2;
        ColorParticleOption particle = ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, purple);
        level.sendParticles(particle, entity.getX(), entity.getY() + entity.getBbHeight() * 0.5D, entity.getZ(),
                12, entity.getBbWidth() * 0.55D, entity.getBbHeight() * 0.5D, entity.getBbWidth() * 0.55D, 0.02D);
    }

    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity attacker = event.getEntity();
        LivingEntity target = event.getNewAboutToBeSetTarget();
        if (target == null) {
            return;
        }
        if (MesmerizerControl.canAttack(attacker, target)) {
            return;
        }
        event.setCanceled(true);
        if (attacker instanceof Mob mob) {
            if (isBlueprintMachinery(mob)) {
                // 器械没有 Goal 再选一次：被阵营门禁直接清空后，目标永远立不起来。
                // 取消这次非法索敌，保留已有合法目标；空了就当场按原版口径补一个。
                LivingEntity current = mob.getTarget();
                if (current != null && current != target && isMachineryLegalTarget(mob, current)) {
                    return;
                }
                mob.setTarget(null);
                retargetMachinery(mob);
            } else {
                mob.setTarget(null);
            }
        }
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        // 凋灵之首（黑/蓝）对凋灵骷髅阵营完全免疫：直伤与弹头起爆的溅射一并免掉。
        // 这条必须走在"攻击者是不是 LivingEntity"之前——爆炸伤害的 getEntity() 是那枚
        // 弹头而不是发射者，按原样会被下面的类型判断直接放过去。命中侧的"穿过"由
        // WitherSkullFactionPassThroughMixin 负责，这里补的是穿过去之后仍可能吃到的溅射
        // （弹头在同袍身后撞上方块起爆、或多枚弹头互撞起爆）。
        if (MesmerizerControl.isImmuneToWitherSkull(event.getSource(), victim)) {
            event.setCanceled(true);
            return;
        }
        Entity attacker = event.getSource().getEntity();
        if (!(attacker instanceof LivingEntity livingAttacker)) {
            return;
        }
        if (!MesmerizerControl.canAttack(livingAttacker, victim)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlayerAttack(AttackEntityEvent event) {
        Player player = event.getEntity();
        if (!player.hasEffect(GeneratedMod.REBELLION)
                || !(event.getTarget() instanceof LivingEntity target)) {
            return;
        }
        if (!MesmerizerControl.canAttack(player, target)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        Entity killer = event.getSource().getEntity();
        if (!(killer instanceof ServerPlayer)) {
            killer = event.getSource().getDirectEntity();
        }
        if (!(killer instanceof ServerPlayer player)
                || victim instanceof Player
                || !player.hasEffect(GeneratedMod.REBELLION)) {
            return;
        }
        MobEffectInstance current = player.getEffect(GeneratedMod.REBELLION);
        if (current == null || current.isInfiniteDuration()) {
            return;
        }
        int extendedDuration = Math.min(Integer.MAX_VALUE - 20, current.getDuration()) + 20;
        player.addEffect(new MobEffectInstance(
                GeneratedMod.REBELLION,
                extendedDuration,
                current.getAmplifier(),
                current.isAmbient(),
                current.isVisible(),
                current.showIcon()));
    }
}
