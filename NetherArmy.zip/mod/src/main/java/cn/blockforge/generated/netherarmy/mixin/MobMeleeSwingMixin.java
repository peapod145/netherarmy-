package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.NetherArmyFlagWitherAoeHandler;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 怪物近战挥击的落点：{@code Mob#doHurtTarget}。
 *
 * <p>下界军团旗帜的"攻击时范围凋零"要同时覆盖玩家与怪物，但两边根本没有共同的钩子：
 * 玩家侧有 {@code AttackEntityEvent} 与 {@code Item#postHurtEnemy}，怪物侧两者都不会发生——
 * {@code Mob#doHurtTarget} 是直接 {@code target.hurtServer(damageSources().mobAttack(this), ...)}，
 * 从头到尾不碰 {@code ItemStack#hurtEnemy}，而 {@code AttackEntityEvent} 顾名思义只发给玩家。</p>
 *
 * <p>所以怪物侧只剩两条可选路：一是伤害事件
 * （{@code LivingIncomingDamageEvent}，已在处理器里按 {@code mob_attack} 接了），
 * 但受害者免伤、处于受击硬直、或 {@code hurtServer} 提前返回 {@code false} 时它根本不发出；
 * 二是本类这个 {@code HEAD} 注入——它等价于玩家侧的 {@code AttackEntityEvent}：
 * <b>只要这一拳真的挥到了目标身上就触发</b>，与这一拳有没有造成损伤无关。
 * 旗帜 5 刻一刀的节奏很容易踩进原版 10 刻受击硬直，少了这条就会出现"怪砍到人却没波"。</p>
 *
 * <p>注入本身不改变任何返回值，也不吞伤害：处理器内部先做主手判定（没持旗立刻返回），
 * 再按"同一攻击者同一游戏刻只结算一次"去重，所以与伤害事件通道并存也不会叠加双份效果。
 * 子类覆写（如 {@code Zombie#doHurtTarget}、本模组狂战士的覆写）都会先 {@code super} 调到
 * {@code Mob} 的这一个方法，因此注入点只此一处即可覆盖全部生物近战。</p>
 * <p>注入显式带 {@code require = 0}：这条只是"锦上添花"的补齐，通道二（伤害事件里认
 * {@code mob_attack}）本身已经能覆盖怪物打到可受伤目标的常规情况。真遇到名字对不上之类的
 * 绑定问题，宁可退化成少这一条、由 mixin 打一行警告，也不要让整个 {@code Mob} 类转换失败
 * 把游戏崩在启动/进世界的路上。</p>
 */
@Mixin(Mob.class)
public abstract class MobMeleeSwingMixin {

    @Inject(method = "doHurtTarget", at = @At("HEAD"), require = 0)
    private void netherarmy$flagWitherAuraOnMobSwing(Entity target, CallbackInfoReturnable<Boolean> callback) {
        NetherArmyFlagWitherAoeHandler.onMobMeleeSwing((Mob) (Object) this, target);
    }
}
