package cn.blockforge.generated.netherarmy;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * 炼狱晶锭。掉落物形态免疫火焰/岩浆与爆炸（下界合金锭同款待遇）：
 * <ul>
 *   <li>火/岩浆：注册处带 {@code fireResistant} 组件，{@code ItemEntity#fireImmune()}
 *       读 {@code DataComponents.FIRE_RESISTANT} 后直接跳过着火与岩浆伤害；</li>
 *   <li>爆炸：{@code ItemEntity#hurt} 扣血前先问 {@code ItemStack#canBeHurtBy}，
 *       这里把 {@code IS_EXPLOSION} 挡掉（与亡魂重盾 / 地煞战斧同款写法）。</li>
 * </ul>
 * 由锭制成的成品（炼狱晶四件套、炼狱晶锁链马铠、亡魂重盾、地煞战斧）在各自的
 * 注册/物品类里带同一对组合。
 */
public final class NetherCrystalIngotItem extends Item {
    public NetherCrystalIngotItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }
}
