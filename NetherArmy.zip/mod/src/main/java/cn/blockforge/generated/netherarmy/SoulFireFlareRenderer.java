package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import org.joml.Quaternionf;

/**
 * 灵魂火燃烧包裹层：与原版"实体着火"的全身火焰覆盖层（{@code EntityRenderDispatcher#renderFlame}）
 * 完全同款的逐层四边形几何与全亮渲染，只是把火贴图换成灵魂火的 {@code soul_fire_0/soul_fire_1}
 * 动画帧（同一个 blocks atlas，帧动画由原版 atlas tick 驱动）。
 *
 * <p>由 {@code EntityRenderDispatcherSoulFireMixin} 在客户端把原版橙焰调用替换到
 * {@link #render}，因此燃烧的样子就是"像烈焰人/着火生物那样被火焰包住"，
 * 而不是灵魂火把那种小粒子。anim（原版调色板动画的 uv1 层）沿用原版的 (0,10)，
 * 光照沿用原版的 240（方块光满格），与着火生物的火焰亮度一致。</p>
 */
public final class SoulFireFlareRenderer {
    private static final ResourceLocation SOUL_FIRE_0 =
            ResourceLocation.withDefaultNamespace("block/soul_fire_0");
    private static final ResourceLocation SOUL_FIRE_1 =
            ResourceLocation.withDefaultNamespace("block/soul_fire_1");

    private SoulFireFlareRenderer() {
    }

    /** 需要以灵魂火显示全身燃烧火焰的实体：蓄力中的诡影使徒、飞行中的凋零飞弹、被灵魂火烧灼的生物。 */
    public static boolean usesSoulFlame(Entity entity) {
        return (entity instanceof ShadowApostle apostle && apostle.isCharging())
                || entity instanceof WitherCharge
                || SoulFireBurn.isSoulFlame(entity);
    }

    /** 第一人称覆盖层使用原版火焰动画帧，避免与普通着火的渲染管线分叉。 */
    public static TextureAtlasSprite firstPersonSoulFireSprite() {
        return blockSprite(SOUL_FIRE_0);
    }

    /** 复刻原版 renderFlame 的几何：按判定箱宽度 1.4 倍缩放，自下而上逐层叠四边形，向上收缩后退。 */
    public static void render(PoseStack poseStack, MultiBufferSource buffers,
                              Entity entity, Quaternionf orientation) {
        TextureAtlasSprite fire0 = blockSprite(SOUL_FIRE_0);
        TextureAtlasSprite fire1 = blockSprite(SOUL_FIRE_1);
        poseStack.pushPose();
        float width = entity.getBbWidth() * 1.4F;
        poseStack.scale(width, width, width);
        float halfWidth = 0.5F;
        float height = entity.getBbHeight() / width;
        float rise = 0.0F;
        poseStack.mulPose(orientation);
        poseStack.translate(0.0F, 0.0F, 0.3F * (float) (int) height - 0.02F);
        float depth = 0.0F;
        VertexConsumer consumer = buffers.getBuffer(Sheets.cutoutBlockSheet());
        PoseStack.Pose pose = poseStack.last();
        for (int layer = 0; height > 0.0F; ++layer) {
            TextureAtlasSprite sprite = layer % 2 == 0 ? fire0 : fire1;
            float u0 = sprite.getU0();
            float v0 = sprite.getV0();
            float u1 = sprite.getU1();
            float v1 = sprite.getV1();
            if (layer / 2 % 2 != 0) {
                float swap = u0;
                u0 = u1;
                u1 = swap;
            }
            flareVertex(pose, consumer, -halfWidth, -rise, depth, u1, v1);
            flareVertex(pose, consumer, halfWidth, -rise, depth, u0, v1);
            flareVertex(pose, consumer, halfWidth, 1.4F - rise, depth, u0, v0);
            flareVertex(pose, consumer, -halfWidth, 1.4F - rise, depth, u1, v0);
            height -= 0.45F;
            rise -= 0.45F;
            halfWidth *= 0.9F;
            depth -= 0.03F;
        }
        poseStack.popPose();
    }

    private static void flareVertex(PoseStack.Pose pose, VertexConsumer consumer,
                                    float x, float y, float z, float u, float v) {
        consumer.addVertex(pose, x, y, z)
                .setColor(-1)
                .setUv(u, v)
                .setUv1(0, 10)
                .setLight(240)
                .setNormal(pose, 0.0F, 1.0F, 0.0F);
    }

    private static TextureAtlasSprite blockSprite(ResourceLocation spriteId) {
        return Minecraft.getInstance().getModelManager()
                .getAtlas(TextureAtlas.LOCATION_BLOCKS)
                .getSprite(spriteId);
    }
}
