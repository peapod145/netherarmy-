package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;

/** 按 immortal_warrior.bbmodel 的逐面 UV 直接发射六面方块。 */
final class ImmortalWarriorQuads {
    private static final int FACE_STRIDE = 19;
    private static final int CUBE_STRIDE = FACE_STRIDE * 6;
    private static final float PIXEL_TO_BLOCK = 1.0F / 16.0F;

    private ImmortalWarriorQuads() {
    }

    static void emit(PoseStack poseStack, VertexConsumer buffer, ModelPart part, float[] faces,
                     int textureWidth, int textureHeight, int packedLight, int packedOverlay, int color) {
        poseStack.pushPose();
        part.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();
        float su = 1.0F / textureWidth;
        float sv = 1.0F / textureHeight;
        for (int cube = 0; cube < faces.length; cube += CUBE_STRIDE) {
            for (int face = 0; face < 6; face++) {
                emitFace(pose, buffer, faces, cube + face * FACE_STRIDE, su, sv,
                        packedLight, packedOverlay, color);
            }
        }
        poseStack.popPose();
    }

    private static void emitFace(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                                 float su, float sv, int packedLight, int packedOverlay, int color) {
        float u1 = data[offset + 12] * su;
        float v1 = data[offset + 13] * sv;
        float u2 = data[offset + 14] * su;
        float v2 = data[offset + 15] * sv;
        float nx = data[offset + 16];
        float ny = data[offset + 17];
        float nz = data[offset + 18];
        // 与 HackerQuads 同款：逐面拿叉积 (p1-p0)×(p2-p0) 与表内法线比符号来选绕序，不写死
        // 顺序。本模型的表是"x 不翻转"口径，整体 0→1→2→3 朝外，和黑客那套刚好相反；写死
        // 方向会让整层在带剔除的通道（entityCutout）里被剔掉。UV 始终绑各自那个角。
        float ax = data[offset + 3] - data[offset];
        float ay = data[offset + 4] - data[offset + 1];
        float az = data[offset + 5] - data[offset + 2];
        float bx = data[offset + 6] - data[offset];
        float by = data[offset + 7] - data[offset + 1];
        float bz = data[offset + 8] - data[offset + 2];
        boolean forward = (ay * bz - az * by) * nx + (az * bx - ax * bz) * ny
                + (ax * by - ay * bx) * nz > 0.0F;
        // 这份贴图（作者原图，与 bbmodel 内嵌贴图逐像素一致）留了很多透明像素：
        // 躯干胸腹、背部、腰带和头底中央都是镂空的。Blockbench 默认双面显示，作者眼里
        // 这些镂空处能看到对面那块面的内壁；游戏里实体走 entityCutout 带剔除，只发一次
        // 外表面，从镂空看进去就是虚空——正面看不到躯干后方、下方看不到脑袋底面。
        // 因此每个面正反各发一次：外层用表内法线，内层把绕序反过来并把法线取反，
        // 这样内壁可见且光照跟着朝向走，不会比外壳暗一块。
        emitQuad(pose, buffer, data, offset, u1, v1, u2, v2, nx, ny, nz,
                packedLight, packedOverlay, color, !forward);
        emitQuad(pose, buffer, data, offset, u1, v1, u2, v2, -nx, -ny, -nz,
                packedLight, packedOverlay, color, forward);
    }

    /** 发一个四边形。{@code reverse} 为 true 时按 0→3→2→1 的相反绕序走，UV 仍绑各自的角。 */
    private static void emitQuad(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                                 float u1, float v1, float u2, float v2, float nx, float ny, float nz,
                                 int packedLight, int packedOverlay, int color, boolean reverse) {
        if (reverse) {
            vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
        } else {
            vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
        }
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                               int pointOffset, float u, float v, float nx, float ny, float nz,
                               int packedLight, int packedOverlay, int color) {
        buffer.addVertex(pose,
                        data[offset + pointOffset] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 1] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 2] * PIXEL_TO_BLOCK)
                .setUv(u, v)
                .setOverlay(packedOverlay)
                .setLight(packedLight)
                .setColor(color)
                .setNormal(pose, nx, ny, nz);
    }
}
