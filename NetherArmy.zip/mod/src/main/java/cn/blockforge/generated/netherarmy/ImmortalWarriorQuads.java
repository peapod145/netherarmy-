package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;

/** 按 immortal_warrior.bbmodel 的逐面 UV 直接发射六面方块。 */
final class ImmortalWarriorQuads {
    private static final int FACE_STRIDE = 19;
    private static final int CUBE_STRIDE = FACE_STRIDE * 6;
    private static final float PIXEL_TO_BLOCK = 1.0F / 16.0F;

    private ImmortalWarriorQuads() {
    }

    static void emit(PoseStack poseStack, VertexConsumer buffer, ModelPart part, float[] faces,
                     int textureWidth, int textureHeight, int packedLight, int packedOverlay, int color) {
        poseStack.pushPose();
        part.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();
        float su = 1.0F / textureWidth;
        float sv = 1.0F / textureHeight;
        for (int cube = 0; cube < faces.length; cube += CUBE_STRIDE) {
            for (int face = 0; face < 6; face++) {
                emitFace(pose, buffer, faces, cube + face * FACE_STRIDE, su, sv,
                        packedLight, packedOverlay, color);
            }
        }
        poseStack.popPose();
    }

    private static void emitFace(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                                 float su, float sv, int packedLight, int packedOverlay, int color) {
        float u1 = data[offset + 12] * su;
        float v1 = data[offset + 13] * sv;
        float u2 = data[offset + 14] * su;
        float v2 = data[offset + 15] * sv;
        float nx = data[offset + 16];
        float ny = data[offset + 17];
        float nz = data[offset + 18];
        vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                packedLight, packedOverlay, color);
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                               int pointOffset, float u, float v, float nx, float ny, float nz,
                               int packedLight, int packedOverlay, int color) {
        buffer.addVertex(pose,
                        data[offset + pointOffset] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 1] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 2] * PIXEL_TO_BLOCK)
                .setUv(u, v)
                .setOverlay(packedOverlay)
                .setLight(packedLight)
                .setColor(color)
                .setNormal(pose, nx, ny, nz);
    }
}
