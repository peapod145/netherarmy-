package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;

/** 按 hacker.bbmodel 的六面 UV 直接发射实体四边形。 */
final class HackerQuads {
    // 每个面：4 个顶点 xyz（12）+ UV 矩形（4）+ 法线 xyz（3）。
    static final int FACE_STRIDE = 19;
    static final int CUBE_STRIDE = FACE_STRIDE * 6;
    /**
     * 表里的顶点是 Blockbench 的像素单位。原版走 ModelPart#render → Cube#compile
     * 时每个顶点都会除以 16 再乘矩阵，而这里绕过了 Cube#compile 直接 addVertex，
     * 必须自己做同一换算——否则模型放大 16 倍，且与 translateAndRotate 的
     * （已除以 16 的）骨骼偏移完全错位。
     */
    private static final float PIXEL_TO_BLOCK = 1.0F / 16.0F;

    private HackerQuads() {
    }

    static void emit(PoseStack poseStack, VertexConsumer buffer, ModelPart part, float[] faces,
                     int textureWidth, int textureHeight, int packedLight, int packedOverlay, int color) {
        poseStack.pushPose();
        part.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();
        float su = 1.0F / textureWidth;
        float sv = 1.0F / textureHeight;
        for (int i = 0; i < faces.length; i += CUBE_STRIDE) {
            for (int face = 0; face < 6; face++) {
                emitFace(pose, buffer, faces, i + face * FACE_STRIDE, su, sv,
                        packedLight, packedOverlay, color);
            }
        }
        poseStack.popPose();
    }

    private static void emitFace(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                                 float su, float sv, int packedLight, int packedOverlay, int color) {
        float u1 = data[offset + 12] * su;
        float v1 = data[offset + 13] * sv;
        float u2 = data[offset + 14] * su;
        float v2 = data[offset + 15] * sv;
        float nx = data[offset + 16];
        float ny = data[offset + 17];
        float nz = data[offset + 18];
        vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                packedLight, packedOverlay, color);
        vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                packedLight, packedOverlay, color);
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                               int pointOffset, float u, float v, float nx, float ny, float nz,
                               int packedLight, int packedOverlay, int color) {
        buffer.addVertex(pose, data[offset + pointOffset] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 1] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 2] * PIXEL_TO_BLOCK)
                .setUv(u, v)
                .setOverlay(packedOverlay)
                .setLight(packedLight)
                .setColor(color)
                .setNormal(pose, nx, ny, nz);
    }
}
