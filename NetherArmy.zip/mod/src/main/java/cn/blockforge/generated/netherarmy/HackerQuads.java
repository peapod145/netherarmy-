package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;

/**
 * 按 bbmodel 的六面 UV 直接发射实体四边形，供 per-face UV 的模型共用
 * （黑客、御首者等）。
 *
 * <p>为什么不能走 ModelPart/CubeListBuilder：那套 API 的 UV 矩形尺寸被盒子尺寸锁死，
 * 而 bbmodel 每个面的 UV 是作者手绘的、可以比盒子大也可以比盒子小（法杖杆 1x31 的
 * 盒子贴 2x32 的矩形、杖头 inflate -3 后 2x2x2 的盒子贴 8x8 的矩形）。texOffs 怎么
 * 反解都复刻不了这种拉伸。这里直接 addVertex，UV 就是 bbmodel 里的原始矩形。</p>
 *
 * <h3>顶点绕序必须与原版 Cube 同向（否则开剔除的渲染通道整块消失）</h3>
 * <p>方块面可见与否由 GPU 按屏幕空间绕序判前后，不看我们 setNormal 的朝向。带剔除的
 * 通道（{@code entityCutout}、{@code eyes}）一旦绕序反了，整层面片会被剔掉、游戏里
 * 什么都看不到；NoCull 通道则会把盒子的内表面也画出来，透明处露出贴图的镜像拷贝。</p>
 * <p>bbmodel 转出来的表里顶点顺序并不统一：大多数元素是"叉积指向盒内"，但带镜像/
 * 旋转的元素（黑客电脑盖的 -180°）恰好相反。所以这里不写死顺序，而是逐面拿叉积
 * {@code (p1-p0)×(p2-p0)} 与表内法线比符号：同向按 0→1→2→3 发，反向按 0→3→2→1
 * 发，保证不论顶点怎么排，发出去的面都朝外。UV 始终绑各自原来那个角，采样逐像素不变。</p>
 */
final class HackerQuads {
    // 每个面：4 个顶点 xyz（12）+ UV 矩形（4）+ 法线 xyz（3）。
    static final int FACE_STRIDE = 19;
    static final int CUBE_STRIDE = FACE_STRIDE * 6;
    /**
     * 表里的顶点是 Blockbench 的像素单位。原版走 ModelPart#render → Cube#compile
     * 时每个顶点都会除以 16 再乘矩阵，而这里绕过了 Cube#compile 直接 addVertex，
     * 必须自己做同一换算——否则模型放大 16 倍，且与 translateAndRotate 的
     * （已除以 16 的）骨骼偏移完全错位。
     */
    private static final float PIXEL_TO_BLOCK = 1.0F / 16.0F;

    private HackerQuads() {
    }

    static void emit(PoseStack poseStack, VertexConsumer buffer, ModelPart part, float[] faces,
                     int textureWidth, int textureHeight, int packedLight, int packedOverlay, int color) {
        poseStack.pushPose();
        part.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();
        float su = 1.0F / textureWidth;
        float sv = 1.0F / textureHeight;
        for (int i = 0; i < faces.length; i += CUBE_STRIDE) {
            for (int face = 0; face < 6; face++) {
                emitFace(pose, buffer, faces, i + face * FACE_STRIDE, su, sv,
                        packedLight, packedOverlay, color);
            }
        }
        poseStack.popPose();
    }

    private static void emitFace(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                                 float su, float sv, int packedLight, int packedOverlay, int color) {
        float u1 = data[offset + 12] * su;
        float v1 = data[offset + 13] * sv;
        float u2 = data[offset + 14] * su;
        float v2 = data[offset + 15] * sv;
        float nx = data[offset + 16];
        float ny = data[offset + 17];
        float nz = data[offset + 18];
        // GPU 判面前后只看屏幕空间绕序，不看 setNormal。这里按表内法线逐面挑一边：
        // 叉积 (p1-p0)×(p2-p0) 与法线同向就按 0→1→2→3 发，反向就按 0→3→2→1 发。
        // bbmodel 里有元素带镜像/旋转（黑客电脑盖的 -180° 就是反手性的），固定顺序会有
        // 几个面在带剔除的通道里被剔掉；逐面判定后不管顶点怎么排都画得出来。
        // UV 始终绑各自那个角，贴图采样逐像素不变。
        float ax = data[offset + 3] - data[offset];
        float ay = data[offset + 4] - data[offset + 1];
        float az = data[offset + 5] - data[offset + 2];
        float bx = data[offset + 6] - data[offset];
        float by = data[offset + 7] - data[offset + 1];
        float bz = data[offset + 8] - data[offset + 2];
        boolean forward = (ay * bz - az * by) * nx + (az * bx - ax * bz) * ny
                + (ax * by - ay * bx) * nz > 0.0F;
        if (forward) {
            vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
        } else {
            vertex(pose, buffer, data, offset, 0, u1, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 9, u1, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 6, u2, v2, nx, ny, nz,
                    packedLight, packedOverlay, color);
            vertex(pose, buffer, data, offset, 3, u2, v1, nx, ny, nz,
                    packedLight, packedOverlay, color);
        }
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer buffer, float[] data, int offset,
                               int pointOffset, float u, float v, float nx, float ny, float nz,
                               int packedLight, int packedOverlay, int color) {
        buffer.addVertex(pose, data[offset + pointOffset] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 1] * PIXEL_TO_BLOCK,
                        data[offset + pointOffset + 2] * PIXEL_TO_BLOCK)
                .setUv(u, v)
                .setOverlay(packedOverlay)
                .setLight(packedLight)
                .setColor(color)
                .setNormal(pose, nx, ny, nz);
    }
}
