package cn.blockforge.generated.netherarmy;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** “超度”附魔：让弓和弩射出的箭对亡灵生物造成额外伤害。 */
public final class SoulPurificationHandler {
    private static final float BONUS_DAMAGE_PER_LEVEL = 0.10F;

    private SoulPurificationHandler() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (!victim.getType().is(net.minecraft.tags.EntityTypeTags.UNDEAD)) {
            return;
        }

        if (!(event.getSource().getDirectEntity() instanceof AbstractArrow arrow)) {
            return;
        }

        ItemStack weapon = arrow.getWeaponItem();
        if (weapon == null || weapon.isEmpty()) {
            return;
        }

        var enchantment = victim.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT)
                .get(GeneratedMod.SOUL_PURIFICATION);
        if (enchantment.isEmpty()) {
            return;
        }
        int level = EnchantmentHelper.getItemEnchantmentLevel(enchantment.get(), weapon);
        if (level > 0 && event.getAmount() > 0.0F) {
            event.setAmount(event.getAmount() * (1.0F + BONUS_DAMAGE_PER_LEVEL * level));
        }
    }
}
