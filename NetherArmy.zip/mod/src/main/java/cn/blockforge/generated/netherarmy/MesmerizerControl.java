package cn.blockforge.generated.netherarmy;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;

/** 反逆者控制关系的持久化与阵营辅助方法。 */
public final class MesmerizerControl {
    private static final String CONTROLLER_UUID = "generated_mod_mesmerizer_controller";
    private static final TagKey<net.minecraft.world.entity.EntityType<?>> WITHER_SKELETONS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.withDefaultNamespace("wither_skeletons"));

    private MesmerizerControl() {
    }

    public static void setControlledBy(LivingEntity target, Mesmerizer controller) {
        if (isCrownProtected(target)) {
            return;
        }
        target.getPersistentData().putUUID(CONTROLLER_UUID, controller.getUUID());
    }

    public static boolean isCrownProtected(LivingEntity target) {
        return target.getItemBySlot(EquipmentSlot.HEAD).is(GeneratedMod.MESMERIZER_CROWN.get());
    }

    public static boolean isControlled(LivingEntity target) {
        return target.getPersistentData().hasUUID(CONTROLLER_UUID);
    }

    public static void releaseControl(LivingEntity target) {
        target.getPersistentData().remove(CONTROLLER_UUID);
        target.removeEffect(GeneratedMod.MESMERIZED);
        clearControlledTargetMemories(target);
        clearAllTargets(target.level(), target);
    }

    /**
     * 清除 Brain AI 实体（监守者、猪灵/猪灵蛮兵）缓存的攻击目标与愤怒记忆。
     * 这些实体覆盖后的 {@code getTarget()} 只读 Brain 的 {@code ATTACK_TARGET}，
     * 仅调用 {@code Mob.setTarget(null)} 无法立刻解除它们的锁定。
     */
    public static void clearControlledTargetMemories(LivingEntity target) {
        if (!(target instanceof Mob mob)) {
            return;
        }
        mob.setTarget(null);
        // 原版 eraseMemory 会调用 getMemory；任意被控生物未必注册这些模块，统一安全擦除。
        HackerCountermeasureHandler.eraseRegisteredMemory(mob, net.minecraft.world.entity.ai.memory.MemoryModuleType.ATTACK_TARGET);
        HackerCountermeasureHandler.eraseRegisteredMemory(mob, net.minecraft.world.entity.ai.memory.MemoryModuleType.ANGRY_AT);
        HackerCountermeasureHandler.eraseRegisteredMemory(mob, net.minecraft.world.entity.ai.memory.MemoryModuleType.UNIVERSAL_ANGER);
        if (mob instanceof net.minecraft.world.entity.monster.warden.Warden warden) {
            warden.setAttackTarget(null);
            for (int i = 0; i < 8; i++) {
                LivingEntity suspect = warden.getEntityAngryAt().orElse(null);
                if (suspect == null) {
                    break;
                }
                warden.clearAnger(suspect);
            }
        }
    }

    public static boolean isControlledBy(LivingEntity target, Entity controller) {
        return isControlled(target) && target.getPersistentData().getUUID(CONTROLLER_UUID).equals(controller.getUUID());
    }

    public static LivingEntity getController(LivingEntity target) {
        if (!(target.level() instanceof ServerLevel level) || !isControlled(target)) {
            return null;
        }
        Entity entity = level.getEntity(target.getPersistentData().getUUID(CONTROLLER_UUID));
        return entity instanceof LivingEntity living && living.isAlive() ? living : null;
    }

    public static void clearAllTargets(net.minecraft.world.level.Level level, LivingEntity cleared) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        for (Entity entity : serverLevel.getAllEntities()) {
            if (entity instanceof Mob mob && mob.getTarget() == cleared) {
                mob.setTarget(null);
            }
        }
    }

    /** 控制者死亡时立即释放其控制的实体，并清除所有维度中的相关仇恨。 */
    public static void releaseAllControlledBy(Mesmerizer controller) {
        if (!(controller.level() instanceof ServerLevel controllerLevel)) {
            return;
        }
        MinecraftServer server = controllerLevel.getServer();
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof LivingEntity target) || !isControlledBy(target, controller)) {
                    continue;
                }
                target.getPersistentData().remove(CONTROLLER_UUID);
                target.removeEffect(GeneratedMod.MESMERIZED);
                clearControlledTargetMemories(target);
                clearAllTargets(level, target);
            }
        }
    }

    public static boolean sameWitherSkeletonFaction(Entity left, Entity right) {
        return isWitherSkeletonFaction(left) && isWitherSkeletonFaction(right);
    }

    /**
     * 凋灵骷髅阵营判定：{@code #minecraft:wither_skeletons} 阵营名册、原版凋灵骷髅/凋灵，
     * 外加无头骑士头颅。<b>本模组不认 {@code #minecraft:skeletons}</b>。
     *
     * <p>为什么不认骨骼大标签：那里头装着主世界射箭的普通骷髅（以及流髑），一旦把它们
     * 算进凋灵骷髅阵营，军团与它们就成了"同袍"——{@link #canAttack} 直接判定互不可攻击，
     * {@code LivingIncomingDamageEvent} 与 {@code LivingChangeTargetEvent} 两个钩子会把
     * 误伤取消、把反击仇恨清空，表现为双方在战场上互相穿过去、谁也不打谁。阵营名册由本
     * 模组在 {@code data/minecraft/tags/entity_type/wither_skeletons.json} 里逐个维护，
     * 模组的骷髅系生物（狂战士、床战士、下界猎手、御首者、运输兵、挑头者、黑客、怨灵、
     * 不朽战士……）全都登记在内，原版凋灵骷髅也登记在内（再加上 {@code instanceof
     * WitherSkeleton} 双保险），因此去掉骨骼标签依据不会漏掉任何阵营成员。</p>
     *
     * <p>头颅必须特判：{@code DullhanHead} 是史莱姆系实体，进不了阵营名册里的骨骼口径
     * （会被当成骨骼生物引发副作用），它只登记在 {@code #minecraft:wither_friends} 里，
     * 强袭头颅由 {@code BlitzDullhanHead extends DullhanHead} 一并覆盖。</p>
     */
    public static boolean isWitherSkeletonFaction(Entity entity) {
        return entity instanceof WitherBoss
                || entity instanceof WitherSkeleton
                || entity instanceof DullhanHead
                || entity.getType().is(WITHER_SKELETONS);
    }

    /**
     * 该伤害是否出自凋灵之首（黑色或蓝色弹头）。
     *
     * <p>两种口径都要认，缺一不可：</p>
     * <ul>
     * <li>{@code minecraft:wither_skull}：{@code WitherSkull#onHitEntity} 的 8 点直伤，
     * 以及本模组复刻蓝头命中时（{@code WitherEnhancementHandler#resolveBlueSkullImpactDirect}）
     * 用的同源伤害；只有 {@code getOwner()} 不是 {@code LivingEntity} 时才会退化成
     * {@code magic}，那种情况下下一条兜住。</li>
     * <li>{@code getDirectEntity() instanceof WitherSkull}：弹头起爆产生的爆炸伤害，其类型是
     * {@code explosion}/{@code player_explosion}，只有直接实体仍指向那枚弹头。黑色弹头撞上
     * 阵营生物身后的方块、或蓝头"命中即爆"时，同袍受到的正是这一份溅射。</li>
     * </ul>
     */
    public static boolean isWitherSkullDamage(DamageSource source) {
        return source.getDirectEntity() instanceof WitherSkull || source.is(DamageTypes.WITHER_SKULL);
    }

    /**
     * 凋灵骷髅阵营对凋灵之首的完全免疫：不分黑头蓝头，也不问弹头是谁发射的。
     *
     * <p>与 {@link #isWitherSkeletonFaction} 同为阵营门禁的组成部分，但这条比
     * {@link #canAttack} 更宽——后者只在攻击者也属于阵营时才免伤，而凋灵之首的设定是
     * "同袍之间连弹头都碰不到"，敌对势力（例如玩家用凋灵之首打凋灵骷髅）也在免疫之列。</p>
     */
    public static boolean isImmuneToWitherSkull(DamageSource source, Entity victim) {
        return isWitherSkullDamage(source) && isWitherSkeletonFaction(victim);
    }

    public static boolean canAttack(LivingEntity attacker, LivingEntity target) {
        if (attacker == target || !target.isAlive()) {
            return false;
        }
        // 器械传说把所有蓝图器械都归为 MACHINE 阵营，原生逻辑因此会让
        // 普通器械互不攻击；这里按“反逆侧”区分双方：正常器械 ↔ 反逆器械
        // 可以互伤，同侧器械仍保持友军关系。没有器械传说时该方法永远返回 false。
        if (MachineryLegendCompat.isMachinery(attacker) && MachineryLegendCompat.isMachinery(target)) {
            return MachineryLegendCompat.isRebelMachinery(attacker)
                    != MachineryLegendCompat.isRebelMachinery(target);
        }
        if (isWitherSkeletonFaction(attacker) && isWitherSkeletonFaction(target)) {
            return false;
        }
        // 凋灵骷髅阵营不把反逆器械当作敌人；反逆器械也不能自行把军团
        // 当作普通 Enemy 锁定，必须由反逆者控制关系提供目标。
        if (isWitherSkeletonFaction(attacker) && MachineryLegendCompat.isRebelMachinery(target)) {
            return false;
        }
        if (MachineryLegendCompat.isRebelMachinery(attacker)
                && isWitherSkeletonFaction(target)) {
            return false;
        }
        // 所有被心控实体都属于同一阵营，不能因控制者不同而互相攻击。
        // 这条规则必须放在后续特殊阵营判断之前，覆盖近战、远程和受击反击。
        if (isControlled(attacker) && isControlled(target)) {
            return false;
        }
        if (isControlled(target) && isControlledBy(target, attacker)) {
            return false;
        }
        // 受控铁傀儡不应把无头骑士的独立头颅当成敌人；该规则同时
        // 覆盖原版目标 AI、受击反击和 NeoForge 的目标变更事件。
        if (attacker instanceof IronGolem && isControlled(attacker) && target instanceof DullhanHead) {
            return false;
        }
        if (isControlled(target) && attacker.getType().is(EntityTypeTags.UNDEAD)) {
            return false;
        }
        // 受控生物一律视作军团友军，凋灵骷髅阵营成员不得攻击它。上一条只按
        // "攻击方是 undead 标签类型"拦截，头颅（史莱姆系）这类不在 undead 标签里的
        // 阵营成员会漏网；自"阵营与《机械传说》蓝图器械敌对"起，被反逆者收编的
        // 器械必须靠这条挡住——器械一旦被心控就成了友军单位，军团不能再轰它。
        if (isWitherSkeletonFaction(attacker) && isControlled(target)) {
            return false;
        }
        if (isWitherSkeletonFaction(target) && isControlled(attacker)) {
            return false;
        }
        if (attacker instanceof Player player && player.hasEffect(GeneratedMod.REBELLION)
                && isWitherSkeletonFaction(target)) {
            return false;
        }
        return !isControlledBy(attacker, target);
    }

    public static void removeStaleControl(LivingEntity target) {
        if (isControlled(target) && getController(target) == null) {
            target.getPersistentData().remove(CONTROLLER_UUID);
        }
    }
}
