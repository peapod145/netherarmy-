package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * 熔髓（emberbone）：凋灵骷髅阵营的火焰系亡灵，近战人形。
 *
 * <h3>基础数值</h3>
 * <ul>
 *   <li>血量 20、护甲 0；移速 0.25（同凋灵骷髅）、近战 3 点（同僵尸）、索敌 35；</li>
 *   <li>免疫火焰（{@code EntityType.Builder#fireImmune}）与爆炸伤害（{@link #isInvulnerableTo}）；</li>
 *   <li>身处火焰方块或岩浆中时护甲抬到 10（{@link #getArmorValue}）；</li>
 *   <li>身处火焰方块（普通火/灵魂火）中时获得速度 I 状态效果，离开火焰立即解除（{@link #applyFireSpeedBoost}）；
 *       岩浆与自燃不触发这条增益；</li>
 *   <li>任意维度低概率自然生成于火焰或岩浆处，无视亮度；可在岩浆中像玩家一样游泳；</li>
 *   <li>经验 5（同凋灵骷髅），掉落见 {@code data/netherarmy/loot_table/entities/emberbone.json}；</li>
 *   <li>会捡拾并穿戴护甲、武器（{@code setCanPickUpLoot(true)} + 渲染器的护甲/手持层）。</li>
 * </ul>
 *
 * <h3>近战与死亡爆炸</h3>
 * <p>近战命中附加 30 秒燃烧；死亡时原地引爆：半径 5 格内所有活体吃 4 点爆炸伤害并被点燃
 * 60 秒，不破坏方块，音效走原版"岩浆毁物"的 1501 事件（{@code block.lava.extinguish}），
 * 同时喷出大量火焰粒子并在地表留下火焰（受 {@code mobGriefing} 约束）。</p>
 *
 * <h3>灵魂火形态</h3>
 * <p>一旦身体接触到灵魂火（灵魂火方块，或本模组的灵魂火燃烧状态），立刻且不可逆地转入
 * 灵魂火形态：移速 +50%，近战伤害 ×2，近战与爆炸改为附加灵魂火燃烧，爆炸粒子换成
 * 灵魂火粒子，本体渲染换成灵魂火贴图。形态写进同步数据供客户端换贴图，同时存进 NBT
 * 保证读档不还原。</p>
 *
 * <h3>火焰弹与自燃</h3>
 * <p>生成时 20% 概率手持火焰弹：发射资格完全以主手实物为准——只有握着火焰弹
 * （灵魂火形态为诡影使徒同款的凋零飞弹）才能每 30 tick 朝视野内 16 格的目标射击，
 * 近战 AI 照常接近，表现为边射边走；主手一旦被替换（比如捡起武器）就失去发射能力，
 * 弹药不再有任何独立标志位。被灵魂火转化时，手中握着的火焰弹同步换成凋零飞弹。
 * 锁定敌人时自燃（烈焰人式全身火焰覆盖层，免疫火焰不伤己，灵魂火形态烧蓝焰），
 * 目标丢失后熄灭，自燃期间脚下地面被点燃（受 mobGriefing 约束）。</p>
 *
 * <h3>水</h3>
 * <p>伤害照烈焰人处理：{@code isSensitiveToWater} 让雨水/水/气泡柱每 tick 扣 1 点血，
 * {@link FloatInWaterGoal} 保证入水后能扑腾上浮（只认水、不认岩浆，避免搅动岩浆游泳手感）。
 * 逃避行为由三层叠起来，缺一层就退化成"直勾勾追进水里"：
 * 寻路对 {@code PathType.WATER} 给 16 点高代价（只影响<b>建路</b>，绕水走而不封死，
 * 保证掉进水里还能铺出回岸的路）；空闲游荡走
 * {@link WaterAvoidingRandomStrollGoal}，取点概率传 0.0F＝永不选水面（烈焰人同款）；
 * 真正在挨水伤害时由 {@link FleeWaterGoal}（优先级 1，压过近战）接管移动，
 * 就近找"干燥 + 不被雨淋 + 脚下实心 + 三格身位"的落脚点脱身——上岸与躲雨是同一条判据。</p>
 *
 * <h3>自然生成</h3>
 * <p>任意维度：岩浆位在主世界以外与炽足兽同概率（权重 60、无随机闸门），主世界的岩浆位
 * 与纯火焰位一样走 1/20 低概率闸门；无视亮度。刷怪蛋/召唤等非自然路径不受概率限制。</p>
 */
public class Emberbone extends Monster {
    /** 近战附加燃烧时长（秒）。 */
    private static final float MELEE_FIRE_SECONDS = 30.0F;
    /** 死亡爆炸半径（格）。 */
    private static final float DEATH_EXPLOSION_RADIUS = 5.0F;
    /** 死亡爆炸伤害。 */
    private static final float DEATH_EXPLOSION_DAMAGE = 4.0F;
    /** 死亡爆炸附加燃烧时长（秒，规格 1 分钟）。 */
    private static final float DEATH_EXPLOSION_FIRE_SECONDS = 60.0F;
    /** 自然刷新在火焰处的低概率闸门：每次刷怪位置检查约 5%；主世界的岩浆位同样走这道闸门，其他维度的岩浆位与炽足兽同权重、无闸门。 */
    private static final int FIRE_LAVA_SPAWN_ROLLS = 20;
    /** 火焰中速度 I 效果的续挂时长（tick）：在火里每 tick 刷新，出火时直接摘除。 */
    private static final int FIRE_SPEED_DURATION_TICKS = 40;
    /** 生成时手持火焰弹的概率。 */
    private static final float FIREBALL_CHANCE = 0.2F;
    /** 火焰弹发射间隔（tick）。 */
    private static final int FIREBALL_INTERVAL_TICKS = 30;
    /** 火焰弹射程（格，平方距离比较）；近战 AI 照常接近，这条只是远程补充。 */
    private static final double FIREBALL_RANGE_SQR = 16.0D * 16.0D;
    /** 岩浆游泳的输入力度与速度阻尼，沿用尸鬼的鱼类式手感。 */
    private static final float LAVA_SWIM_RELATIVE_FORCE = 0.02F;
    private static final double LAVA_SWIM_DAMPING = 0.9D;
    /** 灵魂火形态的移速加成修饰符 ID（+50%）。 */
    private static final ResourceLocation SOUL_FIRE_SPEED_ID = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "emberbone_soul_fire_speed");
    /** 灵魂火形态的近战伤害加成修饰符 ID（×2）。 */
    private static final ResourceLocation SOUL_FIRE_DAMAGE_ID = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "emberbone_soul_fire_damage");

    private static final EntityDataAccessor<Boolean> DATA_SOUL_FIRE_FORM =
            SynchedEntityData.defineId(Emberbone.class, EntityDataSerializers.BOOLEAN);
    /** 自燃状态：锁定敌人时点燃自身（不伤己），丢失目标后熄灭。 */
    private static final EntityDataAccessor<Boolean> DATA_IGNITED =
            SynchedEntityData.defineId(Emberbone.class, EntityDataSerializers.BOOLEAN);

    /** 服务端权威的灵魂火形态标志；客户端读同步数据。 */
    private boolean soulFireForm;
    /** 距下一次发射火焰弹的冷却（仅服务端）。 */
    private int fireballCooldown;
    /** 上一 tick 是否已经把火焰速度增益挂上（仅服务端），用于出火时精确摘除。 */
    private boolean fireSpeedActive;

    public Emberbone(EntityType<? extends Emberbone> entityType, Level level) {
        super(entityType, level);
        // 经验与凋灵骷髅一致（Monster 默认 5，这里显式钉住）。
        this.xpReward = 5;
        // 可捡拾并穿戴护甲/武器（Mob 原生的装备替换管线）。
        this.setCanPickUpLoot(true);
        // 怕水：寻路给水高代价（仍能从水里走回岸上，不像烈焰人那样整块封死），
        // 岩浆对它是可通行的游泳介质；火焰/岩浆生成点不应被寻路代价阻断。
        this.setPathfindingMalus(PathType.WATER, 16.0F);
        this.setPathfindingMalus(PathType.LAVA, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ARMOR, 0.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 35.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SOUL_FIRE_FORM, false);
        builder.define(DATA_IGNITED, false);
    }

    @Override
    protected void registerGoals() {
        // 0：入水后蹦跳上浮。原版地面怪标配是 FloatGoal，但它的 canUse 把 isInLava()
        // 也算进去，而且构造时会顺手 navigation.setCanFloat(true)——这两条都会搅动
        // 熔髓已经调好的"岩浆里像玩家一样游泳"手感（岩浆起跳 + 水面浮力语义），
        // 所以这里只留水：见 FloatInWaterGoal。
        this.goalSelector.addGoal(0, new FloatInWaterGoal(this));
        // 1：惧水脱身。必须压过近战（2），否则玩家一进 35 格索敌范围，
        // 占着 MOVE 的近战 Goal 就把一切"避水/躲雨"逻辑整条堵死（详见 FleeWaterGoal 注释）。
        this.goalSelector.addGoal(1, new FleeWaterGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D, 0.0F));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new InstantLockTargetGoal<>(this, Player.class, true));
        // 凋灵骷髅同款：主动攻击猪灵系与铁傀儡。
        this.targetSelector.addGoal(3, new InstantLockTargetGoal<>(this, AbstractPiglin.class, true));
        this.targetSelector.addGoal(3, new InstantLockTargetGoal<>(this, IronGolem.class, true));
    }

    // ---------------------------------------------------------------- 生成与装备

    /**
     * 生成时 20% 概率把火焰弹（{@link Items#FIRE_CHARGE}）塞进主手：弹药不随射击消耗，
     * 但主手一旦被捡起的武器等替换就失去发射能力（资格只认 {@link #hasFireballAmmo()}
     * 的主手实物，没有独立标志位）。出生即持有的弹药不掉落（它是能力本体，不是战利品）。
     */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData spawnGroupData) {
        spawnGroupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData);
        if (!this.level().isClientSide && this.getItemBySlot(EquipmentSlot.MAINHAND).isEmpty()
                && this.random.nextFloat() < FIREBALL_CHANCE) {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.FIRE_CHARGE));
            this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }
        return spawnGroupData;
    }

    /** 主手是否握着可用弹药（火焰弹或凋零飞弹）；发射资格的唯一定义。 */
    private boolean hasFireballAmmo() {
        ItemStack mainHand = this.getItemBySlot(EquipmentSlot.MAINHAND);
        return mainHand.is(Items.FIRE_CHARGE) || mainHand.is(GeneratedMod.WITHER_CHARGE_ITEM.get());
    }

    /** 当前握着的是不是凋零飞弹（决定发射哪种弹体）。 */
    private boolean isHoldingWitherCharge() {
        return this.getItemBySlot(EquipmentSlot.MAINHAND).is(GeneratedMod.WITHER_CHARGE_ITEM.get());
    }

    // ---------------------------------------------------------------- 声音

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_SKELETON_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.WITHER_SKELETON_STEP, 0.15F, 1.0F);
    }

    // ---------------------------------------------------------------- 属性特例

    /**
     * 身处火焰方块（含灵魂火）或岩浆中时护甲抬到 10；其余时候用属性值（基础 0 + 穿戴护甲）。
     * 覆写 {@code getArmorValue} 而不是加属性修饰符：护甲减伤读的就是这一个入口，
     * 进火/出火即时生效，不会因为每 tick 增删修饰符产生同步抖动。
     */
    @Override
    public int getArmorValue() {
        return this.isInFireOrLava() ? 10 + super.getArmorValue() : super.getArmorValue();
    }

    private boolean isInFireOrLava() {
        // 注意不用 isOnFire()：自燃（锁定敌人）也让它为真，但护甲抬升只认真正的
        // 环境火——岩浆、火焰方块，或外部来源点上的真实火 tick。
        if (this.isInLava() || this.getRemainingFireTicks() > 0) {
            return true;
        }
        return this.anyBlockInBoundingBox(state -> state.getBlock() instanceof BaseFireBlock);
    }

    /**
     * 是否身处火焰中：身体覆盖到火焰方块（普通火与灵魂火都是 {@code BaseFireBlock}），
     * 或被外部火源点上真实火 tick。与护甲那条的区别只有岩浆——岩浆是本体的游泳介质，
     * 按设定不给速度增益；自燃（{@link #DATA_IGNITED}）是战斗表现，也不占用真实火 tick。
     */
    private boolean isInFire() {
        if (this.getRemainingFireTicks() > 0) {
            return true;
        }
        return this.anyBlockInBoundingBox(state -> state.getBlock() instanceof BaseFireBlock);
    }

    /**
     * 火焰中挂速度 I（原版 Speed 状态效果，+20% 移速），出火立刻摘掉，进火即时生效。
     * 与灵魂火形态的永久 +50% 移速修饰符叠算；{@code ambient=true} 让它不额外冒
     * 状态粒子（本体常驻火焰粒子已经够密），{@code visible=true} 保留效果图标。
     */
    private void applyFireSpeedBoost() {
        if (this.isInFire()) {
            this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,
                    FIRE_SPEED_DURATION_TICKS, 0, true, true));
            this.fireSpeedActive = true;
        } else if (this.fireSpeedActive || this.hasEffect(MobEffects.MOVEMENT_SPEED)) {
            this.removeEffect(MobEffects.MOVEMENT_SPEED);
            this.fireSpeedActive = false;
        }
    }

    /**
     * 覆写原版着火判定：除真实火 tick 外，自燃（{@link #DATA_IGNITED}）也算着火。
     * 客户端由此走 {@code Entity#displayFireAnimation} 的全身火焰覆盖层（灵魂火形态
     * 经 {@link SoulFireFlareRenderer} 换蓝焰）；服务端熔髓免疫火焰伤害，自燃不伤己。
     */
    @Override
    public boolean isOnFire() {
        return super.isOnFire() || this.entityData.get(DATA_IGNITED);
    }

    /** 完全免疫爆炸伤害（自身死亡爆炸时已死亡，不影响结算）。 */
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.is(DamageTypeTags.IS_EXPLOSION) || super.isInvulnerableTo(source);
    }

    // ---------------------------------------------------------------- 近战

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!super.doHurtTarget(target)) {
            return false;
        }
        if (target instanceof LivingEntity living) {
            this.burnTarget(living, MELEE_FIRE_SECONDS);
        }
        return true;
    }

    /** 按当前形态给目标附加普通火或灵魂火。 */
    private void burnTarget(LivingEntity target, float seconds) {
        if (this.isSoulFireForm()) {
            SoulFireBurn.ignite(target, seconds);
        } else {
            target.igniteForSeconds(seconds);
        }
    }

    // ---------------------------------------------------------------- 自燃与火焰弹

    /**
     * 服务端 AI 步进：维护自燃状态、烧灼脚下地面、按 30 tick 节奏发射弹药。
     *
     * <p>自燃照烈焰人蓄火的观感：锁定敌人即点燃自身（免疫火焰所以不伤己），
     * 目标死亡或丢失后熄灭；岩浆/水中不点燃（水会浇灭火焰，与烈焰人同理）。
     * 发射资格只看主手实物：握着火焰弹/凋零飞弹才开火，武器替换掉弹药后即哑火。
     * 发射不占移动控制——近战 Goal 照常接近目标，游戏表现为边射边走。</p>
     */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity target = this.getTarget();
        boolean ignited = target != null && target.isAlive()
                && !this.isInLava() && !this.isInWater();
        if (ignited != this.entityData.get(DATA_IGNITED)) {
            this.entityData.set(DATA_IGNITED, ignited);
        }
        if (ignited) {
            this.igniteGroundUnderfoot();
        }
        if (this.fireballCooldown > 0) {
            this.fireballCooldown--;
        }
        if (this.fireballCooldown > 0 || !this.hasFireballAmmo()
                || target == null || !target.isAlive()) {
            return;
        }
        double distanceSqr = this.distanceToSqr(target);
        if (distanceSqr > FIREBALL_RANGE_SQR || distanceSqr < 1.0E-6D
                || !this.hasLineOfSight(target)) {
            return;
        }
        this.shootFireball(target);
        this.fireballCooldown = FIREBALL_INTERVAL_TICKS;
    }

    /**
     * 朝目标发射主手里握着的弹药：火焰弹打出原版小火球，凋零飞弹放出
     * 诡影使徒同款的 {@link WitherCharge}。两者都是 {@code Projectile}，
     * 阵营投掷物穿友军的 Mixin 自动生效；飞弹额外打开同袍起爆豁免。
     */
    private void shootFireball(LivingEntity target) {
        Vec3 eye = this.getEyePosition();
        Vec3 direction = target.getEyePosition().subtract(eye);
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        double spawnX = eye.x + direction.x * 0.5D;
        double spawnY = eye.y + direction.y * 0.5D;
        double spawnZ = eye.z + direction.z * 0.5D;
        if (this.isHoldingWitherCharge()) {
            WitherCharge charge = new WitherCharge(this, this.level(), direction);
            charge.setPos(spawnX, spawnY, spawnZ);
            charge.setFactionPassthrough(true);
            charge.launch(direction);
            this.level().addFreshEntity(charge);
        } else {
            SmallFireball ball = new SmallFireball(this.level(), this, direction);
            ball.setPos(spawnX, spawnY, spawnZ);
            this.level().addFreshEntity(ball);
        }
        this.playSound(SoundEvents.FIRECHARGE_USE, 1.0F,
                0.92F + this.getRandom().nextFloat() * 0.16F);
    }

    /** 自燃期间把脚下（可站面的正上方空格）点成火；受 mobGriefing 约束。 */
    private void igniteGroundUnderfoot() {
        if (!(this.level() instanceof ServerLevel server)
                || !server.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return;
        }
        BlockPos below = this.blockPosition().below();
        if (!server.getBlockState(below).isFaceSturdy(server, below, Direction.UP)
                || !BaseFireBlock.canBePlacedAt(server, this.blockPosition(), Direction.UP)) {
            return;
        }
        server.setBlockAndUpdate(this.blockPosition(),
                BaseFireBlock.getState(server, this.blockPosition()));
    }

    // ---------------------------------------------------------------- 水

    /**
     * 与烈焰人一致：雨、水、气泡柱每 tick 造成 1 点伤害（结算在 {@code LivingEntity#aiStep}）。
     * 这条同时也是 {@link FleeWaterGoal} 与 {@link FloatInWaterGoal} 的总闸——
     * {@code FleeWaterGoal} 的触发判据与它逐字对齐，保证"开始掉血"和"开始逃水"是同一刻。
     */
    @Override
    public boolean isSensitiveToWater() {
        return true;
    }

    // ---------------------------------------------------------------- 灵魂火形态

    public boolean isSoulFireForm() {
        return this.level().isClientSide ? this.entityData.get(DATA_SOUL_FIRE_FORM) : this.soulFireForm;
    }

    @Override
    public void tick() {
        super.tick();
        this.floatInLava();
        if (this.level().isClientSide) {
            this.emitAmbientParticles();
            return;
        }
        if (!this.soulFireForm && this.touchesSoulFire()) {
            this.becomeSoulFireForm();
        }
        this.applyFireSpeedBoost();
    }

    /** 身体接触灵魂火方块，或身上挂着本模组的灵魂火燃烧状态。 */
    private boolean touchesSoulFire() {
        if (SoulFireBurn.isSoulFlame(this)) {
            return true;
        }
        return this.anyBlockInBoundingBox(state -> state.is(Blocks.SOUL_FIRE));
    }

    /** 判定包围盒所覆盖的方块里是否存在满足条件的方块。 */
    private boolean anyBlockInBoundingBox(java.util.function.Predicate<BlockState> predicate) {
        AABB box = this.getBoundingBox().inflate(0.05D);
        BlockPos min = BlockPos.containing(box.minX, box.minY, box.minZ);
        BlockPos max = BlockPos.containing(box.maxX, box.maxY, box.maxZ);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (predicate.test(this.level().getBlockState(pos))) {
                return true;
            }
        }
        return false;
    }

    /**
     * 不可逆地转入灵魂火形态：换贴图（同步数据）、提速 +50%、近战伤害 ×2、
     * 喷一圈灵魂火粒子；主手还握着火焰弹的个体把它换成凋零飞弹（外观与实弹同步换），
     * 弹药早已被替换掉的个体不借此复活发射能力。
     */
    private void becomeSoulFireForm() {
        this.soulFireForm = true;
        this.entityData.set(DATA_SOUL_FIRE_FORM, true);
        this.applySoulFireSpeed();
        this.applySoulFireDamage();
        if (this.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.FIRE_CHARGE)) {
            this.setItemSlot(EquipmentSlot.MAINHAND,
                    new ItemStack(GeneratedMod.WITHER_CHARGE_ITEM.get()));
        }
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.SOUL_ESCAPE.value(), this.getSoundSource(), 1.0F, 1.0F);
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    this.getX(), this.getY(0.5D), this.getZ(), 60, 0.6D, 1.0D, 0.6D, 0.02D);
        }
    }

    private void applySoulFireSpeed() {
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(SOUL_FIRE_SPEED_ID) == null) {
            speed.addPermanentModifier(new AttributeModifier(SOUL_FIRE_SPEED_ID, 0.5D,
                    AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    /** 灵魂火熔髓的近战伤害是普通熔髓的 2 倍（基础值 ×2，走属性乘区）。 */
    private void applySoulFireDamage() {
        AttributeInstance attack = this.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack != null && attack.getModifier(SOUL_FIRE_DAMAGE_ID) == null) {
            attack.addPermanentModifier(new AttributeModifier(SOUL_FIRE_DAMAGE_ID, 1.0D,
                    AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    /** 客户端身上的常驻火焰粒子（灵魂火形态换成灵魂火粒子）。 */
    private void emitAmbientParticles() {
        if (this.random.nextInt(4) != 0) {
            return;
        }
        this.level().addParticle(
                this.isSoulFireForm() ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                this.getRandomX(0.5D), this.getRandomY(), this.getRandomZ(0.5D), 0.0D, 0.0D, 0.0D);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("SoulFireForm", this.soulFireForm);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.getBoolean("SoulFireForm")) {
            this.soulFireForm = true;
            this.entityData.set(DATA_SOUL_FIRE_FORM, true);
            this.applySoulFireSpeed();
            this.applySoulFireDamage();
        }
    }

    // ---------------------------------------------------------------- 死亡爆炸

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.detonateOnDeath();
        }
        super.die(source);
    }

    /**
     * 死亡自爆：半径 5 格内活体吃 4 点爆炸伤害并被点燃 1 分钟，不破坏方块；
     * 音效与"岩浆烧毁物品"同一条（level event 1501），并喷大量火焰粒子、在地面留火。
     */
    private void detonateOnDeath() {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        boolean soul = this.isSoulFireForm();
        double x = this.getX();
        double y = this.getY(0.5D);
        double z = this.getZ();
        // 保留原版岩浆嘶鸣，同时补上明确的爆炸音效。
        server.levelEvent(1501, this.blockPosition(), 0);
        server.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE.value(),
                SoundSource.HOSTILE, 1.0F, 1.0F);
        server.sendParticles(soul ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                x, y, z, 180, 2.5D, 1.5D, 2.5D, 0.05D);
        server.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 40, 2.0D, 1.2D, 2.0D, 0.02D);

        DamageSource explosion = server.damageSources().explosion(this, this);
        AABB area = new AABB(
                x - DEATH_EXPLOSION_RADIUS, y - DEATH_EXPLOSION_RADIUS, z - DEATH_EXPLOSION_RADIUS,
                x + DEATH_EXPLOSION_RADIUS, y + DEATH_EXPLOSION_RADIUS, z + DEATH_EXPLOSION_RADIUS);
        double radiusSqr = (double) DEATH_EXPLOSION_RADIUS * DEATH_EXPLOSION_RADIUS;
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, area)) {
            if (living == this || !living.isAlive() || living.distanceToSqr(x, y, z) > radiusSqr) {
                continue;
            }
            living.hurt(explosion, DEATH_EXPLOSION_DAMAGE);
            this.burnTarget(living, DEATH_EXPLOSION_FIRE_SECONDS);
        }

        if (server.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            this.placeGroundFire();
        }
    }

    /** 在爆炸范围内贴着地表留下火（灵魂土/灵魂沙上自动落灵魂火，其余落普通火）。 */
    private void placeGroundFire() {
        Level level = this.level();
        BlockPos origin = this.blockPosition();
        int radius = (int) DEATH_EXPLOSION_RADIUS;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius || this.random.nextFloat() > 0.35F) {
                    continue;
                }
                for (int dy = 3; dy >= -4; dy--) {
                    BlockPos base = origin.offset(dx, dy, dz);
                    BlockPos fire = base.above();
                    if (level.getBlockState(base).isFaceSturdy(level, base, Direction.UP)
                            && BaseFireBlock.canBePlacedAt(level, fire, Direction.UP)) {
                        level.setBlockAndUpdate(fire, BaseFireBlock.getState(level, fire));
                        break;
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- 岩浆游泳

    /** 岩浆内采用鱼类式浮力，保留水平游泳速度并把个体托向岩浆面。 */
    private void floatInLava() {
        if (!this.isInLava()) {
            return;
        }
        CollisionContext collisionContext = CollisionContext.of(this);
        if (collisionContext.isAbove(LiquidBlock.STABLE_SHAPE, this.blockPosition(), true)
                && !this.level().getFluidState(this.blockPosition().above()).is(FluidTags.LAVA)) {
            this.setOnGround(true);
            return;
        }
        Vec3 movement = this.getDeltaMovement();
        double vertical = Mth.clamp(movement.y * 0.5D + 0.05D, -0.08D, 0.08D);
        this.setDeltaMovement(movement.x, vertical, movement.z);
    }

    /** 岩浆中按鱼类曲线推进，避免 LivingEntity 默认液体阻尼过强。 */
    @Override
    public void travel(Vec3 travelInput) {
        FluidState fluidState = this.level().getFluidState(this.blockPosition());
        if (!this.isControlledByLocalInstance()
                || !this.isInLava()
                || !this.isAffectedByFluids()
                || this.canStandOnFluid(fluidState)) {
            super.travel(travelInput);
            return;
        }
        double startY = this.getY();
        this.moveRelative(LAVA_SWIM_RELATIVE_FORCE, travelInput);
        this.move(MoverType.SELF, this.getDeltaMovement());
        Vec3 movement = this.getDeltaMovement().scale(LAVA_SWIM_DAMPING);
        if (this.getTarget() == null) {
            movement = movement.add(0.0D, -0.003D, 0.0D);
        }
        this.setDeltaMovement(movement);
        if (this.horizontalCollision
                && this.isFree(movement.x, movement.y + 0.6D - this.getY() + startY, movement.z)) {
            this.setDeltaMovement(movement.x, 0.3D, movement.z);
        }
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        this.checkInsideBlocks();
        if (this.isInLava()) {
            this.resetFallDistance();
        } else {
            super.checkFallDamage(y, onGround, state, pos);
        }
    }

    @Override
    public void updateSwimming() {
        if (!this.level().isClientSide) {
            this.setSwimming(this.isInLava());
        }
    }

    @Override
    public boolean isVisuallySwimming() {
        return this.isSwimming();
    }

    @Override
    public boolean isPushedByFluid() {
        return !this.isSwimming();
    }

    // ---------------------------------------------------------------- 自然生成

    /**
     * 熔髓只在火焰或岩浆位置参与自然生成；不读取亮度，因而下界、主世界以及其他
     * 维度的火焰/岩浆都能成为候选点。自然刷怪候选点由 {@code NaturalSpawner}
     * 先行选定，本方法只校验它是否落在热源附近。
     *
     * <p>岩浆位在主世界以外与炽足兽同口径：无随机闸门，只要求 1 格内有岩浆（刷怪权重同为 60），
     * 实际稀有度由"岩浆表面候选点占比"自然决定；纯火焰位保留 1/20 的低概率闸门。
     * <b>主世界的岩浆位降到与火焰位同一道 1/20 闸门</b>——地表岩浆湖、洞穴熔岩池太多，
     * 不加闸门会在主世界刷屏；下界/末地/其他维度维持原样。</p>
     */
    public static boolean checkEmberboneSpawnRules(EntityType<Emberbone> entityType,
                                                    ServerLevelAccessor level,
                                                    MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            return false;
        }
        boolean natural = spawnType == MobSpawnType.NATURAL || spawnType == MobSpawnType.CHUNK_GENERATION;
        if (!natural) {
            return true;
        }
        boolean nearLava = hasLavaWithin(level, pos);
        boolean nearFire = hasFireWithin(level, pos);
        if (!nearLava && !nearFire) {
            return false;
        }
        if (nearLava && !level.getLevel().dimension().equals(Level.OVERWORLD)) {
            return true;
        }
        // 火焰位，以及主世界的岩浆位：共用这道 1/20 低概率闸门。
        return random.nextInt(FIRE_LAVA_SPAWN_ROLLS) == 0;
    }

    private static boolean hasFireWithin(ServerLevelAccessor level, BlockPos pos) {
        for (BlockPos candidate : BlockPos.betweenClosed(pos.offset(-1, -1, -1), pos.offset(1, 1, 1))) {
            if (level.getBlockState(candidate).getBlock() instanceof BaseFireBlock) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasLavaWithin(ServerLevelAccessor level, BlockPos pos) {
        for (BlockPos candidate : BlockPos.betweenClosed(pos.offset(-1, -1, -1), pos.offset(1, 1, 1))) {
            if (level.getFluidState(candidate).is(FluidTags.LAVA)) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- 惧水

    /**
     * 入水后蹦跳上浮（原版 {@code FloatGoal} 的水上专用版）。
     *
     * <p>不直接用 {@code FloatGoal} 有两个原因：它的 {@code canUse} 把 {@code isInLava()}
     * 也算作起跳条件，而岩浆是熔髓的家（要像玩家一样在里面游），每刻蹬一次水会把已经调好的
     * 岩浆手感顶得一颤一颤；更关键的是它的构造器会顺手 {@code navigation.setCanFloat(true)}，
     * 而 {@code Mob#jumpInLiquidInternal} 正是按这个开关分流——开了走 {@code LivingEntity}
     * 的温和浮力（约 0.04 × 游泳速度），关了才拿到 {@code +0.3} 的强冲量。熔髓要的是后者：
     * 一阶岸沿正好高出默认 0.6 的步高，冲量小了根本蹦不上去。本类只占 JUMP 标志，
     * 其余全部照抄原版。</p>
     */
    private static final class FloatInWaterGoal extends Goal {
        private final Emberbone mob;

        private FloatInWaterGoal(Emberbone mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return this.mob.isInWater()
                    && this.mob.getFluidHeight(FluidTags.WATER) > this.mob.getFluidJumpThreshold();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            if (this.mob.getRandom().nextFloat() < 0.8F) {
                this.mob.getJumpControl().jump();
            }
        }
    }

    /**
     * 惧水脱身：熔髓只要正在被水结算伤害，就抢在攻击之前把身体挪出水里/雨里。
     *
     * <h3>为什么原方案等于没实装</h3>
     * <p>原版 {@code WaterAvoidingRandomStrollGoal} 确实自带"在水里就找陆地"的分支，
     * 但它挂在优先级 7、占 {@code Flag.MOVE}；而熔髓用
     * {@link InstantLockTargetGoal} 每刻锁定 35 格内的玩家，优先级 2 的
     * {@code MeleeAttackGoal} 同样占着 MOVE 并长期在跑。{@code GoalSelector} 里抢占的
     * 硬条件是 {@code WrappedGoal#canBeReplacedBy}——新目标必须<b>严格更高的优先级</b>才能
     * 从占用者手里夺走标志位，所以玩家一进索敌圈，游荡目标连启动资格都没有，它那条
     * "入水找岸"自然也从没执行过。原先的 {@code SeekShelterGoal} 更直接，
     * {@code canUse} 第一行写的就是"有攻击目标就不躲"。结果就是熔髓直勾勾追进水池和雨里：
     * {@code isSensitiveToWater} 在 {@code LivingEntity#aiStep} 里每刻扣 1 点血，
     * 20 血撑不到 1 秒，看上去跟"怕水设定没生效"一模一样。</p>
     *
     * <p>另外，光靠 {@code setPathfindingMalus(PathType.WATER, 16.0F)} 也只能让<b>寻路</b>
     * 绕开水：它既不阻止熔髓被目标引到水边，更不会在它已经泡在水里时把它拖出来。</p>
     *
     * <h3>本目标的口径</h3>
     * <p>触发条件与原版掉血判定<b>逐字一致</b>（{@code isSensitiveToWater() &&
     * isInWaterRainOrBubble()}，即浸水 / 被雨淋 / 气泡柱三者之一正在扣血），
     * 一句话：<b>正在被水伤害就逃</b>。目的地由近及远扫一个"脚下实心 + 三格身位 +
     * 不泡水"的落脚点；还泡在水里时先求"离水最近"，已经上岸只淋雨时再加一条"不被雨淋"
     * （即屋檐/树洞），所以上岸与躲雨共用同一条判据，不需要两套代码。
     * 优先级 1，只占 MOVE（JUMP 归 {@link FloatInWaterGoal}），不与任何目标抢标志位。</p>
     *
     * <p>撒手有三种：身体离开水/雨（脱身成功，立刻还给近战）、离目的地 2 格内、
     * 或连续 {@value #MAX_STALLED_REPATHS} 次重铺都没能靠近目的地（被地形卡死）——
     * 最后一种会先冷却 {@value #GIVE_UP_COOLDOWN_TICKS} 刻再试，避免和近战反复互抢 MOVE。
     * 铺不出绕行路线时（池子中央四面是水）退化为朝岸边直线泅水，
     * 由 {@code MoveControl} 自己在目的地高出一阶时要求起跳。</p>
     */
    private static final class FleeWaterGoal extends Goal {
        /** 就近扫描的水平半径（格）。 */
        private static final int SEARCH_RADIUS = 10;
        /** 就近扫描的垂直范围（格）：岸沿、屋檐与壕沟的落差通常在这个量级内。 */
        private static final int SEARCH_HEIGHT = 3;
        /** 单轮扫描最多试几个格子：给 isRainingAt 这类贵判定封顶，暴雨开阔地不至于每轮全量扫。 */
        private static final int MAX_SPOT_TESTS = 500;
        /** 未运行时多久扫一次（刻）：一轮扫描最坏要试 {@value #MAX_SPOT_TESTS} 个格子，不能每刻都来。 */
        private static final int SCAN_INTERVAL_TICKS = 5;
        /** 运行中重铺路线的间隔（刻）。 */
        private static final int REPATH_INTERVAL_TICKS = 20;
        /** 被地形卡住后的撒手冷却（刻）。 */
        private static final int GIVE_UP_COOLDOWN_TICKS = 60;
        /** 离目的地多近算到位（平方格）。 */
        private static final double ARRIVE_DISTANCE_SQR = 4.0D;
        /** 连续多少次重铺都没有实质靠近就认输。 */
        private static final int MAX_STALLED_REPATHS = 3;
        /** 一个重铺间隔内至少靠近这么多格才算有进展（平方格差值）。 */
        private static final double MIN_PROGRESS_SQR = 1.0D;
        /** 脱身速度倍率，比平时游荡快一档。 */
        private static final double ESCAPE_SPEED = 1.25D;
        /** 熔髓碰撞箱 2.4 格高，身体占三个整格。 */
        private static final int BODY_BLOCKS = 3;

        private final Emberbone mob;
        @Nullable
        private Vec3 destination;
        private int scanCooldown;
        private int repathCooldown;
        private int stalledRepaths;
        private double lastDistanceSqr = Double.MAX_VALUE;
        /** 绕行路线铺不出来（四面是水）时的直线泅水模式。 */
        private boolean directSwim;

        private FleeWaterGoal(Emberbone mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        /** 与 {@code LivingEntity#aiStep} 里的扣血判定完全同口径。 */
        private boolean isTakingWaterDamage() {
            return this.mob.isSensitiveToWater() && this.mob.isInWaterRainOrBubble();
        }

        @Override
        public boolean canUse() {
            if (!this.isTakingWaterDamage()) {
                this.scanCooldown = 0;
                return false;
            }
            if (this.scanCooldown > 0) {
                this.scanCooldown--;
                return false;
            }
            this.scanCooldown = SCAN_INTERVAL_TICKS;
            this.destination = this.findSafeGround();
            this.lastDistanceSqr = Double.MAX_VALUE;
            this.stalledRepaths = 0;
            return this.destination != null;
        }

        @Override
        public boolean canContinueToUse() {
            // 不挂靠在"路走完了没"上：那样一旦导航器被换掉或铺不出路，
            // isDone() 会长期为真，目标反复起停把移动权抖来抖去。
            return this.destination != null
                    && this.isTakingWaterDamage()
                    && this.mob.distanceToSqr(this.destination) > ARRIVE_DISTANCE_SQR;
        }

        @Override
        public void start() {
            this.repathCooldown = REPATH_INTERVAL_TICKS;
            this.navigate();
        }

        @Override
        public void tick() {
            Vec3 target = this.destination;
            if (target == null) {
                return;
            }
            if (--this.repathCooldown > 0) {
                if (this.directSwim) {
                    // 直线泅水模式下每刻重申移动指令：Mob#serverAiStep 里导航器先于移动控制器步进，
                    // 而它此刻没有路径、不会覆盖 wantedPosition，不重申就会被下一条指令顶掉。
                    this.mob.getMoveControl().setWantedPosition(target.x, target.y, target.z, ESCAPE_SPEED);
                }
                return;
            }
            this.repathCooldown = REPATH_INTERVAL_TICKS;
            double distanceSqr = this.mob.distanceToSqr(target);
            if (distanceSqr > this.lastDistanceSqr - MIN_PROGRESS_SQR
                    && ++this.stalledRepaths >= MAX_STALLED_REPATHS) {
                this.giveUp();
                return;
            }
            this.lastDistanceSqr = distanceSqr;
            this.navigate();
        }

        @Override
        public void stop() {
            this.destination = null;
            this.directSwim = false;
            this.stalledRepaths = 0;
            this.mob.getNavigation().stop();
        }

        /** 撒手：交还移动权，隔一会儿再试，别把近战目标顶得反复启停。 */
        private void giveUp() {
            this.destination = null;
            this.directSwim = false;
            this.stalledRepaths = 0;
            this.scanCooldown = GIVE_UP_COOLDOWN_TICKS;
        }

        private void navigate() {
            Vec3 target = this.destination;
            if (target == null) {
                return;
            }
            this.directSwim = !this.mob.getNavigation().moveTo(target.x, target.y, target.z, ESCAPE_SPEED);
            if (this.directSwim) {
                this.mob.getMoveControl().setWantedPosition(target.x, target.y, target.z, ESCAPE_SPEED);
            }
        }

        /**
         * 找落脚点。一轮扫描的取舍：
         * <ul>
         *   <li><b>本体还泡在水里/气泡柱里</b>：只要求"干燥"，取最近的一个。水里是每刻 1 点、
         *       20 刻就见底的血量，先蹦上去再说；落岸后如果仍在淋雨，本 Goal 会因"还在挨水伤害"
         *       继续运行，到位撒手后下一轮扫描自动切成找遮蔽。</li>
         *   <li><b>只是被雨淋</b>：要求"干燥且不被雨淋"，直接奔最近的屋檐/洞里去。</li>
         * </ul>
         * {@code BlockPos#withinManhattan} 按曼哈顿距离逐层展开，所以先试到的就是最近的格子；
         * {@value #MAX_SPOT_TESTS} 格的测试预算是硬上限——暴雨的开阔平原上到处都能站人，
         * 每个候选都要走一遍 {@code isRainingAt}（查天空可见度＋高度图＋群系降水），
         * 不设上限的话光扫描就能把 tick 吃掉一大块。
         */
        @Nullable
        private Vec3 findSafeGround() {
            BlockPos origin = this.mob.blockPosition();
            boolean requireShelter = !this.mob.isInWaterOrBubble();
            int testsLeft = MAX_SPOT_TESTS;
            for (BlockPos pos : BlockPos.withinManhattan(origin, SEARCH_RADIUS, SEARCH_HEIGHT, SEARCH_RADIUS)) {
                if (testsLeft-- <= 0) {
                    break;
                }
                if (this.isSafeSpot(pos, requireShelter)) {
                    return Vec3.atBottomCenterOf(pos);
                }
            }
            return null;
        }

        /**
         * 落脚点校验。便宜的判定（越界、身位碰撞、水/气泡柱、脚下实心面）全排在前面，
         * 最贵的 {@code isRainingAt}（要查天空可见度、MOTION_BLOCKING 高度图和生物群系降水类型）
         * 留到最后，绝大多数候选格在前几关就被剔掉了。
         *
         * <p>只把水算危险液体：岩浆是熔髓的家（护甲 10、可游泳），不能当障碍排除。</p>
         */
        private boolean isSafeSpot(BlockPos pos, boolean requireShelter) {
            Level level = this.mob.level();
            if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) {
                return false;
            }
            BlockPos below = pos.below();
            if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                return false;
            }
            for (int i = 0; i < BODY_BLOCKS; i++) {
                BlockPos body = pos.above(i);
                BlockState state = level.getBlockState(body);
                if (!state.getCollisionShape(level, body).isEmpty()
                        || state.getFluidState().is(FluidTags.WATER)
                        || state.is(Blocks.BUBBLE_COLUMN)) {
                    return false;
                }
            }
            return !requireShelter || !level.isRainingAt(pos);
        }
    }
}
