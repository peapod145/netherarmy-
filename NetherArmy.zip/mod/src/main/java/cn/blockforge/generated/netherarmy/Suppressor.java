package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.Vec3;

/**
 * 反转士（Suppressor）：凋灵骷髅变种，凋灵骷髅阵营的施法者。
 *
 * <p>面板：血量 20、护甲 2、移速同凋灵骷髅（0.25）、索敌 30 格；掉落物沿用凋灵骷髅
 * 的煤／骨头／头颅（本版本原版凋灵骷髅本就不掉石剑，且本类不生成石剑），额外
 * 10% 掉一朵凋灵玫瑰；经验是凋灵骷髅的 2 倍（5 → 10）。阵营身份靠
 * {@code minecraft:wither_skeletons} 标签——近战附凋零、免疫凋零／火焰、主动攻击
 * 猪灵系、军团光环与寻路宽容全部随之继承。</p>
 *
 * <h3>两种能力（共用 40 秒冷却，生成时即就绪）</h3>
 * <ol>
 *   <li><b>漂浮</b>：给当前目标挂 30 秒漂浮（Levitation I）。</li>
 *   <li><b>重力反转</b>：以自身为中心半径 30 格内所有<b>非</b>凋灵骷髅阵营的生物
 *       挂 30 秒重力反转（{@link GravityReversalMobEffect}）：上下颠倒、重力反向、
 *       玩家的视野也上下倒转。</li>
 * </ol>
 *
 * <p><b>创造模式玩家豁免</b>：索敌与作用对象都跳过创造模式玩家（连同旁观者一起
 * 豁免）——不论是"落单目标漂浮"还是范围重力反转，创造模式玩家既不会成为技能目标，
 * 也不会被半径 30 格的 AoE 波及。</p>
 *
 * <p><b>唤魔者同款施法前摇</b>：技能不再瞬发。触发后先进入 40 刻（2 秒）施法状态，
 * 前 20 刻为蓄力（手臂抬起、{@link #SPELL_WARMUP_TICKS}），到点才真正结算效果并播放
 * 施法音；后 20 刻维持收势。时序、音效与抬手姿态逐项对齐原版
 * {@code SpellcasterIllager}／{@code IllagerModel.SPELLCASTING}，抬手姿态在
 * {@link SuppressorModel#setupAnim} 里复刻。<b>施法不可打断</b>：法术的选择与前摇倒计时
 * 只挂在实体自身的计时器上，{@link AbilityGoal#stop()} 被抢占时只交出 MOVE／LOOK 控制权，
 * 不重置施法状态，因此挨打、被撞开、目标丢失都拦不下这一发。</p>
 *
 * <p><b>2 格反弹护盾</b>：任何进入自身 2 格气泡、由非凋灵骷髅阵营生物发射、且正在
 * 朝自己飞来的抛射物都会被"原路返回"——速度取反、弹体推到气泡外沿，做法与凋灵护盾的
 * 抛射物反弹一致；{@link SuppressorProjectileHandler} 在 {@code ProjectileImpactEvent}
 * 上兜底取消命中，保证高速弹丸即使在一帧内跨进判定箱也伤不到它。</p>
 *
 * <p><b>远程 AI</b>：反转士是站桩施法者，<b>永远不主动接近目标</b>。目标一旦进入技能射程
 * （{@value #ABILITY_RADIUS} 格出头）就由 {@link RangedPositionGoal}（优先级 2）接管 MOVE
 * 标志并原地站定；只有敌人逼近到 {@value #RETREAT_ENTER} 格才后撤到
 * {@value #RETREAT_EXIT} 格开外，把战场维持在技能射程里。原版骨架系的
 * {@code meleeGoal}（优先级 4）已在 {@link #reassessWeaponGoal()} 里注销，所以反转士
 * 不会出现"冲到脸前再逃跑"的来回横跳。施法期间由 {@link AbilityGoal}（优先级 1）接管，
 * 站定抬手。</p>
 *
 * <p><b>凋零飞弹（独立冷却）</b>：每隔 5 秒，在目标处于 30 格射程且视线畅通时发射一枚
 * 凋零飞弹（{@link WitherCharge}，与诡影使徒同款弹体：带灵魂火外观、命中起爆、爆炸
 * 伤害＋灵魂火）。此技能冷却独立于上述两种能力；两种能力施法前摇与收势期间优先，
 * 飞弹暂缓，施法结束后再发射。飞弹带同袍豁免，起爆不会溅射身边的凋灵骷髅阵营成员。</p>
 *
 * <p><b>只对敌人出手</b>：技能起手的先决条件是射程内有<b>真实敌人</b>——见
 * {@link #isFactionEnemy}：玩家、铁傀儡、雪傀儡、猪灵系，或此刻正以某个阵营成员为攻击目标
 * 的生物。附近只有牛羊村民这类没招惹它的生物时，它<b>不会</b>起手（旧的触发条件把"半径
 * 30 格内的非阵营生物 ≥ 2"直接当成敌人，牲畜、村民、宠物全都算数，于是它会对着一群路人
 * 莫名其妙地抬手施法）。</p>
 *
 * <p><b>出手对象不限于已锁定目标</b>：原版骷髅系的目标表只有玩家、铁傀儡、猪灵（本模组另在
 * 事件里补了蓝图器械），雪傀儡这类宿敌、以及别的模组里把阵营成员当猎物的生物都不在其中。
 * 光看 {@code getTarget()} 会出现"敌人打上门、反转士却站着发呆"——目标表里没有它，
 * 出手闸门又只认 {@code getTarget()}，两种法术与凋零飞弹一起哑火。为此
 * {@link #resolveCastTarget()} 把"已经锁定且合法的目标"与"射程内正在与阵营为敌的真实敌人"
 * 合成同一条出手判据：没锁定时就近认一个真实敌人并补成当前目标。{@link
 * FactionEnemyTargetGoal} 同样以 {@link #isFactionEnemy} 为准，把这些宿敌正式纳入索敌。</p>
 *
 * <p>注意区分<b>出手条件</b>与<b>结算对象</b>：范围重力反转一旦起手，命中名单依旧是
 * 半径 30 格内全部非凋灵骷髅阵营生物，<b>无差别</b>影响（牲畜、村民、宠物照吃 30 秒翻转），
 * 判据只是"值不值得为这一发 AoE 抬手"。</p>
 *
 * <p>选择规则：半径 30 格内<b>真实敌人</b>≥ 2 个就放范围重力反转（收益更大），
 * 否则对落单的那个目标（{@code getTarget()}，或刚认下的真实敌人）放漂浮。两者都吃同一条
 * 40 秒冷却，"刚生成就放一次"由 {@code abilityCooldown} 初值 0 保证。</p>
 *
 * <p>能力目标用 {@link WitherFactionHostilityHandler#isWitherFaction} 判阵营，因此
 * 自身、凋灵骷髅、本模组全部阵营成员都不会吃到范围效果，也不会成为漂浮目标。</p>
 */
public class Suppressor extends WitherSkeleton {

    /** 掉落表：与原版凋灵骷髅一致，去掉石剑、加 10% 凋灵玫瑰。 */
    public static final ResourceKey<LootTable> LOOT_TABLE = ResourceKey.create(
            Registries.LOOT_TABLE,
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "entities/suppressor"));

    /** 两种能力共用的冷却：40 秒。 */
    public static final int ABILITY_COOLDOWN_TICKS = 800;
    /** 凋零飞弹独立冷却：5 秒。 */
    public static final int WITHER_CHARGE_INTERVAL_TICKS = 100;
    /** 能力持续时间：30 秒。 */
    public static final int ABILITY_DURATION_TICKS = 600;
    /** 重力反转半径：30 格（与索敌范围同值）。 */
    public static final double ABILITY_RADIUS = 30.0D;
    private static final double ABILITY_RADIUS_SQR = ABILITY_RADIUS * ABILITY_RADIUS;
    /** 范围能力的最低受益目标数：扎堆才值得放 AoE。 */
    private static final int AREA_ABILITY_MIN_TARGETS = 2;
    /** 无锁定目标时兜底索敌的刷新间隔（刻），免得逐 tick 扫一遍半径 30 的实体。 */
    private static final int ENEMY_SCAN_INTERVAL_TICKS = 10;

    /** 施法状态总时长：40 刻（与原版唤魔者 {@code EvokerAttackSpellGoal.getCastingTime()} 同值）。 */
    public static final int SPELL_CAST_TICKS = 40;
    /** 施法前摇：20 刻（与原版 {@code SpellcasterUseSpellGoal.getCastWarmupTime()} 同值），到点结算效果。 */
    public static final int SPELL_WARMUP_TICKS = 20;

    /** 反弹护盾半径：2 格（需求值），进入这个气泡的敌方抛射物一律原路弹回。 */
    public static final double DEFLECT_RADIUS = 2.0D;
    private static final double DEFLECT_RADIUS_SQR = DEFLECT_RADIUS * DEFLECT_RADIUS;
    /** 弹体复位到气泡外沿时额外留出的余量，避免恰好卡在 2 格判定线上。 */
    private static final double DEFLECT_PUSH_OUT = 0.5D;

    /** 远程 AI 后撤触发距离：敌人进到 6 格就退。 */
    private static final double RETREAT_ENTER = 6.0D;
    /** 后撤收手距离：拉开到 11 格才停（滞回，免得起停抖动）。 */
    private static final double RETREAT_EXIT = 11.0D;
    /**
     * 站位目标接管距离：技能射程（{@value #ABILITY_RADIUS}）再放 2 格余量，
     * 目标进到这个范围就由 {@link RangedPositionGoal} 占住 MOVE 并原地站定。
     */
    private static final double POSITION_RANGE = ABILITY_RADIUS + 2.0D;
    private static final double POSITION_RANGE_SQR = POSITION_RANGE * POSITION_RANGE;
    /** 后撤取点的水平半径／高度，与原版 {@code AvoidEntityGoal} 的探路参数同款。 */
    private static final int RETREAT_PROBE_RADIUS = 16;
    private static final int RETREAT_PROBE_HEIGHT = 7;
    /** 后撤寻路速度倍率（比漫游快一点，但不到冲刺）。 */
    private static final double RETREAT_SPEED = 1.25D;
    private static final int RETREAT_REPATH_INTERVAL = 8;

    /** 法术 id：与原版 {@code SpellcasterIllager.IllagerSpell} 同款同步字节，0 = 未施法。 */
    private static final byte SPELL_NONE = 0;
    private static final byte SPELL_LEVITATION = 1;
    private static final byte SPELL_GRAVITY = 2;

    /**
     * 客户端施法判定用同步字节：> 0 表示正在施法，具体值区分法术（决定粒子颜色）。
     * 与 {@code SpellcasterIllager.DATA_SPELL_CASTING_ID} 同一套做法。
     */
    private static final EntityDataAccessor<Byte> DATA_SPELL_CASTING_ID =
            SynchedEntityData.defineId(Suppressor.class, EntityDataSerializers.BYTE);

    /** 渲染器里的 1.2× 缩放：施法粒子要按视觉身高摆放，这里对齐同一系数。 */
    private static final double VISUAL_SCALE = 1.2D;

    /** 剩余冷却刻数；0 表示就绪。生成时为 0，即"生成时技能已经就绪"。 */
    private int abilityCooldown;
    /** 凋零飞弹剩余冷却刻数；0 表示就绪，独立于两种法术能力。 */
    private int witherChargeCooldown;
    /** 剩余施法刻数（含前摇与收势）；> 0 即处于施法动画中。 */
    private int spellCastingTicks;
    /** 距离效果结算还剩几刻。 */
    private int castWarmupTicks;
    /** 本次选择的法术（SPELL_LEVITATION / SPELL_GRAVITY）。 */
    private byte pendingSpell = SPELL_NONE;
    /** 漂浮的预定目标，脱战或死亡则结算时退回当前目标。 */
    private LivingEntity pendingTarget;
    /** 本次出手认下的敌人（{@link #resolveCastTarget()} 的结果），供起手时复用，避免重复扫描。 */
    private LivingEntity castTarget;
    /** 没锁定目标时的兜底索敌结果：射程内最近的真实敌人。 */
    private LivingEntity nearbyEnemy;
    /** 兜底索敌的剩余缓存刻数。 */
    private int enemyScanCooldown;

    public Suppressor(EntityType<? extends Suppressor> type, Level level) {
        super(type, level);
        // 凋灵骷髅基准 5 的 2 倍 = 10。
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ARMOR, 2.0D)
                // 凋灵骷髅 0.25，显式再声明一次作为锚点。
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 30.0D);
    }

    /**
     * 空手施法：不生成石剑（需求"没有石剑"——不但掉落表里没有，手上也不拿）。
     * 父类 {@code WitherSkeleton#populateDefaultEquipmentSlots} 是 100% 塞石剑的。
     */
    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
    }

    /**
     * 纯施法者：不注册任何近战／弓目标。
     *
     * <p>{@code AbstractSkeleton#reassessWeaponGoal()} 在"手上既没有弓也没有武器"的分支里
     * <b>无条件</b>把 {@code meleeGoal}（{@code MeleeAttackGoal}）以优先级 4 塞进目标表，
     * 而反转士的空手出装正好命中这个分支——它会让反转士一路冲向目标贴脸，直到进到
     * {@link #RETREAT_ENTER} 格才被后撤目标顶开，于是形成"冲到面前又逃跑"的来回横跳。
     * 覆写成空实现后近战与弓目标都不会挂上，站位完全交给 {@link RangedPositionGoal}。</p>
     *
     * <p>该方法会被 {@code finalizeSpawn}、{@code setItemSlot}、{@code readAdditionalSaveData}
     * 等多处调用，覆盖在这里可以保证任何路径都不会把近战目标加回来（例如玩家用命令
     * 塞一把剑给它）。</p>
     */
    @Override
    public void reassessWeaponGoal() {
    }

    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return LOOT_TABLE;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 优先级 1 压过站位（2）与漫游（5）：施法期间站定、转向目标，姿态与唤魔者一致。
        this.goalSelector.addGoal(1, new AbilityGoal(this));
        // 优先级 2：远程站位。目标进到技能射程就占住 MOVE 标志原地站定，只有逼近到
        // RETREAT_ENTER 格才后撤。近战目标（4）已被 reassessWeaponGoal() 注销，
        // 所以这里不会再出现"主动接近"。
        this.goalSelector.addGoal(2, new RangedPositionGoal(this));
        // 目标补充：把"真正与阵营为敌"的生物也纳入索敌（雪傀儡、正在围攻阵营成员的怪……）。
        // 原版骷髅系的目标表只认玩家／铁傀儡／猪灵，雪傀儡这类宿敌打上门时它连目标都没有，
        // 技能自然放不出来、只会站着发呆。这里用与出手判据同源的 isFactionEnemy 补齐，
        // 牛羊村民这类没招惹阵营的生物不在名单里。
        this.targetSelector.addGoal(2, new FactionEnemyTargetGoal(this));
    }

    // ================================================================ 同步数据

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SPELL_CASTING_ID, SPELL_NONE);
    }

    /** 是否处于施法状态。客户端读同步字节，服务端读自己的计时器（不额外往返）。 */
    public boolean isCastingSpell() {
        return this.level().isClientSide
                ? this.entityData.get(DATA_SPELL_CASTING_ID) != SPELL_NONE
                : this.spellCastingTicks > 0;
    }

    private void setCastingSpell(byte spell) {
        this.entityData.set(DATA_SPELL_CASTING_ID, spell);
    }

    // ================================================================ 冷却

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SuppressorAbilityCooldown", this.abilityCooldown);
        tag.putInt("SuppressorWitherChargeCooldown", this.witherChargeCooldown);
        tag.putInt("SuppressorSpellCastingTicks", this.spellCastingTicks);
        tag.putInt("SuppressorCastWarmupTicks", this.castWarmupTicks);
        tag.putByte("SuppressorPendingSpell", this.pendingSpell);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.abilityCooldown = Math.max(0, tag.getInt("SuppressorAbilityCooldown"));
        this.witherChargeCooldown = Math.max(0, tag.getInt("SuppressorWitherChargeCooldown"));
        this.spellCastingTicks = Math.max(0, tag.getInt("SuppressorSpellCastingTicks"));
        this.castWarmupTicks = Math.max(0, tag.getInt("SuppressorCastWarmupTicks"));
        this.pendingSpell = tag.getByte("SuppressorPendingSpell");
        // 同步字节跟着本地计时器复位，避免重载后客户端一直保持"施法中"。
        this.setCastingSpell(this.spellCastingTicks > 0 ? this.pendingSpell : SPELL_NONE);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.isCastingSpell()) {
                this.spawnCastingParticles();
            }
            return;
        }
        if (this.abilityCooldown > 0) {
            this.abilityCooldown--;
        }
        if (this.enemyScanCooldown > 0) {
            this.enemyScanCooldown--;
        }
        if (this.spellCastingTicks > 0) {
            this.spellCastingTicks--;
        }
        if (this.castWarmupTicks > 0) {
            this.castWarmupTicks--;
            if (this.castWarmupTicks == 0) {
                this.performSpell();
            }
        }
        if (this.spellCastingTicks == 0 && this.pendingSpell != SPELL_NONE) {
            this.clearCastState();
        }
        this.deflectNearbyProjectiles();
    }

    /**
     * 独立的远程攻击计时。每 5 秒朝可见范围内的当前目标发射一枚凋零飞弹
     * （{@link WitherCharge}，与诡影使徒同款）；两种法术正在施法时暂缓发射，
     * 冷却仍继续计时，法术结束后即可补发。
     *
     * <p>发射条件与两种法术共用同一道闸门 {@link #resolveCastTarget()}：<b>只打真实敌人</b>，
     * 附近有牲畜或村民时不会"对着路人开火"；敌人打上门但还没被正式锁定时，先把它认成目标
     * 再开火，不会出现"挨打却一弹不发"。</p>
     */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.witherChargeCooldown > 0) {
            this.witherChargeCooldown--;
        }
        if (this.witherChargeCooldown > 0 || this.spellCastingTicks > 0) {
            return;
        }
        LivingEntity target = this.resolveCastTarget();
        if (target == null || !this.hasLineOfSight(target)) {
            return;
        }
        if (this.fireWitherCharge(target)) {
            this.witherChargeCooldown = WITHER_CHARGE_INTERVAL_TICKS;
        }
    }

    /**
     * 朝目标发射凋零飞弹；返回 false 表示目标与发射点重合，未消耗冷却。
     *
     * <p>发射音效用的是<b>火焰弹发射</b>（{@link SoundEvents#FIRECHARGE_USE}，即原版火焰弹
     * 被射出时的那声"呼"），音高在 1.0 附近小幅抖动，避免连续射击听起来像复制粘贴。</p>
     */
    private boolean fireWitherCharge(LivingEntity target) {
        Vec3 eyePos = this.getEyePosition();
        Vec3 direction = target.getEyePosition().subtract(eyePos);
        if (direction.lengthSqr() < 1.0E-6D) {
            return false;
        }
        direction = direction.normalize();
        WitherCharge charge = new WitherCharge(this, this.level(), direction);
        charge.setPos(eyePos.x + direction.x * 0.5D, eyePos.y + direction.y * 0.5D,
                eyePos.z + direction.z * 0.5D);
        // 反转士属于凋灵骷髅阵营，飞弹起爆不溅射身边同袍。
        charge.setFactionPassthrough(true);
        charge.launch(direction);
        this.level().addFreshEntity(charge);
        this.playSound(SoundEvents.FIRECHARGE_USE, 1.0F,
                0.92F + this.getRandom().nextFloat() * 0.16F);
        return true;
    }

    // ================================================================ 抛射物反弹护盾

    /**
     * 半径 {@value #DEFLECT_RADIUS} 格的"原路返回"气泡：把正在朝自己飞来的、来自非凋灵
     * 骷髅阵营生物的抛射物按原方向弹回去（速度取反）。
     *
     * <p>逐刻扫一次：这样擦着身边飞过、本来不会命中的弹丸也会被弹开，而不是只在
     * 命中那一帧才反应。真正打到判定箱里的高速弹丸由
     * {@link SuppressorProjectileHandler} 在 {@code ProjectileImpactEvent} 上兜底取消。</p>
     */
    private void deflectNearbyProjectiles() {
        List<Projectile> incoming = this.level().getEntitiesOfClass(Projectile.class,
                this.getBoundingBox().inflate(DEFLECT_RADIUS),
                projectile -> this.distanceToSqr(projectile) <= DEFLECT_RADIUS_SQR
                        && canDeflect(projectile, this));
        for (Projectile projectile : incoming) {
            reflectProjectile(projectile, this);
        }
    }

    /**
     * 该抛射物是否属于"要被弹回"的对象：活着、不是自己射的、不是圣光炸弹（它有自己的
     * 强制伤害链路）、发射者是可追溯的生物且不属于凋灵骷髅阵营、并且此刻正朝自己靠近。
     *
     * <p>加"正在靠近"这条闸门是为了防抖：弹出去之后速度已反向，
     * {@code delta·(自己 − 弹体)} 变负，同一枚弹丸不会被自己反复弹回来。</p>
     */
    static boolean canDeflect(Projectile projectile, Suppressor suppressor) {
        if (!projectile.isAlive() || projectile.getOwner() == suppressor) {
            return false;
        }
        // 插进方块的箭/三叉戟带着一个"假速度"（插地姿态向量），不排除就会被弹上天。
        if (!ProjectileFlightTracker.isActuallyFlying(projectile)) {
            return false;
        }
        if (projectile instanceof HolyBomb) {
            return false;
        }
        Entity owner = projectile.getOwner();
        if (!(owner instanceof LivingEntity) || MesmerizerControl.isWitherSkeletonFaction(owner)) {
            return false;
        }
        Vec3 delta = projectile.getDeltaMovement();
        return delta.dot(suppressor.position().subtract(projectile.position())) > 0.0D;
    }

    /** 原路返回：速度取反，并把弹体推到气泡外沿，保证它下一帧不再落在 2 格判定里。 */
    static void reflectProjectile(Projectile projectile, Suppressor suppressor) {
        Vec3 delta = projectile.getDeltaMovement();
        double speed = delta.length();
        if (speed < 1.0E-4D) {
            return;
        }
        Vec3 outgoing = delta.scale(-1.0D / speed);
        double push = DEFLECT_RADIUS + DEFLECT_PUSH_OUT;
        Vec3 pos = projectile.position();
        projectile.setPos(suppressor.getX() + outgoing.x * push, pos.y,
                suppressor.getZ() + outgoing.z * push);
        projectile.setDeltaMovement(outgoing.scale(speed));
        projectile.hasImpulse = true;
    }

    // ================================================================ 能力

    /**
     * 是否值得抬手：冷却走完、不在施法中，并且<b>射程内有真实敌人</b>。
     *
     * <p>旧实现写成"半径 30 格内的非阵营生物 ≥ 2 就返回 true"，那个计数把附近所有活物都
     * 算进去——牛羊、村民、宠物、别的模组的中立生物都成了"敌人"，于是反转士在没有敌人的
     * 地方也会每隔 40 秒对着路人放一次法术。现在起手统一以 {@link #resolveCastTarget()} 为准：
     * 只认已经锁定的目标，或射程内正在与阵营为敌的真实敌人（{@link #isFactionEnemy}）。</p>
     *
     * <p>范围重力反转的<b>结算</b>不受这里影响：起手之后仍按
     * {@link #enemiesInRange()} 无差别作用到半径 30 格内全部非阵营生物。</p>
     */
    private boolean canCastAbility() {
        if (this.level().isClientSide) {
            return false;
        }
        return this.resolveCastTarget() != null;
    }

    /**
     * 出手对象：优先取已经锁定、且仍然合法的单体目标；没有锁定时，就近认一个真实敌人
     * （{@link #isFactionEnemy}）并把它补成当前目标。
     *
     * <p>为什么不能只看 {@code getTarget()}：原版骷髅系的目标表只有玩家、铁傀儡、猪灵
     * （外加本模组补的蓝图器械），雪傀儡这类阵营宿敌、以及别的模组里正把阵营成员当猎物的
     * 生物都不在其中。它们打上门时反转士既没有目标、出手闸门又只认 {@code getTarget()}，
     * 于是两种法术与凋零飞弹一起哑火，站在原地发呆。这里把"已经锁定的目标"和"射程内正在
     * 与阵营为敌的真实敌人"合成同一条出手判据：既不会对着牛羊村民抬手
     * （{@link #isFactionEnemy} 的名单很窄），也不会漏掉打上门的敌人。</p>
     */
    private LivingEntity resolveCastTarget() {
        LivingEntity current = this.getTarget();
        if (this.isValidSingleTarget(current)) {
            this.castTarget = current;
            return current;
        }
        LivingEntity enemy = this.nearestFactionEnemy();
        if (!this.isValidSingleTarget(enemy)) {
            this.castTarget = null;
            return null;
        }
        if (current != enemy) {
            this.setTarget(enemy);
        }
        this.castTarget = enemy;
        return enemy;
    }

    /**
     * 射程内最近的真实敌人；结果缓存 {@value #ENEMY_SCAN_INTERVAL_TICKS} 刻，
     * 免得冷却就绪却四下无敌人时每 tick 扫一遍半径 30 的实体。
     */
    private LivingEntity nearestFactionEnemy() {
        if (this.enemyScanCooldown > 0) {
            return this.nearbyEnemy != null && this.nearbyEnemy.isAlive() ? this.nearbyEnemy : null;
        }
        this.enemyScanCooldown = ENEMY_SCAN_INTERVAL_TICKS;
        LivingEntity nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (LivingEntity entity : this.enemiesInRange()) {
            if (!isFactionEnemy(entity) || !this.hasLineOfSight(entity)) {
                continue;
            }
            double distance = this.distanceToSqr(entity);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = entity;
            }
        }
        this.nearbyEnemy = nearest;
        return nearest;
    }

    /**
     * 起手：定法术、进施法姿态并放前摇音。真正效果在 20 刻后的
     * {@link #performSpell()} 才结算，玩家有整整一秒的反应时间。
     */
    private void beginCast() {
        // canUse() 刚跑过 resolveCastTarget()，castTarget 就是本刻认下的敌人。
        LivingEntity target = this.castTarget != null ? this.castTarget : this.getTarget();
        boolean area = this.countFactionEnemiesInRange() >= AREA_ABILITY_MIN_TARGETS;
        this.pendingSpell = area ? SPELL_GRAVITY : SPELL_LEVITATION;
        this.pendingTarget = area ? null : target;
        // 冷却从起手就扣：放完 2 秒施法动画后只剩 38 秒。
        this.abilityCooldown = ABILITY_COOLDOWN_TICKS;
        this.spellCastingTicks = SPELL_CAST_TICKS;
        this.castWarmupTicks = SPELL_WARMUP_TICKS;
        this.setCastingSpell(this.pendingSpell);
        this.navigation.stop();
        this.playSound(area ? SoundEvents.EVOKER_PREPARE_SUMMON : SoundEvents.EVOKER_PREPARE_ATTACK, 1.0F, 1.0F);
    }

    /** 前摇到点：结算本次法术，并按唤魔者的方式补上施法音。 */
    private void performSpell() {
        if (this.pendingSpell == SPELL_GRAVITY) {
            this.castGravityReversal();
            this.playSound(SoundEvents.ILLUSIONER_CAST_SPELL, 1.0F, 0.7F);
            return;
        }
        LivingEntity target = this.pendingTarget;
        if (!this.isValidSingleTarget(target)) {
            target = this.getTarget();
        }
        if (this.isValidSingleTarget(target)) {
            this.castLevitation(target);
        }
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 1.0F, 1.4F);
    }

    /** 施法自然收尾时复位施法状态（冷却不回退）；施法不可打断，所以被抢占不会走到这里。 */
    private void clearCastState() {
        this.spellCastingTicks = 0;
        this.castWarmupTicks = 0;
        this.pendingSpell = SPELL_NONE;
        this.pendingTarget = null;
        this.castTarget = null;
        this.setCastingSpell(SPELL_NONE);
    }

    /** 能力 1：把目标挑上天，30 秒漂浮。 */
    private void castLevitation(LivingEntity target) {
        target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, ABILITY_DURATION_TICKS, 0), this);
        if (this.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.END_ROD,
                    target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                    24, 0.35D, 0.6D, 0.35D, 0.02D);
        }
    }

    /** 能力 2：半径 30 格内所有可作用生物 30 秒重力反转（无差别结算）。 */
    private void castGravityReversal() {
        List<LivingEntity> affected = this.enemiesInRange();
        for (LivingEntity entity : affected) {
            entity.addEffect(new MobEffectInstance(
                    GeneratedMod.GRAVITY_REVERSAL, ABILITY_DURATION_TICKS, 0), this);
            if (this.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.REVERSE_PORTAL,
                        entity.getX(), entity.getY() + entity.getBbHeight() * 0.5D, entity.getZ(),
                        20, 0.4D, 0.8D, 0.4D, 0.05D);
            }
        }
    }

    /**
     * 半径 30 格内的<b>全部</b>可作用生物（不区分敌我、不看是否在战斗）。
     * 这是重力反转的<b>结算</b>名单，不是出手判据——牲畜、村民、宠物都在里面。
     */
    private List<LivingEntity> enemiesInRange() {
        return this.level().getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(ABILITY_RADIUS), this::isAffectable);
    }

    /**
     * 半径 30 格内<b>真实敌人</b>的数量：只用来决定"值不值得为这一发范围重力反转抬手"，
     * 与上面那份无差别的结算名单是两回事。
     */
    private int countFactionEnemiesInRange() {
        if (this.level().isClientSide) {
            return 0;
        }
        int count = 0;
        for (LivingEntity entity : this.enemiesInRange()) {
            if (this.isFactionEnemy(entity)) {
                count++;
            }
        }
        return count;
    }

    /**
     * 是否是"确实会与凋灵骷髅阵营为敌"的生物，用于出手判据与阵营敌对索敌：
     *
     * <ul>
     *   <li>玩家：创造与旁观之外的一律算敌对（和原版索敌同口径，豁免模式在
     *       {@link #isAffectable} 里已被过滤掉）；</li>
     *   <li>铁傀儡、雪傀儡、猪灵系：阵营的原生宿敌（与狂战士／诡影使徒等兄弟生物的目标
     *       列表一致）；</li>
     *   <li>其他生物：只有它此刻正以某个阵营成员为攻击目标时才算——受击反击、传令兵护卫、
     *       阵营受击联动留下的仇恨都落在这里，一只被玩家训服的狼扑上来同样会被认出来。</li>
     * </ul>
     *
     * <p>最外层先过一遍 {@link MesmerizerControl#canAttack}：被反逆者心控的生物与反逆器械
     * 属于反逆者一侧，阵营本就不能打它们（目标变更事件也会把仇恨清掉），这里一并排除，
     * 免得它们被当成敌人、又把技能浪费在同袍身上。被排除的还有阵营成员自身——{@code
     * canAttack} 对同阵营返回 false。</p>
     *
     * <p>反过来说，牛羊、村民、宠物、以及任何没对阵营动手的中立生物都不算敌人；
     * 附近只有它们时反转士不会起手。</p>
     */
    private boolean isFactionEnemy(LivingEntity entity) {
        if (!MesmerizerControl.canAttack(this, entity)) {
            return false;
        }
        if (entity instanceof Player player) {
            return !player.isCreative() && !player.isSpectator();
        }
        if (entity instanceof IronGolem || entity instanceof SnowGolem
                || entity instanceof AbstractPiglin) {
            return true;
        }
        if (!(entity instanceof Mob mob)) {
            return false;
        }
        LivingEntity victim = mob.getTarget();
        return victim != null && victim.isAlive()
                && WitherFactionHostilityHandler.isWitherFaction(victim);
    }

    /**
     * 是否是能力 2 的作用对象：活着、不是自己、在球形半径内、不属于凋灵骷髅阵营，
     * 且不是创造模式／旁观玩家。半径用包围盒膨胀做粗筛（盒内才可能进球形判定），
     * 再补一次球面距离。
     */
    private boolean isAffectable(LivingEntity entity) {
        return entity != this
                && entity.isAlive()
                && !isExemptPlayer(entity)
                && this.distanceToSqr(entity) <= ABILITY_RADIUS_SQR
                && !WitherFactionHostilityHandler.isWitherFaction(entity);
    }

    /**
     * 能力 1 的合法单体目标：活着、非豁免玩家、非阵营同袍，且还在 30 格施法范围内。
     */
    private boolean isValidSingleTarget(LivingEntity target) {
        return target != null
                && target.isAlive()
                && !isExemptPlayer(target)
                && !WitherFactionHostilityHandler.isWitherFaction(target)
                && this.distanceToSqr(target) <= ABILITY_RADIUS_SQR;
    }

    /**
     * 技能豁免对象：创造模式与旁观玩家。创造模式玩家不会被反转士"索敌"，既不进
     * 单体漂浮的目标位，也不会被半径 30 格的重力反转 AoE 扫到；旁观本身没有重力，
     * 一并跳过以免出现无意义的翻转。
     */
    private static boolean isExemptPlayer(LivingEntity entity) {
        return entity instanceof Player player && (player.isCreative() || player.isSpectator());
    }

    /** 施法期间挂在双手位置的唤魔者同款粒子（颜色区分两种法术）。 */
    private void spawnCastingParticles() {
        boolean gravity = this.entityData.get(DATA_SPELL_CASTING_ID) == SPELL_GRAVITY;
        float red = gravity ? 0.7F : 0.4F;
        float green = gravity ? 0.7F : 0.3F;
        float blue = gravity ? 0.8F : 0.35F;
        float angle = this.yBodyRot * (float) (Math.PI / 180.0)
                + Mth.cos((float) this.tickCount * 0.6662F) * 0.25F;
        float cos = Mth.cos(angle);
        float sin = Mth.sin(angle);
        double radius = 0.6D * VISUAL_SCALE;
        double height = 1.8D * VISUAL_SCALE;
        ColorParticleOption particle = ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, red, green, blue);
        this.level().addParticle(particle,
                this.getX() + (double) cos * radius, this.getY() + height, this.getZ() + (double) sin * radius,
                0.0D, 0.0D, 0.0D);
        this.level().addParticle(particle,
                this.getX() - (double) cos * radius, this.getY() + height, this.getZ() - (double) sin * radius,
                0.0D, 0.0D, 0.0D);
    }

    /**
     * 阵营敌对索敌：把"真正与凋灵骷髅阵营为敌"的生物补进目标表。
     *
     * <p>原版骷髅系只挂玩家、铁傀儡、猪灵三个目标（本模组另在事件里补了蓝图器械），
     * 雪傀儡这种宿敌、以及别的模组里把阵营成员当猎物的生物都不在其中：它们打上门时
     * 反转士没有目标，两种法术与凋零飞弹的出手闸门一起落空，表现就是"敌人在眼前却站着
     * 发呆"。这里用与出手判据同源的 {@link #isFactionEnemy} 作谓词，只认会伤害阵营的
     * 敌人，牛羊村民宠物这类中立生物不会被点名。</p>
     *
     * <p>优先级 2：与玩家索敌同级，压过铁傀儡／猪灵／蓝图器械（3），低于受击反击（1）
     * 与传令兵护卫（0）。10 tick 一轮的随机间隔由父类负责，不会每 tick 全量扫描。</p>
     */
    private static final class FactionEnemyTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
        private FactionEnemyTargetGoal(Suppressor suppressor) {
            super(suppressor, LivingEntity.class, 10, true, false, suppressor::isFactionEnemy);
        }
    }

    /**
     * 施法目标：带 MOVE／LOOK 标志的一次性 {@link Goal}。
     *
     * <p>{@code canUse} 只在冷却走完且当前有值得施放的对象时为真；一旦起手，
     * {@code spellCastingTicks > 0} 就通过 {@code canContinueToUse} 把目标保持 40 刻，
     * 期间站定并盯着目标（与唤魔者 {@code SpellcasterCastingSpellGoal} 同款）。</p>
     *
     * <p><b>不可打断</b>：{@code stop()} 只交出 MOVE／LOOK 控制权（被更高级目标抢占、
     * 或施法自然结束时都会走到这里），<b>不</b>调用 {@code clearCastState()}。法术的
     * 前摇倒计时与结算都挂在实体自己的 {@code tick()} 上，所以哪怕这个目标中途被停，
     * 到点照样放出效果；冷却从起手就算起，也不会靠打断重刷。</p>
     */
    private static final class AbilityGoal extends Goal {
        private final Suppressor suppressor;

        private AbilityGoal(Suppressor suppressor) {
            this.suppressor = suppressor;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return this.suppressor.abilityCooldown <= 0
                    && this.suppressor.spellCastingTicks <= 0
                    && this.suppressor.canCastAbility();
        }

        @Override
        public boolean canContinueToUse() {
            return this.suppressor.spellCastingTicks > 0;
        }

        @Override
        public void start() {
            this.suppressor.beginCast();
        }

        @Override
        public void tick() {
            LivingEntity target = this.suppressor.pendingTarget != null
                    ? this.suppressor.pendingTarget
                    : this.suppressor.getTarget();
            if (target != null) {
                this.suppressor.getLookControl().setLookAt(target, 30.0F, 30.0F);
            }
        }

        @Override
        public void stop() {
            // 施法不可打断：只交出 MOVE／LOOK，施法状态继续由实体 tick 推进。
            // 自然结束时 tick() 已经 clearCastState()，这里再清一遍是幂等的。
            if (this.suppressor.spellCastingTicks <= 0) {
                this.suppressor.clearCastState();
            }
        }
    }

    /**
     * 远程站位目标：敌人一进技能射程就接管移动权——<b>原地站定，绝不主动接近</b>；
     * 只有敌人逼近到 {@value #RETREAT_ENTER} 格才朝反方向后撤，拉到
     * {@value #RETREAT_EXIT} 格开外收手。
     *
     * <p>优先级 2：低于施法（1），高于漫游（5）。{@code canUse} 只要"有活着的目标且在
     * {@value #POSITION_RANGE} 格内"就为真，于是目标进了射程之后 MOVE 标志长期被本目标
     * 占住，漫游目标接管不了——这就是"站立不动"的实现；近战目标已在
     * {@link #reassessWeaponGoal()} 里注销，"贴身也只会后退、不抡拳头"不再需要靠标志占用
     * 兜底。施法目标一旦起手（优先级 1）就会把本目标顶下去，于是"退着退着停下来抬手"
     * 是同一套优先级的结果。</p>
     *
     * <p>后撤取点走原版 {@code DefaultRandomPos.getPosAway}（保证落点比原地离威胁更远、
     * 且站得住），取不到就沿"威胁 → 自己"的反方向直退；连直线都算不出来（与目标重合）
     * 就只停住不动。铺不出路时只停导航、<b>不</b>释放移动权，避免把 MOVE 让给漫游后
     * 反而朝着目标晃过去。</p>
     */
    private static final class RangedPositionGoal extends Goal {
        private final Suppressor suppressor;
        private int repathCooldown;

        private RangedPositionGoal(Suppressor suppressor) {
            this.suppressor = suppressor;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return this.canKeepPositioning();
        }

        @Override
        public boolean canContinueToUse() {
            return this.canKeepPositioning();
        }

        /** 有活着的目标、不在施法、且目标还在接管的横向距离内。 */
        private boolean canKeepPositioning() {
            LivingEntity target = this.suppressor.getTarget();
            return target != null && target.isAlive()
                    && !this.suppressor.isCastingSpell()
                    && this.suppressor.distanceToSqr(target) <= POSITION_RANGE_SQR;
        }

        @Override
        public void start() {
            this.repathCooldown = 0;
        }

        @Override
        public void stop() {
            this.suppressor.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.suppressor.getTarget();
            if (target == null) {
                return;
            }
            this.suppressor.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (this.suppressor.distanceToSqr(target) > RETREAT_ENTER * RETREAT_ENTER) {
                // 敌人在技能射程内但还没逼近：站定，别凑上去。
                this.suppressor.getNavigation().stop();
                return;
            }
            if (this.repathCooldown-- > 0 && this.suppressor.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = RETREAT_REPATH_INTERVAL;
            Vec3 away = this.awayPoint(target);
            if (away == null || !this.suppressor.getNavigation().moveTo(away.x, away.y, away.z, RETREAT_SPEED)) {
                this.suppressor.getNavigation().stop();
            }
        }

        /** 后撤落点：优先原版取点器给出的、确实离威胁更远的站位；取不到就直线反退。 */
        private Vec3 awayPoint(LivingEntity target) {
            Vec3 away = DefaultRandomPos.getPosAway(this.suppressor,
                    RETREAT_PROBE_RADIUS, RETREAT_PROBE_HEIGHT, target.position());
            if (away != null
                    && target.distanceToSqr(away.x, away.y, away.z) > this.suppressor.distanceToSqr(target)) {
                return away;
            }
            Vec3 dir = this.suppressor.position().subtract(target.position());
            Vec3 flat = new Vec3(dir.x, 0.0D, dir.z);
            if (flat.lengthSqr() < 1.0E-6D) {
                return null;
            }
            return this.suppressor.position().add(flat.normalize().scale(RETREAT_EXIT));
        }
    }
}
