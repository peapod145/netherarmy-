package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;

/**
 * 御首者法杖层模型（杖纹贴图 c57fafb7，32x32）：杖杆 + 杖尖 + 16 块悬浮装饰。
 *
 * <p>只含 bbmodel staff 骨骼树里用杖纹贴图的部分；杖头（staffhead）用的是主贴图，
 * 留在 {@link HeadDominatorModel}。两层共用 staff 骨骼枢轴 (−5,24,−8)（java 空间，
 * 换算口径见 {@link HeadDominatorPose}），
 * 施法动画的抬杖位移由 {@link HeadDominatorPose#apply} 对两层同帧应用，
 * 因此永远贴合。</p>
 */
public class HeadDominatorStaffModel extends EntityModel<HeadDominator> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "head_dominator_staff"), "main");

    private final ModelPart staff;

    public HeadDominatorStaffModel(ModelPart root) {
        this.staff = root.getChild("staff");
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        staff.render(poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public void setupAnim(HeadDominator entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HeadDominatorPose.apply(null, null, null, null, null, null, this.staff, null,
                entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition parent = mesh.getRoot();
        PartDefinition staff = parent.addOrReplaceChild("staff", CubeListBuilder.create(), PartPose.offset(-5F, 24F, -8F));
        { // 杖杆：bb y1..32，四面顺排 (0/2/4/6,0)，端面 1px
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 0F, 0F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            face(builder, Direction.SOUTH, 4F, 0F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            face(builder, Direction.WEST, 2F, 0F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            face(builder, Direction.EAST, 6F, 0F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            face(builder, Direction.UP, 12F, 11F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            face(builder, Direction.DOWN, 26F, 14F, -0.5F, -32F, -0.5F, 1F, 31F, 1F);
            staff.addOrReplaceChild("shaft", builder, PartPose.offset(0.0F, 0.0F, 0.0F));
        }
        { // 杖尖（X45° 烘进 PartPose）
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 20F, 5F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            face(builder, Direction.SOUTH, 23F, 7F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            face(builder, Direction.WEST, 22F, 0F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            face(builder, Direction.EAST, 22F, 0F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            face(builder, Direction.UP, 27F, 22F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            face(builder, Direction.DOWN, 25F, 27F, -0.375F, -0.875F, -0.875F, 0.75F, 1.75F, 1.75F);
            staff.addOrReplaceChild("tip", builder, PartPose.offsetAndRotation(0F, 0.25F, 0F, -45F, 0F, 0F));
        }
        PartDefinition group = staff.addOrReplaceChild("group", CubeListBuilder.create(), PartPose.offset(0F, -18.8F, 0F));
        { // 悬浮装饰簇 0
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 8F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.SOUTH, 10F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.WEST, 9F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.EAST, 10F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.UP, 28F, 6F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.DOWN, 28F, 14F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            group.addOrReplaceChild("deco0", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 0F, 0F));
        }
        { // 悬浮装饰簇 1
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 26F, 27F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 22F, 3F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 27F, 26F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 0F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco1", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 0F, 0F));
        }
        { // 悬浮装饰簇 2
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 15F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.SOUTH, 23F, 3F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.WEST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.EAST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.UP, 17F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.DOWN, 24F, 7F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            group.addOrReplaceChild("deco2", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 0F, 0F));
        }
        { // 悬浮装饰簇 3
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 28F, 4F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 28F, 2F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 12F, 28F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 12F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco3", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 0F, 0F));
        }
        { // 悬浮装饰簇 4
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 8F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.SOUTH, 10F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.WEST, 9F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.EAST, 10F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.UP, 28F, 6F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.DOWN, 28F, 14F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            group.addOrReplaceChild("deco4", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 90F, 0F));
        }
        { // 悬浮装饰簇 5
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 26F, 27F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 22F, 3F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 27F, 26F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 0F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco5", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 90F, 0F));
        }
        { // 悬浮装饰簇 6
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 15F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.SOUTH, 23F, 3F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.WEST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.EAST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.UP, 17F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.DOWN, 24F, 7F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            group.addOrReplaceChild("deco6", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 90F, 0F));
        }
        { // 悬浮装饰簇 7
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 28F, 4F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 28F, 2F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 12F, 28F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 12F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco7", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, 90F, 0F));
        }
        { // 悬浮装饰簇 8
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 28F, 17F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            face(builder, Direction.SOUTH, 19F, 28F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            face(builder, Direction.WEST, 26F, 10F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            face(builder, Direction.EAST, 26F, 11F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            face(builder, Direction.UP, 19F, 20F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            face(builder, Direction.DOWN, 21F, 5F, -0.5125F, 0.1893F, -2.3107F, 1.025F, 0.5F, 2.5F);
            group.addOrReplaceChild("deco8", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 0F, 0F));
        }
        { // 悬浮装饰簇 9
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 22F, 3F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 26F, 27F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 12F, 11F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 12F, 11F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 27F, 26F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 0F, -0.25F, -0.1893F, -3.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco9", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 0F, 0F));
        }
        { // 悬浮装饰簇 10
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 23F, 3F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.SOUTH, 15F, 23F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.WEST, 15F, 9F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.EAST, 15F, 9F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.UP, 17F, 23F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.DOWN, 24F, 7F, -0.375F, 0.3965F, -3.1036F, 0.75F, 2F, 2F);
            group.addOrReplaceChild("deco10", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 0F, 0F));
        }
        { // 悬浮装饰簇 11
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 28F, 2F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 28F, 4F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 29F, 19F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 29F, 19F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 12F, 28F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 12F, -0.25F, 2.1893F, -0.8107F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco11", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, 0F, 0F));
        }
        { // 悬浮装饰簇 12
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 8F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.SOUTH, 10F, 18F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.WEST, 9F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.EAST, 10F, 25F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.UP, 28F, 6F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            face(builder, Direction.DOWN, 28F, 14F, -0.5125F, -2.8107F, 0.1893F, 1.025F, 3.5F, 0.5F);
            group.addOrReplaceChild("deco12", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, -45F, -90F, 0F));
        }
        { // 悬浮装饰簇 13
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 26F, 27F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 22F, 3F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 12F, 11F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 27F, 26F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 0F, -0.25F, -0.1893F, 2.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco13", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, -90F, 0F));
        }
        { // 悬浮装饰簇 14
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 15F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.SOUTH, 23F, 3F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.WEST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.EAST, 15F, 9F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.UP, 17F, 23F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            face(builder, Direction.DOWN, 24F, 7F, -0.375F, 0.3965F, 1.1036F, 0.75F, 2F, 2F);
            group.addOrReplaceChild("deco14", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, -90F, 0F));
        }
        { // 悬浮装饰簇 15
            CubeListBuilder builder = CubeListBuilder.create();
            face(builder, Direction.NORTH, 28F, 4F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.SOUTH, 28F, 2F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.WEST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.EAST, 29F, 19F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.UP, 12F, 28F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            face(builder, Direction.DOWN, 28F, 12F, -0.25F, 2.1893F, -0.1893F, 0.5F, 1F, 1F);
            group.addOrReplaceChild("deco15", builder, PartPose.offsetAndRotation(0F, -10.5F, 0F, 45F, -90F, 0F));
        }
        return LayerDefinition.create(mesh, 32, 32);
    }

    private static void face(CubeListBuilder builder, Direction dir, float u, float v,
                             float x, float y, float z, float w, float h, float d) {
        HeadDominatorPose.face(builder, dir, u, v, x, y, z, w, h, d);
    }
}
