package cn.blockforge.generated.netherarmy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 御首者法杖层（杖纹贴图 c57fafb7，32x32）：杖杆 + 杖尖 + 16 块悬浮装饰。
 * 由 tools/gen_head_dominator_quads.py 生成。
 *
 * <p>这里的贴图拉伸最典型：杖杆盒子只有 1x31x1，UV 矩形却是 2x32；装饰簇盒子
 * 1.025x3.5x0.5，UV 是 2x7。用 CubeListBuilder 的 texOffs 只能取到矩形的左上角，
 * 所以改走 {@link HackerQuads} 直发四边形，UV 按 bbmodel 原始矩形走。</p>
 *
 * <p>只含 bbmodel staff 骨骼树里用杖纹贴图的部分；杖头（staffhead）用主贴图，
 * 留在 {@link HeadDominatorModel}。两层共用 staff 骨枢轴（java 空间 (−5,24,−8)），
 * 施法抬杖位移由 {@link HeadDominatorPose#apply} 对两层同帧应用，永远贴合。</p>
 */
public class HeadDominatorStaffModel extends EntityModel<HeadDominator> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "head_dominator_staff"), "main");
    private static final int TEX_WIDTH = 32;
    private static final int TEX_HEIGHT = 32;

    private final ModelPart staff;
    private final ModelPart shaft;
    private final ModelPart tip;
    private final ModelPart group;
    private final ModelPart deco0;
    private final ModelPart deco1;
    private final ModelPart deco2;
    private final ModelPart deco3;
    private final ModelPart deco4;
    private final ModelPart deco5;
    private final ModelPart deco6;
    private final ModelPart deco7;
    private final ModelPart deco8;
    private final ModelPart deco9;
    private final ModelPart deco10;
    private final ModelPart deco11;
    private final ModelPart deco12;
    private final ModelPart deco13;
    private final ModelPart deco14;
    private final ModelPart deco15;

    private static final float[] SHAFT = {
            -0.5F, -32.0F, -0.5F, 0.5F, -32.0F, -0.5F, 0.5F, -1.0F, -0.5F, -0.5F,
            -1.0F, -0.5F, 0.0F, 0.0F, 2.0F, 32.0F, 0.0F, 0.0F, -1.0F, 0.5F,
            -32.0F, 0.5F, -0.5F, -32.0F, 0.5F, -0.5F, -1.0F, 0.5F, 0.5F, -1.0F,
            0.5F, 4.0F, 0.0F, 6.0F, 32.0F, 0.0F, 0.0F, 1.0F, -0.5F, -32.0F,
            0.5F, -0.5F, -32.0F, -0.5F, -0.5F, -1.0F, -0.5F, -0.5F, -1.0F, 0.5F,
            2.0F, 0.0F, 4.0F, 32.0F, -1.0F, 0.0F, 0.0F, 0.5F, -32.0F, -0.5F,
            0.5F, -32.0F, 0.5F, 0.5F, -1.0F, 0.5F, 0.5F, -1.0F, -0.5F, 6.0F,
            0.0F, 8.0F, 32.0F, 1.0F, 0.0F, 0.0F, 0.5F, -32.0F, -0.5F, -0.5F,
            -32.0F, -0.5F, -0.5F, -32.0F, 0.5F, 0.5F, -32.0F, 0.5F, 14.0F, 13.0F,
            12.0F, 11.0F, 0.0F, -1.0F, 0.0F, 0.5F, -1.0F, 0.5F, -0.5F, -1.0F,
            0.5F, -0.5F, -1.0F, -0.5F, 0.5F, -1.0F, -0.5F, 28.0F, 14.0F, 26.0F,
            16.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] TIP = {
            -0.375F, -0.875F, -0.875F, 0.375F, -0.875F, -0.875F, 0.375F, 0.875F, -0.875F, -0.375F,
            0.875F, -0.875F, 20.0F, 5.0F, 21.0F, 8.0F, 0.0F, 0.0F, -1.0F, 0.375F,
            -0.875F, 0.875F, -0.375F, -0.875F, 0.875F, -0.375F, 0.875F, 0.875F, 0.375F, 0.875F,
            0.875F, 23.0F, 7.0F, 24.0F, 10.0F, 0.0F, 0.0F, 1.0F, -0.375F, -0.875F,
            0.875F, -0.375F, -0.875F, -0.875F, -0.375F, 0.875F, -0.875F, -0.375F, 0.875F, 0.875F,
            22.0F, 0.0F, 25.0F, 3.0F, -1.0F, 0.0F, 0.0F, 0.375F, -0.875F, -0.875F,
            0.375F, -0.875F, 0.875F, 0.375F, 0.875F, 0.875F, 0.375F, 0.875F, -0.875F, 25.0F,
            0.0F, 22.0F, 3.0F, 1.0F, 0.0F, 0.0F, 0.375F, -0.875F, -0.875F, -0.375F,
            -0.875F, -0.875F, -0.375F, -0.875F, 0.875F, 0.375F, -0.875F, 0.875F, 28.0F, 25.0F,
            27.0F, 22.0F, 0.0F, -1.0F, 0.0F, 0.375F, 0.875F, 0.875F, -0.375F, 0.875F,
            0.875F, -0.375F, 0.875F, -0.875F, 0.375F, 0.875F, -0.875F, 26.0F, 27.0F, 25.0F,
            30.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO0 = {
            -0.5125F, -2.81066F, 0.18934F, 0.5125F, -2.81066F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, -0.5125F,
            0.68934F, 0.18934F, 8.0F, 18.0F, 10.0F, 25.0F, 0.0F, 0.0F, -1.0F, 0.5125F,
            -2.81066F, 0.68934F, -0.5125F, -2.81066F, 0.68934F, -0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F,
            0.68934F, 10.0F, 18.0F, 12.0F, 25.0F, 0.0F, 0.0F, 1.0F, -0.5125F, -2.81066F,
            0.68934F, -0.5125F, -2.81066F, 0.18934F, -0.5125F, 0.68934F, 0.18934F, -0.5125F, 0.68934F, 0.68934F,
            9.0F, 25.0F, 10.0F, 32.0F, -1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F,
            0.5125F, -2.81066F, 0.68934F, 0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F, 0.18934F, 10.0F,
            25.0F, 11.0F, 32.0F, 1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F, -0.5125F,
            -2.81066F, 0.18934F, -0.5125F, -2.81066F, 0.68934F, 0.5125F, -2.81066F, 0.68934F, 30.0F, 7.0F,
            28.0F, 6.0F, 0.0F, -1.0F, 0.0F, 0.5125F, 0.68934F, 0.68934F, -0.5125F, 0.68934F,
            0.68934F, -0.5125F, 0.68934F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, 30.0F, 14.0F, 28.0F,
            15.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO1 = {
            -0.25F, -0.18934F, 2.18934F, 0.25F, -0.18934F, 2.18934F, 0.25F, 0.81066F, 2.18934F, -0.25F,
            0.81066F, 2.18934F, 27.0F, 27.0F, 26.0F, 29.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            -0.18934F, 3.18934F, -0.25F, -0.18934F, 3.18934F, -0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F,
            3.18934F, 23.0F, 3.0F, 22.0F, 5.0F, 0.0F, 0.0F, 1.0F, -0.25F, -0.18934F,
            3.18934F, -0.25F, -0.18934F, 2.18934F, -0.25F, 0.81066F, 2.18934F, -0.25F, 0.81066F, 3.18934F,
            14.0F, 11.0F, 12.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F,
            0.25F, -0.18934F, 3.18934F, 0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F, 2.18934F, 12.0F,
            11.0F, 14.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F, -0.25F,
            -0.18934F, 2.18934F, -0.25F, -0.18934F, 3.18934F, 0.25F, -0.18934F, 3.18934F, 28.0F, 26.0F,
            27.0F, 28.0F, 0.0F, -1.0F, 0.0F, 0.25F, 0.81066F, 3.18934F, -0.25F, 0.81066F,
            3.18934F, -0.25F, 0.81066F, 2.18934F, 0.25F, 0.81066F, 2.18934F, 29.0F, 2.0F, 28.0F,
            0.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO2 = {
            -0.375F, 0.39645F, 1.10355F, 0.375F, 0.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, -0.375F,
            2.39645F, 1.10355F, 17.0F, 23.0F, 15.0F, 27.0F, 0.0F, 0.0F, -1.0F, 0.375F,
            0.39645F, 3.10355F, -0.375F, 0.39645F, 3.10355F, -0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F,
            3.10355F, 25.0F, 3.0F, 23.0F, 7.0F, 0.0F, 0.0F, 1.0F, -0.375F, 0.39645F,
            3.10355F, -0.375F, 0.39645F, 1.10355F, -0.375F, 2.39645F, 1.10355F, -0.375F, 2.39645F, 3.10355F,
            19.0F, 9.0F, 15.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F,
            0.375F, 0.39645F, 3.10355F, 0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F, 1.10355F, 15.0F,
            9.0F, 19.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F, -0.375F,
            0.39645F, 1.10355F, -0.375F, 0.39645F, 3.10355F, 0.375F, 0.39645F, 3.10355F, 19.0F, 23.0F,
            17.0F, 27.0F, 0.0F, -1.0F, 0.0F, 0.375F, 2.39645F, 3.10355F, -0.375F, 2.39645F,
            3.10355F, -0.375F, 2.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, 26.0F, 11.0F, 24.0F,
            7.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO3 = {
            -0.25F, 2.18934F, -0.18934F, 0.25F, 2.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, -0.25F,
            3.18934F, -0.18934F, 29.0F, 4.0F, 28.0F, 6.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            2.18934F, 0.81066F, -0.25F, 2.18934F, 0.81066F, -0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F,
            0.81066F, 29.0F, 2.0F, 28.0F, 4.0F, 0.0F, 0.0F, 1.0F, -0.25F, 2.18934F,
            0.81066F, -0.25F, 2.18934F, -0.18934F, -0.25F, 3.18934F, -0.18934F, -0.25F, 3.18934F, 0.81066F,
            31.0F, 19.0F, 29.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F,
            0.25F, 2.18934F, 0.81066F, 0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F, -0.18934F, 29.0F,
            19.0F, 31.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F, -0.25F,
            2.18934F, -0.18934F, -0.25F, 2.18934F, 0.81066F, 0.25F, 2.18934F, 0.81066F, 13.0F, 28.0F,
            12.0F, 30.0F, 0.0F, -1.0F, 0.0F, 0.25F, 3.18934F, 0.81066F, -0.25F, 3.18934F,
            0.81066F, -0.25F, 3.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, 29.0F, 14.0F, 28.0F,
            12.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO4 = {
            -0.5125F, -2.81066F, 0.18934F, 0.5125F, -2.81066F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, -0.5125F,
            0.68934F, 0.18934F, 8.0F, 18.0F, 10.0F, 25.0F, 0.0F, 0.0F, -1.0F, 0.5125F,
            -2.81066F, 0.68934F, -0.5125F, -2.81066F, 0.68934F, -0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F,
            0.68934F, 10.0F, 18.0F, 12.0F, 25.0F, 0.0F, 0.0F, 1.0F, -0.5125F, -2.81066F,
            0.68934F, -0.5125F, -2.81066F, 0.18934F, -0.5125F, 0.68934F, 0.18934F, -0.5125F, 0.68934F, 0.68934F,
            9.0F, 25.0F, 10.0F, 32.0F, -1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F,
            0.5125F, -2.81066F, 0.68934F, 0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F, 0.18934F, 10.0F,
            25.0F, 11.0F, 32.0F, 1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F, -0.5125F,
            -2.81066F, 0.18934F, -0.5125F, -2.81066F, 0.68934F, 0.5125F, -2.81066F, 0.68934F, 30.0F, 7.0F,
            28.0F, 6.0F, 0.0F, -1.0F, 0.0F, 0.5125F, 0.68934F, 0.68934F, -0.5125F, 0.68934F,
            0.68934F, -0.5125F, 0.68934F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, 30.0F, 14.0F, 28.0F,
            15.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO5 = {
            -0.25F, -0.18934F, 2.18934F, 0.25F, -0.18934F, 2.18934F, 0.25F, 0.81066F, 2.18934F, -0.25F,
            0.81066F, 2.18934F, 27.0F, 27.0F, 26.0F, 29.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            -0.18934F, 3.18934F, -0.25F, -0.18934F, 3.18934F, -0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F,
            3.18934F, 23.0F, 3.0F, 22.0F, 5.0F, 0.0F, 0.0F, 1.0F, -0.25F, -0.18934F,
            3.18934F, -0.25F, -0.18934F, 2.18934F, -0.25F, 0.81066F, 2.18934F, -0.25F, 0.81066F, 3.18934F,
            14.0F, 11.0F, 12.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F,
            0.25F, -0.18934F, 3.18934F, 0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F, 2.18934F, 12.0F,
            11.0F, 14.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F, -0.25F,
            -0.18934F, 2.18934F, -0.25F, -0.18934F, 3.18934F, 0.25F, -0.18934F, 3.18934F, 28.0F, 26.0F,
            27.0F, 28.0F, 0.0F, -1.0F, 0.0F, 0.25F, 0.81066F, 3.18934F, -0.25F, 0.81066F,
            3.18934F, -0.25F, 0.81066F, 2.18934F, 0.25F, 0.81066F, 2.18934F, 29.0F, 2.0F, 28.0F,
            0.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO6 = {
            -0.375F, 0.39645F, 1.10355F, 0.375F, 0.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, -0.375F,
            2.39645F, 1.10355F, 17.0F, 23.0F, 15.0F, 27.0F, 0.0F, 0.0F, -1.0F, 0.375F,
            0.39645F, 3.10355F, -0.375F, 0.39645F, 3.10355F, -0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F,
            3.10355F, 25.0F, 3.0F, 23.0F, 7.0F, 0.0F, 0.0F, 1.0F, -0.375F, 0.39645F,
            3.10355F, -0.375F, 0.39645F, 1.10355F, -0.375F, 2.39645F, 1.10355F, -0.375F, 2.39645F, 3.10355F,
            19.0F, 9.0F, 15.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F,
            0.375F, 0.39645F, 3.10355F, 0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F, 1.10355F, 15.0F,
            9.0F, 19.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F, -0.375F,
            0.39645F, 1.10355F, -0.375F, 0.39645F, 3.10355F, 0.375F, 0.39645F, 3.10355F, 19.0F, 23.0F,
            17.0F, 27.0F, 0.0F, -1.0F, 0.0F, 0.375F, 2.39645F, 3.10355F, -0.375F, 2.39645F,
            3.10355F, -0.375F, 2.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, 26.0F, 11.0F, 24.0F,
            7.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO7 = {
            -0.25F, 2.18934F, -0.18934F, 0.25F, 2.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, -0.25F,
            3.18934F, -0.18934F, 29.0F, 4.0F, 28.0F, 6.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            2.18934F, 0.81066F, -0.25F, 2.18934F, 0.81066F, -0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F,
            0.81066F, 29.0F, 2.0F, 28.0F, 4.0F, 0.0F, 0.0F, 1.0F, -0.25F, 2.18934F,
            0.81066F, -0.25F, 2.18934F, -0.18934F, -0.25F, 3.18934F, -0.18934F, -0.25F, 3.18934F, 0.81066F,
            31.0F, 19.0F, 29.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F,
            0.25F, 2.18934F, 0.81066F, 0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F, -0.18934F, 29.0F,
            19.0F, 31.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F, -0.25F,
            2.18934F, -0.18934F, -0.25F, 2.18934F, 0.81066F, 0.25F, 2.18934F, 0.81066F, 13.0F, 28.0F,
            12.0F, 30.0F, 0.0F, -1.0F, 0.0F, 0.25F, 3.18934F, 0.81066F, -0.25F, 3.18934F,
            0.81066F, -0.25F, 3.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, 29.0F, 14.0F, 28.0F,
            12.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO8 = {
            -0.5125F, 0.18934F, -2.31066F, 0.5125F, 0.18934F, -2.31066F, 0.5125F, 0.68934F, -2.31066F, -0.5125F,
            0.68934F, -2.31066F, 28.0F, 17.0F, 30.0F, 18.0F, 0.0F, 0.0F, -1.0F, 0.5125F,
            0.18934F, 0.18934F, -0.5125F, 0.18934F, 0.18934F, -0.5125F, 0.68934F, 0.18934F, 0.5125F, 0.68934F,
            0.18934F, 19.0F, 28.0F, 21.0F, 29.0F, 0.0F, 0.0F, 1.0F, -0.5125F, 0.18934F,
            0.18934F, -0.5125F, 0.18934F, -2.31066F, -0.5125F, 0.68934F, -2.31066F, -0.5125F, 0.68934F, 0.18934F,
            26.0F, 10.0F, 31.0F, 11.0F, -1.0F, 0.0F, 0.0F, 0.5125F, 0.18934F, -2.31066F,
            0.5125F, 0.18934F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, 0.5125F, 0.68934F, -2.31066F, 26.0F,
            11.0F, 31.0F, 12.0F, 1.0F, 0.0F, 0.0F, 0.5125F, 0.18934F, -2.31066F, -0.5125F,
            0.18934F, -2.31066F, -0.5125F, 0.18934F, 0.18934F, 0.5125F, 0.18934F, 0.18934F, 21.0F, 25.0F,
            19.0F, 20.0F, 0.0F, -1.0F, 0.0F, 0.5125F, 0.68934F, 0.18934F, -0.5125F, 0.68934F,
            0.18934F, -0.5125F, 0.68934F, -2.31066F, 0.5125F, 0.68934F, -2.31066F, 23.0F, 5.0F, 21.0F,
            10.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO9 = {
            -0.25F, -0.18934F, -3.18934F, 0.25F, -0.18934F, -3.18934F, 0.25F, 0.81066F, -3.18934F, -0.25F,
            0.81066F, -3.18934F, 22.0F, 3.0F, 23.0F, 5.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            -0.18934F, -2.18934F, -0.25F, -0.18934F, -2.18934F, -0.25F, 0.81066F, -2.18934F, 0.25F, 0.81066F,
            -2.18934F, 26.0F, 27.0F, 27.0F, 29.0F, 0.0F, 0.0F, 1.0F, -0.25F, -0.18934F,
            -2.18934F, -0.25F, -0.18934F, -3.18934F, -0.25F, 0.81066F, -3.18934F, -0.25F, 0.81066F, -2.18934F,
            12.0F, 11.0F, 14.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, -3.18934F,
            0.25F, -0.18934F, -2.18934F, 0.25F, 0.81066F, -2.18934F, 0.25F, 0.81066F, -3.18934F, 14.0F,
            11.0F, 12.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, -3.18934F, -0.25F,
            -0.18934F, -3.18934F, -0.25F, -0.18934F, -2.18934F, 0.25F, -0.18934F, -2.18934F, 28.0F, 28.0F,
            27.0F, 26.0F, 0.0F, -1.0F, 0.0F, 0.25F, 0.81066F, -2.18934F, -0.25F, 0.81066F,
            -2.18934F, -0.25F, 0.81066F, -3.18934F, 0.25F, 0.81066F, -3.18934F, 29.0F, 0.0F, 28.0F,
            2.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO10 = {
            -0.375F, 0.39645F, -3.10355F, 0.375F, 0.39645F, -3.10355F, 0.375F, 2.39645F, -3.10355F, -0.375F,
            2.39645F, -3.10355F, 23.0F, 3.0F, 25.0F, 7.0F, 0.0F, 0.0F, -1.0F, 0.375F,
            0.39645F, -1.10355F, -0.375F, 0.39645F, -1.10355F, -0.375F, 2.39645F, -1.10355F, 0.375F, 2.39645F,
            -1.10355F, 15.0F, 23.0F, 17.0F, 27.0F, 0.0F, 0.0F, 1.0F, -0.375F, 0.39645F,
            -1.10355F, -0.375F, 0.39645F, -3.10355F, -0.375F, 2.39645F, -3.10355F, -0.375F, 2.39645F, -1.10355F,
            15.0F, 9.0F, 19.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, -3.10355F,
            0.375F, 0.39645F, -1.10355F, 0.375F, 2.39645F, -1.10355F, 0.375F, 2.39645F, -3.10355F, 19.0F,
            9.0F, 15.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, -3.10355F, -0.375F,
            0.39645F, -3.10355F, -0.375F, 0.39645F, -1.10355F, 0.375F, 0.39645F, -1.10355F, 19.0F, 27.0F,
            17.0F, 23.0F, 0.0F, -1.0F, 0.0F, 0.375F, 2.39645F, -1.10355F, -0.375F, 2.39645F,
            -1.10355F, -0.375F, 2.39645F, -3.10355F, 0.375F, 2.39645F, -3.10355F, 26.0F, 7.0F, 24.0F,
            11.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO11 = {
            -0.25F, 2.18934F, -0.81066F, 0.25F, 2.18934F, -0.81066F, 0.25F, 3.18934F, -0.81066F, -0.25F,
            3.18934F, -0.81066F, 28.0F, 2.0F, 29.0F, 4.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            2.18934F, 0.18934F, -0.25F, 2.18934F, 0.18934F, -0.25F, 3.18934F, 0.18934F, 0.25F, 3.18934F,
            0.18934F, 28.0F, 4.0F, 29.0F, 6.0F, 0.0F, 0.0F, 1.0F, -0.25F, 2.18934F,
            0.18934F, -0.25F, 2.18934F, -0.81066F, -0.25F, 3.18934F, -0.81066F, -0.25F, 3.18934F, 0.18934F,
            29.0F, 19.0F, 31.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.81066F,
            0.25F, 2.18934F, 0.18934F, 0.25F, 3.18934F, 0.18934F, 0.25F, 3.18934F, -0.81066F, 31.0F,
            19.0F, 29.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.81066F, -0.25F,
            2.18934F, -0.81066F, -0.25F, 2.18934F, 0.18934F, 0.25F, 2.18934F, 0.18934F, 13.0F, 30.0F,
            12.0F, 28.0F, 0.0F, -1.0F, 0.0F, 0.25F, 3.18934F, 0.18934F, -0.25F, 3.18934F,
            0.18934F, -0.25F, 3.18934F, -0.81066F, 0.25F, 3.18934F, -0.81066F, 29.0F, 12.0F, 28.0F,
            14.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO12 = {
            -0.5125F, -2.81066F, 0.18934F, 0.5125F, -2.81066F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, -0.5125F,
            0.68934F, 0.18934F, 8.0F, 18.0F, 10.0F, 25.0F, 0.0F, 0.0F, -1.0F, 0.5125F,
            -2.81066F, 0.68934F, -0.5125F, -2.81066F, 0.68934F, -0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F,
            0.68934F, 10.0F, 18.0F, 12.0F, 25.0F, 0.0F, 0.0F, 1.0F, -0.5125F, -2.81066F,
            0.68934F, -0.5125F, -2.81066F, 0.18934F, -0.5125F, 0.68934F, 0.18934F, -0.5125F, 0.68934F, 0.68934F,
            9.0F, 25.0F, 10.0F, 32.0F, -1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F,
            0.5125F, -2.81066F, 0.68934F, 0.5125F, 0.68934F, 0.68934F, 0.5125F, 0.68934F, 0.18934F, 10.0F,
            25.0F, 11.0F, 32.0F, 1.0F, 0.0F, 0.0F, 0.5125F, -2.81066F, 0.18934F, -0.5125F,
            -2.81066F, 0.18934F, -0.5125F, -2.81066F, 0.68934F, 0.5125F, -2.81066F, 0.68934F, 30.0F, 7.0F,
            28.0F, 6.0F, 0.0F, -1.0F, 0.0F, 0.5125F, 0.68934F, 0.68934F, -0.5125F, 0.68934F,
            0.68934F, -0.5125F, 0.68934F, 0.18934F, 0.5125F, 0.68934F, 0.18934F, 30.0F, 14.0F, 28.0F,
            15.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO13 = {
            -0.25F, -0.18934F, 2.18934F, 0.25F, -0.18934F, 2.18934F, 0.25F, 0.81066F, 2.18934F, -0.25F,
            0.81066F, 2.18934F, 27.0F, 27.0F, 26.0F, 29.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            -0.18934F, 3.18934F, -0.25F, -0.18934F, 3.18934F, -0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F,
            3.18934F, 23.0F, 3.0F, 22.0F, 5.0F, 0.0F, 0.0F, 1.0F, -0.25F, -0.18934F,
            3.18934F, -0.25F, -0.18934F, 2.18934F, -0.25F, 0.81066F, 2.18934F, -0.25F, 0.81066F, 3.18934F,
            14.0F, 11.0F, 12.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F,
            0.25F, -0.18934F, 3.18934F, 0.25F, 0.81066F, 3.18934F, 0.25F, 0.81066F, 2.18934F, 12.0F,
            11.0F, 14.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.25F, -0.18934F, 2.18934F, -0.25F,
            -0.18934F, 2.18934F, -0.25F, -0.18934F, 3.18934F, 0.25F, -0.18934F, 3.18934F, 28.0F, 26.0F,
            27.0F, 28.0F, 0.0F, -1.0F, 0.0F, 0.25F, 0.81066F, 3.18934F, -0.25F, 0.81066F,
            3.18934F, -0.25F, 0.81066F, 2.18934F, 0.25F, 0.81066F, 2.18934F, 29.0F, 2.0F, 28.0F,
            0.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO14 = {
            -0.375F, 0.39645F, 1.10355F, 0.375F, 0.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, -0.375F,
            2.39645F, 1.10355F, 17.0F, 23.0F, 15.0F, 27.0F, 0.0F, 0.0F, -1.0F, 0.375F,
            0.39645F, 3.10355F, -0.375F, 0.39645F, 3.10355F, -0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F,
            3.10355F, 25.0F, 3.0F, 23.0F, 7.0F, 0.0F, 0.0F, 1.0F, -0.375F, 0.39645F,
            3.10355F, -0.375F, 0.39645F, 1.10355F, -0.375F, 2.39645F, 1.10355F, -0.375F, 2.39645F, 3.10355F,
            19.0F, 9.0F, 15.0F, 13.0F, -1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F,
            0.375F, 0.39645F, 3.10355F, 0.375F, 2.39645F, 3.10355F, 0.375F, 2.39645F, 1.10355F, 15.0F,
            9.0F, 19.0F, 13.0F, 1.0F, 0.0F, 0.0F, 0.375F, 0.39645F, 1.10355F, -0.375F,
            0.39645F, 1.10355F, -0.375F, 0.39645F, 3.10355F, 0.375F, 0.39645F, 3.10355F, 19.0F, 23.0F,
            17.0F, 27.0F, 0.0F, -1.0F, 0.0F, 0.375F, 2.39645F, 3.10355F, -0.375F, 2.39645F,
            3.10355F, -0.375F, 2.39645F, 1.10355F, 0.375F, 2.39645F, 1.10355F, 26.0F, 11.0F, 24.0F,
            7.0F, 0.0F, 1.0F, 0.0F
    };
    private static final float[] DECO15 = {
            -0.25F, 2.18934F, -0.18934F, 0.25F, 2.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, -0.25F,
            3.18934F, -0.18934F, 29.0F, 4.0F, 28.0F, 6.0F, 0.0F, 0.0F, -1.0F, 0.25F,
            2.18934F, 0.81066F, -0.25F, 2.18934F, 0.81066F, -0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F,
            0.81066F, 29.0F, 2.0F, 28.0F, 4.0F, 0.0F, 0.0F, 1.0F, -0.25F, 2.18934F,
            0.81066F, -0.25F, 2.18934F, -0.18934F, -0.25F, 3.18934F, -0.18934F, -0.25F, 3.18934F, 0.81066F,
            31.0F, 19.0F, 29.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F,
            0.25F, 2.18934F, 0.81066F, 0.25F, 3.18934F, 0.81066F, 0.25F, 3.18934F, -0.18934F, 29.0F,
            19.0F, 31.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.25F, 2.18934F, -0.18934F, -0.25F,
            2.18934F, -0.18934F, -0.25F, 2.18934F, 0.81066F, 0.25F, 2.18934F, 0.81066F, 13.0F, 28.0F,
            12.0F, 30.0F, 0.0F, -1.0F, 0.0F, 0.25F, 3.18934F, 0.81066F, -0.25F, 3.18934F,
            0.81066F, -0.25F, 3.18934F, -0.18934F, 0.25F, 3.18934F, -0.18934F, 29.0F, 14.0F, 28.0F,
            12.0F, 0.0F, 1.0F, 0.0F
    };

    public HeadDominatorStaffModel(ModelPart root) {
        this.staff = root.getChild("staff");
        this.shaft = this.staff.getChild("shaft");
        this.tip = this.staff.getChild("tip");
        this.group = this.staff.getChild("group");
        this.deco0 = this.group.getChild("deco0");
        this.deco1 = this.group.getChild("deco1");
        this.deco2 = this.group.getChild("deco2");
        this.deco3 = this.group.getChild("deco3");
        this.deco4 = this.group.getChild("deco4");
        this.deco5 = this.group.getChild("deco5");
        this.deco6 = this.group.getChild("deco6");
        this.deco7 = this.group.getChild("deco7");
        this.deco8 = this.group.getChild("deco8");
        this.deco9 = this.group.getChild("deco9");
        this.deco10 = this.group.getChild("deco10");
        this.deco11 = this.group.getChild("deco11");
        this.deco12 = this.group.getChild("deco12");
        this.deco13 = this.group.getChild("deco13");
        this.deco14 = this.group.getChild("deco14");
        this.deco15 = this.group.getChild("deco15");
    }

    @Override
    public void setupAnim(HeadDominator entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        HeadDominatorPose.apply(null, null, null, null, null, null, this.staff, null,
                entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.staff.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.shaft, SHAFT, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.tip, TIP, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.pushPose();
        this.group.translateAndRotate(poseStack);
        HackerQuads.emit(poseStack, buffer, this.deco0, DECO0, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco1, DECO1, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco2, DECO2, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco3, DECO3, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco4, DECO4, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco5, DECO5, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco6, DECO6, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco7, DECO7, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco8, DECO8, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco9, DECO9, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco10, DECO10, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco11, DECO11, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco12, DECO12, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco13, DECO13, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco14, DECO14, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        HackerQuads.emit(poseStack, buffer, this.deco15, DECO15, TEX_WIDTH, TEX_HEIGHT,
                packedLight, packedOverlay, color);
        poseStack.popPose();
        poseStack.popPose();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition staff = root.addOrReplaceChild("staff", CubeListBuilder.create(),
                PartPose.offset(-5F, 24F, -8F));
        staff.addOrReplaceChild("shaft", CubeListBuilder.create(), PartPose.ZERO);
        // bbmodel 里杖尖 X+45° -> java -45°，与改造前一样留在 PartPose。
        staff.addOrReplaceChild("tip", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, 0.25F, 0F, -45F, 0F, 0F));
        PartDefinition group = staff.addOrReplaceChild("group", CubeListBuilder.create(),
                PartPose.offset(0F, -18.8F, 0F));
            group.addOrReplaceChild("deco0", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco1", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco2", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco3", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco4", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 90.0F, 0F));
            group.addOrReplaceChild("deco5", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 90.0F, 0F));
            group.addOrReplaceChild("deco6", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 90.0F, 0F));
            group.addOrReplaceChild("deco7", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, 90.0F, 0F));
            group.addOrReplaceChild("deco8", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco9", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco10", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco11", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, 0.0F, 0F));
            group.addOrReplaceChild("deco12", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, -45.0F, -90.0F, 0F));
            group.addOrReplaceChild("deco13", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, -90.0F, 0F));
            group.addOrReplaceChild("deco14", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, -90.0F, 0F));
            group.addOrReplaceChild("deco15", CubeListBuilder.create(),
                    PartPose.offsetAndRotation(0F, -10.5F, 0F, 45.0F, -90.0F, 0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
