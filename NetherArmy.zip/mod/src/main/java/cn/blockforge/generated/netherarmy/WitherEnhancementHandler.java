package cn.blockforge.generated.netherarmy;

import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 原版凋灵的战斗强化：血量上限 300 → 600（二阶段阈值随半血口径自动移到 300）、
 * 飞行速度翻倍、远距离索敌、蓝色凋灵之首、受击技能、二阶段冲刺、召唤尸鬼与击杀回血；
 * 由一阶段转入二阶段的瞬间还会立即召唤一支下界巡逻队（见 {@link #summonPhaseTwoPatrol}）。
 */
public final class WitherEnhancementHandler {
    private static final String SKULL_SPEED_BOOSTED = "generated_mod_wither_skull_speed_boosted";
    private static final String SKULL_SPEED = "generated_mod_wither_skull_speed";
    private static final String EXTRA_SHOT_TICKS = "generated_mod_wither_extra_shot_ticks";
    private static final String DASH_COOLDOWN = "generated_mod_wither_dash_cooldown";
    private static final String DASH_TICKS = "generated_mod_wither_dash_ticks";
    private static final String DASH_X = "generated_mod_wither_dash_x";
    private static final String DASH_Y = "generated_mod_wither_dash_y";
    private static final String DASH_Z = "generated_mod_wither_dash_z";
    private static final String DASH_HIT_ENTITIES = "generated_mod_wither_dash_hit_entities";
    private static final String PHASE_TWO_INITIALIZED = "generated_mod_wither_phase_two_initialized";
    private static final String PHASE_ONE_SUMMON_TICKS = "generated_mod_wither_phase_one_summon_ticks";
    /** 凋灵召唤物的印记：记录召唤它的凋灵，用于把仇恨与凋灵同步。 */
    private static final String SUMMONER_WITHER = "generated_mod_wither_summoner";
    private static final String RISE_ACTIVE = "generated_mod_wither_rise_active";
    private static final String RISE_BASE_Y = "generated_mod_wither_rise_base_y";
    private static final String RISE_RETURN_TICKS = "generated_mod_wither_rise_return_ticks";

    private static final double WITHER_TARGET_RANGE = 100.0D;
    private static final double WITHER_RANGED_ATTACK_RANGE = 50.0D;
    /**
     * 原版凋灵的 FLYING_SPEED 与 MOVEMENT_SPEED 属性底都是 0.6
     * （{@code WitherBoss#createAttributes}）。
     */
    private static final double WITHER_BASE_FLIGHT_SPEED = 0.6D;
    /**
     * 凋灵飞行速度翻倍的倍率：属性底覆写到 {@code 0.6 × 2 = 1.2}。
     *
     * <p>1.21.1 的 {@code FlyingMoveControl#tick} 每 tick 位移 =
     * {@code speedModifier × getAttributeValue(FLYING_SPEED)}（贴地分支改用
     * MOVEMENT_SPEED）。凋灵的全部移动目标——{@code RangedAttackGoal} 与
     * {@code WaterAvoidingRandomFlyingGoal}——传入的 speedModifier 都是 1.0，
     * 所以把属性底翻倍就等价于飞行速度翻倍。</p>
     */
    private static final double WITHER_FLIGHT_SPEED_MULTIPLIER = 2.0D;
    private static final int BLUE_WITHER_DURATION = 20 * 60 * 2;
    private static final int BLUE_WITHER_AMPLIFIER = 5; // 六级效果对应 amplifier 5
    private static final int EXTRA_SHOT_INTERVAL = 34;
    private static final int CONTACT_DAMAGE_INTERVAL = 20;
    private static final int DASH_INTERVAL = 20 * 30;
    private static final int DASH_DURATION = 10;
    private static final double DASH_DISTANCE_PER_TICK = 2.0D;
    /**
     * 冲刺对沿途"非凋灵骷髅阵营"生物造成的伤害：按命中瞬间目标当前生命值的 25% 结算。
     *
     * <p>此前是固定 10 点，对高血量目标几乎没有存在感；改成按当前血量比例后，无论目标
     * 多肉，被撞到一次就掉四分之一血，同一次冲刺反复蹭到（不同个体）也都有明显反馈。</p>
     */
    private static final float DASH_DAMAGE_HEALTH_FRACTION = 0.25F;
    /** 冲刺撞上黄金制品被阻断时，凋灵承受的虚空伤害（10 点 = 5 颗心）。 */
    private static final float DASH_GOLD_VOID_DAMAGE = 10.0F;
    /**
     * 冲刺撞上"金胡萝卜/闪烁的西瓜/金苹果/附魔金苹果"这四件圣物时，凋灵额外承受的
     * 虚弱 III：30 秒、amplifier 2。
     */
    private static final int DASH_WEAKNESS_DURATION = 20 * 30;
    private static final int DASH_WEAKNESS_AMPLIFIER = 2;
    /** 黄金检测覆盖的装备槽：手持与穿戴都算，BODY 兜底狼铠之类的特殊装备。 */
    private static final EquipmentSlot[] GOLD_EQUIPMENT_SLOTS = {
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
            EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.BODY
    };
    // 保留此前的翻倍设定；所有凋灵之首统一从构造器的原版初速度开始计算。
    private static final double SKULL_SPEED_MULTIPLIER = 2.0D;
    /**
     * 原版 {@code AbstractHurtingProjectile#tick} 每 tick 的速度递推：
     * {@code v = (v + v̂ * SKULL_ACCELERATION_POWER) * getInertia()}。
     * 普通凋灵之头的阻力系数取父类的 0.95，蓝色（dangerous）凋灵之头被
     * {@code WitherSkull#getInertia} 压到 0.73，两者初速度都是 0.1 格/tick。
     */
    private static final double NORMAL_SKULL_INERTIA = 0.95D;
    private static final double BLUE_SKULL_INERTIA = 0.73D;
    /** {@code AbstractHurtingProjectile#INITAL_ACCELERATION_POWER}。 */
    private static final double SKULL_ACCELERATION_POWER = 0.1D;
    /**
     * 蓝色凋灵之首在"折算回普通弹头速度"之后再乘的倍率。
     *
     * <p>蓝头能穿墙且无视方块自毁，若与普通弹头完全同速（上限 1.90 格/tick，约 38 格/秒），
     * 命中起来几乎没有反应时间，整体强度过高。这里统一压到一半：上限约 0.95 格/tick
     * （约 19 格/秒），仍是原版蓝头（上限 0.27 格/tick）的三倍半，肉眼明显比普通弹头慢一档。</p>
     */
    private static final double BLUE_SKULL_SPEED_SCALE = 0.5D;
    /** 凋灵击杀任意生物时回复的血量（5 点 = 2.5 颗心）。 */
    private static final float KILL_HEAL_AMOUNT = 5.0F;
    private static final float SUMMON_CHANCE = 0.10F;
    private static final int RISE_HEIGHT = 2;
    private static final int RISE_RETURN_DELAY = 20 * 5;
    /** 一阶段召唤周期：每 10 秒一次。 */
    private static final int PHASE_ONE_SUMMON_INTERVAL = 20 * 10;
    /** 一阶段召唤半径：10 格内。 */
    private static final double PHASE_ONE_SUMMON_RADIUS = 10.0D;
    /** 穿墙的蓝色凋灵之首不再因方块自毁，给一个兜底存活上限避免无限堆积（60 秒）。 */
    private static final int PIERCING_SKULL_LIFETIME = 20 * 60;
    /** 冲刺命中判定的额外外扩范围；贴边掠过时也应算作命中。 */
    private static final double DASH_SWEEP_INFLATE = 0.5D;
    /** 接触判定的数值余量，不用于扩大实际扫掠距离。 */
    private static final double CONTACT_EPSILON = 1.0E-7D;
    /**
     * 召唤动画的补偿回血：上限翻倍到 600（见 {@code WitherBossMaxHealthMixin}）后，
     * 原版"每 10 tick 回 10 点"的固定节奏只够把血量从 600/3 = 200 拉回 420，
     * 动画结束时 boss 只有 70% 血。这里在动画无敌帧内、与原版完全相同的
     * {@code tickCount % 10} 拍点上再补回 10 点，合成 20 点/10t，收尾恰好回满 600
     * （中途触顶由 {@code heal} 的钳制消化，与原版 100→320 钳到 300 的行为同款）。
     */
    private static final float SPAWN_ANIMATION_TOP_OFF = 10.0F;

    private WitherEnhancementHandler() {
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof WitherSkull skull)) {
            return;
        }
        Entity owner = skull.getOwner();
        if (!(owner instanceof WitherBoss wither) || wither instanceof OverlordWitherBoss) {
            return;
        }

        if (!hasRangedAttackTarget(wither)) {
            // 原版凋灵的三颗头也必须遵守 50 格远程攻击距离。
            event.setCanceled(true);
            return;
        }
        if (isPhaseTwo(wither)) {
            // 二阶段之后，原版和额外生成的每一枚凋灵之首都强制为蓝色。
            skull.setDangerous(true);
        }
        boostSkullSpeed(skull);
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        Entity entity = event.getEntity();
        if (entity.level().isClientSide()) {
            return;
        }
        if (entity instanceof WitherSkull skull && skull.getOwner() instanceof WitherBoss wither
                && !(wither instanceof OverlordWitherBoss)) {
            tickSkull(skull, wither);
        }
        if (entity instanceof WitherBoss wither && !(wither instanceof OverlordWitherBoss)) {
            tickWither(wither);
        }
        if (entity instanceof Mob mob) {
            syncSummonedMobTarget(mob);
        }
    }

    @SubscribeEvent
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        if (event.getEntity() instanceof WitherBoss wither && !(wither instanceof OverlordWitherBoss)) {
            // 末影龙首次击败时掉落 12000 点经验，凋灵死亡时保持同等奖励。
            event.setDroppedExperience(12000);
        }
    }

    /**
     * 凋灵击杀生物时回复自身 5 点血量（2.5 颗心）。
     *
     * <p>归因走原版弹道规则：凋灵之首的 {@code DamageSource#getEntity()} 就是发射它的凋灵；
     * 自身的接触伤害与冲刺伤害也显式挂上凋灵为凶手（见 {@link #witherMagicDamage}），
     * 因此技能命中致死同样回血。回复由 {@code LivingEntity#heal} 完成，自动封顶到满血。</p>
     */
    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || victim instanceof WitherBoss) {
            return;
        }
        DamageSource source = event.getSource();
        WitherBoss wither = findWither(source.getDirectEntity(), source.getEntity());
        if (wither == null || !wither.isAlive() || wither.level() != victim.level()
                || wither instanceof OverlordWitherBoss) {
            // 霸主凋灵的击杀回血走它自己的阶段规则（三阶段起 10 点）。
            return;
        }
        wither.heal(KILL_HEAL_AMOUNT);
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim instanceof WitherBoss wither) {
            if (wither instanceof OverlordWitherBoss) {
                // 霸主凋灵的受击上浮、召唤运兵车与阶段口径全部由它自己的实体逻辑接管。
                return;
            }
            if (wither.level().isClientSide() || event.isCanceled() || event.getAmount() <= 0.0F) {
                return;
            }
            // 二阶段凋灵免疫爆炸伤害（TNT、苦力怕、床与重生锚爆炸等）。
            if (isPhaseTwo(wither) && event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
                event.setCanceled(true);
                return;
            }
            // 二阶段被方块窒息（in_wall）时立即朝随机方向冲刺脱困。
            if (isPhaseTwo(wither) && event.getSource().is(DamageTypes.IN_WALL)) {
                triggerSuffocationDash(wither);
            }
            triggerRise(wither);
            if (wither.getRandom().nextFloat() < SUMMON_CHANCE
                    && wither.level() instanceof ServerLevel level) {
                summonReinforcements(level, wither);
            }
            return;
        }

        Entity direct = event.getSource().getDirectEntity();
        Entity causing = event.getSource().getEntity();
        WitherBoss wither = findWither(direct, causing);
        if (wither == null || wither instanceof OverlordWitherBoss
                || victim == wither || event.getAmount() <= 0.0F) {
            return;
        }

        // 凋灵骷髅阵营免疫凋灵之首（含黑头、蓝头与其爆炸溅射），免伤由阵营门禁的
        // LivingIncomingDamageEvent 负责；这里的蓝头强化必须跟着让路——同一事件上两个
        // 处理器的先后顺序不作保证，若本方法先跑，双倍直伤与凋零 V 会赶在取消之前挂上。
        if (direct instanceof WitherSkull skull && skull.isDangerous()
                && skull.getOwner() == wither
                && !MesmerizerControl.isWitherSkeletonFaction(victim)) {
            event.setAmount(event.getAmount() * 2.0F);
            if (!event.isCanceled()) {
                victim.addEffect(new MobEffectInstance(MobEffects.WITHER,
                        BLUE_WITHER_DURATION, BLUE_WITHER_AMPLIFIER), wither);
            }
        }
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (projectile.level().isClientSide()) {
            return;
        }
        // 圣光炸弹必须走自己的命中、爆炸、发光和强制伤害结算，不能被原版凋灵
        // 二阶段的抛射物反弹逻辑拦截；否则命中原版凋灵时会被弹回，onHit 不会执行。
        if (projectile instanceof HolyBomb) {
            return;
        }
        // 蓝色凋灵之首无视方块：取消方块撞击处理（原版会在这里爆炸并自毁），弹头继续穿墙飞行。
        if (projectile instanceof WitherSkull skull && skull.isDangerous()
                && skull.getOwner() instanceof WitherBoss
                && event.getRayTraceResult() instanceof BlockHitResult) {
            event.setCanceled(true);
            return;
        }
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof WitherBoss wither)
                || wither instanceof OverlordWitherBoss || !wither.isPowered()) {
            return;
        }
        Entity attacker = projectile.getOwner();
        if (!(attacker instanceof LivingEntity) || attacker == wither || !attacker.isAlive()) {
            return;
        }

        Vec3 direction = attacker.getEyePosition().subtract(wither.getEyePosition());
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        double speed = Math.max(projectile.getDeltaMovement().length(), 0.8D);
        projectile.setPos(wither.getEyePosition().add(direction.scale(1.6D)));
        projectile.setDeltaMovement(direction.scale(speed));
        projectile.hasImpulse = true;
        event.setCanceled(true);
    }

    private static void boostSkullSpeed(WitherSkull skull) {
        if (skull.getPersistentData().getBoolean(SKULL_SPEED_BOOSTED)) {
            return;
        }
        double speed = skull.getDeltaMovement().length();
        if (speed < 1.0E-4D) {
            speed = 0.5D;
        }
        speed *= SKULL_SPEED_MULTIPLIER;
        skull.setDeltaMovement(skull.getDeltaMovement().lengthSqr() < 1.0E-8D
                ? new Vec3(speed, 0.0D, 0.0D)
                : skull.getDeltaMovement().normalize().scale(speed));
        skull.getPersistentData().putBoolean(SKULL_SPEED_BOOSTED, true);
        skull.getPersistentData().putDouble(SKULL_SPEED, speed);
    }

    private static void tickSkull(WitherSkull skull, WitherBoss wither) {
        if (isPhaseTwo(wither)) {
            skull.setDangerous(true);
        }
        // 先推进速度记忆值（黑头与原版递推同步，蓝头折算回普通阻力），再决定是否覆写。
        double speed = advanceNormalSkullSpeed(skull);
        if (!skull.isDangerous()) {
            return;
        }
        // 穿墙的蓝色弹头不再因撞击方块自毁，超过存活上限直接回收，避免实体堆积。
        if (skull.tickCount > PIERCING_SKULL_LIFETIME) {
            skull.discard();
            return;
        }
        steerBlueSkull(skull, wither, wither.getTarget(), speed * BLUE_SKULL_SPEED_SCALE,
                WITHER_TARGET_RANGE);
    }

    /**
     * 用凋灵同一套速度记忆、限步追踪与穿墙命中扫描，推进其他生物发射的蓝色凋灵之首。
     * 御首者的弹头也走这里，避免两套制导算法产生不同的速度抖动和命中行为。
     */
    public static void tickTrackingBlueSkull(WitherSkull skull, LivingEntity owner,
                                              LivingEntity target) {
        if (!skull.isDangerous()) {
            skull.setDangerous(true);
        }
        if (skull.tickCount > PIERCING_SKULL_LIFETIME) {
            skull.discard();
            return;
        }
        double speed = advanceNormalSkullSpeed(skull);
        steerBlueSkull(skull, owner, target, speed * BLUE_SKULL_SPEED_SCALE,
                Double.MAX_VALUE);
    }

    /**
     * 按"普通凋灵之首"的阻力系数推进弹头的速度记忆值，返回本 tick 普通弹头应有的速度大小。
     *
     * <p>蓝色凋灵之头慢得多是 {@code WitherSkull#getInertia} 造成的：dangerous 时返回
     * 0.73，普通弹头走父类的 0.95，代进原版每 tick 的递推式
     * {@code v = (v + 0.1) * inertia}，蓝头的速度上限只有
     * {@code 0.1 * 0.73 / 0.27 ≈ 0.27} 格/tick，普通弹头是
     * {@code 0.1 * 0.95 / 0.05 = 1.9} 格/tick，肉眼相差七倍。这里把蓝头刚被 0.73 拖慢的
     * 速度折算回普通阻力的等效值，再沿用同一条递推式，使记忆值始终贴在普通弹头的速度曲线上；
     * 蓝头实际拿到的值是它的一半（{@link #BLUE_SKULL_SPEED_SCALE}）。</p>
     *
     * <p>注意：本方法只推进记忆值，不直接写蓝头的位移。蓝头被降速后写回的位移是记忆值的
     * 一半，折算回普通阻力也只有曲线的一半，恒小于记忆值，所以下一 tick 的
     * {@code max(remembered, actual)} 仍然取到记忆值——普通弹头的曲线不会被蓝头的降速拖下来。</p>
     */
    private static double advanceNormalSkullSpeed(WitherSkull skull) {
        double actual = skull.getDeltaMovement().length();
        if (skull.isDangerous()) {
            actual *= NORMAL_SKULL_INERTIA / BLUE_SKULL_INERTIA;
        }
        double remembered = skull.getPersistentData().getDouble(SKULL_SPEED);
        double speed = Math.max(remembered, actual);
        if (speed < 1.0E-4D) {
            // 兜底：读不到任何速度时按构造器的原版初速度起步。
            speed = SKULL_ACCELERATION_POWER * SKULL_SPEED_MULTIPLIER;
        }
        speed = (speed + SKULL_ACCELERATION_POWER) * NORMAL_SKULL_INERTIA;
        skull.getPersistentData().putDouble(SKULL_SPEED, speed);
        return speed;
    }

    /**
     * 覆写蓝色弹头的速度大小与方向：速度取传入值（普通弹头曲线的
     * {@link #BLUE_SKULL_SPEED_SCALE} 倍），方向上有目标时指向目标（保留追踪），
     * 没目标时保持原方向直行。
     *
     * <p>这里额外处理"追踪到目标头顶来回抽搐却怎么都不命中、甚至与目标重合也不爆炸"的
     * 三个成因：</p>
     * <ol>
     * <li><b>一步跨过瞄准点。</b>纯追踪制导每 tick 整步推进（蓝头上限 0.95 格），离目标只剩
     * 半步时会在瞄准点两侧来回跳（2-循环，振幅约半个步长），观感就是抽搐。现在把这一步压到
     * 不超过"弹头到瞄准点的剩余距离"。</li>
     * <li><b>实体判定被方块射线截断。</b>蓝头穿墙后经常整段位移都在实心方块里，而原版
     * {@code ProjectileUtil#getHitResult} 会先把实体射线的终点收到方块命中点，再用"距抛射物
     * 0.3 格以内才算命中"的余量过滤实体；两者叠加，贴着目标头顶悬停的弹头永远测不到目标，
     * 只能一层层穿过去不掉血。所以这里改用不被方块截断、也没有 0.3 格余量的完整线段自行扫一次；
     * 线段扫空时再兜底查一次与弹头包围盒直接重叠的目标（{@link #lockBlueSkullImpact}），
     * 找到目标就地结算——不再"送进盒内等下一 tick 原版结算"，否则目标恰好在这间隙被打死时，
     * 弹头就会悬在原地与目标重合、既不爆炸也不掉血。</li>
     * <li><b>末影龙不在原版命中判定的登记范围内。</b>它 {@code isPickable} 恒为 false，
     * 任何抛射物的原版判定都轮不到它——命中龙时同样走就地复刻
     * {@code WitherSkull#onHit} 结算（{@link #resolveBlueSkullImpactDirect}）。</li>
     * </ol>
     */
    private static void steerBlueSkull(WitherSkull skull, LivingEntity owner,
                                       LivingEntity target, double speed, double targetRange) {
        Vec3 motion = skull.getDeltaMovement();
        if (motion.lengthSqr() < 1.0E-8D) {
            // 速度被清零（如被弹开）时没有方向可参照，交回原版处理，避免弹头悬停。
            return;
        }
        Vec3 heading = motion.normalize();
        Vec3 aimPoint = null;
        if (target != null && target.isAlive() && target.level() == skull.level()
                && target.distanceToSqr(skull) <= targetRange * targetRange) {
            aimPoint = target.getEyePosition();
            Vec3 aim = aimPoint.subtract(skull.position());
            if (aim.lengthSqr() >= 1.0E-6D) {
                heading = aim.normalize();
            }
        }
        double step = speed;
        if (aimPoint != null) {
            step = Math.min(speed, skull.position().distanceTo(aimPoint));
        }
        if (lockBlueSkullImpact(skull, owner, heading, step)) {
            return;
        }
        skull.setDeltaMovement(heading.scale(step));
        skull.hasImpulse = true;
    }

    /**
     * 用"下一 tick 真正会走完的整条线段"自行扫一次实体命中，命中即在原地结算。
     *
     * <p>原版蓝头穿墙后经常整段位移都在实心方块里，而原版实体判定会先把射线终点收到
     * 方块命中点、再用"距抛射物 0.3 格以内才算命中"的余量过滤实体；弹头贴脸嵌进目标
     * 包围盒后，线段还会因"终点收到起点所在方块内"而退化成一个点，同样什么都扫不到。
     * 所以这里用不被方块截断、也没有 0.3 格余量的完整线段自行扫一次，线段扫空时再兜底
     * 查一次与弹头包围盒直接重叠的目标（{@link #overlappingBlueSkullHit}）。找到目标就
     * 走 {@link #resolveBlueSkullImpactDirect} 就地复刻 {@code WitherSkull#onHit} 的完整
     * 链路（伤害、爆炸、自毁），不再"送进盒内等下一 tick 原版结算"——那一步会在目标
     * 恰好被别的伤害杀死时让弹头悬空不爆。</p>
     *
     * @return 是否已经结算命中（结算后本 tick 不再覆写速度）
     */
    private static boolean lockBlueSkullImpact(WitherSkull skull, LivingEntity owner,
                                               Vec3 heading, double step) {
        Vec3 start = skull.position();
        Vec3 movement = heading.scale(step);
        AABB scanArea = sweptBox(skull.getBoundingBox(), movement).inflate(1.0D);
        // 最后那个参数是原版用于限制"实体最多只能离抛射物多远"的余量，传 Double.MAX_VALUE
        // 等于取消 0.3 格限制，让整条线段上的目标都能被扫到。
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(skull, start, start.add(movement), scanArea,
                entity -> canBlueSkullStrike(owner, entity), Double.MAX_VALUE);
        if (hit == null) {
            // 原版这条射线对"贴到身体里"的弹头是瞎的：起点已经嵌进目标包围盒时，
            // 缩放后的线段回收成零长度，扫不到任何盒面，于是弹头与目标重合却既不
            // 命中也不爆炸（蓝头在追踪中反复出现的现症）。这里兜底再查一次与弹头
            // 包围盒直接重叠的实体，命中点落在弹头处。
            hit = overlappingBlueSkullHit(skull, owner);
            if (hit == null) {
                return false;
            }
        }
        Entity victim = hit.getEntity();
        Vec3 center = victim.getBoundingBox().getCenter();
        Vec3 location = hit.getLocation();
        if (!skull.getBoundingBox().inflate(1.0E-4D).contains(location)) {
            // 命中点还在弹头盒外（线段正常扫到盒面）：先把弹头推进到目标盒内靠盒心
            // 一侧，让爆炸与直伤的作用位置和原版一致，再结算。
            Vec3 inside = location.add(center.subtract(location).scale(0.35D));
            skull.setPos(inside.x, inside.y, inside.z);
        }
        resolveBlueSkullImpactDirect(skull, victim);
        return true;
    }

    /**
     * 兜底命中查询：直接找与弹头包围盒重叠、且能被打的活体。
     *
     * <p>原版 {@link ProjectileUtil#getEntityHitResult} 在建线段前会先把终点收缩到起点所在
     * 方块的范围内；弹头一旦嵌进目标体内（追踪制导每 tick 压步、目标贴脸时很容易发生），
     * 收缩后的终点与起点重合，退化线段扫不到目标包围盒的入口，这正是"重合却不爆炸"的
     * 直接成因。这里不看盒面相交，只按弹头当前位置找重叠实体，命中点落在弹头处，
     * 由调用方识别成"已在盒内"走就地结算。</p>
     */
    private static EntityHitResult overlappingBlueSkullHit(WitherSkull skull, LivingEntity owner) {
        List<Entity> overlaps = skull.level().getEntities(skull, skull.getBoundingBox().inflate(0.5D),
                entity -> canBlueSkullStrike(owner, entity));
        Entity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity candidate : overlaps) {
            double distance = candidate.distanceToSqr(skull);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        if (best == null) {
            return null;
        }
        return new EntityHitResult(best, skull.position());
    }

    /**
     * 蓝头命中即结算：在弹头当前位置复刻一遍
     * {@code WitherSkull#onHitEntity} + {@code WitherSkull#onHit} 的实体命中链路：
     * <ol>
     * <li>直伤 8 点。伤害源与原版同为 {@code damageSources().witherSkull(弹头, 凋灵)}，
     * 所以本模组挂在 {@link #onIncomingDamage}（双倍伤害、凋零 V）与 {@link #onLivingDeath}
     * （击杀回血）上的强化会照常生效。注意末影龙的 {@code hurt} 还有一道登记闸门：只接受
     * 玩家造成的伤害或 {@code #minecraft:always_hurts_ender_dragons} 标签内的伤害类型，
     * 光有这里的结算还不够，标签必须把 {@code minecraft:wither_skull} 收进去
     * （见 {@code data/minecraft/tags/damage_type/always_hurts_ender_dragons.json}）。</li>
     * <li>伤害成功后与原版一致：目标存活则结算攻击方附魔的命中后效应；打死了则回 5 点血
     * （凋灵本体的击杀回血由死亡事件另行结算，与原版对普通生物的结算顺序相同）。</li>
     * <li>最后在弹头位置放出威力 1.0、MOB 破坏等级、不点火的爆炸并自毁——与原版"命中即爆"
     * 一致，不区分直伤有没有真正打出血。龙本来就免疫不了 {@code #is_explosion} 的伤害，
     * 这一爆也是它原版的受伤渠道之一。</li>
     * </ol>
     *
     * <p>之所以所有目标都走这里而不是原先"把弹头送进目标包围盒内侧、等下一 tick 原版扫描"：
     * 目标若在等待的这一 tick 里被别的伤害打死，原版扫描会因为 {@code isAlive()} 为假
     * 把尸体滤掉，弹头便悬在原地不爆；弹头嵌进目标体内时（追踪压步、贴脸命中的常见形态），
     * 原版线段判定也会因退化线段而扫不到目标。命中即结算同时根治这两种"重合不爆炸"。</p>
     */
    private static void resolveBlueSkullImpactDirect(WitherSkull skull, Entity victim) {
        // 炼狱霸主弹头虽然复用蓝头的制导扫描，但命中结算必须保留自己的
        // 24 点直伤、威力 4 爆炸、药水云和落点头颅，不能落入蓝头的 8 点/威力 1 口径。
        if (skull instanceof OverlordWitherSkull overlordSkull) {
            overlordSkull.resolveGuidedImpact(victim);
            return;
        }
        Level level = skull.level();
        Entity owner = skull.getOwner();
        DamageSource source;
        boolean damaged;
        if (owner instanceof LivingEntity ownerLiving) {
            source = skull.damageSources().witherSkull(skull, ownerLiving);
            damaged = victim.hurt(source, 8.0F);
        } else {
            source = skull.damageSources().magic();
            damaged = victim.hurt(source, 5.0F);
        }
        if (damaged && level instanceof ServerLevel serverLevel) {
            if (victim.isAlive()) {
                EnchantmentHelper.doPostAttackEffects(serverLevel, victim, source);
            } else if (owner instanceof LivingEntity ownerLiving) {
                ownerLiving.heal(5.0F);
            }
        }
        level.explode(skull, skull.getX(), skull.getY(), skull.getZ(), 1.0F, false,
                Level.ExplosionInteraction.MOB);
        skull.discard();
    }

    /**
     * 蓝头自行结算命中时的目标筛选，等价于原版 {@code canHitEntity} 再加本模组的阵营规则：
     * 必须是活着、可被击中的实体；不打发射者自己；不打其他凋灵
     * （凋灵互殴有专门的弹头偏折逻辑，见 {@link #onProjectileImpact}）；凋灵骷髅阵营
     * 无条件免打（{@link MesmerizerControl#isWitherSkeletonFaction}，与
     * {@code WitherSkullFactionPassThroughMixin} 里原版 {@code canHitEntity} 的过滤同源），
     * 最后还要过 {@link MesmerizerControl#canAttack} 的阵营判定，避免误伤自己人。
     *
     * <p>阵营过滤为什么不靠 {@code canAttack} 就够：{@code canAttack} 只在<b>攻击者也属于阵营</b>
     * 时才拒绝，而凋灵之首的设定是对同袍完全不命中、完全免伤，与发射者是谁无关。本方法决定
     * 蓝头会不会"就地结算命中"，一旦漏过去就是撞在阵营生物身上爆炸自毁（伤害虽被门禁取消，
     * 弹头照样没了，看上去像被同袍挡下）。</p>
     *
     * <p>末影龙是原版命中判定的死角：{@code EnderDragon#isPickable} 恒为 false、
     * {@code noPhysics} 恒为 true（它飞行时不与方块碰撞）。按原样照抄原版条件会让蓝头
     * 在扫描阶段就把龙滤掉，于是永远悬在龙头顶不落地。蓝头的设定就是要能命中龙，
     * 这里对龙放宽这两个条件，命中后的结算走
     * {@link #resolveBlueSkullImpactDirect}。</p>
     */
    private static boolean canBlueSkullStrike(LivingEntity owner, Entity entity) {
        if (entity == owner || entity instanceof WitherBoss || !(entity instanceof LivingEntity living)) {
            return false;
        }
        if (!living.isAlive()) {
            return false;
        }
        if (MesmerizerControl.isWitherSkeletonFaction(entity)) {
            return false;
        }
        if (!(living instanceof EnderDragon) && (!living.isPickable() || entity.noPhysics)) {
            return false;
        }
        return MesmerizerControl.canAttack(owner, living);
    }

    public static void tickWither(WitherBoss wither) {
        if (!(wither.level() instanceof ServerLevel level) || !wither.isAlive()) {
            return;
        }

        setTargetRange(wither);
        doubleFlightSpeed(wither);
        topOffSpawnAnimation(wither);
        updateTarget(level, wither);
        tickRise(wither);

        CompoundTag data = wither.getPersistentData();
        int extraShotTicks = data.getInt(EXTRA_SHOT_TICKS) + 1;
        if (extraShotTicks >= EXTRA_SHOT_INTERVAL) {
            extraShotTicks = 0;
            LivingEntity target = wither.getTarget();
            if (isWithinRangedAttackRange(wither, target)) {
                shootExtraSkull(level, wither, target, isPhaseTwo(wither));
            }
        }
        data.putInt(EXTRA_SHOT_TICKS, extraShotTicks);

        if (wither.tickCount % CONTACT_DAMAGE_INTERVAL == 0) {
            applyContactDamage(level, wither);
        }

        if (isPhaseTwo(wither)) {
            if (!data.getBoolean(PHASE_TWO_INITIALIZED)) {
                // 转入二阶段的这一 tick 立即召唤一支下界巡逻队（一次性，标记随凋灵存档保存）。
                // 召唤失败（所有采样点都找不到可站立地面）时不吃标记，下一 tick 原地重试，
                // 保证"转阶段必带巡逻队"；失败时整队未生成，重试不会叠出半支或多支队伍。
                if (summonPhaseTwoPatrol(level, wither)) {
                    data.putBoolean(PHASE_TWO_INITIALIZED, true);
                    data.putInt(DASH_COOLDOWN, DASH_INTERVAL);
                }
            }
            tickDash(level, wither);
        } else {
            // 一阶段：每 10 秒在半径 10 格内召唤 1~3 只尸鬼。
            // 生成/换阶段的无敌帧里不计时，避免凋灵还没能行动就先攒出一波召唤。
            if (wither.getInvulnerableTicks() <= 0) {
                int summonTicks = data.getInt(PHASE_ONE_SUMMON_TICKS) + 1;
                if (summonTicks >= PHASE_ONE_SUMMON_INTERVAL) {
                    data.putInt(PHASE_ONE_SUMMON_TICKS, 0);
                    summonPhaseOneGhouls(level, wither);
                } else {
                    data.putInt(PHASE_ONE_SUMMON_TICKS, summonTicks);
                }
            }
        }
    }

    /**
     * 由一阶段转入二阶段的瞬间立即召唤一支完整下界巡逻队（编队构成与自发刷新的
     * 巡逻队一致：领队传令兵 + 2 名下界猎手 + 3 名随机成员）。
     *
     * <p>与 {@link #summonPhaseOneGhouls}、{@link #summonReinforcements} 同一套归属
     * 机制：每名成员经 {@link #markSummonedBy} 打上凋灵印记，初始仇恨直接继承凋灵当前
     * 目标，之后由 {@link #syncSummonedMobTarget} 每 tick 保持一致；同时设为不消失，
     * 避免护卫队在转移阶段前被自然刷怪清理。</p>
     *
     * <p>落点锚定在凋灵脚下（从凋灵所在高度向下找地面），属战斗技能，不受
     * {@code do_patrol_spawning}、和平难度与自然巡逻冷却的约束。</p>
     *
     * @return 是否成功刷出整队；失败时调用方应在下一次转阶段判定处重试
     */
    private static boolean summonPhaseTwoPatrol(ServerLevel level, WitherBoss wither) {
        return NetherPatrolSpawner.summonSquadAt(level, wither.position(), mob -> {
            mob.setPersistenceRequired();
            markSummonedBy(mob, wither);
        });
    }

    private static void summonPhaseOneGhouls(ServerLevel level, WitherBoss wither) {
        int count = 1 + wither.getRandom().nextInt(3);
        for (int index = 0; index < count; index++) {
            Vec3 spot = findPhaseOneSummonSpot(level, wither);
            WitherZombie ghoul = GeneratedMod.WITHER_ZOMBIE.get().create(level);
            if (ghoul == null) {
                continue;
            }
            ghoul.setPos(spot.x, spot.y, spot.z);
            DifficultyInstance difficulty = level.getCurrentDifficultyAt(ghoul.blockPosition());
            ghoul.finalizeSpawn(level, difficulty, MobSpawnType.MOB_SUMMONED, null);
            ghoul.setPersistenceRequired();
            markSummonedBy(ghoul, wither);
            level.addFreshEntity(ghoul);
        }
    }

    /**
     * 在半径 10 格内采样找一个能站下尸鬼的空位（身体两格无完整碰撞且只允许空气/岩浆，
     * 脚下是实心方块或岩浆，与 {@link WitherZombie#checkWitherZombieSpawnRules} 的岩浆海口径一致）；
     * 12 次都采不到就退化成凋灵脚下，靠重力自然落下。
     */
    private static Vec3 findPhaseOneSummonSpot(ServerLevel level, WitherBoss wither) {
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = wither.getRandom().nextDouble() * Math.PI * 2.0D;
            double distance = 2.0D + wither.getRandom().nextDouble() * (PHASE_ONE_SUMMON_RADIUS - 2.0D);
            double x = wither.getX() + Math.cos(angle) * distance;
            double z = wither.getZ() + Math.sin(angle) * distance;
            int y = (int) Math.floor(wither.getY());
            BlockPos feet = BlockPos.containing(x, y, z);
            if (isSummonCellFree(level, feet) && isSummonCellFree(level, feet.above())
                    && canStandAt(level, feet.below())) {
                return new Vec3(x, y, z);
            }
        }
        return wither.position();
    }

    /** 召唤落点的占位格：无完整碰撞，流体只允许空气或岩浆。 */
    private static boolean isSummonCellFree(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return !state.isCollisionShapeFullBlock(level, pos) && isAirOrLava(state);
    }

    /** 下方支撑：岩浆（尸鬼能在岩浆里游泳）或实心方块。 */
    private static boolean canStandAt(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return isAirOrLava(state) || state.isRedstoneConductor(level, pos);
    }

    private static boolean isAirOrLava(BlockState state) {
        var fluid = state.getFluidState();
        return fluid.isEmpty() || fluid.is(net.minecraft.tags.FluidTags.LAVA);
    }

    private static void setTargetRange(WitherBoss wither) {
        var followRange = wither.getAttribute(Attributes.FOLLOW_RANGE);
        if (followRange != null && followRange.getBaseValue() != WITHER_TARGET_RANGE) {
            followRange.setBaseValue(WITHER_TARGET_RANGE);
        }
    }

    /**
     * 凋灵飞行速度翻倍：把 FLYING_SPEED 与 MOVEMENT_SPEED 的属性底从原版 0.6 覆写为 1.2。
     *
     * <p>凋灵的位移完全由 {@code FlyingMoveControl} 驱动：空中每 tick 速度 =
     * {@code speedModifier × getAttributeValue(FLYING_SPEED)}，贴地（onGround）分支则是
     * {@code speedModifier × getAttributeValue(MOVEMENT_SPEED)}。原版凋灵两个属性的底都是
     * 0.6，而它所有移动目标（{@code RangedAttackGoal}、{@code WaterAvoidingRandomFlyingGoal}）
     * 传进来的 speedModifier 都是 1.0，因此把两个属性底翻倍，就等于飞行速度在所有姿态下
     * 翻倍。写法与 {@link #setTargetRange} 一致：不等才回写，{@code /summon} 携带自定义
     * 属性 NBT 的凋灵也会被归一成翻倍底值，常规情况下不会每 tick 反复标脏属性。</p>
     */
    private static void doubleFlightSpeed(WitherBoss wither) {
        double target = WITHER_BASE_FLIGHT_SPEED * WITHER_FLIGHT_SPEED_MULTIPLIER;
        var flying = wither.getAttribute(Attributes.FLYING_SPEED);
        if (flying != null && flying.getBaseValue() != target) {
            flying.setBaseValue(target);
        }
        var movement = wither.getAttribute(Attributes.MOVEMENT_SPEED);
        if (movement != null && movement.getBaseValue() != target) {
            movement.setBaseValue(target);
        }
    }

    /**
     * 召唤动画补偿回血：上限 300 → 600 后，原版动画"1/3 起步 + 每 10 tick 回 10 点"
     * 的固定节奏到收尾只剩 420/600（约 70%）。这里在无敌帧内与原版同一个
     * {@code tickCount % 10} 拍点上再补 10 点，合成 20 点/10t，动画结束时恰好回满
     * 600——与原版按 300 上限设计的回满行为对齐。无敌帧之外不做任何回血，
     * 不影响正常战斗与击杀回血（{@link #KILL_HEAL_AMOUNT}）。
     */
    private static void topOffSpawnAnimation(WitherBoss wither) {
        if (wither.getInvulnerableTicks() > 0 && wither.tickCount % 10 == 0) {
            wither.heal(SPAWN_ANIMATION_TOP_OFF);
        }
    }

    private static void updateTarget(ServerLevel level, WitherBoss wither) {
        LivingEntity current = wither.getTarget();
        if (isValidTarget(wither, current)
                && current.distanceToSqr(wither) <= WITHER_TARGET_RANGE * WITHER_TARGET_RANGE) {
            return;
        }
        LivingEntity nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        AABB searchArea = wither.getBoundingBox().inflate(WITHER_TARGET_RANGE);
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, searchArea,
                entity -> isValidTarget(wither, entity)
                        && entity.distanceToSqr(wither) <= WITHER_TARGET_RANGE * WITHER_TARGET_RANGE)) {
            double distance = candidate.distanceToSqr(wither);
            if (distance < nearestDistance) {
                nearest = candidate;
                nearestDistance = distance;
            }
        }
        wither.setTarget(nearest);
    }

    private static boolean isValidTarget(WitherBoss wither, LivingEntity candidate) {
        if (candidate == null || candidate == wither || !candidate.isAlive()) {
            return false;
        }
        // 创造和旁观玩家不应成为凋灵的索敌目标，也要覆盖原版已保存的目标。
        if (candidate instanceof Player player && (player.isCreative() || player.isSpectator())) {
            return false;
        }
        return MesmerizerControl.canAttack(wither, candidate);
    }

    private static boolean isWithinRangedAttackRange(WitherBoss wither, LivingEntity target) {
        return isValidTarget(wither, target)
                && target.distanceToSqr(wither) <= WITHER_RANGED_ATTACK_RANGE * WITHER_RANGED_ATTACK_RANGE;
    }

    private static boolean hasRangedAttackTarget(WitherBoss wither) {
        if (isWithinRangedAttackRange(wither, wither.getTarget())) {
            return true;
        }
        for (int head = 0; head < 3; head++) {
            Entity candidate = wither.level().getEntity(wither.getAlternativeTarget(head));
            if (candidate instanceof LivingEntity target && isWithinRangedAttackRange(wither, target)) {
                return true;
            }
        }
        return false;
    }

    private static void shootExtraSkull(ServerLevel level, WitherBoss wither,
                                        LivingEntity target, boolean dangerous) {
        Vec3 direction = target.getEyePosition().subtract(wither.getEyePosition());
        if (direction.lengthSqr() < 1.0E-6D) {
            return;
        }
        direction = direction.normalize();
        WitherSkull skull = new WitherSkull(level, wither, direction);
        skull.setPos(wither.getEyePosition().add(direction.scale(1.2D)));
        skull.setDangerous(dangerous);
        skull.setDeltaMovement(direction);
        level.addFreshEntity(skull);
    }

    private static void applyContactDamage(ServerLevel level, WitherBoss wither) {
        AABB area = wither.getBoundingBox().inflate(0.25D);
        DamageSource source = witherMagicDamage(level, wither);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity != wither && entity.isAlive() && !entity.isInvertedHealAndHarm()
                        && MesmerizerControl.canAttack(wither, entity))) {
            victim.invulnerableTime = 0;
            victim.hurt(source, 1.0F);
            victim.invulnerableTime = 0;
        }
    }

    /**
     * 归因到凋灵本体身上的魔法伤害源。
     *
     * <p>原版 {@code DamageSources#magic()} 不带凶手：接触伤害与冲刺伤害打死的生物既算不到
     * 凋灵头上（拿不到 {@link #KILL_HEAL_AMOUNT} 回血），也不会触发凋灵骷髅阵营的感染判定。
     * 这里保持伤害类型仍是 {@code minecraft:magic}，只把因果实体与直接实体都补成凋灵本人。</p>
     */
    private static DamageSource witherMagicDamage(ServerLevel level, WitherBoss wither) {
        return new DamageSource(level.damageSources().magic().typeHolder(), wither, wither);
    }

    public static void triggerRise(WitherBoss wither) {
        if (!(wither.level() instanceof ServerLevel level)) {
            return;
        }
        CompoundTag data = wither.getPersistentData();
        double baseY = data.getBoolean(RISE_ACTIVE) ? data.getDouble(RISE_BASE_Y) : wither.getY();
        double targetY = baseY + RISE_HEIGHT;
        destroyVerticalPath(level, wither, targetY);
        wither.setPos(wither.getX(), targetY, wither.getZ());
        wither.setDeltaMovement(new Vec3(wither.getDeltaMovement().x, 0.0D, wither.getDeltaMovement().z));
        data.putBoolean(RISE_ACTIVE, true);
        data.putDouble(RISE_BASE_Y, baseY);
        data.putInt(RISE_RETURN_TICKS, RISE_RETURN_DELAY);
    }

    public static void tickRise(WitherBoss wither) {
        CompoundTag data = wither.getPersistentData();
        if (!data.getBoolean(RISE_ACTIVE)) {
            return;
        }
        int ticks = data.getInt(RISE_RETURN_TICKS);
        if (ticks > 1) {
            // 只记录倒计时，不再每 tick 把凋灵钉在 baseY + 2；否则会和原版飞行 AI
            // 争夺垂直位置，目标从高处下降后凋灵可能永远无法建立下降速度。
            data.putInt(RISE_RETURN_TICKS, ticks - 1);
            return;
        }

        double baseY = data.getDouble(RISE_BASE_Y);
        wither.setPosRaw(wither.getX(), baseY, wither.getZ());
        wither.setOldPosAndRot();
        wither.setDeltaMovement(new Vec3(wither.getDeltaMovement().x, 0.0D, wither.getDeltaMovement().z));
        wither.resetFallDistance();
        data.putBoolean(RISE_ACTIVE, false);
        data.remove(RISE_BASE_Y);
        data.remove(RISE_RETURN_TICKS);
    }

    private static void destroyVerticalPath(ServerLevel level, WitherBoss wither,
                                             double endY) {
        AABB start = wither.getBoundingBox();
        double deltaY = endY - wither.getY();
        AABB swept = sweptBox(start, new Vec3(0.0D, deltaY, 0.0D));
        int minX = (int) Math.floor(swept.minX - CONTACT_EPSILON);
        int minY = (int) Math.floor(swept.minY - CONTACT_EPSILON);
        int minZ = (int) Math.floor(swept.minZ - CONTACT_EPSILON);
        int maxX = (int) Math.floor(swept.maxX + CONTACT_EPSILON);
        int maxY = (int) Math.floor(swept.maxY + CONTACT_EPSILON);
        int maxZ = (int) Math.floor(swept.maxZ + CONTACT_EPSILON);
        for (BlockPos pos : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) {
            BlockState state = level.getBlockState(pos);
            if (WitherBoss.canDestroy(state) && touchesSweptBox(level, pos, state, swept)) {
                level.destroyBlock(pos, false, wither);
            }
        }
    }

    private static void summonReinforcements(ServerLevel level, WitherBoss wither) {
        int count = 1 + wither.getRandom().nextInt(3);
        for (int index = 0; index < count; index++) {
            Entity entity = switch (wither.getRandom().nextInt(3)) {
                case 0 -> EntityType.WITHER_SKELETON.create(level);
                case 1 -> GeneratedMod.BERSERKER.get().create(level);
                default -> GeneratedMod.NETHER_HUNTER.get().create(level);
            };
            if (!(entity instanceof Mob mob)) {
                continue;
            }
            double angle = (Math.PI * 2.0D * index / count) + wither.getRandom().nextDouble() * 0.5D;
            double distance = 2.0D + wither.getRandom().nextDouble() * 1.5D;
            mob.setPos(wither.getX() + Math.cos(angle) * distance,
                    wither.getY(), wither.getZ() + Math.sin(angle) * distance);
            DifficultyInstance difficulty = level.getCurrentDifficultyAt(mob.blockPosition());
            mob.finalizeSpawn(level, difficulty, MobSpawnType.MOB_SUMMONED, null);
            mob.setPersistenceRequired();
            markSummonedBy(mob, wither);
            level.addFreshEntity(mob);
        }
    }

    /**
     * 推进二阶段凋灵的冲刺：每 tick 沿既定方向平移 {@link #DASH_DISTANCE_PER_TICK} 格，
     * 扫过的走廊里对非凋灵骷髅阵营生物结算伤害并清掉可破坏方块。
     *
     * <p>冲刺途中只要撞上黄金制品（金块、金矿石、金粒、反逆者王冠、金胡萝卜、闪烁的
     * 西瓜、金苹果、附魔金苹果等方块或物品），冲刺立刻中断：黄金制品被清掉，凋灵吃 10 点
     * 虚空伤害，并进入正常冷却。若撞到的实体手持/穿戴的是"金胡萝卜、闪烁的西瓜、金苹果、
     * 附魔金苹果"这四件圣物，则优先只消除这些圣物，并让凋灵额外获得 30 秒虚弱 III。
     * 检测发生在清方块之前，否则金块会先被通用的冲刺破坏逻辑吃掉。</p>
     *
     * <p>尸鬼等凋灵骷髅阵营生物是凋灵的友军，它们身上带的金制品不构成阻断。</p>
     */
    /**
     * 凋灵当前是否正在冲刺位移中。
     *
     * <p>冲刺的移动完全由这里的逐 tick 位移接管（自己 {@code move} 再把速度清零），
     * 所以霸主凋灵自身的推进目标在冲刺期间要让位，别去抢 {@code MoveControl}。
     * 破坏口径同理独立：{@link #destroyDashBlocks} 连基岩一起清，与本体接触破坏互不影响。</p>
     */
    public static boolean isDashing(WitherBoss wither) {
        return wither.getPersistentData().getInt(DASH_TICKS) > 0;
    }

    /**
     * 冲刺方向（单位向量）；不在冲刺中时退回身体朝向。
     *
     * <p>霸主凋灵本体的接触破坏要按"这一拍真正前进的方向"清理走廊，冲刺期间就得用这里
     * 的固定航向，而不是已经被目标拉扯的身体朝向。</p>
     */
    public static Vec3 dashDirection(WitherBoss wither) {
        CompoundTag data = wither.getPersistentData();
        if (data.getInt(DASH_TICKS) <= 0) {
            return wither.getForward();
        }
        Vec3 direction = new Vec3(data.getDouble(DASH_X), data.getDouble(DASH_Y), data.getDouble(DASH_Z));
        return direction.lengthSqr() < 1.0E-8D ? wither.getForward() : direction.normalize();
    }

    /** 初始化冲刺循环：进入可用阶段的瞬间调用，保证首个冲刺在 30 秒后才触发。 */
    public static void initDashCycle(WitherBoss wither) {
        CompoundTag data = wither.getPersistentData();
        data.putBoolean(PHASE_TWO_INITIALIZED, true);
        data.putInt(DASH_COOLDOWN, DASH_INTERVAL);
    }

    public static void tickDash(ServerLevel level, WitherBoss wither) {
        CompoundTag data = wither.getPersistentData();
        int dashTicks = data.getInt(DASH_TICKS);
        if (dashTicks > 0) {
            Vec3 direction = new Vec3(data.getDouble(DASH_X), data.getDouble(DASH_Y), data.getDouble(DASH_Z));
            Vec3 start = wither.position();
            Vec3 movement = direction.scale(DASH_DISTANCE_PER_TICK);
            Vec3 end = start.add(movement);
            AABB sweptArea = sweptBox(wither.getBoundingBox(), movement).inflate(DASH_SWEEP_INFLATE);
            damageDashEntities(level, wither, sweptArea, data);
            if (blockDashOnGold(level, wither, sweptArea)) {
                data.putInt(DASH_TICKS, 0);
                data.putInt(DASH_COOLDOWN, DASH_INTERVAL);
                wither.invulnerableTime = 0;
                wither.hurt(level.damageSources().fellOutOfWorld(), DASH_GOLD_VOID_DAMAGE);
                return;
            }
            destroyDashBlocks(level, wither, start, end);
            wither.move(MoverType.SELF, movement);
            wither.setDeltaMovement(Vec3.ZERO);
            data.putInt(DASH_TICKS, dashTicks - 1);
            return;
        }

        int cooldown = Math.max(0, data.getInt(DASH_COOLDOWN) - 1);
        if (cooldown <= 0) {
            LivingEntity target = wither.getTarget();
            if (target != null && target.isAlive()) {
                startDash(wither, target);
                cooldown = DASH_INTERVAL;
            }
        }
        data.putInt(DASH_COOLDOWN, cooldown);
    }

    /**
     * 对冲刺走廊里的"非凋灵骷髅阵营"生物结算伤害：命中瞬间按其当前生命值的 25%，
     * 同一只生物在一次冲刺里只吃一次。
     *
     * <p>伤害走 {@link #witherMagicDamage}（魔法伤害、凶手挂凋灵），既保证击穿护甲后
     * 数字稳定，也让冲刺击杀能触发凋灵的击杀回血。</p>
     */
    private static void damageDashEntities(ServerLevel level, WitherBoss wither,
                                           AABB sweptArea, CompoundTag data) {
        DamageSource source = witherMagicDamage(level, wither);
        ListTag hitEntities = data.getList(DASH_HIT_ENTITIES, Tag.TAG_COMPOUND);
        for (Entity entity : level.getEntities(wither, sweptArea,
                candidate -> candidate instanceof LivingEntity living
                        && living.isAlive() && MesmerizerControl.canAttack(wither, living))) {
            if (!(entity instanceof LivingEntity victim) || containsEntity(hitEntities, entity)) {
                continue;
            }
            float amount = victim.getHealth() * DASH_DAMAGE_HEALTH_FRACTION;
            if (amount <= 0.0F) {
                continue;
            }
            victim.invulnerableTime = 0;
            victim.hurt(source, amount);
            victim.invulnerableTime = 0;
            CompoundTag hit = new CompoundTag();
            hit.putUUID("UUID", entity.getUUID());
            hitEntities.add(hit);
        }
        data.put(DASH_HIT_ENTITIES, hitEntities);
    }

    private static boolean containsEntity(ListTag hitEntities, Entity entity) {
        for (int index = 0; index < hitEntities.size(); index++) {
            CompoundTag hit = hitEntities.getCompound(index);
            if (hit.hasUUID("UUID") && hit.getUUID("UUID").equals(entity.getUUID())) {
                return true;
            }
        }
        return false;
    }

    /** 返回当前碰撞盒沿相对位移扫掠后的包围盒；movement 不是世界坐标点。 */
    private static AABB sweptBox(AABB box, Vec3 movement) {
        return new AABB(
                Math.min(box.minX, box.minX + movement.x),
                Math.min(box.minY, box.minY + movement.y),
                Math.min(box.minZ, box.minZ + movement.z),
                Math.max(box.maxX, box.maxX + movement.x),
                Math.max(box.maxY, box.maxY + movement.y),
                Math.max(box.maxZ, box.maxZ + movement.z));
    }

    /** 只有方块碰撞形状与凋灵本次实际扫过的盒子相交，才算凋灵接触到该方块。 */
    private static boolean touchesSweptBox(ServerLevel level, BlockPos pos, BlockState state, AABB sweptBox) {
        AABB expanded = new AABB(sweptBox.minX - CONTACT_EPSILON, sweptBox.minY - CONTACT_EPSILON,
                sweptBox.minZ - CONTACT_EPSILON, sweptBox.maxX + CONTACT_EPSILON,
                sweptBox.maxY + CONTACT_EPSILON, sweptBox.maxZ + CONTACT_EPSILON);
        for (AABB local : state.getCollisionShape(level, pos).toAabbs()) {
            AABB worldShape = local.move(pos.getX(), pos.getY(), pos.getZ());
            if (worldShape.intersects(expanded)) {
                return true;
            }
        }
        return false;
    }

    private static void destroyDashBlocks(ServerLevel level, WitherBoss wither,
                                          Vec3 start, Vec3 end) {
        Vec3 movement = end.subtract(start);
        AABB area = sweptBox(wither.getBoundingBox(), movement);
        int minX = (int) Math.floor(area.minX - CONTACT_EPSILON);
        int minY = (int) Math.floor(area.minY - CONTACT_EPSILON);
        int minZ = (int) Math.floor(area.minZ - CONTACT_EPSILON);
        int maxX = (int) Math.floor(area.maxX + CONTACT_EPSILON);
        int maxY = (int) Math.floor(area.maxY + CONTACT_EPSILON);
        int maxZ = (int) Math.floor(area.maxZ + CONTACT_EPSILON);
        for (BlockPos pos : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) {
            BlockState state = level.getBlockState(pos);
            // 凋灵冲刺可以破坏基岩（原版凋灵不可破坏方块中的特例），但仍只能清扫掠过的方块。
            if ((state.is(Blocks.BEDROCK) || WitherBoss.canDestroy(state))
                    && touchesSweptBox(level, pos, state, area)) {
                level.destroyBlock(pos, false, wither);
            }
        }
    }

    /** 一次装备清扫的结果：没清到东西 / 清了普通黄金制品 / 清了四件圣物之一。 */
    private enum GoldStripResult {
        NONE,
        GOLD,
        SACRED_FOOD
    }

    /**
     * 冲刺路径上的黄金检测：撞到黄金相关方块就把它清掉，撞到手持/穿戴黄金相关物品的
     * 实体就把那些物品清掉。只要清掉任意一件，本次冲刺就算被阻断。
     *
     * <p>判定口径是"注册名里带 gold"（金锭、金粒、金块、金剑、金盔甲、粗金、金矿石、
     * 金胡萝卜、金苹果、附魔金苹果，以及模组里各类金制变体都覆盖），名字里没有 gold 的
     * 反逆者王冠（{@code netherarmy:mesmerizer_crown}）、闪烁的西瓜
     * （{@code minecraft:glistering_melon_slice}）与金镶黑石单独补上；方块另外认
     * {@link BlockTags#GOLD_ORES}，照顾到被打了金矿标签但命名不同的模组方块。</p>
     *
     * <p>手持/穿戴四件圣物（金胡萝卜、闪烁的西瓜、金苹果、附魔金苹果）的实体优先走特殊
     * 分支：只消除这些圣物，并让凋灵额外吃 30 秒虚弱 III。凋灵骷髅阵营的友军（尸鬼等）
     * 不参与检测，它们带着黄金也不会阻断冲刺。</p>
     */
    private static boolean blockDashOnGold(ServerLevel level, WitherBoss wither, AABB sweptArea) {
        boolean blocked = false;
        BlockPos min = BlockPos.containing(sweptArea.minX, sweptArea.minY, sweptArea.minZ);
        BlockPos max = BlockPos.containing(sweptArea.maxX, sweptArea.maxY, sweptArea.maxZ);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = level.getBlockState(pos);
            if (isGoldRelatedBlock(state) && touchesSweptBox(level, pos, state, sweptArea)) {
                // drop=false：金块等直接消失，不给掉落物；仍要求确实被冲刺扫到。
                level.destroyBlock(pos, false, wither);
                blocked = true;
            }
        }
        boolean sacredFoodStripped = false;
        for (Entity entity : level.getEntities(wither, sweptArea,
                candidate -> candidate instanceof LivingEntity living && living.isAlive())) {
            LivingEntity living = (LivingEntity) entity;
            // 尸鬼等凋灵骷髅阵营生物是凋灵的友军，身上带什么都不阻断冲刺。
            if (MesmerizerControl.isWitherSkeletonFaction(living)) {
                continue;
            }
            GoldStripResult result = stripGoldEquipment(living);
            if (result == GoldStripResult.NONE) {
                continue;
            }
            blocked = true;
            if (result == GoldStripResult.SACRED_FOOD) {
                sacredFoodStripped = true;
            }
        }
        if (sacredFoodStripped) {
            wither.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,
                    DASH_WEAKNESS_DURATION, DASH_WEAKNESS_AMPLIFIER));
        }
        return blocked;
    }

    private static boolean isGoldRelatedBlock(BlockState state) {
        if (state.isAir()) {
            return false;
        }
        if (state.is(BlockTags.GOLD_ORES) || state.is(Blocks.GILDED_BLACKSTONE)) {
            return true;
        }
        return registryNameHasGold(BuiltInRegistries.BLOCK.getKey(state.getBlock()));
    }

    private static boolean isGoldRelatedItem(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        // 注册名里没有 gold、但属于黄金相关制品的少数几件，单独列出。
        if (stack.is(Items.GILDED_BLACKSTONE)
                || stack.is(Items.GLISTERING_MELON_SLICE)
                || stack.is(GeneratedMod.MESMERIZER_CROWN.get())) {
            return true;
        }
        return registryNameHasGold(BuiltInRegistries.ITEM.getKey(stack.getItem()));
    }

    /**
     * "四件圣物"：金胡萝卜、闪烁的西瓜、金苹果、附魔金苹果。凋灵冲刺接触到持有它们的
     * 实体时，优先消除这些物品，并额外获得 30 秒虚弱 III。
     */
    private static boolean isSacredGoldFood(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        return stack.is(Items.GOLDEN_CARROT)
                || stack.is(Items.GLISTERING_MELON_SLICE)
                || stack.is(Items.GOLDEN_APPLE)
                || stack.is(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static boolean registryNameHasGold(ResourceLocation id) {
        return id != null && id.getPath().contains("gold");
    }

    /**
     * 清空实体手持/穿戴的黄金相关物品（含装备槽）。
     *
     * <p>优先扫四件圣物：只要身上有其中任意一件，就只清这些圣物并返回
     * {@link GoldStripResult#SACRED_FOOD}，其余黄金装备这一轮不动；一件圣物都没有时，
     * 才按普通口径清掉所有黄金相关物品。</p>
     */
    private static GoldStripResult stripGoldEquipment(LivingEntity entity) {
        boolean sacred = false;
        for (EquipmentSlot slot : GOLD_EQUIPMENT_SLOTS) {
            if (isSacredGoldFood(entity.getItemBySlot(slot))) {
                entity.setItemSlot(slot, ItemStack.EMPTY);
                sacred = true;
            }
        }
        if (sacred) {
            return GoldStripResult.SACRED_FOOD;
        }
        boolean stripped = false;
        for (EquipmentSlot slot : GOLD_EQUIPMENT_SLOTS) {
            if (isGoldRelatedItem(entity.getItemBySlot(slot))) {
                entity.setItemSlot(slot, ItemStack.EMPTY);
                stripped = true;
            }
        }
        return stripped ? GoldStripResult.GOLD : GoldStripResult.NONE;
    }

    private static void startDash(WitherBoss wither, LivingEntity target) {
        Vec3 away = wither.position().subtract(target.position());
        away = new Vec3(away.x, 0.0D, away.z);
        if (away.lengthSqr() < 1.0E-6D) {
            away = new Vec3(1.0D, 0.0D, 0.0D);
        }
        away = away.normalize();
        wither.move(MoverType.SELF, away.scale(5.0D));

        Vec3 toward = target.position().subtract(wither.position());
        if (toward.lengthSqr() < 1.0E-6D) {
            return;
        }
        startDashInDirection(wither, toward.normalize());
    }

    private static void startDashInDirection(WitherBoss wither, Vec3 direction) {
        CompoundTag data = wither.getPersistentData();
        data.putDouble(DASH_X, direction.x);
        data.putDouble(DASH_Y, direction.y);
        data.putDouble(DASH_Z, direction.z);
        data.putInt(DASH_TICKS, DASH_DURATION);
        data.put(DASH_HIT_ENTITIES, new ListTag());
    }

    /**
     * 二阶段凋灵被方块窒息：立刻朝任意水平方向来一次冲刺自救。冲刺途中会顺带清空
     * 路径上的方块（含基岩），因此不需要额外的后撤位移，避免反而钻进更深的方块。
     * 已在冲刺中则不重复触发。
     */
    public static void triggerSuffocationDash(WitherBoss wither) {
        CompoundTag data = wither.getPersistentData();
        if (data.getInt(DASH_TICKS) > 0) {
            return;
        }
        double angle = wither.getRandom().nextDouble() * Math.PI * 2.0D;
        startDashInDirection(wither, new Vec3(Math.cos(angle), 0.0D, Math.sin(angle)));
        data.putInt(DASH_COOLDOWN, DASH_INTERVAL);
    }

    /**
     * 给凋灵召唤出的生物打上召唤者印记，并把凋灵当前的仇恨作为初始目标。
     * 之后由 {@link #syncSummonedMobTarget(Mob)} 持续保持一致。
     */
    public static void markSummonedBy(Mob summoned, WitherBoss wither) {
        summoned.getPersistentData().putUUID(SUMMONER_WITHER, wither.getUUID());
        LivingEntity target = wither.getTarget();
        if (target != null && target.isAlive() && target != summoned
                && MesmerizerControl.canAttack(summoned, target)) {
            summoned.setTarget(target);
        }
    }

    /** 让所有带着召唤者印记的生物持续跟随召唤它的凋灵的仇恨。 */
    private static void syncSummonedMobTarget(Mob mob) {
        CompoundTag data = mob.getPersistentData();
        if (!data.hasUUID(SUMMONER_WITHER) || !(mob.level() instanceof ServerLevel level)) {
            return;
        }
        Entity summoner = level.getEntity(data.getUUID(SUMMONER_WITHER));
        if (!(summoner instanceof WitherBoss wither) || !wither.isAlive()) {
            data.remove(SUMMONER_WITHER);
            return;
        }
        LivingEntity target = wither.getTarget();
        if (target == null || !target.isAlive() || target == mob || mob.getTarget() == target) {
            return;
        }
        if (MesmerizerControl.canAttack(mob, target)) {
            mob.setTarget(target);
        }
    }

    /**
     * 二阶段口径与原版 {@code WitherBoss#isPowered()} 一致（血量 ≤ 上限一半），
     * 但必须叠加"召唤动画已结束"（{@code Invul} 计到 0）的前置条件。
     *
     * <p>原版凋灵被召唤时走 {@code makeInvulnerable()}：{@code Invul} 置 220 tick，
     * 血量<b>直接设为上限的三分之一</b>（本模组上限 600，即 600 → 200），动画期间再
     * 每 10 tick 回复 10 点（本模组另有 {@link #topOffSpawnAnimation} 补拍，收尾恰好
     * 回满）。只看血量阈值，前半段动画里凋灵恒处于"半血以下"，刚生成的一拍就会被
     * 误判为二阶段，把 {@link #PHASE_TWO_INITIALIZED} 这个一次性标记连同巡逻队提前消耗掉；
     * 真正掉到半血时标记已置位，转阶段技能反而不再触发。</p>
     *
     * <p>上限 600 之后，这条"半血"口径连同原版 {@code isPowered()}（蓝头瞄准、凋灵护甲
     * 外观与渲染、破坏方块）一起自动平移到 300，无需单独配置阈值。</p>
     */
    private static boolean isPhaseTwo(WitherBoss wither) {
        return wither.getInvulnerableTicks() <= 0
                && wither.getHealth() <= wither.getMaxHealth() * 0.5F;
    }

    private static WitherBoss findWither(Entity direct, Entity causing) {
        if (causing instanceof WitherBoss wither) {
            return wither;
        }
        if (direct instanceof WitherSkull skull && skull.getOwner() instanceof WitherBoss wither) {
            return wither;
        }
        return direct instanceof WitherBoss wither ? wither : null;
    }
}
