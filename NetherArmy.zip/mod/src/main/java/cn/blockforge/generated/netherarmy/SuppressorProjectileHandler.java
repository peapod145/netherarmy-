package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;

/**
 * 反转士 2 格反弹护盾的命中兜底。
 *
 * <p>{@link Suppressor#tick()} 里逐刻扫气泡已经能拦下绝大多数弹丸，但实体 tick 的
 * 先后顺序不作保证：万一某枚高速弹丸在一帧之内从 2 格外直接跨进判定箱，并且它的 tick
 * 排在反转士前面，气泡扫描就来不及。这里在 {@code ProjectileImpactEvent} 上再拦一道——
 * 只要是打在反转士身上的、来自非凋灵骷髅阵营生物的抛射物，一律取消命中判定并原路弹回，
 * 效果与凋灵护盾的抛射物反弹一致。</p>
 *
 * <p>判定复用 {@link Suppressor#canDeflect}：圣光炸弹、自己射的、阵营成员射的都不弹；
 * "正在靠近"的闸门在这一层恒成立（已经在命中姿态），保留只是为了与气泡扫描共用一套逻辑。</p>
 */
public final class SuppressorProjectileHandler {

    private SuppressorProjectileHandler() {
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof Suppressor suppressor)
                || suppressor.level().isClientSide()) {
            return;
        }
        Projectile projectile = event.getProjectile();
        if (!Suppressor.canDeflect(projectile, suppressor)) {
            return;
        }
        Suppressor.reflectProjectile(projectile, suppressor);
        event.setCanceled(true);
    }
}
