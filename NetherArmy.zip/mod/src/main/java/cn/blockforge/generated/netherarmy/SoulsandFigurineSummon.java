package cn.blockforge.generated.netherarmy;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CarvedPumpkinBlock;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;

/**
 * 灵魂土偶召唤：南瓜头叠两块灵魂土，结构与雪傀儡相同。
 */
public final class SoulsandFigurineSummon {
    private static BlockPattern pattern;

    private SoulsandFigurineSummon() {
    }

    public static boolean canSpawn(LevelReader level, BlockPos pos) {
        return getPattern().find(level, pos) != null;
    }

    public static boolean trySpawn(Level level, BlockPos pos) {
        if (level.isClientSide) {
            return false;
        }
        BlockPattern.BlockPatternMatch match = getPattern().find(level, pos);
        if (match == null) {
            return false;
        }
        SoulsandFigurine figurine = GeneratedMod.SOULSAND_FIGURINE.get().create(level);
        if (figurine == null) {
            return false;
        }
        BlockPos spawnPos = match.getBlock(0, 2, 0).getPos();
        CarvedPumpkinBlock.clearPatternBlocks(level, match);
        figurine.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY() + 0.05D, spawnPos.getZ() + 0.5D, 0.0F, 0.0F);
        assignNearestOwner(level, figurine);
        level.addFreshEntity(figurine);
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class,
                figurine.getBoundingBox().inflate(5.0D))) {
            CriteriaTriggers.SUMMONED_ENTITY.trigger(player, figurine);
        }
        CarvedPumpkinBlock.updatePatternBlocks(level, match);
        return true;
    }

    public static void assignNearestOwner(Level level, SoulsandFigurine figurine) {
        ServerPlayer nearest = null;
        double best = Double.MAX_VALUE;
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class,
                figurine.getBoundingBox().inflate(8.0D))) {
            double distance = player.distanceToSqr(figurine);
            if (distance < best) {
                best = distance;
                nearest = player;
            }
        }
        if (nearest != null) {
            figurine.setOwnerUUID(nearest.getUUID());
        }
    }

    public static boolean shouldAssignOwner(MobSpawnType spawnType) {
        return spawnType == MobSpawnType.SPAWN_EGG
                || spawnType == MobSpawnType.MOB_SUMMONED
                || spawnType == MobSpawnType.DISPENSER
                || spawnType == MobSpawnType.BUCKET;
    }

    private static BlockPattern getPattern() {
        if (pattern == null) {
            pattern = BlockPatternBuilder.start()
                    .aisle("^", "#", "#")
                    .where('^', BlockInWorld.hasState(state ->
                            state.is(Blocks.CARVED_PUMPKIN) || state.is(Blocks.JACK_O_LANTERN)))
                    .where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.SOUL_SOIL)))
                    .build();
        }
        return pattern;
    }
}
