package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 下界传令兵本体模型：几何与 UV 逐立方体复刻用户上传的《下界传令兵-2.bbmodel》。
 *
 * <h3>坐标系换算（上一版"错位"的根因）</h3>
 * <p>bbmodel 里立方体用的是"地面 y=0、y 轴向上"的绝对坐标；Java 实体模型
 * （{@code LayerDefinition}）用的是 {@code HumanoidModel.createMesh} 那套
 * "y 轴向下、枢轴"坐标，两者换算为 {@code y_java = 24 - y_bb}。上一版误用了
 * 1.17 以前旧 {@code ModelBiped} 的枢轴数值（头/身 24、肩 22），在这套空间里
 * 会把躯干画到脚底以下、腿画到头顶以上，整机错位。本版枢轴全部取原版
 * {@code createMesh} 实测值：头/身枢轴 (0,0,0)、肩 (±5,2,0)、髋 (±1.9,12,0)。</p>
 *
 * <h3>逐立方体对照（bbmodel 绝对坐标 → Java 部件局部坐标）</h3>
 * <ul>
 *   <li>head：x -4..4, y 24..32, z -4..4 → 枢轴 (0,0,0) + box(-4,-8,-4,8,8,8)，texOffs(0,0)；</li>
 *   <li>body：x -4..4, y 12..24, z -2..2 → 枢轴 (0,0,0) + box(-4,0,-2,8,12,4)，texOffs(16,16)；</li>
 *   <li>right_arm：x -6..-4, y 10..22, z -1..1 → 枢轴 (-5,2,0) + box(-1,0,-1,2,12,2)，texOffs(40,16)；</li>
 *   <li>left_arm：x 4..6, y 10..22, z -1..1 → 枢轴 (5,2,0) + box(-1,0,-1,2,12,2)，texOffs(40,16)；</li>
 *   <li>right_leg：x -2.9..-0.9, y 0..12, z -1..1 → 枢轴 (-1.9,12,0) + box(-1,0,-1,2,12,2)，texOffs(0,16)；</li>
 *   <li>left_leg：x 0.9..2.9, y 0..12, z -1..1 → 枢轴 (1.9,12,0) + box(-1,0,-1,2,12,2)，texOffs(0,16)。</li>
 * </ul>
 * <p>六个立方体的逐面 UV 与原版 64×32 人形网格完全吻合（bbmodel 的 east/west、
 * up/down 面标签相对 Java {@code ModelPart.Cube} 的槽位互换，正是 Java↔基岩
 * 贴图惯例的差异，texOffs 单偏移量即可原样还原作者意图，无需镜像），与
 * {@link WitherZombieModel} 注释里验证过的映射规律一致。</p>
 *
 * <h3>身高</h3>
 * <p>本网格与原版凋灵骷髅一样按 32px（2.0 格）搭建，"与凋灵骷髅等高"由渲染器
 * {@code WitherSkeletonRenderer} 同款的 1.2× 整体放大达成（2.0 × 1.2 = 2.4 格，
 * 判定箱 0.6×2.4），见 GeneratedModClient 的 NetherCourierRenderer#scale。
 * 四肢宽度（2px）、躯干（8×12×4）等全部保持用户上传模型的原尺寸。</p>
 *
 * <h3>双臂恒前平举 + 攻击挥手</h3>
 * <p>观感要求：常态（走路、待机）双手始终水平前伸（旗帜由 ItemInHandLayer
 * 挂在右臂末端，随手臂保持前指）。{@code setupAnim} 在 super 之后把两条手臂
 * 的旋转钉死为绕 X 轴 -90°（僵尸前伸手臂的同款角度），头部摆动与双腿走路
 * 动画不受影响。攻击时在钉死的基准上给右臂叠加原版挥砍节拍的挥手动作，
 * 见 {@link CourierArmAnimation#apply}——不能沿用 super 写进右臂的原版挥砍，
 * 因为那份增量叠在垂手基准上，会被随后的钉死抹掉（上一版"攻击不挥手"的
 * 根因）。</p>
 *
 * <p>胸甲与左右肩甲不在本模型内——它们用第二张 32×32 贴图、由
 * {@link NetherCourierArmorModel} 单独成层渲染，受击闪红只作用于本体的
 * 头/身/臂/腿（见 GeneratedModClient 的 NetherCourierRenderer）。</p>
 */
public final class NetherCourierModel extends HumanoidModel<NetherCourier> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "nether_courier"), "main");

    public NetherCourierModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(NetherCourier entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // 常态钉死双臂前平举；正在挥砍（attackTime>0）时在基准上叠加右臂挥手。
        CourierArmAnimation.apply(this);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }
}
