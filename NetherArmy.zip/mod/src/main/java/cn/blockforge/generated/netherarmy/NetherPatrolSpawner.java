package cn.blockforge.generated.netherarmy;

import java.util.List;
import java.util.function.Consumer;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * 下界巡逻队：在下界随机刷新的军团编队，刷新节奏逐项对齐原版掠夺者巡逻队
 * （{@code PatrolSpawner}）——冷却 12000+rand(1200) tick，冷却到期后 2/5 概率
 * 出手（原版为 1/5，本模组按需求翻倍），锚点取随机玩家 24~48 格外（横/纵各自独立），
 * 要求区块已加载、生物群系不在 {@code without_patrol_spawns} 标签内。
 *
 * <p>与原版的两处必要差异：① 维度换成下界，因此不做"第 5 个白天后白天不刷"
 * 的昼夜判定（下界没有昼夜）；② 编队构成固定，不再随难度增减人数：</p>
 * <ul>
 *   <li>必带：1 名下界传令兵（领队，落点不合法则整队取消，与原版队长同规则）；</li>
 *   <li>必带：2 名下界猎手；</li>
 *   <li>随机 3 名，每名独立掷：60% 原版凋灵骷髅、30% 狂战士、5% 无头骑士
 *       （{@link DullhanBody} 生成时自动带马与头颅）、5% 反逆者。</li>
 * </ul>
 *
 * <p>落点检查：从 y=126（顶棚基岩之下）逐格向下扫，取第一个"脚下实心、脚与头
 * 两格不挡实体（草/花这类不挡）"的位置——下界任何高度图都恒返回屋顶之上的 128，
 * 绝不能用作落点，否则整队会刷在玩家看不见的地狱屋顶上。不要求原版怪物生成的
 * 光照条件——军团成员本就免疫烈焰地形，且这是事件式编队刷新而非自然刷怪。
 * 每名成员落点后 x/z 各抖 ±(0~4) 格，与原版一致，避免整队叠在同一个格子里。</p>
 *
 * <p>除自发刷新外，本类还向凋灵二阶段技能提供 {@link #summonSquadAt}：以凋灵为锚点
 * 立即刷出同样构成的一整队，成员仇恨由调用方挂到凋灵身上（见
 * {@link WitherEnhancementHandler}），与凋灵自身的其他召唤物规则一致。</p>
 */
public final class NetherPatrolSpawner {
    /** 与原版 PatrolSpawner 相同的冷却与随机抖动。 */
    private static final int SPAWN_COOLDOWN_TIME = 12000;
    private static final int COOLDOWN_JITTER = 1200;
    /** 原版：冷却到期后 nextInt(5)==0 才尝试，即 20%；本模组翻倍为 2/5（40%）。 */
    private static final int SPAWN_CHANCE_NUMERATOR = 2;
    private static final int SPAWN_CHANCE_DENOMINATOR = 5;
    private static final int MIN_SPAWN_DISTANCE = 24;
    private static final int MAX_SPAWN_DISTANCE = 48;
    /** 下界顶棚基岩在 y=127，落点扫描必须从它下方一格开始（见 {@link #findFloor}）。 */
    private static final int ROOF_SCAN_TOP = 126;

    private static int nextTick = SPAWN_COOLDOWN_TIME;

    private NetherPatrolSpawner() {
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        ServerLevel level = event.getServer().getLevel(Level.NETHER);
        if (level == null) {
            return;
        }
        if (!level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)
                || !level.getGameRules().getBoolean(GameRules.RULE_DO_PATROL_SPAWNING)
                || level.getDifficulty() == Difficulty.PEACEFUL) {
            return;
        }
        if (nextTick > 0) {
            nextTick--;
            return;
        }
        RandomSource random = level.getRandom();
        nextTick = SPAWN_COOLDOWN_TIME + random.nextInt(COOLDOWN_JITTER);
        if (random.nextInt(SPAWN_CHANCE_DENOMINATOR) >= SPAWN_CHANCE_NUMERATOR) {
            return;
        }
        List<ServerPlayer> players = level.players().stream()
                .filter(player -> !player.isSpectator())
                .toList();
        if (players.isEmpty()) {
            return;
        }
        ServerPlayer anchor = players.get(random.nextInt(players.size()));
        int dx = MIN_SPAWN_DISTANCE + random.nextInt(MAX_SPAWN_DISTANCE - MIN_SPAWN_DISTANCE + 1);
        int dz = MIN_SPAWN_DISTANCE + random.nextInt(MAX_SPAWN_DISTANCE - MIN_SPAWN_DISTANCE + 1);
        if (random.nextBoolean()) {
            dx = -dx;
        }
        if (random.nextBoolean()) {
            dz = -dz;
        }
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(
                anchor.blockPosition().getX() + dx, 0, anchor.blockPosition().getZ() + dz);
        if (!level.hasChunksAt(pos.getX() - 10, pos.getZ() - 10, pos.getX() + 10, pos.getZ() + 10)) {
            return;
        }
        if (level.getBiome(pos).is(BiomeTags.WITHOUT_PATROL_SPAWNS)) {
            return;
        }
        spawnSquad(level, pos, random);
    }

    private static void spawnSquad(ServerLevel level, BlockPos.MutableBlockPos pos, RandomSource random) {
        spawnSquad(level, pos, random, mob -> { }, defaultScanTop(level));
    }

    /**
     * 刷出一支完整巡逻队。
     *
     * @param memberTuning 每名成员 finalizeSpawn 之后、进世界之前的后处理钩子
     *                     （自发刷新传空实现；凋灵召唤用它打召唤者印记）
     * @param scanTop      落点扫描的起始高度，向下找第一个可站立地面
     * @return 领队传令兵是否落地成功（失败即整队取消，与原版队长同规则）
     */
    private static boolean spawnSquad(ServerLevel level, BlockPos.MutableBlockPos pos, RandomSource random,
                                      Consumer<Mob> memberTuning, int scanTop) {
        // 领队传令兵必须落地成功，否则整队取消（与原版队长同规则）。
        if (!spawnMember(level, pos, random, GeneratedMod.NETHER_COURIER.get(), memberTuning, scanTop)) {
            return false;
        }
        jitter(pos, random);
        spawnMember(level, pos, random, GeneratedMod.NETHER_HUNTER.get(), memberTuning, scanTop);
        jitter(pos, random);
        spawnMember(level, pos, random, GeneratedMod.NETHER_HUNTER.get(), memberTuning, scanTop);
        for (int i = 0; i < 3; i++) {
            jitter(pos, random);
            spawnMember(level, pos, random, rollRandomMember(random), memberTuning, scanTop);
        }
        return true;
    }

    /**
     * 凋灵由一阶段转入二阶段时立即召唤的下界巡逻队：编队构成与自发刷新完全一致
     * （领队传令兵 + 2 名下界猎手 + 3 名随机成员），差别只有三处——
     * ① 锚点取凋灵所在位置，从凋灵所在高度向下找地面，让整队直接出现在凋灵脚下；
     * ② 每名成员经 {@code memberTuning} 后处理（{@link WitherEnhancementHandler}
     * 用它打召唤者印记，使巡逻队仇恨与凋灵保持一致，并锁定不消失）；
     * ③ 这是凋灵的战斗技能而非生态刷新，不受 {@code do_patrol_spawning} 等游戏规则、
     * 和平难度与自然冷却的约束，也不看生物群系标签。
     *
     * <p>凋灵悬空或正下方找不到地面时，围绕锚点再采样 5 次；整队取消只发生在所有采样点
     * 领队都落不了地的场合（领队失败时其他成员尚未生成，重试不会产生半支巡逻队）。</p>
     */
    public static boolean summonSquadAt(ServerLevel level, Vec3 anchor, Consumer<Mob> memberTuning) {
        RandomSource random = level.getRandom();
        int scanTop = Mth.floor(anchor.y);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(
                Mth.floor(anchor.x), scanTop, Mth.floor(anchor.z));
        for (int attempt = 0; attempt < 6; attempt++) {
            if (attempt > 0) {
                double angle = random.nextDouble() * Math.PI * 2.0D;
                double distance = 2.0D + random.nextDouble() * 6.0D;
                pos.setX(Mth.floor(anchor.x + Math.cos(angle) * distance));
                pos.setZ(Mth.floor(anchor.z + Math.sin(angle) * distance));
            }
            if (spawnSquad(level, pos, random, memberTuning, scanTop)) {
                return true;
            }
        }
        return false;
    }

    /** 随机成员独立掷：60% 凋灵骷髅、30% 狂战士、5% 无头骑士、5% 反逆者。 */
    private static EntityType<? extends Mob> rollRandomMember(RandomSource random) {
        float roll = random.nextFloat();
        if (roll < 0.60F) {
            return EntityType.WITHER_SKELETON;
        }
        if (roll < 0.90F) {
            return GeneratedMod.BERSERKER.get();
        }
        if (roll < 0.95F) {
            return GeneratedMod.DULLHAN_BODY.get();
        }
        return GeneratedMod.MESMERIZER.get();
    }

    private static void jitter(BlockPos.MutableBlockPos pos, RandomSource random) {
        pos.setX(pos.getX() + random.nextInt(5) - random.nextInt(5));
        pos.setZ(pos.getZ() + random.nextInt(5) - random.nextInt(5));
    }

    private static boolean spawnMember(ServerLevel level, BlockPos.MutableBlockPos pos,
                                       RandomSource random, EntityType<? extends Mob> type,
                                       Consumer<Mob> memberTuning, int scanTop) {
        if (!findFloor(level, pos, scanTop)) {
            return false;
        }
        Mob member = type.create(level);
        if (member == null) {
            return false;
        }
        member.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
        member.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.PATROL, null);
        memberTuning.accept(member);
        level.addFreshEntityWithPassengers(member);
        return true;
    }

    /** 自发刷新用的扫描顶：下界顶棚基岩之下、且不高于建筑上限。 */
    private static int defaultScanTop(ServerLevel level) {
        return Math.min(ROOF_SCAN_TOP, level.getMaxBuildHeight() - 2);
    }

    /**
     * 自上而下找可站立的落点。
     *
     * <p>不能用 {@code getHeightmapPos}：下界顶棚基岩（y=127）是 motion-blocking
     * 方块，任何高度图（MOTION_BLOCKING / WORLD_SURFACE 等）在下界都恒返回 128，
     * 上一版据此落点，整支巡逻队其实全部刷在了下界屋顶之上、玩家永远看不见。
     * 自发刷新从顶棚下方一格（{@link #defaultScanTop}）逐格向下扫；凋灵召唤则从
     * 凋灵所在高度扫起，让整队直接落在凋灵脚下。取第一个"脚下实心、头脚两格可站"
     * 的位置；扫到维度最低建筑高度仍无落点则本成员放弃。</p>
     */
    private static boolean findFloor(ServerLevel level, BlockPos.MutableBlockPos pos, int scanTop) {
        int top = Math.min(scanTop, level.getMaxBuildHeight() - 2);
        int bottom = level.getMinBuildHeight() + 1;
        for (int y = top; y >= bottom; y--) {
            pos.setY(y);
            if (isSquadPlacement(level, pos)) {
                return true;
            }
        }
        return false;
    }

    /** 脚下有实心地面（不含流体），脚、头两格实体可通过。 */
    private static boolean isSquadPlacement(ServerLevel level, BlockPos pos) {
        BlockState ground = level.getBlockState(pos.below());
        if (!ground.blocksMotion() || !ground.getFluidState().isEmpty()) {
            return false;
        }
        return passesThrough(level, pos) && passesThrough(level, pos.above());
    }

    private static boolean passesThrough(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return !state.blocksMotion() && state.getFluidState().isEmpty();
    }
}
