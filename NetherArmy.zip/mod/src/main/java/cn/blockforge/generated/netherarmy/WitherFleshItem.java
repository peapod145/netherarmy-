package cn.blockforge.generated.netherarmy;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * 枯肉：尸鬼与衰翼掉落的凋零腐肉。
 *
 * <p>饥饿/饱和度由 {@code FOOD} 数据组件结算（5 点饥饿、1.5 倍率 → 5×1.5×2 = 15 点饱和度）。
 * 食用后的随机效果在这里结算：{@code super.finishUsingItem} 内部走
 * {@code LivingEntity#eat}（消耗物品 + 组件效果），随后按 80% / 20% 二选一——
 * 用一次掷骰保证"凋零 II 10 秒"与"饱和 10 秒"互斥，不能写成两条组件效果
 * （{@code FoodProperties} 的每条效果独立掷概率，会同时命中或同时落空）。
 * 服务端侧施加，避免客户端预测造成效果闪烁。</p>
 */
public class WitherFleshItem extends Item {
    /** 获得凋零 II（10 秒）的概率；否则（20%）获得饱和（10 秒）。 */
    public static final float WITHER_CHANCE = 0.8F;
    /** 10 秒 = 200 刻。 */
    public static final int EFFECT_DURATION = 200;

    public WitherFleshItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
        ItemStack result = super.finishUsingItem(stack, level, livingEntity);
        if (!level.isClientSide) {
            if (livingEntity.getRandom().nextFloat() < WITHER_CHANCE) {
                // 凋零 II：等级 2 对应 amplifier 1。
                livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, EFFECT_DURATION, 1));
            } else {
                livingEntity.addEffect(new MobEffectInstance(MobEffects.SATURATION, EFFECT_DURATION, 0));
            }
        }
        return result;
    }
}
