package cn.blockforge.generated.netherarmy;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.DaylightDetectorBlock;
import net.minecraft.world.level.block.DetectorRailBlock;
import net.minecraft.world.level.block.DiodeBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.ObserverBlock;
import net.minecraft.world.level.block.PoweredRailBlock;
import net.minecraft.world.level.block.RedStoneWireBlock;
import net.minecraft.world.level.block.TargetBlock;
import net.minecraft.world.level.block.TntBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 黑客：中立的凋灵骷髅阵营电脑专家。 */
public class Hacker extends PathfinderMob {
    public static final int COMPUTER_TICKS = 100;
    /** 使用电脑"结束"的音效提前播放的 tick 数（动画还剩 5 tick 时即响）。 */
    public static final int SOUND_LEAD_TICKS = 5;
    public static final int EFFECT_TICKS = 200;
    public static final int SEARCH_RANGE = 50;
    public static final int REDSTONE_SCAN_INTERVAL = 500;
    /** 敌意察觉扫描周期：1 秒，保证被盯上后很快进入反制而不是先挨打。 */
    public static final int HOSTILE_SCAN_INTERVAL = 20;

    private static final EntityDataAccessor<Integer> DATA_COMPUTER_TICKS =
            SynchedEntityData.defineId(Hacker.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Byte> DATA_COMPUTER_KIND =
            SynchedEntityData.defineId(Hacker.class, EntityDataSerializers.BYTE);

    private static final byte NONE = 0;
    private static final byte DOOR = 1;
    private static final byte REDSTONE = 2;
    private static final byte REVENGE = 3;

    private int computerTicks;
    private byte computerKind;
    private BlockPos computerPos;
    private UUID computerEnemy;
    private int redstoneTimer = REDSTONE_SCAN_INTERVAL;
    /** 敌意察觉扫描计时器：每 HOSTILE_SCAN_INTERVAL tick 找一次"仇恨指向自己"的生物。 */
    private int hostileScanTimer = 10;
    private BlockPos hackedDoor;
    private long doorCloseAt;
    private BlockPos hackedRedstone;
    private BlockState redstoneOriginal;
    private BlockState redstoneChanged;
    private long redstoneRestoreAt;
    private LivingEntity fleeFrom;
    private long fleeUntil;

    public Hacker(EntityType<? extends Hacker> type, Level level) {
        super(type, level);
        this.xpReward = 5;
        this.setCanPickUpLoot(false);
        this.setPathfindingMalus(PathType.DOOR_WOOD_CLOSED, 0.0F);
        this.setPathfindingMalus(PathType.DOOR_IRON_CLOSED, 1.0F);
        this.setPathfindingMalus(PathType.DOOR_OPEN, 0.0F);
        if (this.getNavigation() instanceof net.minecraft.world.entity.ai.navigation.GroundPathNavigation ground) {
            ground.setCanOpenDoors(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ARMOR, 2.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                // Mob 模板本身不含 ATTACK_DAMAGE；显式给一份基础近战攻击力，
                // 否则仇恨驱动的挥击（含外部强制仇恨）会打出 0 伤害。
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, SEARCH_RANGE);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_COMPUTER_TICKS, 0);
        builder.define(DATA_COMPUTER_KIND, NONE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new ComputerGoal(this));
        this.goalSelector.addGoal(1, new FleeGoal(this));
        // 仇恨驱动：无论仇恨来自本模组"被攻击还手"还是外部 Mod 的强制仇恨（setTarget），
        // 锁定敌人后黑客原地使用电脑反制，而不是冲上去近战。
        this.goalSelector.addGoal(2, new HackerTargetComputerGoal(this));
        // "主动远离猪灵"(AvoidEntityGoal) 已按要求移除：猪灵对黑客的敌意
        // 改由下方 aiStep 的敌意察觉扫描处理（察觉→删 AI→逃跑）。
        this.goalSelector.addGoal(4, new OpenDoorGoal(this, false));
        this.goalSelector.addGoal(6, new HackerStrollGoal(this, 0.8D, 100));
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide() && this.computerTicks > 0) {
            // 动画不可被打断（其一）：使用电脑期间在移动结算前清掉横向速度，
            // 击退、爆炸冲击、其他实体推挤都会在下一 tick 到达 travel 前被抹除，
            // 黑客定在原地把动画放完；纵向仍交给重力，不会悬空。
            Vec3 motion = this.getDeltaMovement();
            this.setDeltaMovement(0.0D, motion.y, 0.0D);
        }
        super.aiStep();
        if (this.level().isClientSide()) {
            return;
        }
        if (this.computerTicks > 0) {
            this.getNavigation().stop();
            this.computerTicks--;
            this.entityData.set(DATA_COMPUTER_TICKS, this.computerTicks);
            if (this.computerTicks == SOUND_LEAD_TICKS) {
                // 结束音效提前 SOUND_LEAD_TICKS 播放。动画一旦开始必定放满全程，
                // 不存在"中途放弃"的分支了。
                this.playSound(GeneratedMod.HACKER_USE_COMPUTER.get(), 1.0F, 1.0F);
            } else if (this.computerTicks <= 0) {
                finishComputer();
            }
        } else {
            if (--this.hostileScanTimer <= 0) {
                this.hostileScanTimer = HOSTILE_SCAN_INTERVAL;
                Mob threat = this.findThreatTowardsMe();
                if (threat != null) {
                    // 察觉先于开门/红石扫描：哪怕黑客自己没锁定对方、甚至正在逃跑，
                    // 只要对方仇恨指向自己就立刻用电脑（结束时对其施加 10 秒删 AI，随后逃跑）。
                    this.startComputer(REVENGE, null, threat.getUUID());
                }
            }
            if (this.computerTicks <= 0) {
                this.tryIronDoorHack();
                if (this.computerTicks <= 0 && --this.redstoneTimer <= 0) {
                    if (isFleeing()) {
                        // 逃跑途中到期的扫描不再重排整段间隔，改为保持极小值；
                        // 逃跑一结束立刻补扫，消除"技能+逃跑"之后的长时间空窗。
                        this.redstoneTimer = 5;
                    } else {
                        this.redstoneTimer = REDSTONE_SCAN_INTERVAL;
                        BlockPos found = findRedstoneBlock();
                        if (found != null) {
                            startComputer(REDSTONE, found, null);
                        }
                    }
                }
            }
        }
        if (this.hackedDoor != null && this.level().getGameTime() >= this.doorCloseAt) {
            closeDoor(this.hackedDoor);
            this.hackedDoor = null;
        }
        if (this.hackedRedstone != null && this.level().getGameTime() >= this.redstoneRestoreAt) {
            if (this.level().getBlockState(this.hackedRedstone).getBlock() == this.redstoneChanged.getBlock()) {
                this.level().setBlock(this.hackedRedstone, this.redstoneOriginal, 3);
            }
            this.hackedRedstone = null;
            this.redstoneOriginal = null;
            this.redstoneChanged = null;
        }
    }

    // 免疫凋零效果由 WitherFactionWitherImmunityMixin 按阵营统一判定（黑客在
    // #minecraft:wither_skeletons 名册里），本类不再单独覆盖 canBeAffected。

    // ---- 与凋灵骷髅同款的音效组（黑客属凋灵骷髅类生物） ----

    @Override
    public SoundSource getSoundSource() {
        return SoundSource.HOSTILE;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_SKELETON_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.WITHER_SKELETON_STEP, 0.15F, 1.0F);
    }

    // ---- 仇恨与索敌 ----

    @Override
    public void setTarget(LivingEntity target) {
        // 统一在入口过滤：外部 Mod 的强制仇恨工具走的也是 setTarget，
        // 创造/旁观玩家与自身一律不建立仇恨。
        if (target == this || isUntargetablePlayer(target)) {
            target = null;
        }
        super.setTarget(target);
    }

    /** 仇恨目标是否仍然有效：存活、不索敌创造/旁观玩家、不超出索敌范围。 */
    private boolean isValidHateTarget(LivingEntity target) {
        return target.isAlive()
                && !isUntargetablePlayer(target)
                && this.distanceToSqr(target) <= (double) SEARCH_RANGE * SEARCH_RANGE;
    }

    private static boolean isUntargetablePlayer(LivingEntity entity) {
        return entity instanceof Player player && (player.isCreative() || player.isSpectator());
    }

    /**
     * 敌意察觉：找出"仇恨指向黑客"的生物——无论对方已经锁定了黑客
     * （{@code Mob#getTarget()}，含 Brain 系 ATTACK_TARGET 的原版兜底），
     * 还是只存在愤怒记忆里（猪灵系/监守者的 ANGRY_AT）。
     * 黑客自己是否仇恨对方完全不重要：本方法只看对方的仇恨表。
     * 已被删 AI 的个体直接跳过，不重复出手。
     */
    private Mob findThreatTowardsMe() {
        AABB box = this.getBoundingBox().inflate(SEARCH_RANGE);
        List<Mob> candidates = this.level().getEntitiesOfClass(Mob.class, box, this::isAggroOnMe);
        Mob nearest = null;
        double bestDistance = (double) SEARCH_RANGE * SEARCH_RANGE;
        for (Mob candidate : candidates) {
            double distance = this.distanceToSqr(candidate);
            if (distance <= bestDistance) {
                bestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private boolean isAggroOnMe(Mob mob) {
        if (mob == this || !mob.isAlive() || isUntargetablePlayer(mob)
                || HackerCountermeasureHandler.isSuppressed(mob)) {
            return false;
        }
        if (mob.getTarget() == this) {
            return true;
        }
        // 并非所有 Mob 的 Brain 都会注册这些记忆模块；getMemory 对未注册模块直接抛异常。
        // 先读取 Brain 已注册模块集合，再查询，确保对任意 Mob（含 Mob Battle 生成体）均不会崩溃。
        if (!mob.getBrain().getMemories().containsKey(MemoryModuleType.ANGRY_AT)) {
            return false;
        }
        return mob.getBrain().getMemory(MemoryModuleType.ANGRY_AT)
                .map(id -> id.equals(this.getUUID())).orElse(false);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide() && this.isAlive()) {
            Entity attacker = source.getEntity() != null ? source.getEntity() : source.getDirectEntity();
            if (attacker instanceof LivingEntity living && living != this && !isUntargetablePlayer(living)) {
                // 被攻击建立真实仇恨（getTarget 可见），还手电脑反制照旧。
                this.setTarget(living);
                // 动画不可被打断（其二）：正在放动画时不重开、不换目标，
                // 本轮自然放完后由 HackerTargetComputerGoal / 敌意察觉扫描
                // 对这个新仇家补上 REVENGE 反制，效果不丢，只是不打断演出。
                if (this.computerTicks <= 0) {
                    startComputer(REVENGE, null, living.getUUID());
                }
            }
        }
        return hurt;
    }

    @Override
    public boolean hasLineOfSight(Entity entity) {
        return entity != null && entity != this && this.distanceToSqr(entity) <= SEARCH_RANGE * SEARCH_RANGE;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level,
                                        DifficultyInstance difficulty, net.minecraft.world.entity.MobSpawnType reason,
                                        SpawnGroupData data) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data);
        this.setPersistenceRequired();
        return result;
    }

    public boolean isUsingComputer() {
        return this.entityData.get(DATA_COMPUTER_TICKS) > 0;
    }

    public float computerAnimationTime(float ageInTicks) {
        int remaining = this.entityData.get(DATA_COMPUTER_TICKS);
        if (remaining <= 0) return -1.0F;
        float partial = ageInTicks - this.tickCount;
        return (COMPUTER_TICKS - remaining + partial) / 20.0F;
    }

    public boolean isFleeing() {
        return this.fleeFrom != null && this.level().getGameTime() < this.fleeUntil && this.fleeFrom.isAlive();
    }

    public LivingEntity getFleeFrom() {
        return this.fleeFrom;
    }

    public long getFleeUntil() {
        return this.fleeUntil;
    }

    private void startComputer(byte kind, BlockPos pos, UUID enemy) {
        this.computerKind = kind;
        this.computerPos = pos == null ? null : pos.immutable();
        this.computerEnemy = enemy;
        this.computerTicks = COMPUTER_TICKS;
        this.entityData.set(DATA_COMPUTER_KIND, kind);
        this.entityData.set(DATA_COMPUTER_TICKS, COMPUTER_TICKS);
        this.getNavigation().stop();
    }

    private void abortComputer() {
        this.computerTicks = 0;
        this.computerKind = NONE;
        this.computerPos = null;
        this.computerEnemy = null;
        this.entityData.set(DATA_COMPUTER_TICKS, 0);
        this.entityData.set(DATA_COMPUTER_KIND, NONE);
    }

    private void finishComputer() {
        byte kind = this.computerKind;
        BlockPos pos = this.computerPos;
        UUID enemyId = this.computerEnemy;
        this.abortComputer();
        // 结束音效已提前到 aiStep 的 SOUND_LEAD_TICKS 处播放，这里不再重复。
        if (kind == DOOR && pos != null) {
            BlockState state = this.level().getBlockState(pos);
            // 动画全程不可打断：哪怕中途有人从另一侧把门开了，本段动画也照放完，
            // 只是这里发现门已开就什么也不做（音效仍响，表示"用完了电脑"）。
            if (state.getBlock() instanceof DoorBlock door && !isOpenDoor(state)) {
                door.setOpen(this, this.level(), state, pos, true);
                this.hackedDoor = bottomDoor(pos, state);
                this.doorCloseAt = this.level().getGameTime() + EFFECT_TICKS;
                this.getNavigation().recomputePath();
            }
        } else if (kind == REDSTONE && pos != null) {
            BlockState state = this.level().getBlockState(pos);
            Block block = state.getBlock();
            if (block instanceof TntBlock) {
                // 黑客 TNT：按原版红石引爆流程点燃（生成 TNT 爆炸实体并移除方块），无需还原。
                TntBlock.explode(this.level(), pos);
            } else if (block instanceof DispenserBlock) {
                // 黑客发射器/投掷器：置 TRIGGERED 并安排一次方块 tick，走原版 dispensing 流程；
                // 原版 tick 自己会清 TRIGGERED，为防残留再登记一次原状态还原。
                this.level().setBlock(pos, state.setValue(DispenserBlock.TRIGGERED, true), 3);
                this.level().scheduleTick(pos, block, 1);
                this.hackedRedstone = pos.immutable();
                this.redstoneOriginal = state;
                this.redstoneChanged = state.setValue(DispenserBlock.TRIGGERED, true);
                this.redstoneRestoreAt = this.level().getGameTime() + 40L;
            } else {
                BlockState changed = toggleRedstone(state);
                if (changed != null) {
                    this.level().setBlock(pos, changed, 3);
                    this.hackedRedstone = pos.immutable();
                    this.redstoneOriginal = state;
                    this.redstoneChanged = changed;
                    this.redstoneRestoreAt = this.level().getGameTime() + EFFECT_TICKS;
                }
            }
        } else if (kind == REVENGE && enemyId != null && this.level() instanceof ServerLevel server) {
            Entity enemy = server.getEntity(enemyId);
            if (enemy instanceof Player player) {
                applyCooldowns(player);
            } else if (enemy instanceof Mob mob) {
                // "删除 AI"技能：目标生物的一切 AI（索敌、攻击、移动、Brain 传感器）
                // 整体冻结 EFFECT_TICKS=200 tick，即 10 秒后自动恢复。
                HackerCountermeasureHandler.suppress(mob, EFFECT_TICKS);
            }
            if (enemy instanceof LivingEntity living) {
                this.fleeFrom = living;
                this.fleeUntil = this.level().getGameTime() + EFFECT_TICKS;
            }
        }
    }

    private void tryIronDoorHack() {
        if (!this.horizontalCollision || isFleeing()) return;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        AABB box = this.getBoundingBox().inflate(1.4D, 0.6D, 1.4D);
        for (int x = Mth.floor(box.minX); x <= Mth.floor(box.maxX); x++) {
            for (int y = Mth.floor(box.minY); y <= Mth.floor(box.maxY); y++) {
                for (int z = Mth.floor(box.minZ); z <= Mth.floor(box.maxZ); z++) {
                    cursor.set(x, y, z);
                    BlockState state = this.level().getBlockState(cursor);
                    if (state.getBlock() instanceof DoorBlock door && !DoorBlock.isWoodenDoor(state)
                            && !isOpenDoor(state)) {
                        startComputer(DOOR, bottomDoor(cursor, state), null);
                        return;
                    }
                }
            }
        }
    }

    private BlockPos findRedstoneBlock() {
        BlockPos origin = this.blockPosition();
        int r = SEARCH_RANGE;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        for (int x = origin.getX() - r; x <= origin.getX() + r; x++) {
            for (int y = Math.max(this.level().getMinBuildHeight(), origin.getY() - r); y <= Math.min(this.level().getMaxBuildHeight() - 1, origin.getY() + r); y++) {
                for (int z = origin.getZ() - r; z <= origin.getZ() + r; z++) {
                    cursor.set(x, y, z);
                    if (!this.level().hasChunkAt(cursor)) continue;
                    BlockState state = this.level().getBlockState(cursor);
                    if (toggleRedstone(state) != null) {
                        double distance = this.distanceToSqr(Vec3.atCenterOf(cursor));
                        if (distance < bestDistance) {
                            bestDistance = distance;
                            best = cursor.immutable();
                        }
                    }
                }
            }
        }
        return best;
    }

    private static boolean isOpenDoor(BlockState state) {
        return state.hasProperty(DoorBlock.OPEN) && state.getValue(DoorBlock.OPEN);
    }

    private static BlockPos bottomDoor(BlockPos pos, BlockState state) {
        return state.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)
                && state.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER
                ? pos.below() : pos;
    }

    private void closeDoor(BlockPos pos) {
        BlockState state = this.level().getBlockState(pos);
        if (state.getBlock() instanceof DoorBlock door && isOpenDoor(state)) {
            door.setOpen(this, this.level(), state, pos, false);
        }
    }

    /** 可被黑客翻转的开关类方块属性（按优先级匹配第一个存在的属性）。 */
    private static final BooleanProperty[] TOGGLE_PROPERTIES = {
            BlockStateProperties.OPEN,       // 门、活板门、栅栏门
            BlockStateProperties.POWERED,    // 拉杆、按钮、中继器、比较器、轨道、观察者、音符盒、绊线钩
            BlockStateProperties.LIT,        // 红石火把、红石灯、避雷针
            BlockStateProperties.EXTENDED,   // 活塞（含黏液/蜂蜜活塞）
            BlockStateProperties.ENABLED     // 漏斗
    };

    /**
     * 该方块是否与红石相关、可被黑客锁定。覆盖原版所有可激活红石方块族；
     * 模组方块只要继承这些原版类（如自定义活塞/门/轨道）同样会被识别。
     */
    private static boolean isHackableRedstone(BlockState state) {
        Block block = state.getBlock();
        return block instanceof RedStoneWireBlock          // 红石粉
                || block instanceof TargetBlock              // 箭头目标方块
                || block instanceof LeverBlock              // 拉杆
                || block instanceof ButtonBlock             // 石质/木质按钮
                || block instanceof ObserverBlock           // 观察者
                || block instanceof DaylightDetectorBlock   // 阳光探测器
                || block instanceof DiodeBlock              // 中继器与比较器
                || block instanceof PistonBaseBlock         // 活塞族
                || block instanceof TrapDoorBlock           // 活板门
                || block instanceof FenceGateBlock          // 栅栏门（含铁栅栏门）
                || block instanceof DoorBlock               // 门（含铁门）
                || block instanceof DispenserBlock          // 发射器与投掷器（投掷器继承发射器）
                || block instanceof TntBlock                // TNT
                || block instanceof PoweredRailBlock        // 充能铁轨与激活铁轨
                || block instanceof DetectorRailBlock       // 探测铁轨
                || block instanceof HopperBlock             // 漏斗
                || block instanceof NoteBlock               // 音符盒
                || block instanceof TripWireHookBlock       // 绊线钩
                || block == Blocks.REDSTONE_TORCH
                || block == Blocks.REDSTONE_WALL_TORCH
                || block == Blocks.REDSTONE_LAMP
                || block == Blocks.LIGHTNING_ROD;
    }

    /**
     * 计算被黑客入侵后的目标方块状态。返回 null 表示不是可激活红石方块；
     * TNT 与发射器/投掷器返回原状态本身（一次性激活型，由 finishComputer 引爆/触发）。
     */
    private static BlockState toggleRedstone(BlockState state) {
        if (!isHackableRedstone(state)) {
            return null;
        }
        Block block = state.getBlock();
        if (block instanceof TntBlock || block instanceof DispenserBlock) {
            return state;
        }
        if (block instanceof RedStoneWireBlock && state.hasProperty(RedStoneWireBlock.POWER)) {
            int power = state.getValue(RedStoneWireBlock.POWER);
            return state.setValue(RedStoneWireBlock.POWER, power == 0 ? 15 : 0);
        }
        if (block instanceof DaylightDetectorBlock && state.hasProperty(DaylightDetectorBlock.POWER)) {
            int power = state.getValue(DaylightDetectorBlock.POWER);
            return state.setValue(DaylightDetectorBlock.POWER, power == 0 ? 15 : 0);
        }
        for (BooleanProperty property : TOGGLE_PROPERTIES) {
            if (state.hasProperty(property)) {
                return state.setValue(property, !state.getValue(property));
            }
        }
        // 兜底：名为 "power" 的整数信号属性（目标方块等未提供公开属性的方块，
        // 以及继承属性命名的模组红石方块）。
        for (Property<?> property : state.getProperties()) {
            if (property instanceof IntegerProperty powerProperty && "power".equals(powerProperty.getName())) {
                int min = Integer.MAX_VALUE;
                int max = Integer.MIN_VALUE;
                for (int candidate : powerProperty.getPossibleValues()) {
                    min = Math.min(min, candidate);
                    max = Math.max(max, candidate);
                }
                int current = state.getValue(powerProperty);
                int next = current == min ? max : min;
                return state.setValue(powerProperty, next);
            }
        }
        return null;
    }

    private static void applyCooldowns(Player player) {
        List<ItemStack> stacks = new ArrayList<>();
        stacks.addAll(player.getInventory().items);
        stacks.addAll(player.getInventory().armor);
        stacks.addAll(player.getInventory().offhand);
        for (ItemStack stack : stacks) {
            if (!stack.isEmpty()) player.getCooldowns().addCooldown(stack.getItem(), EFFECT_TICKS);
        }
    }

    private static final class ComputerGoal extends Goal {
        private final Hacker hacker;
        private ComputerGoal(Hacker hacker) {
            this.hacker = hacker;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }
        @Override public boolean canUse() { return hacker.isUsingComputer(); }
        @Override public boolean canContinueToUse() { return hacker.isUsingComputer(); }
        @Override public void start() { hacker.getNavigation().stop(); }
        @Override public void tick() {
            if (hacker.computerPos != null) {
                hacker.getLookControl().setLookAt(
                        hacker.computerPos.getX() + 0.5D, hacker.computerPos.getY() + 0.5D,
                        hacker.computerPos.getZ() + 0.5D, 30.0F, 30.0F);
            } else if (hacker.computerKind == REVENGE && hacker.computerEnemy != null
                    && hacker.level() instanceof ServerLevel server) {
                Entity enemy = server.getEntity(hacker.computerEnemy);
                if (enemy instanceof LivingEntity living) {
                    hacker.getLookControl().setLookAt(living, 30.0F, 30.0F);
                }
            }
        }
    }

    /**
     * 仇恨响应：完全以 {@link Mob#getTarget()} 为准——外部强制仇恨工具 setTarget 后立刻生效。
     * 黑客锁定敌人后不冲锋、近战，而是原地使用电脑远程反制；无效目标会被清仇。
     */
    private static final class HackerTargetComputerGoal extends Goal {
        private final Hacker hacker;

        private HackerTargetComputerGoal(Hacker hacker) {
            this.hacker = hacker;
        }

        @Override
        public boolean canUse() {
            if (hacker.isUsingComputer() || hacker.isFleeing()) {
                return false;
            }
            LivingEntity target = hacker.getTarget();
            if (target == null || !hacker.isValidHateTarget(target)) {
                if (target != null) {
                    hacker.setTarget(null);
                }
                return false;
            }
            return true;
        }

        @Override
        public void start() {
            LivingEntity target = hacker.getTarget();
            if (target != null && !hacker.isUsingComputer()) {
                hacker.startComputer(REVENGE, null, target.getUUID());
            }
        }
    }

    private static final class FleeGoal extends Goal {
        private final Hacker hacker;
        private FleeGoal(Hacker hacker) { this.hacker = hacker; this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return hacker.isFleeing() && !hacker.isUsingComputer(); }
        @Override public boolean canContinueToUse() { return hacker.isFleeing() && !hacker.isUsingComputer(); }
        @Override public void stop() {
            // 逃跑结束先清掉残留寻路，否则本体会继续闷头走上一条逃离路径。
            hacker.getNavigation().stop();
            // 自然逃完（而非被新一轮电脑打断）时，尽快恢复红石入侵扫描，不留发呆空窗。
            if (!hacker.isFleeing() && hacker.redstoneTimer > 40) {
                hacker.redstoneTimer = 40;
            }
        }
        @Override public void tick() {
            LivingEntity threat = hacker.getFleeFrom();
            if (threat == null) return;
            Vec3 away = hacker.position().subtract(threat.position());
            away = new Vec3(away.x, 0.0D, away.z);
            if (away.lengthSqr() < 0.01D) away = new Vec3(1.0D, 0.0D, 0.0D);
            away = away.normalize();
            boolean pathFound = hacker.getNavigation().moveTo(hacker.getX() + away.x * 12.0D,
                    hacker.getY(), hacker.getZ() + away.z * 12.0D, 1.8D);
            if (!pathFound) {
                // 身后是墙/角落寻不出路时，原版只会原地站着盯住威胁，看起来就是发呆；
                // 退化为背对威胁的直线平移（贴墙滑行），保证逃离期间始终在动。
                hacker.getMoveControl().strafe(0.0F, -0.5F);
            }
            hacker.getLookControl().setLookAt(threat, 30.0F, 30.0F);
        }
    }

    /**
     * 黑客常驻漫步：原版 RandomStrollGoal 在 {@code Mob.getNoActionTime() >= 100}
     * （一段时间没受伤、判定路径又被外部事件短路）时会拒绝启动，黑客战斗/逃跑后
     * 就只剩站着不动。这里显式关闭该限制并保留避水选点，逃跑结束后始终能走动。
     */
    private static final class HackerStrollGoal extends RandomStrollGoal {
        private final Hacker hacker;

        HackerStrollGoal(Hacker hacker, double speed, int interval) {
            super(hacker, speed, interval, false);
            this.hacker = hacker;
        }

        @Override
        public boolean canUse() {
            return !hacker.isUsingComputer() && !hacker.isFleeing() && super.canUse();
        }

        @Override
        protected Vec3 getPosition() {
            if (this.mob.isInWaterOrBubble()) {
                Vec3 land = LandRandomPos.getPos(this.mob, 15, 7);
                return land == null ? super.getPosition() : land;
            }
            return this.mob.getRandom().nextFloat() < 0.001F
                    ? LandRandomPos.getPos(this.mob, 10, 7) : super.getPosition();
        }
    }
}
