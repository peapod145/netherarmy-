package cn.blockforge.generated.netherarmy;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 无头骑士头颅专用的炼狱晶头盔装备模型。
 *
 * <p>与原版盔壳在头颅上的做法（{@link DullhanHeadArmorModel}）同构：立方体直接建在
 * 头颅主模型的坐标系里（主模型骷髅占 y 16..24），渲染时不做任何 PoseStack 位移、
 * 不借用 HumanoidModel 的头部骨骼——原版头盔正是这样在头颅上严丝合缝的。
 * 此前的方案把玩家用的 {@link NetherCrystalHelmetArmorModel}（头顶 -8 坐标系）
 * 用运行时 translate 搬上头颅，在无头骑士实测整体偏低；改为静态几何后与主模型
 * 完全同轴。</p>
 *
 * <p>立方尺寸与 UV 逐块取自玩家版盔壳（texOffs(0,0)、8×8×8、外扩 1px，对应用户
 * bbmodel 的 inflate=1），只是把 Y 从 -8 移到 16，采样同一张 64×64 图集
 * nether_crystal_suits.png，观感与玩家佩戴时一致。</p>
 */
public final class DullhanCrystalHelmetArmorModel extends EntityModel<DullhanHead> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "dullhan_crystal_helmet_armor"), "main");

    private final ModelPart root;

    public DullhanCrystalHelmetArmorModel(ModelPart root) {
        this.root = root;
    }

    @Override
    public void setupAnim(DullhanHead entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // 装甲覆盖层与主模型保持完全同轴，不跟随任何动画。
    }

    @Override
    public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack poseStack,
                               com.mojang.blaze3d.vertex.VertexConsumer vertexConsumer,
                               int packedLight, int packedOverlay, int packedColor) {
        this.root.render(poseStack, vertexConsumer, packedLight, packedOverlay, packedColor);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // 与 DullhanHeadArmorModel 的原版盔壳同一个原点：骷髅立方体 y 16..24，外扩 1px。
        root.addOrReplaceChild("helmet", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, 16.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(1.0F)),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }
}
