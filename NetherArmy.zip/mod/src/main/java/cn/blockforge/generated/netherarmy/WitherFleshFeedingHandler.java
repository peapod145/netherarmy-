package cn.blockforge.generated.netherarmy;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * 枯肉的"强行喂食"交互（右键目标，枯肉在主手或副手均可）。
 *
 * <ul>
 *   <li><b>驯服狼</b>：喂下枯肉当场死亡（凋零伤害巨额扣血，走正常死亡流程）。
 *       枯肉刻意不进 {@code minecraft:wolf_food} 标签——狼的歪头乞食
 *       （{@code Wolf#isInterested}）与原版投喂回血都以该标签判定，不入标签
 *       则手持枯肉时狼毫无反应，喂食完全由本处理器接管。</li>
 *   <li><b>可转化为尸鬼的生物</b>（僵尸/溺尸/尸壳/僵尸村民/村民，尸鬼除外，
 *       判定复用 {@link WitherZombie#isInfectable}）：强制锁定攻击该玩家
 *       （{@code Mob#setTarget}），并立刻施加 30 秒凋零 X（amplifier 9）。</li>
 * </ul>
 *
 * <p>事件两侧一起取消：客户端不取消的话，右键村民会先本地弹出交易界面；
 * 取消后以 {@code CONSUME} 作为取消结果，手臂照常挥动。物品消耗走
 * {@code ItemStack#consume}（创造模式不扣数）。</p>
 */
public final class WitherFleshFeedingHandler {
    /** 强喂感染目标的凋零时长：30 秒 = 600 刻。 */
    public static final int FORCED_WITHER_DURATION = 600;
    /** 十级凋零对应 amplifier 9。 */
    public static final int FORCED_WITHER_AMPLIFIER = 9;

    private WitherFleshFeedingHandler() {
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!event.getItemStack().is(GeneratedMod.WITHER_FLESH.get())) {
            return;
        }
        var target = event.getTarget();
        boolean tamedWolf = target instanceof Wolf wolf && wolf.isTame();
        boolean infectable = !tamedWolf && target instanceof LivingEntity living
                && WitherZombie.isInfectable(living);
        if (!tamedWolf && !infectable) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.CONSUME);
        Player player = event.getEntity();
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        event.getItemStack().consume(1, player);
        player.swing(event.getHand());
        level.playSound(null, target, SoundEvents.GENERIC_EAT, SoundSource.NEUTRAL, 1.0F, 1.0F);
        if (tamedWolf) {
            // 1.21.1 的 DamageSources 没有 poison()，凋零伤害源（withered away）最贴题。
            target.hurt(level.damageSources().wither(), Float.MAX_VALUE);
        } else if (target instanceof Mob mob) {
            mob.setTarget(player);
            mob.addEffect(new MobEffectInstance(MobEffects.WITHER,
                    FORCED_WITHER_DURATION, FORCED_WITHER_AMPLIFIER));
        }
    }
}
