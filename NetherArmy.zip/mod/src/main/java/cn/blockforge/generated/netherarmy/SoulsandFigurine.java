package cn.blockforge.generated.netherarmy;

import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.monster.CrossbowAttackMob;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 灵魂土偶：玩家用南瓜头 + 两块灵魂土召唤的傀儡。
 *
 * <p>属性：血量 30、护甲 10、击退抗性 50%、基础近战伤害 4。免疫一切减益与反逆者控制。
 * 站在灵魂沙/灵魂土上时移速 +25%，并以 1/s 回血。玩家召唤的个体独属于召唤者：
 * 右键打开装备界面（盔甲、主手、副手、2×2 物品栏），物品栏里的灵魂沙/土会被
 * 消耗来恢复 4 点生命；玩家也可手持这两种物品右键直接修复。</p>
 *
 * <p>火焰免疫由 {@code EntityType.Builder#fireImmune()} 提供（见
 * {@code GeneratedMod.SOULSAND_FIGURINE}），火焰、着火、岩浆都不掉血、不显示燃烧。</p>
 *
 * <p>水性：不挂 {@code FloatGoal}，落水直接沉底、不会往上游；同时实体类型挂在
 * {@code #minecraft:can_breathe_under_water} 标签里（
 * {@code data/minecraft/tags/entity_type/can_breathe_under_water.json}），
 * 于是 {@code canBreatheUnderwater()} 为真、NeoForge 的呼吸钩子判定"不窒息"，
 * 沉在水底也不会掉氧气、不冒泡、不吃溺水伤害。</p>
 *
 * <p>战斗 AI 对齐凋灵仆役：近战、弓、弩、三叉戟、重锤、举盾各自一套目标。
 * 其中弓完全照搬原版骷髅：射程半径 {@value #SKELETON_BOW_RADIUS} 格、拉满 20 tick 才放箭、
 * 初速 {@value #SKELETON_BOW_VELOCITY} 格/tick、散布 14-4×难度、伤害按满蓄力结算；
 * 索敌范围与骷髅同为 {@value #SKELETON_FOLLOW_RANGE} 格。
 * 玩家召唤体只打召唤者的仇敌与敌对生物，刷怪蛋生成的无主个体打所有敌对生物。</p>
 *
 * <p>行为模式三档（见 {@link SoulsandFigurineMode}）：警戒驻守、保镖跟随并主动清敌、
 * 侍从跟随但只打玩家招惹过的目标。默认保镖，可在土偶界面里按按钮循环切换，
 * 当前档位存同步数据、驻守点存盘。</p>
 */
public class SoulsandFigurine extends AbstractGolem implements CrossbowAttackMob, RangedAttackMob, MenuProvider {

    private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER =
            SynchedEntityData.defineId(SoulsandFigurine.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> DATA_CHARGING_CROSSBOW =
            SynchedEntityData.defineId(SoulsandFigurine.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_SHIELD_BLOCKING =
            SynchedEntityData.defineId(SoulsandFigurine.class, EntityDataSerializers.BOOLEAN);
    /** 当前行为模式（警戒/保镖/侍从），客户端界面读它来显示当前档位。 */
    private static final EntityDataAccessor<Integer> DATA_MODE =
            SynchedEntityData.defineId(SoulsandFigurine.class, EntityDataSerializers.INT);

    private static final ResourceLocation SOUL_GROUND_SPEED_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soulsand_figurine_soul_ground");
    private static final AttributeModifier SOUL_GROUND_SPEED = new AttributeModifier(
            SOUL_GROUND_SPEED_ID, 0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);

    private static final int TRIDENT_ATTACK_INTERVAL = 40;
    private static final float TRIDENT_THROW_RADIUS = 10.0F;
    private static final double TRIDENT_MELEE_ENTER_SQR = 2.0D * 2.0D;
    private static final double TRIDENT_MELEE_EXIT_SQR = 2.5D * 2.5D;
    private static final int TRIDENT_MELEE_INTERVAL = 20;
    private static final double MACE_LEAP_UP = 0.8D;
    private static final double MACE_LEAP_TRAVEL_FACTOR = 9.0D;
    private static final double MACE_SMASH_HORIZONTAL_SQR = 1.5D * 1.5D;
    private static final int MACE_LEAP_COOLDOWN = 40;
    /** 弩目标的攻击半径（本模组原值；掠夺者原版是 8 格）。 */
    private static final float CROSSBOW_RADIUS = 16.0F;
    /**
     * 原版骷髅弓目标（{@code RangedBowAttackGoal}）的射程半径：15 格。
     *
     * <p>骷髅构造时写的就是 {@code new RangedBowAttackGoal(this, 1.0D, 20, 15.0F)}，
     * 每次 {@code reassessWeaponGoal} 用 {@code getHardAttackInterval()/getAttackInterval()}
     * 重置最小间隔（困难 20、其余 40）。土偶的弓目标半径与间隔都取同一组数，
     * 于是"能打多远、多久一箭"和骷髅完全一致。</p>
     */
    private static final float SKELETON_BOW_RADIUS = 15.0F;
    /**
     * 原版骷髅射箭的初速：1.6 格/tick（{@code AbstractSkeleton#performRangedAttack}
     * 里写死的 {@code shoot(..., 1.6F, 14 - 4 × 难度)}）。
     */
    private static final float SKELETON_BOW_VELOCITY = 1.6F;
    /**
     * 原版骷髅的索敌范围：{@code FOLLOW_RANGE} 16 格。
     *
     * <p>1.21.1 里 {@code Monster.createMonsterAttributes()} 只加了攻击力，
     * 基线由 {@code Mob.createMobAttributes()} 的 16 格给出（本工程
     * {@code NetherHunter#SKELETON_FOLLOW_RANGE}、{@code Berserker} 同样按 16 写）。
     * 土偶原本就是 16，这里显式钉成同一个常量，避免以后被误改。</p>
     */
    private static final double SKELETON_FOLLOW_RANGE = 16.0D;
    private static final int SHIELD_REACT_TICKS = 14;
    private static final int SHIELD_COMBAT_GUARD_TICKS = 6;
    private static final double SHIELD_COMBAT_GUARD_RANGE_SQR = 49.0D;
    private static final int SHIELD_ON_HURT_GUARD_TICKS = 24;
    private static final float SHIELD_WEAR_DAMAGE_FLOOR = 3.0F;
    private static final int ATTACK_SWING_LOCK_TICKS = 10;
    private static final double PROJECTILE_LOOKAHEAD = 8.0D;
    private static final double PROJECTILE_CORRIDOR = 0.8D;
    private static final int INVENTORY_HEAL_INTERVAL = 20;
    private static final float INVENTORY_HEAL_AMOUNT = 4.0F;
    private static final float HAND_HEAL_AMOUNT = 4.0F;
    /**
     * 近战目标的优先级：必须排在武器目标（三叉戟/重锤 2、投掷 3）之后。
     *
     * <p>{@code GoalSelector} 只看"新目标能不能抢走旧目标占着的控制标志"
     * （{@code WrappedGoal#canBeReplacedBy}：新优先级数字更小才行），近战一旦
     * 用同一个优先级先跑起来，MOVE 标志就被它一直占着，三叉戟投掷与重锤起跳
     * 永远进不来——这就是之前"凋灵仆役同款武器 AI 没体现"的根因。
     * 凋灵仆役那边近战由 {@code AbstractSkeleton} 挂在 4，本类对齐同一个数。</p>
     */
    private static final int MELEE_PRIORITY = 4;

    private final SimpleContainer inventory = new SimpleContainer(4);
    private int shieldHoldTicks;
    private int shieldSwingLockTicks;
    private int attackIntervalEndTick;
    private int inventoryHealCooldown;
    private int soulGroundHealTicks;
    /** 警戒模式的驻守点：切到警戒模式时记下脚下位置，敌人死后回到这里。 */
    private BlockPos homePos;
    private TridentAttackGoal tridentGoal;
    private RangedCrossbowAttackGoal<SoulsandFigurine> crossbowGoal;
    private MeleeAttackGoal meleeGoal;

    public SoulsandFigurine(EntityType<? extends SoulsandFigurine> type, Level level) {
        super(type, level);
        // 土偶恒为右手主手。Mob#finalizeSpawn 会按 5% 概率把任何生物标成左撇子
        // （刷怪蛋、指令、刷怪笼生成都要经过它），一旦命中，getMainArm() 就返回
        // LEFT：主手武器、拉弓/上弩姿势、挥臂、盾牌格挡全部换到左手。这里与工程里
        // 其他生物（狂暴者、下界猎手、传令兵、不朽武士等）一样钉死右手。
        this.setLeftHanded(false);
        this.setCanPickUpLoot(false);
        this.setPersistenceRequired();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 1.0F);
        }
    }

    @Override
    public boolean isLeftHanded() {
        return false;
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
                .add(Attributes.FOLLOW_RANGE, SKELETON_FOLLOW_RANGE)
                .add(Attributes.STEP_HEIGHT, 1.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_OWNER, Optional.empty());
        builder.define(DATA_CHARGING_CROSSBOW, false);
        builder.define(DATA_SHIELD_BLOCKING, false);
        builder.define(DATA_MODE, SoulsandFigurineMode.DEFAULT.ordinal());
    }

    @Override
    protected void registerGoals() {
        // 不挂 FloatGoal：土偶是实心泥偶，落水要沉底（原版雪傀儡同样不挂这个目标）。
        // 不溺水另由 can_breathe_under_water 实体标签负责，见类注释。
        // 1 号位是"回家"：警戒模式下原地驻守用；与跟随目标互斥（各看模式开关）。
        this.goalSelector.addGoal(1, new ReturnHomeGoal(this));
        this.goalSelector.addGoal(1, new FollowOwnerGoal(this));
        this.meleeGoal = new MeleeAttackGoal(this, 1.0D, true);
        // 武器目标全部排在近战前面（优先级数字更小），靠抢占 MOVE 标志生效：
        // 三叉戟近战/重锤起跳 2、三叉戟投掷 3、近战兜底 4、弩 4、弓 4。
        this.goalSelector.addGoal(2, new TridentMeleeGoal(this));
        this.goalSelector.addGoal(2, new MaceLeapGoal(this));
        this.tridentGoal = new TridentAttackGoal(this, TRIDENT_THROW_RADIUS);
        this.goalSelector.addGoal(3, this.tridentGoal);
        this.crossbowGoal = new RangedCrossbowAttackGoal<>(this, 1.0D, CROSSBOW_RADIUS);
        this.goalSelector.addGoal(4, this.crossbowGoal);
        this.goalSelector.addGoal(MELEE_PRIORITY, this.meleeGoal);
        // 警戒模式不散步（散步会离开驻守点），其余模式照常。
        this.goalSelector.addGoal(5, new ModeStrollGoal(this));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.reassessWeaponGoal();

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        // 同类伤害不进仇恨表：HurtByTargetGoal 自带 toIgnoreDamage，构造时传入本类即可。
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this, SoulsandFigurine.class));
        // 主动索敌：侍从模式不参与（只打玩家招惹过的目标）。
        this.targetSelector.addGoal(4, new ModeTargetGoal(this));
    }

    public void reassessWeaponGoal() {
        if (this.level().isClientSide || this.meleeGoal == null) {
            return;
        }
        this.goalSelector.removeGoal(this.meleeGoal);
        if (!this.isHolding(stack -> stack.getItem() instanceof CrossbowItem)
                && !this.isHolding(stack -> stack.getItem() instanceof BowItem)) {
            this.goalSelector.addGoal(MELEE_PRIORITY, this.meleeGoal);
        }
        this.applyBowRadius(SKELETON_BOW_RADIUS);
    }

    private void applyBowRadius(float radius) {
        this.goalSelector.getAvailableGoals().stream()
                .map(wrapped -> wrapped.getGoal())
                .filter(goal -> goal instanceof net.minecraft.world.entity.ai.goal.RangedBowAttackGoal)
                .findFirst()
                .ifPresent(this.goalSelector::removeGoal);
        if (this.isHolding(stack -> stack.getItem() instanceof BowItem)) {
            int interval = this.level().getDifficulty() == net.minecraft.world.Difficulty.HARD ? 20 : 40;
            this.goalSelector.addGoal(4, new SoulsandFigurineBowAttackGoal(this, 1.0D, interval, radius));
        }
    }

    // ================================================================ 归属

    public Optional<UUID> getOwnerUUID() {
        return this.entityData.get(DATA_OWNER);
    }

    public void setOwnerUUID(UUID uuid) {
        this.entityData.set(DATA_OWNER, Optional.ofNullable(uuid));
    }

    public LivingEntity getOwner() {
        Optional<UUID> uuid = this.getOwnerUUID();
        if (uuid.isEmpty()) {
            return null;
        }
        if (this.level() instanceof ServerLevel serverLevel) {
            Entity entity = serverLevel.getEntity(uuid.get());
            if (entity instanceof LivingEntity living) {
                return living;
            }
        }
        Player player = this.level().getPlayerByUUID(uuid.get());
        return player;
    }

    public boolean isOwnedBy(LivingEntity living) {
        return living != null && this.getOwnerUUID().filter(id -> id.equals(living.getUUID())).isPresent();
    }

    public boolean hasOwner() {
        return this.getOwnerUUID().isPresent();
    }

    /**
     * 界面准入：土偶只认召唤它的主人。
     *
     * <p>多人游戏里创造模式不再放行——原先的 {@code player.isCreative()} 捷径让任何
     * 创造模式玩家都能打开别人土偶的界面、连行为模式也一并改掉，与"玩家只能打开
     * 自己召唤的那只"冲突，这里去掉。无主土偶（指令直接生成、或建档时附近没有
     * 玩家）本就没有归属可认，不设限。</p>
     */
    public boolean canConfigure(Player player) {
        return player != null && (this.isOwnedBy(player) || !this.hasOwner());
    }

    public SimpleContainer getInventory() {
        return this.inventory;
    }

    public void onEquipmentChanged() {
        if (!this.level().isClientSide) {
            this.reassessWeaponGoal();
        }
    }

    public boolean isChargingCrossbow() {
        return this.entityData.get(DATA_CHARGING_CROSSBOW);
    }

    public boolean isBlockingShield() {
        return this.entityData.get(DATA_SHIELD_BLOCKING);
    }

    public boolean isHoldingBowForShooting() {
        return this.isAggressive() && this.getMainHandItem().is(Items.BOW);
    }

    // ================================================================ 行为模式

    /**
     * 当前模式。用同步数据保存，所以界面按钮读到的档位双端一致；
     * 三档的具体差异见 {@link SoulsandFigurineMode}。
     */
    public SoulsandFigurineMode getMode() {
        return SoulsandFigurineMode.byOrdinal(this.entityData.get(DATA_MODE));
    }

    /**
     * 切换模式。只有服务端会走副作用（记驻守点、清掉不再允许的目标）；
     * 客户端只是同步数据跟着变，界面据此刷新按钮文字与说明。
     */
    public void setMode(SoulsandFigurineMode mode) {
        SoulsandFigurineMode previous = this.getMode();
        this.entityData.set(DATA_MODE, mode.ordinal());
        if (!this.level().isClientSide && mode != previous) {
            this.onModeChanged(previous, mode);
        }
    }

    private void onModeChanged(SoulsandFigurineMode previous, SoulsandFigurineMode mode) {
        if (mode == SoulsandFigurineMode.GUARD && previous != SoulsandFigurineMode.GUARD) {
            this.homePos = this.blockPosition();
        }
        if (!mode.huntsHostiles()) {
            // 侍从模式不主动出击：正在打的非"玩家招惹过"的目标立即放下，
            // 玩家攻击过的/攻击玩家的目标由 OwnerHurt* 目标重新挂上。
            this.setTarget(null);
        }
        this.getNavigation().stop();
    }

    // ================================================================ 免疫

    // 火焰免疫不在本类里写：它是实体类型属性，注册处已挂 EntityType.Builder#fireImmune()
    // （GeneratedMod.SOULSAND_FIGURINE）。此处只处理"减益"这一类。

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        Holder<net.minecraft.world.effect.MobEffect> holder = effect.getEffect();
        if (holder.value() instanceof MesmerizedMobEffect
                || holder.value() instanceof RebellionMobEffect) {
            return false;
        }
        return holder.value().getCategory() != MobEffectCategory.HARMFUL;
    }

    // ================================================================ 交互

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (isSoulRepairItem(held) && this.getHealth() < this.getMaxHealth()) {
            if (!this.level().isClientSide) {
                this.heal(HAND_HEAL_AMOUNT);
                this.playSound(SoundEvents.SOUL_SAND_PLACE, 1.0F, 1.0F);
                held.consume(1, player);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (!player.isSecondaryUseActive()) {
            if (this.canConfigure(player)) {
                // 两端都得 CONSUME：客户端不这么做会接着把手里那件物品也用了。
                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.openMenu(this, buffer -> buffer.writeVarInt(this.getId()));
                }
                return InteractionResult.CONSUME;
            }
            // 别人的土偶：服务端回一句提示，客户端这边什么都别开。
            // 只有主手触发才回，免得双手各刷一遍。
            if (hand == InteractionHand.MAIN_HAND && player instanceof ServerPlayer serverPlayer) {
                serverPlayer.displayClientMessage(
                        Component.translatable("entity.netherarmy.soulsand_figurine.not_owner"), true);
            }
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public Component getDisplayName() {
        return this.hasCustomName() ? super.getDisplayName()
                : Component.translatable("container.netherarmy.soulsand_figurine");
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new SoulsandFigurineMenu(containerId, playerInventory, this);
    }

    public static SoulsandFigurineMenu createClientMenu(int containerId, Inventory inventory,
                                                       net.minecraft.network.RegistryFriendlyByteBuf buffer) {
        int entityId = buffer.readVarInt();
        if (inventory.player.level().getEntity(entityId) instanceof SoulsandFigurine figurine) {
            return new SoulsandFigurineMenu(containerId, inventory, figurine);
        }
        return new SoulsandFigurineMenu(containerId, inventory,
                GeneratedMod.SOULSAND_FIGURINE.get().create(inventory.player.level()));
    }

    // ================================================================ 每刻

    @Override
    public void onAddedToLevel() {
        super.onAddedToLevel();
        if (!this.level().isClientSide) {
            // 老存档里警戒模式可能没存驻守点（或从别处加载），补记当前位置。
            if (this.getMode() == SoulsandFigurineMode.GUARD && this.homePos == null) {
                this.homePos = this.blockPosition();
            }
            this.reassessWeaponGoal();
        }
    }

    /**
     * 挥臂动画的时钟：原版 {@code updateSwingTime()} 只在 {@code Monster#aiStep} 里被调，
     * 傀儡不是 Monster，所以 {@code attackAnim} 永远停在 0——近战目标明明每 20 tick 都
     * {@code swing(MAIN_HAND)} 并发出了挥手包，客户端算出来仍是"没挥手"
     * （{@code HumanoidModel#setupAttackAnimation} 开头就是 {@code attackTime <= 0} 直接返回；
     * 原版铁傀儡同样绕开它，自建了 attackAnimationTick）。
     *
     * <p>这里按 {@code Monster#aiStep} 的时序补齐；{@code aiStep} 双端都会跑，
     * 服务端推进攻击计时、客户端把挥手包变成动画，两端一致。</p>
     */
    @Override
    public void aiStep() {
        this.updateSwingTime();
        super.aiStep();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        this.updateSoulGroundBonus();
        this.updateInventoryHeal();
        this.updateShieldStance();
        this.entityData.set(DATA_SHIELD_BLOCKING, this.isShieldRaised());
        LivingEntity target = this.getTarget();
        if (target != null && (!target.isAlive() || !this.isHostileTarget(target))) {
            this.setTarget(null);
        }
    }

    private void updateSoulGroundBonus() {
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) {
            return;
        }
        boolean onSoul = this.isStandingOnSoulBlock();
        if (onSoul) {
            if (!speed.hasModifier(SOUL_GROUND_SPEED_ID)) {
                speed.addTransientModifier(SOUL_GROUND_SPEED);
            }
            this.soulGroundHealTicks++;
            if (this.soulGroundHealTicks >= 20) {
                this.soulGroundHealTicks = 0;
                this.heal(1.0F);
            }
        } else {
            this.soulGroundHealTicks = 0;
            speed.removeModifier(SOUL_GROUND_SPEED_ID);
        }
    }

    private boolean isStandingOnSoulBlock() {
        BlockPos below = this.getBlockPosBelowThatAffectsMyMovement();
        BlockState state = this.level().getBlockState(below);
        return state.is(Blocks.SOUL_SAND) || state.is(Blocks.SOUL_SOIL);
    }

    private void updateInventoryHeal() {
        if (this.inventoryHealCooldown > 0) {
            this.inventoryHealCooldown--;
            return;
        }
        if (this.getHealth() >= this.getMaxHealth()) {
            return;
        }
        for (int i = 0; i < this.inventory.getContainerSize(); i++) {
            ItemStack stack = this.inventory.getItem(i);
            if (!isSoulRepairItem(stack)) {
                continue;
            }
            stack.shrink(1);
            this.inventory.setItem(i, stack);
            this.heal(INVENTORY_HEAL_AMOUNT);
            this.playSound(SoundEvents.SOUL_SAND_PLACE, 0.8F, 1.2F);
            this.inventoryHealCooldown = INVENTORY_HEAL_INTERVAL;
            return;
        }
    }

    static boolean isSoulRepairItem(ItemStack stack) {
        return !stack.isEmpty() && (stack.is(Items.SOUL_SAND) || stack.is(Items.SOUL_SOIL)
                || stack.is(Blocks.SOUL_SAND.asItem()) || stack.is(Blocks.SOUL_SOIL.asItem()));
    }

    // ================================================================ 远程 / 武器

    @Override
    public boolean canFireProjectileWeapon(net.minecraft.world.item.ProjectileWeaponItem weapon) {
        return weapon instanceof BowItem || weapon instanceof CrossbowItem
                || super.canFireProjectileWeapon(weapon);
    }

    /**
     * 弹药来源：先看另一只手（与原版怪物一致），再看土偶自带的 2×2 背包，最后才凭空补箭。
     *
     * <p>弩装填交给 {@code CrossbowItem#releaseUsing → tryLoadProjectiles → draw}，
     * 而"没弹药就白送一支箭"的兜底只写在 {@code Monster#getProjectile} 里。土偶继承的是
     * {@code AbstractGolem}，基类 {@code LivingEntity#getProjectile} 只返回
     * {@code ItemStack.EMPTY}：{@code draw} 拿到空栈直接返回空列表，弩的
     * {@code Charged} 组件永远写不进去，于是弩停在"没上弦"，射击时无箭可发——
     * 这就是"不能正确给弩上弦"的根因。这里补上怪物那套兜底。</p>
     *
     * <p>背包命中时返回的是背包里的<b>真实堆叠</b>而非副本：{@code ProjectileWeaponItem#useAmmo}
     * 会从它身上 {@code split(1)}，因此背包里的箭矢/烟花火箭会被真正消耗；
     * 背包空时才退回凭空一支箭（与原版骷髅、掠夺者同款）。</p>
     */
    @Override
    public ItemStack getProjectile(ItemStack weapon) {
        if (!(weapon.getItem() instanceof ProjectileWeaponItem projectileWeapon)) {
            return ItemStack.EMPTY;
        }
        ItemStack held = ProjectileWeaponItem.getHeldProjectile(this,
                projectileWeapon.getSupportedHeldProjectiles(weapon));
        if (!held.isEmpty()) {
            return held;
        }
        ItemStack bagAmmo = this.findBagAmmo(weapon);
        if (!bagAmmo.isEmpty()) {
            return bagAmmo;
        }
        return new ItemStack(Items.ARROW);
    }

    /** 按武器可用的弹药类型在 2×2 背包里找弹药，命中返回背包内的真实堆叠。 */
    private ItemStack findBagAmmo(ItemStack weapon) {
        if (!(weapon.getItem() instanceof ProjectileWeaponItem projectileWeapon)) {
            return ItemStack.EMPTY;
        }
        Predicate<ItemStack> ammoPredicate = projectileWeapon.getAllSupportedProjectiles(weapon);
        for (int i = 0; i < this.inventory.getContainerSize(); i++) {
            ItemStack stack = this.inventory.getItem(i);
            if (!stack.isEmpty() && ammoPredicate.test(stack)) {
                return stack;
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public void performRangedAttack(LivingEntity target, float pullProgress) {
        if (target == null || !target.isAlive()) {
            return;
        }
        if (this.isHolding(stack -> stack.getItem() instanceof CrossbowItem)) {
            this.performCrossbowAttack(this, 1.6F);
            return;
        }
        InteractionHand hand = this.tridentHand();
        if (hand != null) {
            ItemStack held = this.getItemInHand(hand);
            // 走 MobThrownTridentHandler：投出去的是去掉忠诚的副本，10 秒后自动消失
            // （带忠诚时三叉戟会一直想飞回主人手上，怪物主人永远接不住，只会抽搐）。
            ThrownTrident thrown = MobThrownTridentHandler.create(this.level(), this, held);
            double dx = target.getX() - this.getX();
            double dy = target.getY(0.3333333333333333D) - thrown.getY();
            double dz = target.getZ() - this.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            thrown.shoot(dx, dy + horizontal * 0.2D, dz, 1.6F,
                    (float) (14 - this.level().getDifficulty().getId() * 4));
            this.playSound(SoundEvents.DROWNED_SHOOT, 1.0F,
                    1.0F / (this.random.nextFloat() * 0.4F + 0.8F));
            this.level().addFreshEntity(thrown);
            return;
        }
        if (this.isHolding(stack -> stack.getItem() instanceof BowItem)) {
            // 逐行对齐原版骷髅 AbstractSkeleton#performRangedAttack，差别只在弹药来源：
            // 1) 用 ProjectileUtil.getWeaponHoldingHand 找"真正拿弓的那只手"。父类给的
            //    LivingEntity#getWeaponItem 只认主手——弓放在副手时它会返回主手那件东西
            //    （甚至是空栈），而 AbstractArrow 的构造器在服务端遇到空武器栈会直接抛
            //    IllegalArgumentException("Invalid weapon firing an arrow")，且箭矢带不到
            //    弓上的附魔，力道随之变弱。
            // 2) 造箭后过一遍 ProjectileWeaponItem#customArrow（附魔/箭种处理），骷髅也是这么做的。
            // 3) 初速、散布取骷髅同款（1.6 格/tick、14-4×难度），蓄力钉死为满蓄力。
            InteractionHand bowHand = ProjectileUtil.getWeaponHoldingHand(this,
                    item -> item instanceof BowItem);
            ItemStack weapon = this.getItemInHand(bowHand);
            ProjectileWeaponItem projectileWeapon = (ProjectileWeaponItem) weapon.getItem();
            // 弹药优先级与骷髅一致：另一只手 → 2×2 背包（返回真实堆叠，放完扣一支）→ 凭空一支箭。
            ItemStack ammo = ProjectileWeaponItem.getHeldProjectile(this,
                    projectileWeapon.getSupportedHeldProjectiles(weapon));
            boolean fromBag = false;
            if (ammo.isEmpty()) {
                ammo = this.findBagAmmo(weapon);
                fromBag = !ammo.isEmpty();
            }
            if (ammo.isEmpty()) {
                ammo = new ItemStack(Items.ARROW);
            }
            // 骷髅的弓目标只在拉满 20 tick 后才放箭，getPowerForTime 恒为 1.0（满蓄力）。
            // 这里同样取满蓄力：箭矢伤害 = 初速 × baseDamage，而 baseDamage 正比于蓄力，
            // 兜住任何提前触发的放箭路径，保证力道不低于骷髅。
            float power = Math.max(pullProgress, 1.0F);
            AbstractArrow arrow = ProjectileUtil.getMobArrow(this, ammo, power, weapon);
            arrow = projectileWeapon.customArrow(arrow, ammo, weapon);
            double dx = target.getX() - this.getX();
            double dy = target.getY(0.3333333333333333D) - arrow.getY();
            double dz = target.getZ() - this.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            arrow.shoot(dx, dy + horizontal * 0.2D, dz, SKELETON_BOW_VELOCITY,
                    (float) (14 - this.level().getDifficulty().getId() * 4));
            this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F,
                    1.0F / (this.random.nextFloat() * 0.4F + 0.8F));
            this.level().addFreshEntity(arrow);
            if (fromBag) {
                ammo.shrink(1);
            }
        }
    }

    @Override
    public void setChargingCrossbow(boolean charging) {
        this.entityData.set(DATA_CHARGING_CROSSBOW, charging);
    }

    @Override
    public void onCrossbowAttackPerformed() {
        this.attackAnim = 0.0F;
    }

    @Override
    public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
        super.setItemSlot(slot, stack);
        if (!this.level().isClientSide && (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND)) {
            this.reassessWeaponGoal();
        }
    }

    private boolean isHoldingTrident() {
        return this.tridentHand() != null;
    }

    private boolean isTridentMeleeTarget() {
        LivingEntity target = this.getTarget();
        return target != null && this.distanceToSqr(target) <= TRIDENT_MELEE_ENTER_SQR;
    }

    private InteractionHand tridentHand() {
        if (this.getMainHandItem().is(Items.TRIDENT)) {
            return InteractionHand.MAIN_HAND;
        }
        if (this.getOffhandItem().is(Items.TRIDENT)) {
            return InteractionHand.OFF_HAND;
        }
        return null;
    }

    // ================================================================ 目标

    private boolean isHostileTarget(LivingEntity candidate) {
        if (candidate == null || candidate == this || !candidate.isAlive() || candidate.isSpectator()) {
            return false;
        }
        if (this.isOwnedBy(candidate) || candidate instanceof SoulsandFigurine) {
            return false;
        }
        if (candidate instanceof Player player && (player.isCreative() || player.isSpectator())) {
            return false;
        }
        if (candidate instanceof Creeper) {
            return false;
        }
        LivingEntity owner = this.getOwner();
        if (owner != null && candidate == owner) {
            return false;
        }
        if (candidate instanceof Enemy) {
            return true;
        }
        return owner != null
                && (candidate == owner.getLastHurtByMob() || candidate == owner.getLastHurtMob());
    }

    /**
     * 灵魂土偶之间互不仇恨，也绝不把主人当目标。
     *
     * <p>上面几条目标都走 {@link #isHostileTarget} 过滤，唯独原版
     * {@code HurtByTargetGoal} 只认 {@code getLastHurtByMob()}——误伤、流矢、玩家挑拨
     * 都能把同类写进仇恨表，于是两个土偶打成一团。这里再加两道总闸：</p>
     * <ul>
     *   <li>{@link #canAttack}：任何战斗目标在续期检查（{@code TargetGoal#canContinueToUse}）
     *       时都会问这一句，同类直接答"不能打"。</li>
     *   <li>{@link #setTarget}：兜底，任何来源（含其他模组）想把同类写成目标都拦下。
     *       {@code HurtByTargetGoal} 的 {@code canUse} 走的是
     *       {@code TargetGoal#canAttack(LivingEntity, TargetingConditions)}，绕开了
     *       {@link #canAttack}，所以主人自己射土偶一箭时它会从这条路把主人挂成目标，
     *       一并在这里按归属拦下。</li>
     * </ul>
     */
    @Override
    public boolean canAttack(LivingEntity target) {
        return !(target instanceof SoulsandFigurine) && !this.isOwnedBy(target) && super.canAttack(target);
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target instanceof SoulsandFigurine || this.isOwnedBy(target)) {
            return;
        }
        super.setTarget(target);
    }

    // ================================================================ 存盘

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        this.getOwnerUUID().ifPresent(uuid -> tag.putUUID("Owner", uuid));
        tag.put("Inventory", this.inventory.createTag(this.registryAccess()));
        tag.putString("Mode", this.getMode().getSerializedName());
        if (this.homePos != null) {
            tag.putInt("HomeX", this.homePos.getX());
            tag.putInt("HomeY", this.homePos.getY());
            tag.putInt("HomeZ", this.homePos.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            this.setOwnerUUID(tag.getUUID("Owner"));
        }
        if (tag.contains("Inventory")) {
            this.inventory.fromTag(tag.getList("Inventory", 10), this.registryAccess());
        }
        if (tag.contains("Mode")) {
            this.setMode(SoulsandFigurineMode.byName(tag.getString("Mode")));
        }
        // 驻守点要在 setMode 之后恢复：setMode 切到警戒模式时会先记下当前位置。
        if (tag.contains("HomeX") && tag.contains("HomeY") && tag.contains("HomeZ")) {
            this.homePos = new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ"));
        }
        this.reassessWeaponGoal();
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        for (int i = 0; i < this.inventory.getContainerSize(); i++) {
            ItemStack stack = this.inventory.getItem(i);
            if (!stack.isEmpty()) {
                this.spawnAtLocation(stack);
                this.inventory.setItem(i, ItemStack.EMPTY);
            }
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack stack = this.getItemBySlot(slot);
            if (!stack.isEmpty()) {
                this.spawnAtLocation(stack);
                this.setItemSlot(slot, ItemStack.EMPTY);
            }
        }
    }

    /** 受击：灵魂沙破坏；死亡：烈焰人同款。 */
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SOUL_SAND_BREAK;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BLAZE_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.IRON_GOLEM_STEP, 1.0F, 1.0F);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ================================================================ 盾牌

    private void stopShieldUse() {
        if (this.isUsingItem() && this.getUsedItemHand() == InteractionHand.OFF_HAND) {
            this.stopUsingItem();
        }
    }

    private void updateShieldStance() {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            this.shieldHoldTicks = 0;
            this.shieldSwingLockTicks = 0;
            this.stopShieldUse();
            return;
        }
        if (this.shieldSwingLockTicks > 0) {
            this.shieldSwingLockTicks--;
            this.stopShieldUse();
            return;
        }
        Projectile incoming = this.detectIncomingProjectile();
        if (incoming != null) {
            this.raiseShield(SHIELD_REACT_TICKS);
            this.getLookControl().setLookAt(
                    incoming.getX(), incoming.getY() + incoming.getBbHeight() * 0.5D, incoming.getZ(),
                    90.0F, 30.0F);
        }
        int intervalLeft = this.attackIntervalEndTick - this.tickCount;
        if (intervalLeft > 0) {
            this.raiseShield(intervalLeft + 1);
        }
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive() && this.distanceToSqr(target) <= SHIELD_COMBAT_GUARD_RANGE_SQR) {
            this.raiseShield(SHIELD_COMBAT_GUARD_TICKS);
        }
        if (this.shieldHoldTicks > 0) {
            this.shieldHoldTicks--;
            if (!this.isUsingItem()) {
                this.startUsingItem(InteractionHand.OFF_HAND);
            }
        } else {
            this.stopShieldUse();
        }
    }

    private void raiseShield(int ticks) {
        if (!(this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem)) {
            return;
        }
        this.shieldHoldTicks = Math.max(this.shieldHoldTicks, ticks);
        if (this.shieldSwingLockTicks > 0) {
            return;
        }
        if (!this.isUsingItem()) {
            this.startUsingItem(InteractionHand.OFF_HAND);
        }
    }

    private boolean isShieldRaised() {
        return this.shieldSwingLockTicks <= 0
                && this.shieldHoldTicks > 0
                && this.getItemBySlot(EquipmentSlot.OFFHAND).getItem() instanceof ShieldItem;
    }

    @Override
    public boolean isDamageSourceBlocked(DamageSource source) {
        if (this.isShieldRaised() && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            return this.isAttackFromFront(source);
        }
        return super.isDamageSourceBlocked(source);
    }

    private boolean isAttackFromFront(DamageSource source) {
        Vec3 sourcePos = source.getSourcePosition();
        if (sourcePos == null) {
            Entity attacker = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
            if (attacker == null) {
                return false;
            }
            sourcePos = attacker.getEyePosition();
        }
        Vec3 toSelf = sourcePos.vectorTo(this.position());
        Vec3 flat = new Vec3(toSelf.x, 0.0D, toSelf.z);
        if (flat.lengthSqr() < 1.0E-6D) {
            return true;
        }
        Vec3 towards = flat.normalize();
        return towards.dot(this.calculateViewVector(0.0F, this.getYHeadRot())) < 0.0D
                || towards.dot(this.calculateViewVector(0.0F, this.getYRot())) < 0.0D;
    }

    @Override
    protected void hurtCurrentlyUsedShield(float amount) {
        if (this.level().isClientSide() || amount < SHIELD_WEAR_DAMAGE_FLOOR) {
            return;
        }
        EquipmentSlot slot = EquipmentSlot.OFFHAND;
        ItemStack stack = this.getItemBySlot(slot);
        if (!(stack.getItem() instanceof ShieldItem)) {
            return;
        }
        stack.hurtAndBreak(1 + Mth.floor(amount), this, slot);
        if (stack.isEmpty()) {
            this.setItemSlot(slot, ItemStack.EMPTY);
            this.shieldHoldTicks = 0;
            this.stopShieldUse();
            this.playSound(SoundEvents.SHIELD_BREAK, 0.8F,
                    0.8F + this.level().random.nextFloat() * 0.4F);
        }
    }

    private Projectile detectIncomingProjectile() {
        AABB area = this.getBoundingBox().inflate(16.0D);
        Vec3 center = this.getBoundingBox().getCenter();
        Projectile best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Projectile projectile : this.level().getEntitiesOfClass(Projectile.class, area)) {
            if (!ProjectileFlightTracker.isActuallyFlying(projectile) || projectile.getOwner() == this) {
                continue;
            }
            Vec3 toMe = center.subtract(projectile.position());
            Vec3 velocity = projectile.getDeltaMovement();
            double speed = velocity.length();
            if (speed < 1.0E-3D) {
                continue;
            }
            Vec3 direction = velocity.scale(1.0D / speed);
            double along = toMe.dot(direction);
            if (along < 0.0D || along > PROJECTILE_LOOKAHEAD) {
                continue;
            }
            double perpendicular = toMe.subtract(direction.scale(along)).length();
            double corridor = Math.max(PROJECTILE_CORRIDOR, this.getBbWidth());
            if (perpendicular <= corridor && along < bestDistance) {
                best = projectile;
                bestDistance = along;
            }
        }
        return best;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean damaged = super.hurt(source, amount);
        if (damaged && !this.level().isClientSide && amount > 0.0F
                && !source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            this.raiseShield(SHIELD_ON_HURT_GUARD_TICKS);
        }
        return damaged;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        ItemStack weapon = this.getMainHandItem();
        AttributeInstance attack = this.getAttribute(Attributes.ATTACK_DAMAGE);
        boolean smash = attack != null
                && weapon.getItem() instanceof MaceItem
                && MaceItem.canSmashAttack(this);
        double bonus = 0.0D;
        if (smash) {
            DamageSource source = this.damageSources().mobAttack(this);
            bonus = weapon.getItem().getAttackDamageBonus(target, (float) attack.getValue(), source);
            attack.setBaseValue(attack.getBaseValue() + bonus);
        }
        boolean hurt;
        try {
            hurt = super.doHurtTarget(target);
        } finally {
            if (bonus != 0.0D) {
                attack.setBaseValue(attack.getBaseValue() - bonus);
            }
        }
        if (hurt) {
            this.shieldSwingLockTicks = ATTACK_SWING_LOCK_TICKS;
            this.attackIntervalEndTick = this.tickCount + 20;
            this.shieldHoldTicks = 0;
            if (smash) {
                this.applyMaceSmash(target);
            }
        }
        return hurt;
    }

    private void applyMaceSmash(Entity target) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        float fallen = this.fallDistance;
        SoundEvent sound = target.onGround()
                ? (fallen > 5.0F ? SoundEvents.MACE_SMASH_GROUND_HEAVY : SoundEvents.MACE_SMASH_GROUND)
                : SoundEvents.MACE_SMASH_AIR;
        serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(), sound,
                this.getSoundSource(), 1.0F, 1.0F);
        double radius = MaceItem.SMASH_ATTACK_KNOCKBACK_RADIUS;
        List<LivingEntity> affected = serverLevel.getEntitiesOfClass(LivingEntity.class,
                target.getBoundingBox().inflate(radius),
                entity -> entity != this && entity != target && !entity.isSpectator()
                        && !this.isOwnedBy(entity) && !(entity instanceof SoulsandFigurine));
        for (LivingEntity entity : affected) {
            Vec3 offset = entity.position().subtract(target.position());
            double power = (radius - offset.length()) * 0.7D
                    * (fallen > 5.0F ? 2.0D : 1.0D)
                    * (1.0D - entity.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
            if (power > 0.0D) {
                Vec3 push = offset.normalize().scale(power);
                entity.push(push.x, 0.7D, push.z);
            }
        }
        this.resetFallDistance();
    }

    // ================================================================ 目标内部类

    private static final class TridentAttackGoal extends RangedAttackGoal {
        private final SoulsandFigurine figurine;

        TridentAttackGoal(SoulsandFigurine figurine, float radius) {
            super(figurine, 1.0D, TRIDENT_ATTACK_INTERVAL, radius);
            this.figurine = figurine;
        }

        @Override
        public boolean canUse() {
            return super.canUse() && this.figurine.isHoldingTrident()
                    && !this.figurine.isTridentMeleeTarget();
        }

        @Override
        public boolean canContinueToUse() {
            return super.canContinueToUse() && this.figurine.isHoldingTrident()
                    && !this.figurine.isTridentMeleeTarget();
        }

        @Override
        public void start() {
            super.start();
            this.figurine.setAggressive(true);
            this.figurine.startUsingItem(InteractionHand.MAIN_HAND);
        }

        @Override
        public void stop() {
            super.stop();
            if (this.figurine.isUsingItem()) {
                this.figurine.stopUsingItem();
            }
            this.figurine.setAggressive(false);
        }
    }

    private static final class TridentMeleeGoal extends Goal {
        private final SoulsandFigurine figurine;
        private int attackCooldown;

        TridentMeleeGoal(SoulsandFigurine figurine) {
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = this.figurine.getTarget();
            return target != null && target.isAlive()
                    && this.figurine.isHoldingTrident()
                    && this.figurine.distanceToSqr(target) <= TRIDENT_MELEE_ENTER_SQR;
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity target = this.figurine.getTarget();
            return target != null && target.isAlive()
                    && this.figurine.isHoldingTrident()
                    && this.figurine.distanceToSqr(target) <= TRIDENT_MELEE_EXIT_SQR;
        }

        @Override
        public void start() {
            this.attackCooldown = 0;
            this.figurine.setAggressive(true);
        }

        @Override
        public void stop() {
            this.figurine.setAggressive(false);
            this.figurine.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.figurine.getTarget();
            if (target == null) {
                return;
            }
            this.figurine.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (this.attackCooldown > 0) {
                this.attackCooldown--;
            }
            if (this.figurine.isWithinMeleeAttackRange(target)) {
                this.figurine.getNavigation().stop();
                if (this.attackCooldown <= 0 && this.figurine.getSensing().hasLineOfSight(target)) {
                    InteractionHand hand = this.figurine.tridentHand();
                    this.figurine.swing(hand != null ? hand : InteractionHand.MAIN_HAND);
                    this.figurine.doHurtTarget(target);
                    this.attackCooldown = TRIDENT_MELEE_INTERVAL;
                }
            } else {
                this.figurine.getNavigation().moveTo(target, 1.2D);
            }
        }
    }

    private static final class MaceLeapGoal extends Goal {
        private final SoulsandFigurine figurine;
        private int cooldown;
        private boolean smashed;

        MaceLeapGoal(SoulsandFigurine figurine) {
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.cooldown > 0) {
                this.cooldown--;
                return false;
            }
            LivingEntity target = this.figurine.getTarget();
            if (target == null || !target.isAlive() || this.figurine.isPassenger()) {
                return false;
            }
            if (!(this.figurine.getMainHandItem().getItem() instanceof MaceItem)) {
                return false;
            }
            if (!this.figurine.onGround()) {
                return false;
            }
            return this.figurine.isWithinMeleeAttackRange(target)
                    && this.figurine.getSensing().hasLineOfSight(target);
        }

        @Override
        public void start() {
            LivingEntity target = this.figurine.getTarget();
            if (target == null) {
                return;
            }
            this.smashed = false;
            double dx = target.getX() - this.figurine.getX();
            double dz = target.getZ() - this.figurine.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double speed = Mth.clamp(horizontal / MACE_LEAP_TRAVEL_FACTOR, 0.0D, 0.7D);
            Vec3 motion = this.figurine.getDeltaMovement();
            double mx = horizontal > 1.0E-4D ? dx / horizontal * speed : 0.0D;
            double mz = horizontal > 1.0E-4D ? dz / horizontal * speed : 0.0D;
            this.figurine.setDeltaMovement(mx + motion.x * 0.2D, MACE_LEAP_UP, mz + motion.z * 0.2D);
            this.figurine.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity target = this.figurine.getTarget();
            return target != null && target.isAlive() && !this.figurine.onGround();
        }

        @Override
        public void stop() {
            this.cooldown = MACE_LEAP_COOLDOWN;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.figurine.getTarget();
            if (target == null) {
                return;
            }
            this.figurine.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (this.smashed || this.figurine.getDeltaMovement().y >= 0.0D) {
                return;
            }
            double dx = target.getX() - this.figurine.getX();
            double dz = target.getZ() - this.figurine.getZ();
            if (dx * dx + dz * dz > MACE_SMASH_HORIZONTAL_SQR
                    || this.figurine.fallDistance <= MaceItem.SMASH_ATTACK_FALL_THRESHOLD) {
                return;
            }
            this.figurine.swing(InteractionHand.MAIN_HAND);
            this.smashed = this.figurine.doHurtTarget(target);
        }
    }

    private static final class FollowOwnerGoal extends Goal {
        private final SoulsandFigurine figurine;
        private LivingEntity owner;
        private int repathCooldown;

        FollowOwnerGoal(SoulsandFigurine figurine) {
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            // 警戒模式不跟随：原地驻守交给 ReturnHomeGoal。
            if (!this.figurine.getMode().followsOwner()) {
                return false;
            }
            this.owner = this.figurine.getOwner();
            return this.owner != null && this.figurine.getTarget() == null
                    && this.figurine.distanceToSqr(this.owner) > 16.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return this.figurine.getMode().followsOwner()
                    && this.owner != null && this.owner.isAlive()
                    && this.figurine.getTarget() == null
                    && this.figurine.distanceToSqr(this.owner) > 9.0D;
        }

        @Override
        public void tick() {
            if (this.repathCooldown-- > 0 && this.figurine.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = 10;
            this.figurine.getNavigation().moveTo(this.owner, 1.0D);
        }
    }

    /**
     * 警戒模式的"回岗"目标：没有目标且离驻守点超过 2 格时走回去。
     *
     * <p>它不是战斗目标，敌人一死 {@code getTarget()} 变空就自动生效，
     * 于是土偶追完人自己回到当初站的位置。</p>
     */
    private static final class ReturnHomeGoal extends Goal {
        private final SoulsandFigurine figurine;
        private int repathCooldown;

        ReturnHomeGoal(SoulsandFigurine figurine) {
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return this.home() != null && this.figurine.getTarget() == null
                    && this.figurine.distanceToSqr(Vec3.atBottomCenterOf(this.home())) > 4.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return this.home() != null && this.figurine.getTarget() == null
                    && this.figurine.distanceToSqr(Vec3.atBottomCenterOf(this.home())) > 2.25D;
        }

        private BlockPos home() {
            return this.figurine.getMode() == SoulsandFigurineMode.GUARD ? this.figurine.homePos : null;
        }

        @Override
        public void tick() {
            BlockPos home = this.home();
            if (home == null) {
                return;
            }
            if (this.repathCooldown-- > 0 && this.figurine.getNavigation().isInProgress()) {
                return;
            }
            this.repathCooldown = 10;
            this.figurine.getNavigation().moveTo(
                    home.getX() + 0.5D, home.getY(), home.getZ() + 0.5D, 1.0D);
        }

        @Override
        public void stop() {
            this.figurine.getNavigation().stop();
        }
    }

    /** 警戒模式不散步，否则会飘离驻守点。 */
    private static final class ModeStrollGoal extends WaterAvoidingRandomStrollGoal {
        private final SoulsandFigurine figurine;

        ModeStrollGoal(SoulsandFigurine figurine) {
            super(figurine, 0.8D);
            this.figurine = figurine;
        }

        @Override
        public boolean canUse() {
            return this.figurine.getMode() != SoulsandFigurineMode.GUARD && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.figurine.getMode() != SoulsandFigurineMode.GUARD && super.canContinueToUse();
        }
    }

    /**
     * 主动索敌目标：保镖/警戒模式打靠近的敌对生物；侍从模式直接不启用。
     *
     * <p>{@code canContinueToUse} 同样看模式——从侍从切回保镖时它能重新搜敌，
     * 反向切换则让 {@code TargetGoal#stop} 顺手把当前目标清掉。</p>
     */
    private static final class ModeTargetGoal extends NearestAttackableTargetGoal<Mob> {
        private final SoulsandFigurine figurine;

        ModeTargetGoal(SoulsandFigurine figurine) {
            super(figurine, Mob.class, 10, true, false, figurine::isHostileTarget);
            this.figurine = figurine;
        }

        @Override
        public boolean canUse() {
            return this.figurine.getMode().huntsHostiles() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.figurine.getMode().huntsHostiles() && super.canContinueToUse();
        }
    }

    private static final class OwnerHurtByTargetGoal extends net.minecraft.world.entity.ai.goal.target.TargetGoal {
        private final SoulsandFigurine figurine;
        private LivingEntity attacker;
        private int timestamp;

        OwnerHurtByTargetGoal(SoulsandFigurine figurine) {
            super(figurine, false);
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            LivingEntity owner = this.figurine.getOwner();
            if (owner == null) {
                return false;
            }
            this.attacker = owner.getLastHurtByMob();
            int stamp = owner.getLastHurtByMobTimestamp();
            return stamp != this.timestamp && this.canAttack(this.attacker, net.minecraft.world.entity.ai.targeting.TargetingConditions.DEFAULT)
                    && this.figurine.isHostileTarget(this.attacker);
        }

        @Override
        public void start() {
            this.figurine.setTarget(this.attacker);
            LivingEntity owner = this.figurine.getOwner();
            if (owner != null) {
                this.timestamp = owner.getLastHurtByMobTimestamp();
            }
            super.start();
        }
    }

    private static final class OwnerHurtTargetGoal extends net.minecraft.world.entity.ai.goal.target.TargetGoal {
        private final SoulsandFigurine figurine;
        private LivingEntity target;
        private int timestamp;

        OwnerHurtTargetGoal(SoulsandFigurine figurine) {
            super(figurine, false);
            this.figurine = figurine;
            this.setFlags(EnumSet.of(Goal.Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            LivingEntity owner = this.figurine.getOwner();
            if (owner == null) {
                return false;
            }
            this.target = owner.getLastHurtMob();
            int stamp = owner.getLastHurtMobTimestamp();
            return stamp != this.timestamp && this.canAttack(this.target, net.minecraft.world.entity.ai.targeting.TargetingConditions.DEFAULT)
                    && this.figurine.isHostileTarget(this.target);
        }

        @Override
        public void start() {
            this.figurine.setTarget(this.target);
            LivingEntity owner = this.figurine.getOwner();
            if (owner != null) {
                this.timestamp = owner.getLastHurtMobTimestamp();
            }
            super.start();
        }
    }
}
