package cn.blockforge.generated.netherarmy;

import java.util.IdentityHashMap;
import java.util.Map;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 凋灵魔导师模型：几何与逐面 UV 由 tools/gen_wither_archmage_model.py 从用户上传的
 * {@code wither_Archmage.bbmodel} 生成（64×64 贴图，32px 人形网格）。手臂按原稿
 * 保持"平展"（骨骼绕 X 轴 -90°，横向朝前），走路只动腿，手臂不摆。
 *
 * <p>动画分三份：{@code float} 常驻——魔法书绕自身枢轴轻轻上下浮动、书页轻颤，
 * 任何时候都在播；{@code open}/{@code close} 由 {@link WitherArchmage#getBookOpenAmount()}
 * 驱动左右半书页的夹角（0 = 完全打开，1 = 合拢）；本体施法由
 * {@link WitherArchmage#getCastAmount()} 驱动两臂从"平展"抬到前上方并挥手颤动，
 * 与魔法书的状态互不干涉。</p>
 */
public final class WitherArchmageModel extends EntityModel<WitherArchmage> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "wither_archmage"), "main");
    private static final int TEX_WIDTH = 64;
    private static final int TEX_HEIGHT = 64;
    /**
     * 手臂基准角：bbmodel 里臂骨绕 X 轴 +90°，换算到 Java 为 -90°（横向朝前，不下垂）。
     *
     * <p>臂骨的枢轴已被 {@code repivot_arms} 搬到肩关节（臂骨内端），所以绕 xRot 的
     * 旋转天然以肩为轴，不会像绕臂中段那样上下两头对甩。</p>
     */
    private static final float ARM_BASE_X = -(float) Math.PI / 2.0F;
    /**
     * 施法抬手角：在"平展朝前"的基础上再抬多少弧度（约 57°）。
     *
     * <p>方向很重要：{@link #ARM_BASE_X} 已经把手臂摆成平展朝前，往"上"抬是<b>减</b>角
     * （越负越向上，-180° 是举直）；加角会让手臂转到身体的下方，那看起来是垂手，
     * 不是施法。所以下面用的是 {@code ARM_BASE_X - CAST_LIFT * cast}。</p>
     */
    private static final float CAST_LIFT = 1.00F;
    /** 施法时双臂向外张开的弧度（双手离开躯干、向前上方张开成 V 形）。 */
    private static final float CAST_SPREAD = 0.30F;
    /** 挥手颤动的幅度（弧度）与频率同唤魔者。 */
    private static final float CAST_WAVE = 0.20F;
    /** magic book 骨骼的静态 y 偏移（悬浮动画在它之上叠加）。 */
    private static final float BOOK_BASE_Y = 1.0F;
    /** float 动画一个循环的长度（秒）。 */
    private static final float FLOAT_LOOP_SECONDS = 3.0F;
    /** 合拢时左右半书页的 z 角（原稿 close 动画终帧 -90° / +90°）。 */
    private static final float HALF_CLOSED_Z = 90.0F;
    // ---- 原稿 model-4.animation.json 的关键帧（时间秒 / 角度度 / 位置像素） ----
    private static final float[] FLOAT_TIMES_BOOK = {0.0F, 0.75F, 1.5F, 2.25F, 3.0F};
    private static final float[] FLOAT_POS_BOOK = {0.0F, 1.0F, 0.0F, -1.0F, 0.0F};
    private static final float[] FLOAT_ROT_Y_BOOK = {0.0F, 3.0F, 0.0F, -3.0F, 0.0F};
    private static final float[] FLOAT_ROT_Z_BOOK = {0.0F, 1.0F, 0.0F, -1.0F, 0.0F};
    private static final float[] FLOAT_TIMES_HALF = {0.0F, 1.0F, 2.0F, 3.0F};
    private static final float[] FLOAT_HALF_LEFT = {0.0F, -3.0F, 2.0F, 0.0F};
    private static final float[] FLOAT_HALF_RIGHT = {0.0F, 3.0F, -2.0F, 0.0F};
    private static final float[] FLOAT_TIMES_PAGE = {0.0F, 1.2083F, 2.4167F, 3.0F};
    private static final float[] FLOAT_PAGE_LEFT = {0.0F, 2.0F, -2.0F, 0.0F};
    private static final float[] FLOAT_PAGE_RIGHT = {0.0F, -2.0F, 2.0F, 0.0F};
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart bookRoot;
    private final ModelPart halfLeft;
    private final ModelPart pageLeft;
    private final ModelPart halfRight;
    private final ModelPart pageRight;
    private final ModelPart root;
    private static final String[] NO_CHILDREN = new String[0];
    private final Map<ModelPart, float[]> quads = new IdentityHashMap<>();

    public WitherArchmageModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.bookRoot = root.getChild("book_root");
        this.halfLeft = root.getChild("book_root").getChild("half_left");
        this.pageLeft = root.getChild("book_root").getChild("half_left").getChild("page_left");
        this.halfRight = root.getChild("book_root").getChild("half_right");
        this.pageRight = root.getChild("book_root").getChild("half_right").getChild("page_right");
        // 骨骼名与 bbmodel 一一对应，几何表直接按名字挂上去。
        this.quads.put(root.getChild("head"), WitherArchmageQuads.QUADS_HEAD);
        this.quads.put(root.getChild("head").getChild("hat"), WitherArchmageQuads.QUADS_HAT);
        this.quads.put(root.getChild("body"), WitherArchmageQuads.QUADS_BODY);
        this.quads.put(root.getChild("body").getChild("cloak"), WitherArchmageQuads.QUADS_CLOAK);
        this.quads.put(root.getChild("body").getChild("robe"), WitherArchmageQuads.QUADS_ROBE);
        this.quads.put(root.getChild("left_arm"), WitherArchmageQuads.QUADS_LEFT_ARM);
        this.quads.put(root.getChild("left_arm").getChild("left_sleeve"), WitherArchmageQuads.QUADS_LEFT_SLEEVE);
        this.quads.put(root.getChild("left_arm").getChild("left_sleeve").getChild("left_cuff"), WitherArchmageQuads.QUADS_LEFT_CUFF);
        this.quads.put(root.getChild("right_arm"), WitherArchmageQuads.QUADS_RIGHT_ARM);
        this.quads.put(root.getChild("right_arm").getChild("right_sleeve"), WitherArchmageQuads.QUADS_RIGHT_SLEEVE);
        this.quads.put(root.getChild("right_arm").getChild("right_sleeve").getChild("right_cuff"), WitherArchmageQuads.QUADS_RIGHT_CUFF);
        this.quads.put(root.getChild("left_leg"), WitherArchmageQuads.QUADS_LEFT_LEG);
        this.quads.put(root.getChild("left_leg").getChild("left_boot_b"), WitherArchmageQuads.QUADS_LEFT_BOOT_B);
        this.quads.put(root.getChild("left_leg").getChild("left_boot_a"), WitherArchmageQuads.QUADS_LEFT_BOOT_A);
        this.quads.put(root.getChild("right_leg"), WitherArchmageQuads.QUADS_RIGHT_LEG);
        this.quads.put(root.getChild("right_leg").getChild("right_boot_a"), WitherArchmageQuads.QUADS_RIGHT_BOOT_A);
        this.quads.put(root.getChild("right_leg").getChild("right_boot_b"), WitherArchmageQuads.QUADS_RIGHT_BOOT_B);
        this.quads.put(root.getChild("book_root"), WitherArchmageQuads.QUADS_BOOK_ROOT);
        this.quads.put(root.getChild("book_root").getChild("half_left").getChild("page_left"), WitherArchmageQuads.QUADS_PAGE_LEFT);
        this.quads.put(root.getChild("book_root").getChild("half_right").getChild("page_right"), WitherArchmageQuads.QUADS_PAGE_RIGHT);
    }

    @Override
    public void setupAnim(WitherArchmage entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        // 走路动画同凋灵骷髅：只有腿在摆，手臂保持平展（用户要求）。
        this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
        // 本体技能：像唤魔者那样挥手——手臂绕**肩关节**（臂骨枢轴）从"平展朝前"
        // 向上抬到前上方，再轻微颤动。抬手／放手按实体的施法进度插值（getCastAmount），
        // 起手和收手都不会硬切。
        // 注意符号：抬"上"要在 -90° 基准上继续减角（-180° 为举直），加角是往下甩。
        float cast = Mth.clamp(entity.getCastAmount(), 0.0F, 1.0F);
        float wave = Mth.cos(ageInTicks * 0.6662F) * CAST_WAVE * cast;
        this.leftArm.xRot = ARM_BASE_X - CAST_LIFT * cast + wave;
        this.rightArm.xRot = ARM_BASE_X - CAST_LIFT * cast + wave;
        this.leftArm.yRot = 0.0F;
        this.rightArm.yRot = 0.0F;
        // 两臂各自向外张开：左臂 x 为负，zRot 取负才是朝外；取正会把双手收拢到脸前。
        this.leftArm.zRot = -CAST_SPREAD * cast;
        this.rightArm.zRot = CAST_SPREAD * cast;
        // float：常驻悬浮动画（3 秒一循环），逐骨骼按原动画关键帧取样，
        // 与开合动画相加；Blockbench 的 z 角在 Java 取负、y 角同号、位置 y 取负。
        float floatTime = (ageInTicks / 20.0F) % FLOAT_LOOP_SECONDS;
        float bookBob = sample(floatTime, FLOAT_TIMES_BOOK, FLOAT_POS_BOOK);
        float bookYaw = sample(floatTime, FLOAT_TIMES_BOOK, FLOAT_ROT_Y_BOOK);
        float bookRoll = sample(floatTime, FLOAT_TIMES_BOOK, FLOAT_ROT_Z_BOOK);
        this.bookRoot.y = BOOK_BASE_Y - bookBob;
        this.bookRoot.yRot = bookYaw * Mth.DEG_TO_RAD;
        this.bookRoot.zRot = -bookRoll * Mth.DEG_TO_RAD;
        // open / close：合拢时左右半书页分别转到原稿终帧的 -90° / +90°。
        float closed = 1.0F - Mth.clamp(entity.getBookOpenAmount(), 0.0F, 1.0F);
        this.halfLeft.zRot = (HALF_CLOSED_Z * closed
                - sample(floatTime, FLOAT_TIMES_HALF, FLOAT_HALF_LEFT)) * Mth.DEG_TO_RAD;
        this.halfRight.zRot = (-HALF_CLOSED_Z * closed
                - sample(floatTime, FLOAT_TIMES_HALF, FLOAT_HALF_RIGHT)) * Mth.DEG_TO_RAD;
        this.pageLeft.zRot = -sample(floatTime, FLOAT_TIMES_PAGE, FLOAT_PAGE_LEFT) * Mth.DEG_TO_RAD;
        this.pageRight.zRot = -sample(floatTime, FLOAT_TIMES_PAGE, FLOAT_PAGE_RIGHT) * Mth.DEG_TO_RAD;
    }

    /** 关键帧线性取样（times 严格递增，越界钳到端点）。 */
    private static float sample(float time, float[] times, float[] values) {
        if (time <= times[0]) {
            return values[0];
        }
        for (int i = 1; i < times.length; i++) {
            if (time <= times[i]) {
                float span = times[i] - times[i - 1];
                float ratio = span <= 0.0F ? 0.0F : (time - times[i - 1]) / span;
                return Mth.lerp(ratio, values[i - 1], values[i]);
            }
        }
        return values[values.length - 1];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, int color) {
        poseStack.pushPose();
        this.root.translateAndRotate(poseStack);
        for (String childName : childNames("root")) {
            this.renderPart(poseStack, buffer, this.root.getChild(childName), childName,
                    packedLight, packedOverlay, color);
        }
        poseStack.popPose();
    }

    /**
     * 递归发射几何：&#64;{@code ModelPart#children} 在 1.21.1 是私有字段，子骨骼名单由
     * 生成器写进 {@link #childNames}（层级与 bbmodel 一一对应）。
     */
    private void renderPart(PoseStack poseStack, VertexConsumer buffer, ModelPart part, String name,
                            int packedLight, int packedOverlay, int color) {
        float[] faces = this.quads.get(part);
        if (faces != null) {
            HackerQuads.emit(poseStack, buffer, part, faces, TEX_WIDTH, TEX_HEIGHT,
                    packedLight, packedOverlay, color);
        }
        String[] children = childNames(name);
        if (children.length == 0) {
            return;
        }
        poseStack.pushPose();
        part.translateAndRotate(poseStack);
        for (String childName : children) {
            this.renderPart(poseStack, buffer, part.getChild(childName), childName,
                    packedLight, packedOverlay, color);
        }
        poseStack.popPose();
    }

    /** root 的直接子骨骼（bbmodel 顶层骨骼，顺序照原稿）。漏一项该骨骼整支都不会被画。 */
    private static final String[] ROOT_CHILDREN = {"head", "body", "left_arm", "right_arm", "left_leg", "right_leg", "book_root"};

    private static String[] childNames(String name) {
        return switch (name) {
            case "root" -> ROOT_CHILDREN;
            case "body" -> new String[] {"cloak", "robe"};
            case "book_root" -> new String[] {"half_left", "half_right"};
            case "cloak" -> new String[] {};
            case "half_left" -> new String[] {"page_left"};
            case "half_right" -> new String[] {"page_right"};
            case "hat" -> new String[] {};
            case "head" -> new String[] {"hat"};
            case "left_arm" -> new String[] {"left_sleeve"};
            case "left_boot_a" -> new String[] {};
            case "left_boot_b" -> new String[] {};
            case "left_cuff" -> new String[] {};
            case "left_leg" -> new String[] {"left_boot_b", "left_boot_a"};
            case "left_sleeve" -> new String[] {"left_cuff"};
            case "page_left" -> new String[] {};
            case "page_right" -> new String[] {};
            case "right_arm" -> new String[] {"right_sleeve"};
            case "right_boot_a" -> new String[] {};
            case "right_boot_b" -> new String[] {};
            case "right_cuff" -> new String[] {};
            case "right_leg" -> new String[] {"right_boot_a", "right_boot_b"};
            case "right_sleeve" -> new String[] {"right_cuff"};
            case "robe" -> new String[] {};
            default -> NO_CHILDREN;
        };
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition part_head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition part_hat = part_head.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition part_body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition part_cloak = part_body.addOrReplaceChild("cloak", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 9.5F, 3.5F, 0.0873F, 0.0F, 0.0F));
        PartDefinition part_robe = part_body.addOrReplaceChild("robe", CubeListBuilder.create(), PartPose.offset(0.0F, 27.0F, 0.0F));
        PartDefinition part_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(-5.25F, 2.5F, 1.5F, -1.5708F, 0.0F, 0.0F));
        PartDefinition part_left_sleeve = part_left_arm.addOrReplaceChild("left_sleeve", CubeListBuilder.create(), PartPose.offset(0.25F, 5.0F, 0.0F));
        PartDefinition part_left_cuff = part_left_sleeve.addOrReplaceChild("left_cuff", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.5F, -0.2618F, -3.1416F, 0.0F));
        PartDefinition part_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(5.25F, 2.5F, 1.5F, -1.5708F, 0.0F, 0.0F));
        PartDefinition part_right_sleeve = part_right_arm.addOrReplaceChild("right_sleeve", CubeListBuilder.create(), PartPose.offset(-0.25F, 5.0F, 0.0F));
        PartDefinition part_right_cuff = part_right_sleeve.addOrReplaceChild("right_cuff", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.5F, -0.2618F, -3.1416F, 0.0F));
        PartDefinition part_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 12.0F, 0.0F));
        PartDefinition part_left_boot_b = part_left_leg.addOrReplaceChild("left_boot_b", CubeListBuilder.create(), PartPose.offsetAndRotation(0.5F, -0.6F, 1.5F, -0.0873F, -3.098F, 0.0F));
        PartDefinition part_left_boot_a = part_left_leg.addOrReplaceChild("left_boot_a", CubeListBuilder.create(), PartPose.offsetAndRotation(0.5F, -0.5F, 0.5F, -0.0873F, 0.0436F, 0.0F));
        PartDefinition part_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 12.0F, 0.0F));
        PartDefinition part_right_boot_a = part_right_leg.addOrReplaceChild("right_boot_a", CubeListBuilder.create(), PartPose.offsetAndRotation(0.5F, -0.5F, 0.5F, -0.0873F, 0.0436F, 0.0F));
        PartDefinition part_right_boot_b = part_right_leg.addOrReplaceChild("right_boot_b", CubeListBuilder.create(), PartPose.offsetAndRotation(0.5F, -0.6F, 1.5F, -0.0873F, -3.098F, 0.0F));
        PartDefinition part_book_root = root.addOrReplaceChild("book_root", CubeListBuilder.create(), PartPose.offset(0.0F, 1.0F, -13.0F));
        PartDefinition part_half_left = part_book_root.addOrReplaceChild("half_left", CubeListBuilder.create(), PartPose.offset(-1.0F, 0.0F, 0.0F));
        PartDefinition part_page_left = part_half_left.addOrReplaceChild("page_left", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition part_half_right = part_book_root.addOrReplaceChild("half_right", CubeListBuilder.create(), PartPose.offset(1.0F, 0.0F, 0.0F));
        PartDefinition part_page_right = part_half_right.addOrReplaceChild("page_right", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, TEX_WIDTH, TEX_HEIGHT);
    }
}
