package cn.blockforge.generated.netherarmy.mixin;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Either;
import cn.blockforge.generated.netherarmy.GeneratedMod;
import net.minecraft.commands.arguments.ResourceOrTagKeyArgument;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.commands.LocateCommand;
import net.minecraft.world.level.levelgen.structure.BuiltinStructures;
import net.minecraft.world.level.levelgen.structure.Structure;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * {@code /locate structure minecraft:fortress} 等效于
 * {@code /locate structure netherarmy:fortress}。
 *
 * <p>本模组把 {@code minecraft:nether_complexes} 结构集里的原版要塞换成了
 * {@code netherarmy:fortress}（见 {@code data/netherarmy/worldgen/structure/fortress.json}
 * 与 {@code NetherArmyFortressStructure}），原版 {@code minecraft:fortress} 从此不再
 * 生成。为了让旧写法照常可用，这里在 {@code LocateCommand#locateStructure} 入口把
 * “具体结构 = minecraft:fortress”的解析结果整个替换成 {@code netherarmy:fortress}：
 * 聊天栏、命令方块、函数里发起的定位查询全部走同一条真实命令路径，替换后连标签
 * 解析、报错文案、跨维度择优都沿用原版逻辑，无需重写命令。</p>
 *
 * <p>按标签定位（如 {@code #minecraft:fortress} 之类的结构标签）不受影响——只有
 * {@code unwrap().left()} 命中原版要塞 ResourceKey 时才替换。方向相反的兼容
 * （用 {@code netherarmy:fortress} 也能定位到旧区域文件里存的 {@code minecraft:fortress}
 * 起点）由 {@link NetherFortressLocateAliasMixin} 负责，两者互补。</p>
 */
@Mixin(LocateCommand.class)
public abstract class LocateCommandFortressAliasMixin {
    private static final ResourceLocation NETHERARMY_FORTRESS_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "fortress");

    @ModifyVariable(
            method = "locateStructure",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0)
    private static ResourceOrTagKeyArgument.Result<Structure> netherarmy$aliasVanillaFortress(
            ResourceOrTagKeyArgument.Result<Structure> requested) {
        Either<ResourceKey<Structure>, ?> either = requested.unwrap();
        if (either.left().map(key -> key.equals(BuiltinStructures.FORTRESS)).orElse(false)) {
            try {
                return new ResourceOrTagKeyArgument<>(Registries.STRUCTURE)
                        .parse(new StringReader(NETHERARMY_FORTRESS_ID.toString()));
            } catch (CommandSyntaxException e) {
                // 自己拼出来的合法 ID 不可能解析失败；真失败就保持原样，绝不吃掉命令。
                return requested;
            }
        }
        return requested;
    }
}
