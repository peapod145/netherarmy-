package cn.blockforge.generated.netherarmy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 黑客电脑的"删除 AI"：抑制期内直接走原版 NoAI 语义。
 *
 * <p>旧实现只拦 {@code getTarget} 和外部 setTarget，目标系统、Brain 传感器、
 * 漫游/移动类 Goal 全都照常运行，被"删 AI"的生物依旧会走位、放技能、由
 * Brain AI（猪灵系、监守者）发起攻击——所以体验上是"没生效"。
 * {@code Mob#setNoAi(true)} 之后 {@code isEffectiveAi()} 为 false，
 * goalSelector/targetSelector 不再 tick、sensing 不再刷新、
 * customServerAiStep（含 Brain 的 tick）整体跳过，索敌、攻击、移动一次性全停，
 * 与"删去一切 AI"的语义完全一致；到期再置回 false 恢复。
 *
 * <p>到期时间写在实体的 PersistentData（随实体落盘），由实体 tick 事件恢复——
 * 区块卸载再重载也不会把目标永久留在 NoAI 状态，也无需服务端全局查表。
 */
public final class HackerCountermeasureHandler {
    private static final String TAG_AI_OFF_UNTIL = "netherarmy:ai_off_until";

    private HackerCountermeasureHandler() {
    }

    /** 删去该生物的一切 AI，持续 ticks tick（黑客技能传入 200 = 10 秒）。 */
    public static void suppress(Mob mob, int ticks) {
        // 本身就是 NoAI（命令/编辑器生成的）已无 AI 可删；不写恢复标记，
        // 避免到期后把用户自己设置的 NoAI 给"复活"。
        if (mob.isRemoved() || mob.isNoAi()) {
            return;
        }
        mob.setNoAi(true);
        mob.setTarget(null);
        // Brain 系（猪灵/监守者等）的仇恨与愤怒走记忆而非 getTarget，一并抹掉。
        // 原版 eraseMemory 会先读取 getMemory；未注册模块会导致 IllegalStateException。
        eraseRegisteredMemory(mob, MemoryModuleType.ATTACK_TARGET);
        eraseRegisteredMemory(mob, MemoryModuleType.ANGRY_AT);
        mob.getNavigation().stop();
        mob.stopInPlace();
        mob.getPersistentData().putLong(TAG_AI_OFF_UNTIL, mob.level().getGameTime() + ticks);
    }

    /**
     * 只擦除该 Brain 已注册的记忆模块。
     *
     * <p>原版 {@code eraseMemory} 会先调用 {@code getMemory}，遇到未注册模块会抛
     * {@code IllegalStateException}。黑客会处理任意 Mob（包括 Mob Battle 生成的普通生物），
     * 因此必须统一走这层保护。</p>
     */
    public static void eraseRegisteredMemory(Mob mob, MemoryModuleType<?> type) {
        if (mob.getBrain().getMemories().containsKey(type)) {
            mob.getBrain().eraseMemory(type);
        }
    }

    /** 是否处于抑制期内（含到期时间尚未走到的重载实体）。 */
    public static boolean isSuppressed(Mob mob) {
        return mob.getPersistentData().contains(TAG_AI_OFF_UNTIL, Tag.TAG_LONG);
    }

    /** 抑制期内连外部强制仇恨工具的 setTarget 也无法给它重新建立仇恨。 */
    @SubscribeEvent
    public static void onTargetChange(LivingChangeTargetEvent event) {
        if (event.getNewAboutToBeSetTarget() != null
                && event.getEntity() instanceof Mob mob && isSuppressed(mob)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof Mob mob) || mob.level().isClientSide()) {
            return;
        }
        CompoundTag persistent = mob.getPersistentData();
        if (!persistent.contains(TAG_AI_OFF_UNTIL, Tag.TAG_LONG)) {
            return;
        }
        if (mob.level().getGameTime() >= persistent.getLong(TAG_AI_OFF_UNTIL)) {
            persistent.remove(TAG_AI_OFF_UNTIL);
            mob.setNoAi(false);
        }
    }
}
