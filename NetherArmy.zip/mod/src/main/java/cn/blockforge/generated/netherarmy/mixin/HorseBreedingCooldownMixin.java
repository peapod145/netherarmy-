package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.GeneratedMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 炼狱晶锁链马铠·繁殖周期 -25%。
 *
 * <p>1.21.1 的繁殖冷却没有对应属性：{@code Animal#finalizeSpawnChildFromBreeding}
 * 在产仔后把双亲 {@code setAge(6000)}（{@code PARENT_AGE_AFTER_BREEDING}），
 * 之后每刻减 1，而 {@code Animal#mobInteract} 只允许 {@code age == 0} 的马再次进食
 * 金胡萝卜发情，所以冷却长短完全由这里写入的 6000 决定。</p>
 *
 * <p>这里在方法尾部做后处理：哪位双亲身上穿着炼狱晶锁链马铠，就只把
 * <em>那位</em>的冷却缩短四分之一（6000 → 4500 刻，即 5 分钟 → 3 分 45 秒）。
 * 马铠的判定走 {@code Mob#getBodyArmorItem()}——马匹穿戴（直接右键或马匹
 * 物品栏）最终都会经 {@code setBodyArmorItem} 落到 BODY 装备槽，与普通玩家
 * 穿戴盔甲是同一条链路。</p>
 */
@Mixin(Animal.class)
public abstract class HorseBreedingCooldownMixin {

    @Inject(method = "finalizeSpawnChildFromBreeding", at = @At("TAIL"))
    private void netherarmy$shortenCrystalHorseCooldown(ServerLevel level, Animal other,
                                                        AgeableMob child, CallbackInfo callback) {
        netherarmy$applyToParent((Animal) (Object) this);
        netherarmy$applyToParent(other);
    }

    private static void netherarmy$applyToParent(Animal parent) {
        if (parent instanceof AbstractHorse horse
                && horse.getBodyArmorItem().is(GeneratedMod.NETHER_CRYSTAL_HORSE_ARMOR.get())) {
            int age = parent.getAge();
            if (age > 0) {
                // 只缩短"刚写入的冷却"：6000 × (1 - 25%) = 4500 刻。
                parent.setAge(Math.round(age * 0.75F));
            }
        }
    }
}
