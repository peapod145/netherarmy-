package cn.blockforge.generated.netherarmy;

import java.util.List;
import java.util.function.Predicate;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.EventHooks;

/** 五阶段霸主凋灵。阶段由实际损失血量推导，避免重载后阶段状态漂移。 */
public final class OverlordWitherBoss extends WitherBoss implements RangedAttackMob {
    public static final int MAX_HEALTH = 1000;
    private static final int PHASE_COUNT = 5;
    private static final int PHASE_STEP = 200;
    private static final int INVULNERABLE_DURATION = 220;
    private static final int SUMMON_INTERVAL = 200;
    private static final Predicate<LivingEntity> TARGET_SELECTOR = target ->
            target.attackable() && !MesmerizerControl.isWitherSkeletonFaction(target);
    private static final TargetingConditions SIDE_HEAD_TARGETING = TargetingConditions.forCombat()
            .range(100.0D).selector(TARGET_SELECTOR);

    /**
     * 接触破坏的扫描间隔（tick）。原版凋灵是"受伤之后 20 tick 清一次身边"，霸主每 2 tick
     * 就碾一遍，等于把原版那套一次性爆发变成常驻，这就是"比凋灵更凶猛"的第一层含义。
     */
    private static final int CRUSH_INTERVAL = 2;
    /**
     * 接触判定的数值余量，仅用于把碰撞盒与方块面恰好贴合视为接触；不会把扫描范围向外扩展成走廊。
     */
    private static final double CONTACT_EPSILON = 1.0E-7D;

    /** 推进目标的悬停半径（格）：离对手近到这个距离就改为绕着盘旋，不再继续压脸。 */
    private static final double ADVANCE_STANDOFF = 4.0D;
    /** 航向探测距离（格）：沿某个方向看这么远，有没有碾不碎的实心方块。 */
    private static final double ADVANCE_PROBE_REACH = 3.0D;
    /** 绕行航点的前方距离（格）。 */
    private static final double ADVANCE_WAYPOINT_DISTANCE = 4.0D;
    /** 绕行时的偏转角（度）。 */
    private static final double ADVANCE_DETOUR_ANGLE = 55.0D;
    /** 绕行方向维持的 tick 数：定好一边之后先走稳，免得在墙角左右横跳。 */
    private static final int ADVANCE_DETOUR_HOLD = 30;
    /** 四面都是不可破坏方块时的抬升量（格）：从障碍上方翻过去。 */
    private static final double ADVANCE_CLIMB = 2.5D;
    /** 推进速度倍率（作用在 FLYING_SPEED 上）。 */
    private static final double ADVANCE_SPEED = 1.0D;

    private final ServerBossEvent overlordBossEvent;
    private final int[] nextHeadUpdate = new int[2];
    private final int[] idleHeadUpdates = new int[2];
    /** 接触破坏的节流计数（替代原版的 {@code destroyBlocksTick}）。 */
    private int crushTick;
    private int summonTicks;
    private int lastPhase = 1;
    /** 本 tick 认定的前进方向，供移动与绕行逻辑使用。 */
    private Vec3 heading = new Vec3(0.0D, 0.0D, 1.0D);
    /** 绕行维持的偏转方向：1 / -1 为左右两侧，0 表示四面都不通（改为抬升）。 */
    private int detourSide;
    /** 绕行方向剩余维持的 tick 数。 */
    private int detourTicks;

    public OverlordWitherBoss(EntityType<? extends OverlordWitherBoss> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 10, false);
        this.xpReward = 1000;
        this.overlordBossEvent = new ServerBossEvent(
                this.getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
        this.overlordBossEvent.setDarkenScreen(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.6D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 100.0D)
                .add(Attributes.ARMOR, 0.0D);
    }

    public int getPhase() {
        if (this.getInvulnerableTicks() > 0) {
            return 1;
        }
        int phase = 1 + (int) ((this.getMaxHealth() - this.getHealth()) / PHASE_STEP);
        return Mth.clamp(phase, 1, PHASE_COUNT);
    }

    public float getBossProgress() {
        return Mth.clamp(this.getHealth() / this.getMaxHealth(), 0.0F, 1.0F);
    }

    @Override
    public boolean isPowered() {
        return this.getInvulnerableTicks() <= 0 && this.getPhase() >= 3;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new DoNothingGoal());
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0D, 40, 100.0F));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(
                this, LivingEntity.class, 0, false, false, TARGET_SELECTOR));
    }

    @Override
    public void performRangedAttack(LivingEntity target, float distanceFactor) {
        this.fireSkullAt(0, target.getX(), target.getY() + target.getEyeHeight() * 0.5D, target.getZ());
    }

    @Override
    protected void customServerAiStep() {
        if (this.getInvulnerableTicks() > 0) {
            int remaining = this.getInvulnerableTicks() - 1;
            this.overlordBossEvent.setProgress(1.0F - remaining / (float) INVULNERABLE_DURATION);
            if (remaining <= 0) {
                this.setHealth(this.getMaxHealth());
                this.level().explode(this, this.getX(), this.getEyeY(), this.getZ(), 7.0F, false,
                        Level.ExplosionInteraction.MOB);
                if (!this.isSilent()) {
                    this.level().globalLevelEvent(1023, this.blockPosition(), 0);
                }
            }
            this.setInvulnerableTicks(remaining);
            if (this.tickCount % 10 == 0) {
                this.heal(10.0F);
            }
            return;
        }

        // 注意：不调用 super.customServerAiStep()——WitherBoss 的实现就是我们要整体替换的
        // 原版逻辑（其内部对 Mob 层的 super 调用本身是空钩子，见 Mob#customServerAiStep），
        // 调用它会让侧头按原版 20 格口径再开一轮火。
        this.updateSideHeads();
        // 先定航向，再检查实体碰撞盒真正接触到的方块，最后把航点交给飞行控制。
        this.updateAdvancement();
        this.updateBlockBreaking();
        this.updatePhase();

        if (this.tickCount % 20 == 0) {
            this.heal(this.getPhase() >= 4 ? 4.0F : this.getPhase() >= 2 ? 2.0F : 1.0F);
            if (this.getPhase() >= 2) {
                this.applyContactWither();
            }
        }

        if (++this.summonTicks >= SUMMON_INTERVAL) {
            this.summonTicks = 0;
            this.summonMinions();
        }

        if (this.level() instanceof ServerLevel serverLevel) {
            WitherEnhancementHandler.tickRise(this);
            if (this.getPhase() >= 3) {
                WitherEnhancementHandler.tickDash(serverLevel, this);
            }
        }
        this.overlordBossEvent.setProgress(this.getBossProgress());
    }

    private void updateSideHeads() {
        for (int i = 1; i < 3; i++) {
            int index = i - 1;
            if (this.tickCount < this.nextHeadUpdate[index]) {
                continue;
            }
            this.nextHeadUpdate[index] = this.tickCount + 10 + this.random.nextInt(10);
            if ((this.level().getDifficulty() == Difficulty.NORMAL
                    || this.level().getDifficulty() == Difficulty.HARD)
                    && this.idleHeadUpdates[index]++ > 15) {
                // i 本身就是侧头索引（1、2）；使用 i + 1 会让两次发射都落到同一侧头的中心。
                this.fireSkullAt(i,
                        Mth.nextDouble(this.random, this.getX() - 10.0D, this.getX() + 10.0D),
                        Mth.nextDouble(this.random, this.getY() - 5.0D, this.getY() + 5.0D),
                        Mth.nextDouble(this.random, this.getZ() - 10.0D, this.getZ() + 10.0D));
                this.idleHeadUpdates[index] = 0;
            }
            int alternative = this.getAlternativeTarget(i);
            if (alternative > 0 && this.level().getEntity(alternative) instanceof LivingEntity target
                    && this.canAttack(target) && this.distanceToSqr(target) <= 10000.0D
                    && this.hasLineOfSight(target)) {
                // 与侧头模型索引保持一致：i=1、2 分别对应两颗侧头的几何中心。
                this.fireSkullAt(i, target.getX(), target.getY() + target.getEyeHeight() * 0.5D, target.getZ());
                this.nextHeadUpdate[index] = this.tickCount + 40 + this.random.nextInt(20);
                this.idleHeadUpdates[index] = 0;
            } else if (alternative > 0) {
                this.setAlternativeTarget(i, 0);
            } else {
                List<LivingEntity> nearby = this.level().getNearbyEntities(
                        LivingEntity.class, SIDE_HEAD_TARGETING, this,
                        this.getBoundingBox().inflate(100.0D, 100.0D, 100.0D));
                if (!nearby.isEmpty()) {
                    this.setAlternativeTarget(i, nearby.get(this.random.nextInt(nearby.size())).getId());
                }
            }
        }
        LivingEntity target = this.getTarget();
        this.setAlternativeTarget(0, target == null ? 0 : target.getId());
    }

    /**
     * 接触破坏：只处理当前实体碰撞盒真正接触到的方块，不预先清理前方走廊，也不使用扩大后的
     * AABB 作为破坏依据。这样即使目标方块在前方数格、与实体之间存在空气，也不会被误删。
     */
    private void updateBlockBreaking() {
        if (!(this.level() instanceof ServerLevel level) || !EventHooks.canEntityGrief(level, this)) {
            return;
        }
        if (--this.crushTick > 0) {
            return;
        }
        this.crushTick = CRUSH_INTERVAL;
        if (this.crushTouchingBlocks(level)) {
            level.levelEvent(null, 1022, this.blockPosition(), 0);
        }
    }

    /** 仅按方块碰撞形状判断接触，避免非完整方块被粗略方形扫描误判。 */
    private boolean crushTouchingBlocks(ServerLevel level) {
        AABB body = this.getBoundingBox();
        int minX = Mth.floor(body.minX - CONTACT_EPSILON);
        int minY = Mth.floor(body.minY - CONTACT_EPSILON);
        int minZ = Mth.floor(body.minZ - CONTACT_EPSILON);
        int maxX = Mth.floor(body.maxX + CONTACT_EPSILON);
        int maxY = Mth.floor(body.maxY + CONTACT_EPSILON);
        int maxZ = Mth.floor(body.maxZ + CONTACT_EPSILON);
        boolean destroyed = false;
        for (BlockPos pos : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) {
            BlockState state = level.getBlockState(pos);
            if (this.canCrush(level, pos, state) && this.touchesBody(level, pos, state, body)
                    && EventHooks.onEntityDestroyBlock(this, pos, state)) {
                destroyed = level.destroyBlock(pos, true, this) || destroyed;
            }
        }
        return destroyed;
    }

    private boolean touchesBody(ServerLevel level, BlockPos pos, BlockState state, AABB body) {
        for (AABB local : state.getCollisionShape(level, pos).toAabbs()) {
            AABB worldShape = local.move(pos.getX(), pos.getY(), pos.getZ());
            if (worldShape.intersects(body.minX - CONTACT_EPSILON, body.minY - CONTACT_EPSILON,
                    body.minZ - CONTACT_EPSILON, body.maxX + CONTACT_EPSILON,
                    body.maxY + CONTACT_EPSILON, body.maxZ + CONTACT_EPSILON)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 霸主凋灵"能碾碎什么"：比凋灵原版宽得多，但并非无限。
     *
     * <ul>
     *   <li>黑曜石（硬度 50、抗爆 1200）照碎——它不在凋灵免疫标签里，原版凋灵只在受击后的
     *       那一波里才轮到它，霸主则是常驻口径，这就是"能破坏黑曜石"；哭泣的黑曜石、
     *       锁链、铁块、深板岩同理。</li>
     *   <li>{@code minecraft:wither_immune}（基岩、屏障、命令方块三件套、结构方块、
     *       末地传送门、强化深板岩……）一律保留。</li>
     *   <li>硬度为负（模组里自定义的"不可破坏"方块）也保留，交给绕行逻辑处理。</li>
     *   <li>流体不碰：把水道/熔岩湖捅穿只会造成额外的连锁灾难，不是这次要的效果。</li>
     *   <li>最后仍要过一遍 {@code canEntityDestroy}，尊重别的模组对凋灵的显式保护。</li>
     * </ul>
     */
    private boolean canCrush(BlockGetter level, BlockPos pos, BlockState state) {
        return !state.isAir()
                && !state.is(BlockTags.WITHER_IMMUNE)
                && state.getDestroySpeed(level, pos) >= 0.0F
                && state.getFluidState().isEmpty()
                && state.canEntityDestroy(level, pos, this);
    }

    /**
     * 沿某个水平方向看 {@link #ADVANCE_PROBE_REACH} 格，有没有"碾不碎的实心方块"。
     *
     * <p>会被接触破坏清掉的方块（含黑曜石）不算障碍——它下一拍就碎了，直接飞过去即可；
     * 只有基岩、命令方块这类才需要绕行。{@code mobGriefing} 关掉时什么都清不掉，
     * 于是所有实心方块都按障碍处理。</p>
     *
     * <p>探测按身体宽度的左右两翼各取一列，避免"缝比身体窄却判定为通畅"。</p>
     */
    private boolean isBlockedAhead(Vec3 direction) {
        if (!(this.level() instanceof ServerLevel level)) {
            return false;
        }
        boolean crushes = EventHooks.canEntityGrief(level, this);
        Vec3 origin = this.position();
        Vec3 wing = new Vec3(-direction.z, 0.0D, direction.x).scale(this.getBbWidth() * 0.5D);
        double[] heights = {0.6D, this.getBbHeight() * 0.5D, this.getBbHeight() - 0.6D};
        for (double distance = 0.8D; distance <= ADVANCE_PROBE_REACH + 1.0E-6D; distance += 0.8D) {
            double probeX = origin.x + direction.x * distance;
            double probeZ = origin.z + direction.z * distance;
            for (double height : heights) {
                double probeY = origin.y + height;
                if (this.isImmovableSolid(level, BlockPos.containing(probeX, probeY, probeZ), crushes)
                        || this.isImmovableSolid(level, BlockPos.containing(
                                probeX + wing.x, probeY, probeZ + wing.z), crushes)
                        || this.isImmovableSolid(level, BlockPos.containing(
                                probeX - wing.x, probeY, probeZ - wing.z), crushes)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isImmovableSolid(ServerLevel level, BlockPos pos, boolean crushes) {
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || !state.getFluidState().isEmpty()) {
            return false;
        }
        if (crushes && this.canCrush(level, pos, state)) {
            return false;
        }
        return !state.getCollisionShape(level, pos).isEmpty();
    }

    /**
     * 左右两翼逐档试探，选出第一个通畅的偏转方向：1 表示一侧、-1 表示另一侧，
     * 0 表示连 150° 以内都堵死（此时改为抬升翻越）。
     */
    private int pickDetourSide(Vec3 desired) {
        for (double angle = ADVANCE_DETOUR_ANGLE; angle <= 150.0D; angle += 45.0D) {
            if (!this.isBlockedAhead(rotateYaw(desired, angle))) {
                return 1;
            }
            if (!this.isBlockedAhead(rotateYaw(desired, -angle))) {
                return -1;
            }
        }
        return 0;
    }

    private static Vec3 rotateYaw(Vec3 direction, double degrees) {
        double angle = degrees * Mth.DEG_TO_RAD;
        double cos = Mth.cos((float) angle);
        double sin = Mth.sin((float) angle);
        return new Vec3(direction.x * cos - direction.z * sin,
                0.0D, direction.x * sin + direction.z * cos).normalize();
    }

    /**
     * 决定本 tick 往哪儿飞，并把航点交给 {@code FlyingMoveControl}：直线朝对手，
     * 路上的可破坏方块由 {@link #updateBlockBreaking()} 当场清掉，所以它"无视面前的方块"；
     * 只有撞上基岩、命令方块这类碾不碎的实心方块才偏转绕行，且选定的一侧维持
     * {@link #ADVANCE_DETOUR_HOLD} tick，免得在墙角左右横跳。
     *
     * <p>这里不用 {@code Goal} 而是直接在 {@link #customServerAiStep()} 里驱动：{@code RangedAttackGoal}
     * 已经占着 MOVE\|LOOK（原版 {@code WitherBoss} 同款优先级 2），再加一个抢 MOVE 的目标只会互相
     * 顶掉。{@code Mob#serverAiStep} 的顺序是 goals → customServerAiStep → moveControl.tick()，
     * 在本方法里写航点正好压过随机飞行，又赶在飞行控制结算之前。</p>
     *
     * <p>算出来的 {@link #heading} 同时喂给接触破坏——走廊要清的方向必须和这一拍真正要飞的方向
     * 一致，否则它会一边往侧面绕一边只清正前方。</p>
     */
    private void updateAdvancement() {
        if (WitherEnhancementHandler.isDashing(this)) {
            // 冲刺全程的位移由 WitherEnhancementHandler#tickDash 逐 tick 结算（自己 move 再把速度
            // 清零），这里把 MoveControl 的航点钉在当前位置，避免随机飞行目标在本 tick 末尾
            // 又给冲刺速度叠加一段偏移；走廊仍按冲刺方向清。
            this.heading = WitherEnhancementHandler.dashDirection(this);
            this.getMoveControl().setWantedPosition(this.getX(), this.getY(), this.getZ(), 0.0D);
            return;
        }
        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            this.detourSide = 0;
            this.detourTicks = 0;
            this.heading = this.getForward();
            return;
        }
        Vec3 desired = new Vec3(target.getX() - this.getX(), 0.0D, target.getZ() - this.getZ());
        double distance = Math.hypot(desired.x, desired.z);
        if (desired.lengthSqr() < 1.0E-6D) {
            desired = this.getForward();
        }
        desired = new Vec3(desired.x, 0.0D, desired.z).normalize();
        if (distance < ADVANCE_STANDOFF) {
            // 贴身之后沿切线盘旋：既不让航点等于自己（飞行控制会失去方向），
            // 也不会把身体压在玩家模型里。
            desired = new Vec3(-desired.z, 0.0D, desired.x);
        }
        if (this.detourTicks > 0) {
            --this.detourTicks;
        } else {
            this.detourSide = 0;
        }
        double climb = 0.0D;
        if (this.isBlockedAhead(desired)) {
            if (this.detourSide == 0) {
                this.detourSide = this.pickDetourSide(desired);
                this.detourTicks = ADVANCE_DETOUR_HOLD;
            }
            if (this.detourSide == 0) {
                // 左右 150° 以内全被不可破坏方块堵住：直接抬升，从障碍上方翻过去。
                climb = ADVANCE_CLIMB;
            } else {
                desired = rotateYaw(desired, this.detourSide * ADVANCE_DETOUR_ANGLE);
            }
        }
        this.heading = desired;
        Vec3 waypoint = this.position().add(desired.scale(ADVANCE_WAYPOINT_DISTANCE));
        double rise = Mth.clamp(target.getY() + 1.0D - this.getY(), -2.0D, 2.0D) + climb;
        this.getMoveControl().setWantedPosition(
                waypoint.x, this.getY() + rise, waypoint.z, ADVANCE_SPEED);
    }

    private void updatePhase() {
        int phase = this.getPhase();
        if (phase == this.lastPhase) {
            return;
        }
        this.lastPhase = phase;
        if (this.getAttribute(Attributes.ARMOR) != null) {
            this.getAttribute(Attributes.ARMOR).setBaseValue((phase - 1) * 20.0D);
        }
        if (phase >= 3) {
            WitherEnhancementHandler.initDashCycle(this);
        }
    }

    private void applyContactWither() {
        AABB box = this.getBoundingBox().inflate(0.25D);
        for (LivingEntity victim : this.level().getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity != this && entity.isAlive()
                        && !MesmerizerControl.isWitherSkeletonFaction(entity))) {
            victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 200, 5), this);
        }
    }

    private void fireSkullAt(int head, double x, double y, double z) {
        if (!this.isSilent()) {
            this.level().levelEvent(null, 1024, this.blockPosition(), 0);
        }
        double sx = this.getHeadX(head);
        double sy = this.getHeadY(head);
        double sz = this.getHeadZ(head);
        Vec3 direction = new Vec3(x - sx, y - sy, z - sz);
        if (direction.lengthSqr() < 1.0E-8D) {
            direction = new Vec3(0.0D, 0.0D, 1.0D);
        }
        OverlordWitherSkull skull = new OverlordWitherSkull(this.level(), this, direction.normalize(),
                this.shouldFirePurgatory(head));
        skull.setPosRaw(sx, sy, sz);
        this.level().addFreshEntity(skull);
    }

    private boolean shouldFirePurgatory(int head) {
        int phase = this.getPhase();
        if (phase < 4 && head != 0) {
            return false;
        }
        float chance = switch (phase) {
            case 1 -> 0.10F;
            case 2 -> 0.175F;
            case 3 -> 0.50F;
            case 4 -> 0.75F;
            default -> 1.0F;
        };
        return this.random.nextFloat() < chance;
    }

    private double getHeadX(int head) {
        if (head <= 0) {
            return this.getX();
        }
        float angle = (this.yBodyRot + 180.0F * (head - 1)) * Mth.DEG_TO_RAD;
        return this.getX() + Mth.cos(angle) * 1.3D * this.getScale();
    }

    private double getHeadY(int head) {
        return this.getY() + (head <= 0 ? 3.0D : 2.2D) * this.getScale();
    }

    private double getHeadZ(int head) {
        if (head <= 0) {
            return this.getZ();
        }
        float angle = (this.yBodyRot + 180.0F * (head - 1)) * Mth.DEG_TO_RAD;
        return this.getZ() + Mth.sin(angle) * 1.3D * this.getScale();
    }

    private void summonMinions() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        int phase = this.getPhase();
        EntityType<?>[] roster = switch (phase) {
            case 1 -> new EntityType<?>[]{GeneratedMod.WITHER_ZOMBIE.get(), EntityType.WITHER_SKELETON,
                    GeneratedMod.BERSERKER.get(), GeneratedMod.NETHER_HUNTER.get()};
            case 2 -> new EntityType<?>[]{GeneratedMod.WITHERPHANTOM.get(), GeneratedMod.BERSERKER.get(),
                    GeneratedMod.NETHER_HUNTER.get(), GeneratedMod.WITHER_GHOST.get(),
                    GeneratedMod.IMMORTAL_WARRIOR.get()};
            case 3 -> new EntityType<?>[]{GeneratedMod.DULLHAN_BODY.get(), GeneratedMod.WITHERPHANTOM.get(),
                    GeneratedMod.NETHER_COURIER.get(), GeneratedMod.HACKER.get()};
            case 4 -> new EntityType<?>[]{GeneratedMod.NETHER_COURIER.get(), GeneratedMod.DULLHAN_BODY.get(),
                    GeneratedMod.MESMERIZER.get(), GeneratedMod.BERSERKER.get(),
                    GeneratedMod.SHADOW_APOSTLE.get()};
            default -> new EntityType<?>[]{GeneratedMod.NETHER_COURIER.get(), GeneratedMod.DULLHAN_BODY.get(),
                    GeneratedMod.MESMERIZER.get(), GeneratedMod.BLITZ_DULLHAN_BODY.get()};
        };
        int count = 5 + this.random.nextInt(3);
        for (int i = 0; i < count; i++) {
            EntityType<?> type = roster[this.random.nextInt(roster.length)];
            if (!(type.create(serverLevel) instanceof Mob mob)) {
                continue;
            }
            mob.moveTo(this.getX() + (this.random.nextDouble() - 0.5D) * 12.0D,
                    this.getY() + this.random.nextDouble() * 3.0D,
                    this.getZ() + (this.random.nextDouble() - 0.5D) * 12.0D,
                    this.random.nextFloat() * 360.0F, 0.0F);
            mob.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(mob.blockPosition()),
                    MobSpawnType.TRIGGERED, null);
            mob.setPersistenceRequired();
            boolean blitz = mob instanceof BlitzDullhanBody;
            OverlordSummonGear.equip(mob, phase, blitz, this.random);
            WitherEnhancementHandler.markSummonedBy(mob, this);
            if (phase >= 3) {
                mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, phase - 3), this);
            }
            serverLevel.addFreshEntityWithPassengers(mob);
        }
    }

    private void summonCarrier(ServerLevel level) {
        Mob carrier = GeneratedMod.NETHER_CARRIER.get().create(level);
        if (carrier == null) {
            return;
        }
        carrier.moveTo(this.getX() + 2.0D, this.getY(), this.getZ() + 2.0D, this.getYRot(), 0.0F);
        carrier.finalizeSpawn(level, level.getCurrentDifficultyAt(carrier.blockPosition()), MobSpawnType.TRIGGERED, null);
        carrier.setPersistenceRequired();
        WitherEnhancementHandler.markSummonedBy(carrier, this);
        level.addFreshEntityWithPassengers(carrier);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        Entity direct = source.getDirectEntity();
        if (this.getPhase() >= 3 && direct instanceof Projectile
                && !(source.getEntity() instanceof WitherBoss)
                && !(source.getEntity() != null && MesmerizerControl.isWitherSkeletonFaction(source.getEntity()))) {
            return false;
        }
        boolean hurt = super.hurt(source, amount);
        if (hurt) {
            // 受击时立刻抢一拍接触破坏（原版凋灵这时才第一次清身边，霸主只是把节奏提前）。
            this.crushTick = 0;
            this.idleHeadUpdates[0] += 3;
            this.idleHeadUpdates[1] += 3;
            if (this.getPhase() >= 2 && this.level() instanceof ServerLevel serverLevel) {
                WitherEnhancementHandler.triggerRise(this);
                if (source.is(net.minecraft.world.damagesource.DamageTypes.IN_WALL)
                        && this.getPhase() >= 3) {
                    // 与凋灵二阶段同款：卡进方块窒息时立即朝随机方向冲刺脱困。
                    WitherEnhancementHandler.triggerSuffocationDash(this);
                }
                if (this.getPhase() >= 5 && this.random.nextFloat() < 0.10F) {
                    this.summonCarrier(serverLevel);
                }
            }
            // 血量低于 50% 后，每次真正打进来的攻击另有 10% 概率召唤一只床战士；
            // 三阶段起被弹开的抛射物在 hurt 开头就返回 false，不会走到这里掷骰。
            if (this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth() * 0.5F
                    && this.random.nextFloat() < 0.10F
                    && this.level() instanceof ServerLevel level) {
                BedserkerHandler.summonNear(level, this);
            }
        }
        return hurt;
    }

    /** 免疫摔落伤害（霸主凋灵可被冲刺/抬升机制抛起，落地不应结算摔落）。 */
    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        this.resetFallDistance();
        return false;
    }

    @Override
    public void makeInvulnerable() {
        this.setInvulnerableTicks(INVULNERABLE_DURATION);
        this.overlordBossEvent.setProgress(0.0F);
        this.setHealth(this.getMaxHealth() / 3.0F);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.overlordBossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.overlordBossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        this.overlordBossEvent.setName(name);
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        // 死亡掉落物暂不设计，因此不沿用原版下界之星掉落。
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        serverLevel.explode(this, this.damageSources().magic(), new ExplosionDamageCalculator() {
            @Override
            public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
                return false;
            }

            @Override
            public float getEntityDamageAmount(Explosion explosion, Entity entity) {
                return 0.0F;
            }
        }, this.getX(), this.getY(), this.getZ(), 10.0F, false, Level.ExplosionInteraction.MOB);
        DamageSource deathBlast = serverLevel.damageSources().magic();
        for (LivingEntity victim : serverLevel.getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(10.0D), entity -> entity != this && entity.isAlive())) {
            victim.invulnerableTime = 0;
            victim.hurt(deathBlast, 50.0F);
            victim.invulnerableTime = 0;
        }
    }

    private final class DoNothingGoal extends Goal {
        @Override
        public boolean canUse() {
            return OverlordWitherBoss.this.getInvulnerableTicks() > 0;
        }
    }
}
