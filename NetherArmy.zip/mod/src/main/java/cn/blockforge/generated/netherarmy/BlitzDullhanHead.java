package cn.blockforge.generated.netherarmy;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 无头强袭骑士的头颅：基础行为整体照抄无头骑士头颅（悬浮飞行、独立追击、
 * 可戴头盔、死亡放凋灵之首），差异项按强袭规格覆写：
 * <ul>
 *   <li>血量 40、自带 4 点护甲、免疫击退；</li>
 *   <li>移速与无头骑士头颅一致（0.35 格/tick）；</li>
 *   <li>近战伤害为无头骑士头颅的 1.5 倍（3.0 → 4.5）；</li>
 *   <li>免疫所有负面效果；</li>
 *   <li>近战附带 30 秒凋零 II，已有凋零则重置时长并升一级（上限十级）；</li>
 *   <li>死亡时以自身为中心引爆半径 3 格爆炸：非凋灵骷髅阵营生物受 5 点伤害，
 *       阵营生物反而恢复 5 点血量；</li>
 *   <li>必定携带炼狱晶头盔，常规掉落与无头骑士头颅共用同一张战利品表（完全相同），
 *       装备不随普通死亡掉落，仅 0.001% 概率满耐久掉落。</li>
 * </ul>
 */
public class BlitzDullhanHead extends DullhanHead {
    /** 飞行速度：与无头骑士头颅一致（0.35 格/tick）。 */
    private static final double BLITZ_FLIGHT_SPEED = 0.35D;
    private static final double BLITZ_MAX_HEALTH = 40.0D;
    private static final double BLITZ_BASE_ARMOR = 4.0D;
    /** 近战伤害：无头骑士头颅（3.0）的 1.5 倍。 */
    private static final double BLITZ_ATTACK_DAMAGE = 4.5D;
    /** 死亡爆炸：半径 3 格，非阵营 5 点伤害 / 阵营回 5 点血。 */
    private static final float DEATH_EXPLOSION_RADIUS = 3.0F;
    private static final float DEATH_EXPLOSION_DAMAGE = 5.0F;
    private static final float DEATH_EXPLOSION_HEAL = 5.0F;
    /** 自带装备掉落概率：0.001%。 */
    private static final float EQUIPMENT_DROP_CHANCE = 0.00001F;

    private boolean deathExplosionDone;

    public BlitzDullhanHead(EntityType<? extends BlitzDullhanHead> type, Level level) {
        super(type, level);
        // 移速已与无头骑士一致，直接沿用父类构造装好的 0.35 限速控制器。
        this.repinBlitzStats();
    }

    /**
     * 父类 setSize 会把属性钉回无头骑士的数值（20 血 / 0.35 速 / 3.0 伤），
     * 强袭规格在这里统一钉回：40 血 / 0.35 速 / 4 甲 / 4.5 伤 / 完全免疫击退。
     */
    private void repinBlitzStats() {
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(BLITZ_MAX_HEALTH);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BLITZ_FLIGHT_SPEED);
        this.getAttribute(Attributes.FLYING_SPEED).setBaseValue(BLITZ_FLIGHT_SPEED);
        this.getAttribute(Attributes.ARMOR).setBaseValue(BLITZ_BASE_ARMOR);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(BLITZ_ATTACK_DAMAGE);
        this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
    }

    @Override
    public void setSize(int size, boolean resetHealth) {
        super.setSize(size, resetHealth);
        this.repinBlitzStats();
        if (resetHealth) {
            this.setHealth(this.getMaxHealth());
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return DullhanHead.createAttributes()
                .add(Attributes.MAX_HEALTH, BLITZ_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, BLITZ_FLIGHT_SPEED)
                .add(Attributes.FLYING_SPEED, BLITZ_FLIGHT_SPEED)
                .add(Attributes.ARMOR, BLITZ_BASE_ARMOR)
                .add(Attributes.ATTACK_DAMAGE, BLITZ_ATTACK_DAMAGE)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    /** 免疫一切负面效果（凋零、虚弱、缓速、中毒、 Instant 伤害等按分类拦截）。 */
    @Override
    public boolean canBeAffected(MobEffectInstance instance) {
        if (instance.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
            return false;
        }
        return super.canBeAffected(instance);
    }

    /**
     * 强袭凋零叠加规则（三个部件共用，见 {@link BlitzDullhanBody#applyBlitzWither}）：
     * 父类先挂的 5 秒凋零 I 会被这里统一改写——无凋零则上凋零 II 30 秒，
     * 已有凋零则时长重置 30 秒、等级 +1，上限十级。
     */
    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            BlitzDullhanBody.applyBlitzWither(living);
        }
        return hurt;
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.repinBlitzStats();
        return result;
    }

    /** 强袭头颅必定携带炼狱晶头盔，且不随普通死亡掉落（掉率判定见 dropEquipment）。 */
    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.NETHER_CRYSTAL_HELMET.get()));
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
    }

    /**
     * 常规掉落与无头骑士头颅完全相同：直接共用它的战利品表（煤炭 0-2、1% 凋灵骷髅头颅）。
     * 原版链路按实体注册名派生表 ID（{@code netherarmy:entities/blitz_dullhan_head}），
     * 强袭没有独立 JSON 时该表解析为空——不指回父体就只剩装备特判、常规掉落全空。
     */
    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return GeneratedMod.DULLHAN_HEAD.get().getDefaultLootTable();
    }

    /** 0.001% 概率掉落自身装备，掉出时为满耐久。 */
    @Override
    protected void dropEquipment() {
        if (this.isAlive()) {
            return;
        }
        super.dropEquipment(); // 各槽掉率已钉 0，父类不会掉出任何东西
        if (this.random.nextFloat() < EQUIPMENT_DROP_CHANCE) {
            ItemStack stack = this.getItemBySlot(EquipmentSlot.HEAD);
            if (!stack.isEmpty()) {
                ItemStack copy = stack.copy();
                copy.setDamageValue(0);
                this.spawnAtLocation(copy);
            }
        }
    }

    /** 头颅死亡：先走父类（凋灵骷髅音效、死亡放凋灵之首的事件结算），再引爆。 */
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide() && !this.deathExplosionDone) {
            this.deathExplosionDone = true;
            this.explodeOnDeath();
        }
    }

    private void explodeOnDeath() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        Vec3 center = this.getEyePosition();
        // 爆炸本体只负责视效与音效：半径 3 格、不点火、不毁方块，
        // 实体伤害由下面的精确结算接管（原版爆炸伤害按距离衰减，给不出恒定 5 点）。
        level.explode(this, level.damageSources().explosion(this, this),
                new ExplosionDamageCalculator() {
                    @Override
                    public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
                        return false;
                    }
                },
                center.x, center.y, center.z,
                DEATH_EXPLOSION_RADIUS, false, Level.ExplosionInteraction.NONE);
        DamageSource source = level.damageSources().explosion(this, this);
        AABB area = this.getBoundingBox().inflate(DEATH_EXPLOSION_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity != this && entity.isAlive())) {
            if (NetherArmyFlagWitherAoeHandler.isWitherFaction(victim)) {
                victim.heal(DEATH_EXPLOSION_HEAL);
            } else {
                victim.hurt(source, DEATH_EXPLOSION_DAMAGE);
            }
        }
    }
}
