package cn.blockforge.generated.netherarmy;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** 服务端请求客户端显示格尔多使用确认框。 */
public record GeardleConfirmationPayload(int hand) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GeardleConfirmationPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(
                    GeneratedMod.MOD_ID, "geardle_confirmation"));
    public static final StreamCodec<ByteBuf, GeardleConfirmationPayload> STREAM_CODEC =
            StreamCodec.composite(net.minecraft.network.codec.ByteBufCodecs.VAR_INT,
                    GeardleConfirmationPayload::hand,
                    GeardleConfirmationPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
