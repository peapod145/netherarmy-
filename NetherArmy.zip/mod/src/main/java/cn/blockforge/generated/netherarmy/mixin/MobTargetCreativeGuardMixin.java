package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.WitherFactionCreativePassivityHandler;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 统一拦截凋灵骷髅阵营对创造/旁观玩家的目标写入。 */
@Mixin(Mob.class)
public abstract class MobTargetCreativeGuardMixin {

    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
    private void netherarmy$blockCreativeTarget(LivingEntity target, CallbackInfo callback) {
        if (target != null
                && WitherFactionCreativePassivityHandler.shouldBlockTarget((Mob) (Object) this, target)) {
            callback.cancel();
        }
    }
}
