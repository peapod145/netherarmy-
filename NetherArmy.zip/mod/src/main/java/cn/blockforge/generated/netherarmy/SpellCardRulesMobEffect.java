package cn.blockforge.generated.netherarmy;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;

/**
 * 符卡规则（Spell Card Rules）。
 *
 * <p>行为限制（只能被抛射物伤害、只能以抛射物伤害他人）在
 * {@link SpellCardRulesHandler} 中通过 {@code LivingIncomingDamageEvent} 取消实现；
 * 本类只负责状态本身与粒子。{@code createParticleOptions} 的返回值由服务端在
 * 效果同步时求值一次、随实体数据下发并复用，所以"黑白相间"不能靠在这里换颜色
 * 实现——返回的是自有粒子类型，黑白交替由客户端粒子
 * {@link SpellCardRulesParticle} 在生命周期内自行翻转。</p>
 */
public final class SpellCardRulesMobEffect extends MobEffect {
    public SpellCardRulesMobEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFFFFFF);
    }

    @Override
    public ParticleOptions createParticleOptions(MobEffectInstance instance) {
        // SimpleParticleType 自身就是 ParticleOptions（无附加数据）。
        return GeneratedMod.SPELL_CARD_RULES_PARTICLE.get();
    }
}
