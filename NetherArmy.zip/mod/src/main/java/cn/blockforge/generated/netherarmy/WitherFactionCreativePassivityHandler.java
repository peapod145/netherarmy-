package cn.blockforge.generated.netherarmy;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * 凋灵骷髅阵营对创造/旁观玩家的统一仇恨闸门。
 *
 * <p>阵营生物的目标来源不止主动索敌，还包括受击反击、编组同步、外部强制
 * {@code setTarget} 以及部分自定义目标逻辑。因此这里配合 {@code Mob#setTarget}
 * mixin 作为统一入口；本类负责事件层兜底，并清掉玩家切换为创造/旁观模式后
 * 已经存在的旧目标。</p>
 */
public final class WitherFactionCreativePassivityHandler {

    private WitherFactionCreativePassivityHandler() {
    }

    /**
     * 凋灵骷髅阵营名册：模组维护的 {@code minecraft:wither_skeletons} 标签、
     * 独立的无头骑士头颅，以及凋灵本体。
     */
    public static boolean isWitherFactionMob(Entity entity) {
        return entity instanceof WitherBoss || LegionAuraHandler.isFactionMember(entity);
    }

    /** 创造与旁观玩家都不应成为该阵营的仇恨目标。 */
    public static boolean isIgnoredPlayer(Entity entity) {
        return entity instanceof Player player && (player.isCreative() || player.isSpectator());
    }

    /** 统一目标合法性判定，供事件与 mixin 共用。 */
    public static boolean shouldBlockTarget(Mob mob, LivingEntity target) {
        return target != null && isWitherFactionMob(mob) && isIgnoredPlayer(target);
    }

    /** 目标变更事件兜底：任何通过 NeoForge 目标事件进入的仇恨都拒绝。 */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (event.getEntity() instanceof Mob mob
                && shouldBlockTarget(mob, event.getNewAboutToBeSetTarget())) {
            event.setCanceled(true);
        }
    }

    /**
     * 清理玩家在战斗中切换为创造/旁观后的旧目标与旧复仇记录。
     * {@code setTarget(null)} 和 {@code setLastHurtByMob(null)} 不会被拦截。
     */
    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof Mob mob) || mob.level().isClientSide()) {
            return;
        }

        LivingEntity target = mob.getTarget();
        LivingEntity revengeTarget = mob.getLastHurtByMob();
        if (target == null && revengeTarget == null) {
            return;
        }
        if (!isWitherFactionMob(mob)) {
            return;
        }

        if (isIgnoredPlayer(target)) {
            mob.setTarget(null);
        }
        if (isIgnoredPlayer(revengeTarget)) {
            mob.setLastHurtByMob(null);
        }
    }
}
