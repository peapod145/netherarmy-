package cn.blockforge.generated.netherarmy;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 炼狱晶套单件。提示框分两段：
 * <ul>
 *   <li>单件能力：深红色（{@link ChatFormatting#DARK_RED}），每件三条，键为
 *       {@code item.netherarmy.nether_crystal_<件>.tooltip.ability.<n>}；</li>
 *   <li>套装效果：紫红色（{@link ChatFormatting#DARK_PURPLE}），四件都带同样的
 *       两/三/四件三行说明，实际生效由 {@link NetherCrystalSetBonusHandler} 结算。</li>
 * </ul>
 * 穿戴时的属性类能力（击退抗性、氧气加成、游泳速度、速度、跳跃）走属性组件，
 * 伤害减免、回血加成与 buff 时长缩放集中在 {@link NetherCrystalSetBonusHandler}。
 */
public final class NetherCrystalArmorItem extends ArmorItem {
    /** 四件共用的装备贴图（64×64 图集，布局与用户提供的 bbmodel UV 一致）。 */
    private static final ResourceLocation ARMOR_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/models/armor/nether_crystal_suits.png");

    private final String tooltipKeyPrefix;

    public NetherCrystalArmorItem(Holder<ArmorMaterial> material, Type type,
                                  String tooltipKeyPrefix, Properties properties) {
        super(material, type, properties);
        this.tooltipKeyPrefix = tooltipKeyPrefix;
    }

    /**
     * 掉落物免疫爆炸：{@code ItemEntity#hurt} 在真正扣血前先问 {@code ItemStack#canBeHurtBy}，
     * 这里把 {@code IS_EXPLOSION} 挡掉（与亡魂重盾 / 地煞战斧 / 炼狱晶锭同款写法）。
     * 火焰/岩浆免疫由注册处的 {@code fireResistant} 组件负责。
     */
    @Override
    public boolean canBeHurtBy(ItemStack stack, DamageSource source) {
        return !source.is(DamageTypeTags.IS_EXPLOSION) && super.canBeHurtBy(stack, source);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        // 单件能力：深红色三行。
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable(tooltipKeyPrefix + ".ability." + i)
                    .withStyle(ChatFormatting.DARK_RED));
        }
        // 套装效果：每件都完整列出 2/3/4 件三档，紫红色。
        tooltip.add(Component.translatable("item.netherarmy.nether_crystal_set.bonus.2")
                .withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("item.netherarmy.nether_crystal_set.bonus.3")
                .withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("item.netherarmy.nether_crystal_set.bonus.4")
                .withStyle(ChatFormatting.DARK_PURPLE));
    }

    @Override
    public ResourceLocation getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot,
                                            ArmorMaterial.Layer layer, boolean secondLayer) {
        // 四件的几何 UV 全部来自用户上传的 geo.bbmodel，共用同一张 64×64 图集，
        // 且只有一层（layer 列表长度 1），secondLayer 恒为 false。
        return ARMOR_TEXTURE;
    }
}
