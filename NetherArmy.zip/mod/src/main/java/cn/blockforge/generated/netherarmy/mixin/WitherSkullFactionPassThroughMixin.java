package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MesmerizerControl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.WitherSkull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 凋灵之首（黑色与蓝色）打中凋灵骷髅阵营时会直接<b>穿过去</b>，连"命中"这件事都不发生。
 *
 * <p>为什么必须混入而不能只靠事件：阵营门禁（{@link MesmerizerControl#canAttack}）挂在
 * {@code LivingIncomingDamageEvent} 上，它只能免掉<b>伤害</b>，弹头本身照样会在目标身上
 * 判定命中、爆炸并自毁——表现为"蓝头撞在同袍身上炸开、把同袍推开，却一格血不掉"。
 * 本模组自己制导的蓝头走 {@code WitherEnhancementHandler} 的自写扫描，那里已按阵营过滤；
 * 但黑色凋灵之首和未进入制导的弹头仍然走原版这条链：</p>
 *
 * <ol>
 * <li>{@code AbstractHurtingProjectile#tick} 每 tick 用
 * {@code ProjectileUtil#getHitResultOnMoveVector(this, this::canHitEntity)} 沿本 tick 位移
 * 扫实体与方块；</li>
 * <li>扫到实体即 {@code hitTargetOrDeflectSelf} → {@code Projectile#onHit} →
 * {@code WitherSkull#onHitEntity}（8 点直伤）→ {@code WitherSkull#onHit}（威力 1.0 的爆炸并
 * 自毁）。</li>
 * </ol>
 *
 * <p>因此拦截点选在 {@code canHitEntity}（1.21.1 里由 {@code AbstractHurtingProjectile}
 * 声明，内容就是 {@code super.canHitEntity()} 再补一条 {@code !entity.noPhysics}）：
 * HEAD 取消返回 {@code false}，候选实体在<b>索敌阶段</b>就被剔除，原版扫描会接着找同一条
 * 射线更远处的目标，弹头既不结算命中也不损失本 tick 位移——真正的"穿过"，同时也不会
 * 触发 {@code PROJECTILE_LAND} 游戏事件。</p>
 *
 * <p>作用域收得很窄：条件先判 {@code this instanceof WitherSkull}，凋灵火球、龙之吐息、
 * 烈焰火球等其余 {@code AbstractHurtingProjectile} 子类分毫不动。伤害侧另有兜底
 * （{@link MesmerizerControl#isWitherSkullDamage} 在阵营门禁处免掉凋灵之首的直伤与
 * 弹头爆炸溅射，例如弹头在阵营生物身后撞上方块起爆时），两条一起才构成"打不中、也伤不到"。</p>
 */
@Mixin(AbstractHurtingProjectile.class)
public abstract class WitherSkullFactionPassThroughMixin {

    @Inject(method = "canHitEntity", at = @At("HEAD"), cancellable = true)
    private void netherarmy$letFactionPassThrough(Entity candidate, CallbackInfoReturnable<Boolean> callback) {
        if (!(((Object) this) instanceof WitherSkull)) {
            return;
        }
        if (MesmerizerControl.isWitherSkeletonFaction(candidate)) {
            callback.setReturnValue(false);
        }
    }
}
