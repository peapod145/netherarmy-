package cn.blockforge.generated.netherarmy;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.AnimalArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** 无头骑士的骷髅马：使用小僵尸幼体的移速，增加自主近战攻击；被躯体骑乘时移动权由躯体指挥。 */
public class DullhanHorse extends SkeletonHorse implements Enemy {
    // 与小僵尸幼体一致：0.23 基础速度叠加 50% 幼体速度修正。
    private static final double BABY_ZOMBIE_SPEED = 0.345D;
    // 导航速度修正为 1.0，避免再次放大实体的实际移速。
    private static final double MOVE_SPEED = 1.0D;
    private static final double ATTACK_RANGE_SQR = 4.0D;
    // 两匹坐骑判定箱半径之和约 1.4 格，取略小的阈值避免持续抖动。
    private static final double SEPARATE_MIN_DISTANCE = 1.35D;
    // 每 tick 的分离冲量与水平速度上限；原版落地衰减只有 2%/tick，冲量会累积，
    // 所以取值必须小，靠“脱离重叠即停手”控制总位移。
    private static final double SEPARATE_PUSH = 0.022D;
    private static final double SEPARATE_MAX_SPEED = 0.25D;

    public DullhanHorse(EntityType<? extends SkeletonHorse> type, Level level) {
        super(type, level);
        // 继承 Animal 的原版马类经验奖励（1-3 点）。
        // 非自然生成路径（例如存档恢复）也保持与小僵尸幼体一致的速度。
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BABY_ZOMBIE_SPEED);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return SkeletonHorse.createAttributes()
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 35.0D);
    }

    @Override
    protected void randomizeAttributes(RandomSource random) {
        super.randomizeAttributes(random);
        // SkeletonHorse 会在生成时随机化速度；在其之后覆盖，确保每匹马都与小僵尸幼体同速。
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BABY_ZOMBIE_SPEED);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // 清掉骷髅马默认的惊慌、随机游荡和站立目标，避免它们在同优先级下
        // 抢占 MOVE flag，让马有目标时却不执行攻击移动。
        this.goalSelector.removeAllGoals(goal -> true);
        this.targetSelector.removeAllGoals(goal -> true);
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        // 主动索敌铁傀儡、猪灵与猪灵蛮兵；目标会经双向同步交给躯体，整个编组共同围攻。
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Piglin.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, PiglinBrute.class, true));
        this.goalSelector.addGoal(1, new HorseMeleeGoal(this));
        // 没有敌情时像普通怪物一样四处溜达；有目标时会被上方的近战目标顶替。
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.75D));
    }

    /** 无头骑士的马可以装备马鞍：原版骷髅马拒绝上鞍，这里改为只要求成年存活。 */
    @Override
    public boolean isSaddleable() {
        return this.isAlive() && !this.isBaby();
    }

    /** 开放 BODY 装备槽，允许马匹穿戴马铠（原版骷髅马在 Mob#canUseSlot 中被禁用）。 */
    @Override
    public boolean canUseSlot(EquipmentSlot slot) {
        return slot == EquipmentSlot.BODY || super.canUseSlot(slot);
    }

    /** 与原版马一致：仅接受骑乘系（EQUESTRIAN）动物铠甲，即铁/金/钻马铠。 */
    @Override
    public boolean isBodyArmorItem(ItemStack stack) {
        return stack.getItem() instanceof AnimalArmorItem armor
                && armor.getBodyType() == AnimalArmorItem.BodyType.EQUESTRIAN;
    }

    /**
     * 生成装备：必定携带马鞍，10% 概率携带金马铠。原版骷髅马从不走 populateDefaultEquipmentSlots
     * （该方法只在部分怪物种的 finalizeSpawn 里被调用），因此直接挂在
     * finalizeSpawn 上，并以 groupData==null 作为“新个体首次确定装备”的判据。
     * 马铠永不掉落；马鞍的 10% 掉率在 dropEquipment 中处理。
     */
    @Override
    public SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level,
                                        DifficultyInstance difficulty,
                                        net.minecraft.world.entity.MobSpawnType spawnType,
                                        SpawnGroupData groupData) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        if (groupData == null) {
            RandomSource random = level.getRandom();
            this.equipSaddle(new ItemStack(Items.SADDLE), null);
            if (random.nextFloat() < 0.10F) {
                this.setBodyArmorItem(new ItemStack(Items.GOLDEN_HORSE_ARMOR));
            }
        }
        this.setDropChance(EquipmentSlot.BODY, 0.0F);
        return result;
    }

    /**
     * 原版 AbstractHorse 会把鞍槽物品无条件掉落；先做 10% 概率判定，
     * 未中签时移除马鞍，再交给父类执行统一掉落。
     * 鞍与马铠的取舍拆成两个受保护钩子，供强袭骑士的马覆写
     * （必掉鞍、1% 掉炼狱晶锁链马铠）。
     */
    @Override
    protected void dropEquipment() {
        if (this.isAlive()) {
            return;
        }
        rollSaddleDrop();
        rollBodyArmorDrop();
        super.dropEquipment();
    }

    /** 马鞍 10% 掉率：未中签时先清槽，父类就看不到它。 */
    protected void rollSaddleDrop() {
        if (this.inventory != null && this.random.nextFloat() >= 0.10F) {
            this.inventory.setItem(INV_SLOT_SADDLE, ItemStack.EMPTY);
        }
    }

    /** 马铠钩子：1.21 马铠存放在 BODY 装备槽而非物品栏，原版掉落链路按掉率（已钉 0）跳过它，
     *  父类物品栏扫描也扫不到，因此默认不动作＝马铠永不掉落；强袭马覆写此钩子做 1% 手动掉出。 */
    protected void rollBodyArmorDrop() {
    }

    /** 未被骑乘时，玩家可手持马鞍直接右键装备（马铠走原版交互分支）。 */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!this.level().isClientSide() && !this.isVehicle() && this.isSaddleable()
                && !this.isSaddled() && !player.isSecondaryUseActive() && held.is(Items.SADDLE)) {
            this.equipSaddle(held.copyWithCount(1), null);
            held.consume(1, player);
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    /** 敌对坐骑在和平难度下应按敌对生物规则被清除。 */
    @Override
    protected boolean shouldDespawnInPeaceful() {
        return true;
    }

    /** 无头骑士的马不应因受击进入抬前蹄的站立动画。 */
    @Override
    protected boolean canPerformRearing() {
        return false;
    }

    @Override
    public void standIfPossible() {
        // 明确禁用 AbstractHorse 的受击起立逻辑。
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SKELETON_HORSE_AMBIENT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SKELETON_HORSE_DEATH;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SKELETON_HORSE_HURT;
    }

    @Override
    protected SoundEvent getSwimSound() {
        return SoundEvents.SKELETON_HORSE_SWIM;
    }

    /**
     * 原版 Mob#updateControlFlags 会因为“骑乘者是 Mob”而关闭坐骑的移动旗标，
     * 导致躯体骑乘时马的所有带 MOVE 旗标的目标被禁用。跳过这条规则，
     * 由下方 getMovementCommand 链路显式决定马何时移动。
     */
    @Override
    protected void updateControlFlags() {
        if (!(this.getControllingPassenger() instanceof Mob)) {
            super.updateControlFlags();
        }
    }

    /**
     * 移动指令来源：被无头骑士躯体骑乘时，躯体的目标就是指令（马只执行躯体意图）；
     * 玩家夺到控制权时交还原版操控逻辑；无骑乘者时退化为马自身的目标。
     */
    private LivingEntity getMovementCommand() {
        LivingEntity controller = this.getControllingPassenger();
        if (controller instanceof Player) {
            return null;
        }
        if (controller instanceof DullhanBody body && body.isAlive()) {
            return body.getTarget();
        }
        return this.getTarget();
    }

    /** 驱向指令目标；进入攻击距离后停止推进，便于马上躯体与马头同时近战命中。 */
    private void driveToward(LivingEntity command) {
        if (this.distanceToSqr(command) > ATTACK_RANGE_SQR) {
            this.getNavigation().moveTo(command, MOVE_SPEED);
        } else {
            this.getNavigation().stop();
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        // 移动指令入口：骑乘期间优先执行躯体指令；指令为空时不再强制停步，
        // 交给上方的游荡目标，让无头骑士像普通怪物一样四处移动。
        LivingEntity command = this.getMovementCommand();
        if (command != null && command.isAlive()) {
            this.driveToward(command);
        }
        this.separateFromStackedMounts();
    }

    /**
     * 修复多匹无头骑士召唤在同一格互不碰撞的问题：原版 Entity#push 会跳过
     * 任何“正载着乘客”的实体（isVehicle 判定），而坐骑马永远驮着躯体，
     * 完全重叠时（dx=dz=0）连推开方向都算不出来。这里绕开原版推挤，
     * 直接对相邻的其它无头骑士坐骑施加水平分离冲量。
     */
    private void separateFromStackedMounts() {
        if (this.isPassenger() || !this.isAlive()) {
            return;
        }
        double pushX = 0.0D;
        double pushZ = 0.0D;
        for (DullhanHorse other : this.level().getEntitiesOfClass(DullhanHorse.class,
                this.getBoundingBox().inflate(0.9D, 0.4D, 0.9D))) {
            if (other == this || !other.isAlive() || other.isPassenger()) {
                continue;
            }
            double dx = this.getX() - other.getX();
            double dz = this.getZ() - other.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist >= SEPARATE_MIN_DISTANCE) {
                continue;
            }
            double dirX;
            double dirZ;
            if (dist < 1.0E-4D) {
                // 完全重叠：按两匹马 UUID 的对称散列取一个确定轴向，
                // 比较 UUID 决定正负号，保证同一对马各自朝相反方向被推开。
                long key = this.getUUID().getMostSignificantBits()
                        + other.getUUID().getMostSignificantBits()
                        + this.getUUID().getLeastSignificantBits()
                        + other.getUUID().getLeastSignificantBits();
                double angle = (double) Math.floorMod(key, 3600L) / 3600.0D * Math.PI * 2.0D;
                dirX = Math.cos(angle);
                dirZ = Math.sin(angle);
                if (this.getUUID().compareTo(other.getUUID()) > 0) {
                    dirX = -dirX;
                    dirZ = -dirZ;
                }
            } else {
                dirX = dx / dist;
                dirZ = dz / dist;
            }
            pushX += dirX;
            pushZ += dirZ;
        }
        if (pushX == 0.0D && pushZ == 0.0D) {
            return;
        }
        double length = Math.sqrt(pushX * pushX + pushZ * pushZ);
        Vec3 velocity = this.getDeltaMovement()
                .add(pushX / length * SEPARATE_PUSH, 0.0D, pushZ / length * SEPARATE_PUSH);
        double horizontal = velocity.horizontalDistance();
        if (horizontal > SEPARATE_MAX_SPEED) {
            double scale = SEPARATE_MAX_SPEED / horizontal;
            velocity = new Vec3(velocity.x * scale, velocity.y, velocity.z * scale);
        }
        this.setDeltaMovement(velocity);
        this.hasImpulse = true;
    }

    private static final class HorseMeleeGoal extends Goal {
        private final DullhanHorse horse;
        private int attackCooldown;

        private HorseMeleeGoal(DullhanHorse horse) {
            this.horse = horse;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            // 骑乘期间近战目标同样以躯体指令为准。
            LivingEntity target = horse.getMovementCommand();
            return target != null && target.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            this.attackCooldown = 0;
        }

        @Override
        public void stop() {
            horse.getNavigation().stop();
            horse.setDeltaMovement(Vec3.ZERO);
        }

        @Override
        public void tick() {
            LivingEntity target = horse.getMovementCommand();
            if (target == null || !target.isAlive()) {
                return;
            }
            horse.getLookControl().setLookAt(target, 30.0F, 30.0F);
            // 移动统一走带攻击距离门控的推进，避免目标贴脸时导航持续推挤。
            horse.driveToward(target);
            if (this.attackCooldown > 0) {
                this.attackCooldown--;
            }
            if (horse.distanceToSqr(target) <= ATTACK_RANGE_SQR && this.attackCooldown == 0) {
                horse.swing(InteractionHand.MAIN_HAND);
                horse.doHurtTarget(target);
                this.attackCooldown = 20;
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            DullhanBody.synchronizeTargets(this);
            for (Entity passenger : this.getPassengers()) {
                if (passenger instanceof DullhanBody body) {
                    DullhanBody.setGroupId(this, DullhanBody.ensureGroupId(body));
                    if (this.getTarget() != null) {
                        body.setTarget(this.getTarget());
                    } else if (body.getTarget() != null) {
                        this.setTarget(body.getTarget());
                    }
                }
            }
        }
    }

    /** 拦截对创造/旁观玩家的仇恨：受击反击与编组同步都不能锁定他们。 */
    @Override
    public void setTarget(LivingEntity target) {
        if (DullhanBody.isIgnoredTarget(target)) {
            return;
        }
        super.setTarget(target);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100), this);
        }
        return hurt;
    }
}
