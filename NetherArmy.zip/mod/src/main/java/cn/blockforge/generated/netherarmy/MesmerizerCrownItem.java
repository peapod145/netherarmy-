package cn.blockforge.generated.netherarmy;

import net.minecraft.core.Holder;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** 反逆者王冠：提供头部护甲，并保护穿戴者免受反逆者的精神控制。 */
public final class MesmerizerCrownItem extends ArmorItem {
    public MesmerizerCrownItem(Holder<ArmorMaterial> material, Properties properties) {
        super(material, Type.HELMET, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                net.minecraft.world.item.TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.netherarmy.mesmerizer_crown.tooltip.mind_control_immunity")
                .withStyle(ChatFormatting.DARK_PURPLE));
    }

    @Override
    public ResourceLocation getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot,
                                             ArmorMaterial.Layer layer, boolean secondLayer) {
        // Java 装备模型的 UV 来自 mesmerizer_crown.bbmodel，使用与模型配套的 64x64 贴图。
        return ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                "textures/models/entity/mesmerizer_crown.png");
    }
}
