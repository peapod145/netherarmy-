package cn.blockforge.generated.netherarmy.mixin;

import cn.blockforge.generated.netherarmy.MesmerizerControl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 凋灵骷髅阵营生物射出的投掷物碰到友军时直接<b>穿过去</b>，不结算命中、不被盾牌弹开。
 *
 * <p>需求与 {@link cn.blockforge.generated.netherarmy.MesmerizerOrb 反逆者光球}同款：
 * 光球是靠覆写 {@code canHitEntity} 对自家人返回 false 来穿透的，这里把这套口径搬到
 * "发射者是阵营生物"的投掷物上——箭、弩箭、三叉戟、凋灵之首、雪球、药水等全部走
 * {@link Projectile} 这一条命中扫描链。</p>
 *
 * <h3>为什么拦 {@code canHitEntity}</h3>
 * <p>投掷物的实体命中扫描统一经由 {@code ProjectileUtil.getEntityHitResult} /
 * {@code getHitResultOnMoveVector}，谓词就是 {@code this::canHitEntity}。所有子类的
 * 覆写最终都回到 {@link Projectile#canHitEntity}：普通投掷物直接继承；
 * {@code AbstractArrow#canHitEntity} 用 {@code invokespecial} 调回父类实现再叠穿透等级；
 * {@code AbstractHurtingProjectile#canHitEntity} 同样调回父类再叠 {@code !noPhysics}。</p>
 *
 * <p>在父类 HEAD 处取消返回 {@code false}，候选友军在<b>索敌阶段</b>就被剔除，于是：</p>
 * <ul>
 * <li>投掷物既不结算伤害，也不因命中而消失，本 tick 的位移一点不损失——真正的穿透；</li>
 * <li>不会走到 {@code hitTargetOrDeflectSelf}，也就不会触发盾牌格挡、{@code PROJECTILE_LAND}
 * 游戏事件与 {@code ProjectileImpactEvent}——半血原版凋灵的"弹开非凋灵抛射物"正是在该事件里
 * 改写速度，剔除命中后那条路径自然不再对同袍生效；</li>
 * <li>阵营判定是逐 tick 连续的，飞行途中友军走进弹道也不会被误伤。</li>
 * </ul>
 *
 * <h3>谁是友军</h3>
 * <p>复用阵营门禁 {@link MesmerizerControl#canAttack(LivingEntity, LivingEntity)} 的结论：
 * 该口径本就是"军团成员能不能伤害对方"的唯一权威答案，把同阵营、被反逆者心控的实体、
 * 反逆侧器械以及各类特殊豁免一次性覆盖，不让这里出现第二份敌我名单。只有发射者确属
 * 凋灵骷髅阵营时才介入，玩家与其他生物射出的投掷物分毫不动。</p>
 *
 * <p>与 {@link WitherSkullFactionPassThroughMixin} 分工互补：那边按"命中目标是不是阵营"
 * 过滤，管的是敌方（含玩家）射来的凋灵之首；这边按"发射者是不是阵营"过滤，管的是军团
 * 自己射出去的所有投掷物不误伤同袍。两条并存，不会互相抵消。</p>
 */
@Mixin(Projectile.class)
public abstract class WitherFactionProjectilePassThroughMixin {

    @Inject(method = "canHitEntity", at = @At("HEAD"), cancellable = true)
    private void netherarmy$letFactionProjectilePassThrough(Entity candidate,
                                                             CallbackInfoReturnable<Boolean> callback) {
        Entity owner = ((Projectile) (Object) this).getOwner();
        if (!(owner instanceof LivingEntity livingOwner)
                || !MesmerizerControl.isWitherSkeletonFaction(livingOwner)
                || !(candidate instanceof LivingEntity livingTarget)) {
            return;
        }
        if (!MesmerizerControl.canAttack(livingOwner, livingTarget)) {
            callback.setReturnValue(false);
        }
    }
}
